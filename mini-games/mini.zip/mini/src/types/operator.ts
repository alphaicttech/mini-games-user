// /var/www/typesafe/alpha-mini/src/types/operator.ts
export type Operator = {
    id: number;
    name: string;
    portalName: string;
    baseUrl: string;
    secret: string;
};

export type OperatorSession = {
    sessionId: string;          // from operator ActivateSession
    userName: string;
    clientExternalKey: string;
    currencyCode: string;
};

// What we store for our provider-side session (SID)
export type ProviderSession = {
    sid: string;                // our opaque session id (UUID)
    mode: "real" | "demo";
    operatorId?: number;        // undefined for demo
    portalName: string;
    userName: string;
    clientExternalKey: string;
    currency: string;           // "FUN" in demo
    sessionId?: string;         // operator session ID (for real mode)
    game: { category: string; name: string; lang?: string; returnUrl?: string; stopUrl?: string };
};

export type OperatorCtx = {
    baseUrl: string;
    secret: string;
    session?: OperatorSession;  // filled after ActivateSession
};
