// /var/www/typesafe/alpha-mini/src/server.ts
import { app } from "./app";
import { env } from "./config/env";

import http from "http";
import { Server } from "socket.io"
import { mountAviator } from "./modules/ws/aviator";
import cron from "node-cron";
import { RTP } from "./config/env";
import { runRtpCheckpoint } from "./jobs/rtp.checkpoint";
import { runMidnightCloseOpen } from "./jobs/rtp.midnight-close";
import { rtpRouter } from "./modules/rtp/routes";



const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } }); // path to the server

app.use("/rtp", rtpRouter);

// Jobs
cron.schedule(RTP.CHECKPOINT_CRON, runRtpCheckpoint, { timezone: RTP.TIMEZONE });
cron.schedule(RTP.MIDNIGHT_CRON, runMidnightCloseOpen, { timezone: RTP.TIMEZONE });


mountAviator(io); // <— start multiplayer engine + WS namespace

server.listen(env.PORT, () => {
    console.log(`mini-games aggregator listening on :${env.PORT}`);
});

// import { app } from "./app";
// import { env } from "./config/env";

// app.listen(env.PORT, () => {
//     console.log(`mini-games aggregator listening on :${env.PORT}`);
// });
