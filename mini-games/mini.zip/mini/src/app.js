"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
// /var/www/typesafe/alpha-mini/src/app.ts
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const router_1 = __importDefault(require("./modules/router"));
const async_handler_1 = require("./middleware/async-handler");
const app = (0, express_1.default)();
exports.app = app;
app.use((0, cors_1.default)({ origin: "*" }));
app.use(express_1.default.json());
app.use("/v1", router_1.default);
// health
app.get("/health", (_req, res) => res.json({ ok: true }));
// 404 + error handlers (MUST be after routes)
app.use(async_handler_1.notFoundHandler);
app.use(async_handler_1.errorHandler);
// curl -X POST "https://admin.alphatech.et/4000/v1/sessions/activate" \
//   -H "Content-Type: application/json" \
//   -d '{"token":"DEMO","portal_name":"demo","game_category":"Crash","game_name":"JetX","lang":"en"}'
