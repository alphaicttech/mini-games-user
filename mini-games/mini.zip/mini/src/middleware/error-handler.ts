// /var/www/typesafe/alpha-mini/src/middleware/error-handler.ts
import type { Request, Response, NextFunction } from "express";
import { AppError } from "../errors";

export function notFoundHandler(_req: Request, res: Response) {
    res.status(404).json({ ok: false, code: "NOT_FOUND", message: "Route not found" });
}

export function errorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
    const isProd = process.env.NODE_ENV === "production";
    if (err instanceof AppError) {
        return res.status(err.status).json({
            ok: false,
            code: err.code,
            message: err.message,
            details: err.details,
            request_id: (req as any).id
        });
    }
    // Unexpected error
    console.error("Unhandled error:", err);
    return res.status(500).json({
        ok: false,
        code: "INTERNAL_ERROR",
        message: isProd ? "Internal server error" : (err?.message || "Unknown error"),
        request_id: (req as any).id
    });
}
