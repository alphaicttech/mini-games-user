"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateBody = exports.validateQuery = void 0;
const errors_1 = require("../errors");
const validateQuery = (schema) => (req, _res, next) => {
    const r = schema.safeParse(req.query);
    if (!r.success)
        return next(new errors_1.AppError({ code: "VALIDATION_ERROR", message: "Invalid query", status: 422, details: r.error.flatten() }));
    Object.assign(req.query, r.data);
    next();
};
exports.validateQuery = validateQuery;
const validateBody = (schema) => (req, _res, next) => {
    const r = schema.safeParse(req.body);
    if (!r.success)
        return next(new errors_1.AppError({ code: "VALIDATION_ERROR", message: "Invalid body", status: 422, details: r.error.flatten() }));
    req.body = r.data;
    next();
};
exports.validateBody = validateBody;
