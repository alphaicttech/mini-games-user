// /var/www/typesafe/alpha-mini/src/middleware/async-handler.ts
import type { Request, Response, NextFunction, RequestHandler } from "express";
export const asyncHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<any>): RequestHandler =>
    (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

import { AppError } from "../errors";

export function notFoundHandler(_req: Request, res: Response) {
    res.status(404).json({ ok: false, code: "NOT_FOUND", message: "Route not found" });
}

export function errorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
    const prod = process.env.NODE_ENV === "production";
    if (err instanceof AppError) {
        return res.status(err.status).json({
            ok: false, code: err.code, message: err.message, details: err.details
        });
    }
    console.error("Unhandled error:", err);
    res.status(500).json({
        ok: false, code: "INTERNAL_ERROR",
        message: prod ? "Internal server error" : (err?.message || "Unknown error")
    });
}
