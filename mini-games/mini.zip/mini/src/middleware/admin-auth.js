"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deriveUserScopes = deriveUserScopes;
exports.adminAuth = adminAuth;
exports.requireScope = requireScope;
const crypto_1 = __importDefault(require("crypto"));
const drizzle_1 = require("../config/drizzle");
const redis_1 = require("../config/redis");
const admin_1 = require("../db/admin");
const drizzle_orm_1 = require("drizzle-orm");
function deriveUserScopes(role) {
    if (!role)
        return [];
    // align with your RBAC conventions
    switch (role) {
        case "SUPER_ADMIN":
            return ["*"];
        case "OPS":
            return ["games:read", "games:write", "rtp:read", "cash:read", "token:read", "token:write"];
        case "RISK":
            return ["rtp:read", "rtp:adjust"];
        default:
            return ["read"];
    }
}
/**
 * Accepts either:
 *  - X-Admin-Sid: <sid>  (user session in Redis)
 *  - X-Admin-Token: <raw token>  (API token)
 * Always responds with JSON on failure.
 */
function adminAuth(req, res, next) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        try {
            const sid = req.get("x-admin-sid") || undefined;
            const rawToken = req.get("x-admin-token") || undefined;
            if (sid) {
                // signed in admin (user)
                const key = `admin:sess:${sid}`;
                const session = yield redis_1.redis.getJSON(key);
                if (!session) {
                    return res
                        .status(401)
                        .json({ ok: false, code: "UNAUTHORIZED", message: "INVALID_OR_EXPIRED_SESSION" });
                }
                if (!session.userId || !session.username || !session.role) {
                    return res.status(401).json({ ok: false, code: "UNAUTHORIZED", message: "SESSION_CORRUPT" });
                }
                req.admin = {
                    kind: "user",
                    userId: session.userId,
                    username: session.username,
                    role: session.role,
                    scopes: (_a = session.scopes) !== null && _a !== void 0 ? _a : deriveUserScopes(session.role),
                    sid,
                };
                return next();
            }
            if (rawToken) {
                // token-based principal
                const tokenHash = crypto_1.default.createHash("sha256").digest("hex"); // don't hash undefined
                const row = yield drizzle_1.db.query.adminTokens.findFirst({ where: (0, drizzle_orm_1.eq)(admin_1.adminTokens.tokenHash, tokenHash) });
                if (!row || !row.isActive) {
                    return res.status(401).json({ ok: false, code: "UNAUTHORIZED", message: "INVALID_TOKEN" });
                }
                if (row.expiresAt && new Date(row.expiresAt) < new Date()) {
                    return res.status(401).json({ ok: false, code: "TOKEN_EXPIRED" });
                }
                req.admin = {
                    kind: "token",
                    tokenId: row.id,
                    label: row.label,
                    scopes: ((_b = row.scopes) !== null && _b !== void 0 ? _b : []),
                };
                return next();
            }
            return res
                .status(401)
                .json({ ok: false, code: "UNAUTHORIZED", message: "Missing X-Admin-Sid or X-Admin-Token" });
        }
        catch (err) {
            console.error("adminAuth error:", err);
            return res.status(500).json({
                ok: false,
                code: "INTERNAL_ERROR",
                message: (err === null || err === void 0 ? void 0 : err.message) || "Internal server error",
            });
        }
    });
}
/** Simple scope guard to wrap protected routes */
function requireScope(scope) {
    return (req, res, next) => {
        var _a, _b, _c;
        const p = req.admin;
        if (!p)
            return res.status(401).json({ ok: false, code: "UNAUTHORIZED" });
        const granted = (p.kind === "user" && (((_a = p.scopes) === null || _a === void 0 ? void 0 : _a.includes("*")) || ((_b = p.scopes) === null || _b === void 0 ? void 0 : _b.includes(scope)))) ||
            (p.kind === "token" && ((_c = p.scopes) === null || _c === void 0 ? void 0 : _c.includes(scope)));
        if (!granted) {
            return res.status(403).json({ ok: false, code: "FORBIDDEN", message: "Insufficient scope" });
        }
        next();
    };
}
