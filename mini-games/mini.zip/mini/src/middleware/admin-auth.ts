// // /var/www/typesafe/alpha-mini/src/middleware/admin-auth.ts
// import type { NextFunction, Request, Response } from "express";
import { z } from "zod";
import crypto from "crypto";
import { db } from "../config/drizzle";
import { redis } from "../config/redis";
import { adminTokens, adminUsers } from "../db/admin";
import { eq } from "drizzle-orm";

// export type AdminPrincipal =
//     | { kind: "user"; userId: number; username: string; role: string; scopes: string[] }
//     | { kind: "token"; tokenId: number; label: string; scopes: string[]; operatorId?: number };

// declare global {
//     // augments Express.Request to carry admin principal + sid
//     namespace Express {
//         interface Request {
//             admin?: AdminPrincipal;
//             adminSid?: string;
//         }
//     }
// }

// /** Map roles to scopes for user sessions */
// function roleToScopes(role: string): string[] {
//     if (role === "SUPER_ADMIN") return ["*"];
//     if (role === "OPS") return ["games:read", "games:write", "rtp:read", "cash:read"];
//     if (role === "RISK") return ["rtp:read", "rtp:adjust"];
//     return ["read"];
// }

// /**
//  * adminAuth middleware:
//  *  - Accepts either X-Admin-Sid (user session in Redis) OR X-Admin-Token (API token)
//  *  - Returns 401/403 JSON on failure (never throws raw TypeError)
//  *  - Attaches `req.admin` and `req.adminSid` for downstream handlers
//  */
// export async function adminAuth(req: Request, res: Response, next: NextFunction) {
//     try {
//         // Express lowercases headers, but req.get handles case-insensitivity
//         const sid = req.get("x-admin-sid") || undefined;
//         const token = req.get("x-admin-token") || undefined;

//         // 1) Try user session (sid)
//         if (sid) {
//             const key = `admin:sess:${sid}`;
//             const session = await redis.getJSON<any>(key);
//             if (!session) {
//                 return res
//                     .status(401)
//                     .json({ ok: false, code: "UNAUTHORIZED", message: "INVALID_OR_EXPIRED_SESSION" });
//             }
//             // sanity check: username/role present
//             if (!session.userId || !session.username || !session.role) {
//                 return res
//                     .status(401)
//                     .json({ ok: false, code: "UNAUTHORIZED", message: "SESSION_CORRUPT" });
//             }
//             req.admin = {
//                 kind: "user",
//                 userId: session.userId,
//                 username: session.username,
//                 role: session.role,
//                 scopes: session.scopes ?? roleToScopes(session.role),
//             };
//             req.adminSid = sid;
//             return next();
//         }

//         // 2) Try API token
//         if (token) {
//             const hash = crypto.createHash("sha256").update(token).digest("hex");
//             const row = await db.query.adminTokens.findFirst({
//                 where: eq(adminTokens.tokenHash, hash),
//             });
//             if (!row || !row.isActive) {
//                 return res
//                     .status(401)
//                     .json({ ok: false, code: "UNAUTHORIZED", message: "INVALID_TOKEN" });
//             }
//             if (row.expiresAt && new Date(row.expiresAt) < new Date()) {
//                 return res
//                     .status(401)
//                     .json({ ok: false, code: "TOKEN_EXPIRED", message: "Token expired" });
//             }
//             req.admin = {
//                 kind: "token",
//                 tokenId: row.id,
//                 label: row.label,
//                 scopes: (row.scopes ?? []) as string[],
//                 operatorId: row.operatorId ?? undefined,
//             };
//             return next();
//         }

//         // Neither sid nor token provided
//         return res
//             .status(401)
//             .json({ ok: false, code: "UNAUTHORIZED", message: "Missing X-Admin-Sid or X-Admin-Token" });

//     } catch (err: any) {
//         // Convert any unexpected error to a JSON 500 response
//         console.error("adminAuth error:", err);
//         return res.status(500).json({
//             ok: false,
//             code: "INTERNAL_ERROR",
//             message: err?.message || "Internal server error",
//         });
//     }
// }

// /** Simple scope guard */
// export function requireScope(scope: string) {
//     return (req: Request, res: Response, next: NextFunction) => {
//         const p = req.admin;
//         if (!p) return res.status(401).json({ ok: false, code: "UNAUTHORIZED" });

//         const granted =
//             (p.kind === "user" && (p.role === "SUPER_ADMIN" || p.scopes?.includes("*") || p.scopes?.includes(scope))) ||
//             (p.kind === "token" && p.scopes?.includes(scope));

//         if (!granted) {
//             return res.status(403).json({ ok: false, code: "FORBIDDEN", message: "Insufficient scope" });
//         }
//         next();
//     };
// }

// src/middleware/admin-auth.ts
import type { NextFunction, Request, Response } from "express";
// import { z } from "daisyui"; // or 'zod' if you prefer; just be consistent
// import crypto from "crypto";
// import { db } from "../../config/redis";      // adjust to your project structure
// import { adminTokens } from "../../db/admin"; // adjust import to your actual table file    
//import { eq } from "drizzle-orm";

export type AdminPrincipal =
    | { kind: "user"; userId: number; username: string; role: string; scopes: string[]; sid: string }
    | { kind: "token"; tokenId: number; label: string; scopes: string[] };

declare global {
    namespace Express {
        interface Request {
            admin?: AdminPrincipal;
        }
    }
}

export function deriveUserScopes(role: string): string[] {
    if (!role) return [];
    // align with your RBAC conventions
    switch (role) {
        case "SUPER_ADMIN":
            return ["*"];
        case "OPS":
            return ["games:read", "games:write", "rtp:read", "cash:read", "token:read", "token:write"];
        case "RISK":
            return ["rtp:read", "rtp:adjust"];
        default:
            return ["read"];
    }
}

/**
 * Accepts either:
 *  - X-Admin-Sid: <sid>  (user session in Redis)
 *  - X-Admin-Token: <raw token>  (API token)
 * Always responds with JSON on failure.
 */
export async function adminAuth(req: Request, res: Response, next: NextFunction) {
    try {
        const sid = req.get("x-admin-sid") || undefined;
        const rawToken = req.get("x-admin-token") || undefined;

        if (sid) {
            // signed in admin (user)
            const key = `admin:sess:${sid}`;
            const session = await redis.getJSON<any>(key);
            if (!session) {
                return res
                    .status(401)
                    .json({ ok: false, code: "UNAUTHORIZED", message: "INVALID_OR_EXPIRED_SESSION" });
            }
            if (!session.userId || !session.username || !session.role) {
                return res.status(401).json({ ok: false, code: "UNAUTHORIZED", message: "SESSION_CORRUPT" });
            }
            req.admin = {
                kind: "user",
                userId: session.userId,
                username: session.username,
                role: session.role,
                scopes: session.scopes ?? deriveUserScopes(session.role),
                sid,
            };
            return next();
        }

        if (rawToken) {
            // token-based principal
            const tokenHash = crypto.createHash("sha256").digest("hex"); // don't hash undefined
            const row = await db.query.adminTokens.findFirst({ where: eq(adminTokens.tokenHash, tokenHash) });
            if (!row || !row.isActive) {
                return res.status(401).json({ ok: false, code: "UNAUTHORIZED", message: "INVALID_TOKEN" });
            }
            if (row.expiresAt && new Date(row.expiresAt) < new Date()) {
                return res.status(401).json({ ok: false, code: "TOKEN_EXPIRED" });
            }
            req.admin = {
                kind: "token",
                tokenId: row.id,
                label: row.label,
                scopes: (row.scopes ?? []) as string[],
            };
            return next();
        }

        return res
            .status(401)
            .json({ ok: false, code: "UNAUTHORIZED", message: "Missing X-Admin-Sid or X-Admin-Token" });

    } catch (err: any) {
        console.error("adminAuth error:", err);
        return res.status(500).json({
            ok: false,
            code: "INTERNAL_ERROR",
            message: err?.message || "Internal server error",
        });
    }
}

/** Simple scope guard to wrap protected routes */
export function requireScope(scope: string) {
    return (req: Request, res: Response, next: NextFunction) => {
        const p = req.admin;
        if (!p) return res.status(401).json({ ok: false, code: "UNAUTHORIZED" });

        const granted =
            (p.kind === "user" && (p.scopes?.includes("*") || p.scopes?.includes(scope))) ||
            (p.kind === "token" && p.scopes?.includes(scope));

        if (!granted) {
            return res.status(403).json({ ok: false, code: "FORBIDDEN", message: "Insufficient scope" });
        }
        next();
    };
}
