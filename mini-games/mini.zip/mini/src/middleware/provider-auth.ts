// /var/www/typesafe/alpha-mini/src/middleware/provider-auth.ts
import type { Request, Response, NextFunction } from "express";
import { loadProviderSession } from "../modules/session/service";
import { AppError } from "../errors";

export async function providerAuth(req: Request, _res: Response, next: NextFunction) {
    // Until JWT (GAT) is wired, accept X-Provider-Sid
    const sid = req.header("X-Provider-Sid") || "";
    if (!sid) return next(AppError.unauthorized("Missing X-Provider-Sid"));

    const sess = await loadProviderSession(sid);
    if (!sess) return next(AppError.unauthorized("Invalid or expired session"));

    (req as any).providerSession = sess;
    next();
}
