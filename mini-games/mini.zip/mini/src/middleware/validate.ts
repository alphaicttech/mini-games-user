// /var/www/typesafe/alpha-mini/src/middleware/validate.ts
import type { Request, Response, NextFunction } from "express";
import { ZodSchema } from "zod";
import { AppError } from "../errors";

export const validateQuery = (schema: ZodSchema<any>) => (req: Request, _res: Response, next: NextFunction) => {
    const r = schema.safeParse(req.query);
    if (!r.success) return next(new AppError({ code: "VALIDATION_ERROR", message: "Invalid query", status: 422, details: r.error.flatten() }));
    Object.assign(req.query, r.data);
    next();
};

export const validateBody = (schema: ZodSchema<any>) => (req: Request, _res: Response, next: NextFunction) => {
    const r = schema.safeParse(req.body);
    if (!r.success) return next(new AppError({ code: "VALIDATION_ERROR", message: "Invalid body", status: 422, details: r.error.flatten() }));
    req.body = r.data;
    next();
};
