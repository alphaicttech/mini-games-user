"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.providerAuth = providerAuth;
const service_1 = require("../modules/session/service");
const errors_1 = require("../errors");
function providerAuth(req, _res, next) {
    return __awaiter(this, void 0, void 0, function* () {
        // Until JWT (GAT) is wired, accept X-Provider-Sid
        const sid = req.header("X-Provider-Sid") || "";
        if (!sid)
            return next(errors_1.AppError.unauthorized("Missing X-Provider-Sid"));
        const sess = yield (0, service_1.loadProviderSession)(sid);
        if (!sess)
            return next(errors_1.AppError.unauthorized("Invalid or expired session"));
        req.providerSession = sess;
        next();
    });
}
