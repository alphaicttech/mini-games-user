"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.asyncHandler = void 0;
exports.notFoundHandler = notFoundHandler;
exports.errorHandler = errorHandler;
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
exports.asyncHandler = asyncHandler;
const errors_1 = require("../errors");
function notFoundHandler(_req, res) {
    res.status(404).json({ ok: false, code: "NOT_FOUND", message: "Route not found" });
}
function errorHandler(err, req, res, _next) {
    const prod = process.env.NODE_ENV === "production";
    if (err instanceof errors_1.AppError) {
        return res.status(err.status).json({
            ok: false, code: err.code, message: err.message, details: err.details
        });
    }
    console.error("Unhandled error:", err);
    res.status(500).json({
        ok: false, code: "INTERNAL_ERROR",
        message: prod ? "Internal server error" : ((err === null || err === void 0 ? void 0 : err.message) || "Unknown error")
    });
}
