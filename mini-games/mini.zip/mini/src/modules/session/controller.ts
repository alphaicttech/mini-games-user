// /var/www/typesafe/alpha-mini/src/modules/session/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../middleware/async-handler";
import { validateBody } from "../../middleware/validate";
import { findOperatorByPortalName } from "../../stores/operator";
import { activateSession, getBalance } from "../../operator/client";
import { AppError } from "../../errors";
import { v4 as uuid } from "uuid";
import { saveProviderSession } from "./service";
import { redis } from "../../config/redis";
import { opGetBalance } from "./balance";

const B = z.object({
    token: z.string().min(1),
    portal_name: z.string().min(1),
    game_category: z.string().min(1),
    game_name: z.string().min(1),
    lang: z.string().optional(),
    return_url: z.string().url().optional(),
    stop_url: z.string().url().optional(),
});

export const activateValidate = validateBody(B);

export const activate = asyncHandler(async (req: Request, res: Response) => {
    const { token, portal_name, game_category, game_name, lang, return_url, stop_url } = req.body as z.infer<typeof B>;

    const sid = uuid();
    const isDemo = token === "DEMO" || portal_name === "demo";

    let user_name: string, client_external_key: string, currency: string, balance = 0;

    if (isDemo) {
        user_name = `demo_${sid.slice(0, 6)}`;
        client_external_key = `demo_${sid.slice(6, 12)}`;
        currency = "FUN";
        balance = Number(process.env.DEMO_START_BALANCE ?? 1000);
        await saveProviderSession({
            sid, mode: "demo", portalName: "demo",
            userName: user_name, clientExternalKey: client_external_key, currency,
            game: { category: game_category, name: game_name, lang, returnUrl: return_url, stopUrl: stop_url },
        });
    } else {
        const operator = await findOperatorByPortalName(portal_name); // throws NOT_FOUND if missing
        const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret };


        let opSession: any;
        try {
            opSession = await activateSession(opCtx, token);
            const bal = await getBalance(opCtx);
            user_name = opSession.userName;
            client_external_key = opSession.clientExternalKey;
            currency = opSession.currencyCode;
            balance = bal.amount;
        } catch (e: any) {
            // Normalize upstream failure to a clean AppError
            throw new AppError({ code: "ACTIVATE_FAILED", message: e.message || "Activation failed", status: 502 });
        }

        await saveProviderSession({
            sid, mode: "real", operatorId: operator.id, portalName: operator.portalName,
            userName: user_name, clientExternalKey: client_external_key, currency,
            sessionId: opSession.sessionId,
            game: { category: game_category, name: game_name, lang, returnUrl: return_url, stopUrl: stop_url }
        });
    }

    res.json({
        ok: true,
        mode: isDemo ? "demo" : "real",
        sid,
        user: { user_name, client_external_key },
        currency,
        balance,
        limits: { min_bet: 0.1, max_bet: 100 },
        expires_in: 900
    });
});

export const balance = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../types/operator").ProviderSession;
    const { amount, currency, mode } = await opGetBalance(sess);
    res.json({ ok: true, mode, sid: sess.sid, user: { user_name: sess.userName, client_external_key: sess.clientExternalKey }, currency, balance: amount });
});


export const verify = asyncHandler(async (req, res) => {
    const sess = (req as any).providerSession as import("../../types/operator").ProviderSession;

    const { amount, currency, mode } = await opGetBalance(sess);

    res.json({
        ok: true,
        mode,
        sid: sess.sid,
        user: { user_name: sess.userName, client_external_key: sess.clientExternalKey },
        currency,
        balance: amount,
        game: sess.game,
    });
});