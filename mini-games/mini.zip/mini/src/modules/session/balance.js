"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.opGetBalance = opGetBalance;
const redis_1 = require("../../config/redis");
const operator_1 = require("../../stores/operator"); // or "../../stores/operator"
const client_1 = require("../../operator/client");
const errors_1 = require("../../errors");
/**
 * Unified balance getter for demo + real.
 * - Demo: reads (or initializes) demo balance from Redis.
 * - Real: calls operator GetBalance using stored operator session.
 */
function opGetBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        if (sess.mode === "demo") {
            const key = `demo:bal:${sess.sid}`;
            let raw = yield redis_1.redis.get(key);
            if (raw == null) {
                const start = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
                yield redis_1.redis.set(key, String(start), 2 * 60 * 60);
                raw = String(start);
            }
            return { amount: Number(raw), currency: sess.currency, mode: "demo" };
        }
        // ----- real mode -----
        const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
        // Support either naming you used earlier (opSessionId vs sessionId)
        const operatorSessionId = (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId;
        if (!operatorSessionId)
            throw errors_1.AppError.internal("Missing operator session id");
        // Adjust shape to match your operator client (id vs sessionId)
        const opCtx = {
            baseUrl: operator.baseUrl,
            secret: operator.secret,
            session: {
                id: operatorSessionId, // if your client expects sessionId, rename this key
                userName: sess.userName,
                clientExternalKey: sess.clientExternalKey,
            },
        };
        const bal = yield (0, client_1.getBalance)(opCtx); // -> { amount, currencyCode }
        return { amount: bal.amount, currency: (_c = bal.currencyCode) !== null && _c !== void 0 ? _c : sess.currency, mode: "real" };
    });
}
