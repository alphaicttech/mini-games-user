"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verify = exports.balance = exports.activate = exports.activateValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../middleware/async-handler");
const validate_1 = require("../../middleware/validate");
const operator_1 = require("../../stores/operator");
const client_1 = require("../../operator/client");
const errors_1 = require("../../errors");
const uuid_1 = require("uuid");
const service_1 = require("./service");
const balance_1 = require("./balance");
const B = zod_1.z.object({
    token: zod_1.z.string().min(1),
    portal_name: zod_1.z.string().min(1),
    game_category: zod_1.z.string().min(1),
    game_name: zod_1.z.string().min(1),
    lang: zod_1.z.string().optional(),
    return_url: zod_1.z.string().url().optional(),
    stop_url: zod_1.z.string().url().optional(),
});
exports.activateValidate = (0, validate_1.validateBody)(B);
exports.activate = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const { token, portal_name, game_category, game_name, lang, return_url, stop_url } = req.body;
    const sid = (0, uuid_1.v4)();
    const isDemo = token === "DEMO" || portal_name === "demo";
    let user_name, client_external_key, currency, balance = 0;
    if (isDemo) {
        user_name = `demo_${sid.slice(0, 6)}`;
        client_external_key = `demo_${sid.slice(6, 12)}`;
        currency = "FUN";
        balance = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield (0, service_1.saveProviderSession)({
            sid, mode: "demo", portalName: "demo",
            userName: user_name, clientExternalKey: client_external_key, currency,
            game: { category: game_category, name: game_name, lang, returnUrl: return_url, stopUrl: stop_url },
        });
    }
    else {
        const operator = yield (0, operator_1.findOperatorByPortalName)(portal_name); // throws NOT_FOUND if missing
        const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret };
        let opSession;
        try {
            opSession = yield (0, client_1.activateSession)(opCtx, token);
            const bal = yield (0, client_1.getBalance)(opCtx);
            user_name = opSession.userName;
            client_external_key = opSession.clientExternalKey;
            currency = opSession.currencyCode;
            balance = bal.amount;
        }
        catch (e) {
            // Normalize upstream failure to a clean AppError
            throw new errors_1.AppError({ code: "ACTIVATE_FAILED", message: e.message || "Activation failed", status: 502 });
        }
        yield (0, service_1.saveProviderSession)({
            sid, mode: "real", operatorId: operator.id, portalName: operator.portalName,
            userName: user_name, clientExternalKey: client_external_key, currency,
            sessionId: opSession.sessionId,
            game: { category: game_category, name: game_name, lang, returnUrl: return_url, stopUrl: stop_url }
        });
    }
    res.json({
        ok: true,
        mode: isDemo ? "demo" : "real",
        sid,
        user: { user_name, client_external_key },
        currency,
        balance,
        limits: { min_bet: 0.1, max_bet: 100 },
        expires_in: 900
    });
}));
exports.balance = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { amount, currency, mode } = yield (0, balance_1.opGetBalance)(sess);
    res.json({ ok: true, mode, sid: sess.sid, user: { user_name: sess.userName, client_external_key: sess.clientExternalKey }, currency, balance: amount });
}));
exports.verify = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { amount, currency, mode } = yield (0, balance_1.opGetBalance)(sess);
    res.json({
        ok: true,
        mode,
        sid: sess.sid,
        user: { user_name: sess.userName, client_external_key: sess.clientExternalKey },
        currency,
        balance: amount,
        game: sess.game,
    });
}));
