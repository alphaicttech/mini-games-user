"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveProviderSession = saveProviderSession;
exports.loadProviderSession = loadProviderSession;
// /var/www/typesafe/alpha-mini/src/modules/session/service.ts
const redis_1 = require("../../config/redis");
function saveProviderSession(s_1) {
    return __awaiter(this, arguments, void 0, function* (s, ttlSeconds = 2 * 60 * 60) {
        //await redis.setSession(s.sid, s, ttlSeconds);
        yield redis_1.redis.setJSON(`session:${s.sid}`, s, ttlSeconds);
        return s.sid;
    });
}
function loadProviderSession(sid) {
    return __awaiter(this, void 0, void 0, function* () {
        //return await redis.getSession(sid);
        return yield redis_1.redis.getJSON(`session:${sid}`);
    });
}
