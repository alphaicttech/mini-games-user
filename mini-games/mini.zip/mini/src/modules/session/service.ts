// /var/www/typesafe/alpha-mini/src/modules/session/service.ts
import { redis } from "../../config/redis";
import { ProviderSession } from "../../types/operator";

export async function saveProviderSession(s: ProviderSession, ttlSeconds = 2 * 60 * 60) {
    //await redis.setSession(s.sid, s, ttlSeconds);
    await redis.setJSON(`session:${s.sid}`, s, ttlSeconds);
    return s.sid;
}

export async function loadProviderSession(sid: string): Promise<ProviderSession | null> {
    //return await redis.getSession(sid);
    return await redis.getJSON(`session:${sid}`);
}
