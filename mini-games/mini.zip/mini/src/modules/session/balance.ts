// /var/www/typesafe/alpha-mini/src/modules/session/balance.ts
import { ProviderSession } from "../../types/operator";
import { redis } from "../../config/redis";
import { findOperatorByPortalName } from "../../stores/operator"; // or "../../stores/operator"
import { getBalance as operatorGetBalance } from "../../operator/client";
import { AppError } from "../../errors";

export type BalanceResult = {
    amount: number;
    currency: string;
    mode: "demo" | "real";
};

/**
 * Unified balance getter for demo + real.
 * - Demo: reads (or initializes) demo balance from Redis.
 * - Real: calls operator GetBalance using stored operator session.
 */
export async function opGetBalance(sess: ProviderSession): Promise<BalanceResult> {
    if (sess.mode === "demo") {
        const key = `demo:bal:${sess.sid}`;
        let raw = await redis.get(key);
        if (raw == null) {
            const start = Number(process.env.DEMO_START_BALANCE ?? 1000);
            await redis.set(key, String(start), 2 * 60 * 60);
            raw = String(start);
        }
        return { amount: Number(raw), currency: sess.currency, mode: "demo" };
    }

    // ----- real mode -----
    const operator = await findOperatorByPortalName(sess.portalName);

    // Support either naming you used earlier (opSessionId vs sessionId)
    const operatorSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
    if (!operatorSessionId) throw AppError.internal("Missing operator session id");

    // Adjust shape to match your operator client (id vs sessionId)
    const opCtx: any = {
        baseUrl: operator.baseUrl,
        secret: operator.secret,
        session: {
            id: operatorSessionId,               // if your client expects sessionId, rename this key
            userName: sess.userName,
            clientExternalKey: sess.clientExternalKey,
        },
    };

    const bal = await operatorGetBalance(opCtx); // -> { amount, currencyCode }
    return { amount: bal.amount, currency: bal.currencyCode ?? sess.currency, mode: "real" };
}
