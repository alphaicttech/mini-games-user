"use strict";
// /var/www/typesafe/alpha-mini/src/modules/router.ts
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller_1 = require("./launcher/controller");
const session = __importStar(require("./session/controller"));
const coin = __importStar(require("./games/coin-toss/controller"));
const provider_auth_1 = require("../middleware/provider-auth");
const mines = __importStar(require("./games/mines/controller"));
const chicken = __importStar(require("./games/chicken-road/controller"));
const slot = __importStar(require("./games/777-slot/controller"));
const roulette = __importStar(require("./games/spin/controller"));
const balloon = __importStar(require("./games/balloons/controller"));
const avia = __importStar(require("./games/avia-masters/controller"));
const plinko = __importStar(require("./games/plinko/controller"));
const penality = __importStar(require("./games/penality/controller"));
const keno = __importStar(require("./games/keno/controller"));
const baccarat = __importStar(require("./games/baccarat/controller"));
const blackjack = __importStar(require("./games/blackjack/controller"));
const dragontiger = __importStar(require("./games/dragontiger/controller"));
const casinowar = __importStar(require("./games/casinowar/controller"));
const reddog = __importStar(require("./games/reddog/controller"));
const rouletteMini = __importStar(require("./games/roulette_mini/controller"));
const bingo = __importStar(require("./games/bingo/controller"));
const greyhound = __importStar(require("./games/grayhound/controller"));
const admin = __importStar(require("./admin/controller"));
const router = express_1.default.Router();
// launcher (for testing)
router.get(["/GameLauncher/Loader.aspx", "/GameLauncher/Loader", "/launcher"], controller_1.launcherValidate, controller_1.launcher);
// session
router.post("/sessions/activate", session.activateValidate, session.activate);
// get balance
router.get("/sessions/verify", provider_auth_1.providerAuth, session.verify);
// get demo balance
router.get("/sessions/balance", provider_auth_1.providerAuth, session.balance);
// 1. coin toss
router.post("/games/coin/bet", provider_auth_1.providerAuth, coin.betValidate, coin.bet);
// 2. mines
router.post("/games/mines/start", provider_auth_1.providerAuth, mines.startValidate, mines.start);
router.post("/games/mines/reveal", provider_auth_1.providerAuth, mines.revealValidate, mines.reveal);
router.post("/games/mines/cashout", provider_auth_1.providerAuth, mines.cashoutValidate, mines.cashout);
// 3. chicken road
router.post("/games/chicken/start", provider_auth_1.providerAuth, chicken.startValidate, chicken.start);
router.post("/games/chicken/step", provider_auth_1.providerAuth, chicken.stepValidate, chicken.step);
router.post("/games/chicken/cashout", provider_auth_1.providerAuth, chicken.cashoutValidate, chicken.cashout);
router.get("/games/chicken/odds", provider_auth_1.providerAuth, chicken.chickenOddsValidate, chicken.chickenOdds);
// 4. slot
router.post("/games/slot777/spin", provider_auth_1.providerAuth, slot.spinValidate, slot.spin);
// 5. avia masters
router.post("/games/avia/spin", provider_auth_1.providerAuth, avia.spinValidate, avia.spin);
// 6. balloons
router.post("/games/balloon/start", provider_auth_1.providerAuth, balloon.startValidate, balloon.start);
router.post("/games/balloon/inflate", provider_auth_1.providerAuth, balloon.inflateValidate, balloon.inflate);
router.post("/games/balloon/cashout", provider_auth_1.providerAuth, balloon.cashoutValidate, balloon.cashout);
// 7. roulette
router.post("/games/roulette/spin", provider_auth_1.providerAuth, roulette.spinValidate, roulette.spin);
// 8. keno
router.post("/games/keno/draw", provider_auth_1.providerAuth, keno.drawValidate, keno.draw);
// 9. plinko
router.post("/games/plinko/drop", provider_auth_1.providerAuth, plinko.dropValidate, plinko.drop);
router.get("/games/plinko/odds", plinko.odds);
// 10. penalty ladder
router.post("/games/penalty-ladder/start", provider_auth_1.providerAuth, penality.startValidate, penality.startSeries);
router.post("/games/penalty-ladder/kick", provider_auth_1.providerAuth, penality.kickValidate, penality.kick);
router.post("/games/penalty-ladder/cashout", provider_auth_1.providerAuth, penality.cashoutValidate, penality.cashout);
router.get("/games/penalty-ladder/status", provider_auth_1.providerAuth, penality.statusValidate, penality.status);
// 11. baccarat
router.post("/games/baccarat/deal", provider_auth_1.providerAuth, baccarat.dealValidate, baccarat.deal);
// 12. blackjack
router.post("/games/blackjack/start", provider_auth_1.providerAuth, blackjack.startValidate, blackjack.startRound);
router.post("/games/blackjack/hit", provider_auth_1.providerAuth, blackjack.hitValidate, blackjack.hit);
router.post("/games/blackjack/stand", provider_auth_1.providerAuth, blackjack.standValidate, blackjack.stand);
router.post("/games/blackjack/double", provider_auth_1.providerAuth, blackjack.doubleValidate, blackjack.doubleDown);
router.post("/games/blackjack/split", provider_auth_1.providerAuth, blackjack.splitValidate, blackjack.splitHand);
router.post("/games/blackjack/finish", provider_auth_1.providerAuth, blackjack.finishValidate, blackjack.finishRound);
router.get("/games/blackjack/status", provider_auth_1.providerAuth, blackjack.statusValidate, blackjack.statusRound);
router.post("/games/blackjack/insurance", provider_auth_1.providerAuth, blackjack.insuranceValidate, blackjack.insuranceAction);
router.post("/games/blackjack/surrender", provider_auth_1.providerAuth, blackjack.surrenderValidate, blackjack.surrenderAction);
// 13. dragontiger
router.post("/games/dragontiger/deal", provider_auth_1.providerAuth, dragontiger.dealValidate, dragontiger.deal);
// 14. casinowar
router.post("/games/casinowar/deal", provider_auth_1.providerAuth, casinowar.dealValidate, casinowar.deal);
router.post("/games/casinowar/choice", provider_auth_1.providerAuth, casinowar.choiceValidate, casinowar.choice);
router.get("/games/casinowar/status", provider_auth_1.providerAuth, casinowar.statusValidate, casinowar.status);
// 15. reddog
router.post("/games/reddog/deal", provider_auth_1.providerAuth, reddog.dealValidate, reddog.deal);
router.post("/games/reddog/raise", provider_auth_1.providerAuth, reddog.raiseValidate, reddog.raiseAction);
router.get("/games/reddog/status", provider_auth_1.providerAuth, reddog.statusValidate, reddog.status);
// 16. roulette mini    
router.post("/games/roulette-mini/spin", provider_auth_1.providerAuth, rouletteMini.spinValidate, rouletteMini.spin);
// 17. greyhound
router.post("/games/greyhound/race/new", provider_auth_1.providerAuth, greyhound.newRaceValidate, greyhound.newRace);
router.post("/games/greyhound/regenerate", provider_auth_1.providerAuth, greyhound.regenValidate, greyhound.regenerate);
router.post("/games/greyhound/bets/place", provider_auth_1.providerAuth, greyhound.placeValidate, greyhound.placeBets);
router.post("/games/greyhound/race/start", provider_auth_1.providerAuth, greyhound.startValidate, greyhound.startRace);
router.post("/games/greyhound/race/settle", provider_auth_1.providerAuth, greyhound.settleValidate, greyhound.settleRace);
router.post("/games/greyhound/race/stream/:result_id", provider_auth_1.providerAuth, greyhound.streamValidate, greyhound.streamResultVideo);
router.get("/games/greyhound/race/status", provider_auth_1.providerAuth, greyhound.statusValidate, greyhound.raceStatus);
// 18. bingo
// router.post("/games/bingo/card/new", providerAuth, bingo.newCardValidate, bingo.newCard);
// router.post("/games/bingo/card/regenerate", providerAuth, bingo.regenCardValidate, bingo.regenCard);
// router.post("/games/bingo/bets/place", providerAuth, bingo.placeValidate, bingo.placeBets);
// router.post("/games/bingo/draw", providerAuth, bingo.drawValidate, bingo.draw);
// router.get("/games/bingo/status", providerAuth, bingo.statusValidate, bingo.status);
// // router.ts
// router.post("/games/bingo/batch/place", providerAuth, bingo.placeBatchValidate, bingo.placeBetsBatch);
// router.post("/games/bingo/batch/draw", providerAuth, bingo.drawBatchValidate, bingo.drawBatch);
// single-card flow
router.post("/games/bingo/card/new", provider_auth_1.providerAuth, bingo.newCardValidate, bingo.newCard);
router.post("/games/bingo/card/regenerate", provider_auth_1.providerAuth, bingo.regenCardValidate, bingo.regenCard);
router.post("/games/bingo/bets/place", provider_auth_1.providerAuth, bingo.placeValidate, bingo.placeBets);
router.post("/games/bingo/draw", provider_auth_1.providerAuth, bingo.drawValidate, bingo.draw);
router.get("/games/bingo/status", provider_auth_1.providerAuth, bingo.statusValidate, bingo.status);
// batch flow (up to 4 cards with one shared result)
router.post("/games/bingo/batch/place", provider_auth_1.providerAuth, bingo.placeBatchValidate, bingo.placeBetsBatch);
router.post("/games/bingo/batch/draw", provider_auth_1.providerAuth, bingo.drawBatchValidate, bingo.drawBatch);
router.use("/admin", admin.adminRouter);
// app.post("/v1/games/greyhound/race/new",        providerAuth, newRaceValidate,  newRace);
// app.post("/v1/games/greyhound/race/regenerate", providerAuth, regenValidate,    regenerate);
// app.post("/v1/games/greyhound/bets/place",      providerAuth, placeValidate,    placeBets);
// app.post("/v1/games/greyhound/race/start",      providerAuth, startValidate,    startRace);
// app.post("/v1/games/greyhound/race/settle",     providerAuth, settleValidate,   settleRace);
// app.get ("/v1/games/greyhound/race/status",     providerAuth, statusValidate,   raceStatus);
// // NEW: public-ish stream endpoint (you can keep providerAuth if you want)
// app.get ("/v1/games/greyhound/race/stream/:result_id", streamValidate, streamResultVideo);
exports.default = router;
