import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP accounting (no clamping) ====
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { redis as redisClient } from "../../../config/redis";

/** ============== Config & types ============== */
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "reddog";

type Cfg = {
    decks: number;
    ace_high: boolean;
    min_stake: number;
    max_stake: number;
};

type Card = { r: number; s: number }; // rank 0..12 (A..K), suit 0..3
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];

type RoundState = {
    round_id: string;
    sid: string;
    portalName?: string;
    currency: string;

    server_seed: string;
    server_seed_hash: string;
    client_seed: string;

    cfg: Cfg;
    shoe: Card[];
    shoe_idx: number;

    stake: number;            // original stake
    extra_stake: number;      // added on raise (0 or stake)
    first: Card;              // first up-card
    second: Card;             // second up-card
    low: Card;                // min(first, second) by rank order
    high: Card;               // max(first, second)
    spread: number;           // ranks between low & high (0 = consecutive/pair)
    status: "AUTO" | "PENDING" | "SETTLED"; // PENDING → waiting for /raise
    third?: Card;
    result?: { kind: "WIN" | "LOSE" | "PUSH" | "PAIR_TRIPLE"; return_multiplier: number; payout: number };
    settled: boolean;

    txn_placebet: string;
    txn_raise?: string;
    created_at: number;

    // RTP (REAL mode only)
    mode: "real" | "demo";
    rtpDayKey?: string;
    rtpEntered?: number; // total stake entered (base + raise)
};

/** ============== RNG & shoe helpers (provably fair) ============== */
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (server: string, client: string, i: number, tag: string) =>
    u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;

function buildShoe(decks: number): Card[] {
    const one: Card[] = [];
    for (let s = 0; s < 4; s++) for (let r = 0; r < 13; r++) one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => ({ ...c })));
}
function shuffle(arr: Card[], server: string, client: string) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k]; a[k] = a[j]; a[j] = t;
    }
    return a;
}
const fmt = (c: Card) => ({ rank: RANKS[c.r], suit: SUITS[c.s] });

function rankVal(r: number, ace_high: boolean) {
    // Red Dog uses A high in casinos (toggleable)
    if (ace_high) return r === 0 ? 14 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
    return r === 0 ? 1 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
}

/** ============== Redis helpers ============== */
const rKey = (sid: string, id: string) => `reddog:round:${sid}:${id}`;
async function saveRound(r: RoundState) { await redis.set(rKey(r.sid, r.round_id), JSON.stringify(r), 24 * 60 * 60); }
async function loadRound(sid: string, id: string) { const v = await redis.get(rKey(sid, id)); return v ? JSON.parse(v) as RoundState : null; }
async function withLock<T>(sid: string, id: string, fn: () => Promise<T>) {

    const lk = `reddog:lock:${sid}:${id}`;
//     const ok = await redis.acquireLock(lockKey, 3);
// if (!ok) throw AppError.conflict("ROUND_BUSY");
// try {
//   // critical section
// } finally {
//   await redis.releaseLock(lockKey);
// }
    const ok = await redis.acquireLock(lk, 3);
    if (!ok) throw AppError.conflict("Round is busy, retry");
    try { return await fn(); } finally { await redis.releaseLock(lk); }

    
}
// Idempotency (mode-scoped)
function idemKey(mode: "real" | "demo", sid: string, action: string, key: string) { return `idem:${mode}:reddog:${action}:${sid}:${key}`; }
async function getIdem(mode: "real" | "demo", sid: string, action: string, key?: string) { if (!key) return null; const v = await redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) : null; }
async function setIdem(mode: "real" | "demo", sid: string, action: string, key: string, payload: any) { await redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); }

/** ============== Demo wallet ============== */
async function getDemoBalance(sess: ProviderSession) {
    const k = `demo:bal:${sess.sid}`; const v = await redis.get(k);
    if (v) return Number(v); const base = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(k, String(base), 2 * 60 * 60); return base;
}
async function setDemoBalance(sess: ProviderSession, amount: number) { await redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60); }

/** ============== Payout table (stake-INCLUDED returns) ==============
 * Spread = ranks strictly between low & high:
 *  - 1 → profit 5:1  => return 6.0x
 *  - 2 → profit 4:1  => return 5.0x
 *  - 3 → profit 2:1  => return 3.0x
 *  - 4+ → profit 1:1 => return 2.0x
 * Consecutive (spread = 0) → PUSH (1.0x).
 * Pair: draw third; if third same rank → "PAIR_TRIPLE" pays 11:1 profit (12.0x return), else PUSH.
 */
function winReturnForSpread(spread: number): number {
    if (spread <= 0) return 1.0;  // push (consecutive)
    if (spread === 1) return 6.0;
    if (spread === 2) return 5.0;
    if (spread === 3) return 3.0;
    return 2.0; // 4+
}

/** ============== Public services ============== */
export async function dealSvc(
    sess: ProviderSession,
    input: { stake: number; client_seed?: string; cfg: Partial<Cfg> },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "deal", idem); if (hit) return hit; }

    const stake = Number(input.stake);
    const cfg: Cfg = {
        decks: input.cfg?.decks ?? 6,
        ace_high: input.cfg?.ace_high ?? true,
        min_stake: input.cfg?.min_stake ?? 0.1,
        max_stake: input.cfg?.max_stake ?? 10000,
    };
    if (!(stake > 0)) throw AppError.badRequest("Invalid stake");
    if (stake < cfg.min_stake) throw AppError.badRequest(`Min stake is ${cfg.min_stake}`);
    if (stake > cfg.max_stake) throw AppError.badRequest(`Max stake is ${cfg.max_stake}`);

    const client_seed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";
    const server_seed = crypto.randomBytes(32).toString("hex");
    const server_seed_hash = sha256(server_seed);

    const shoe = shuffle(buildShoe(cfg.decks), server_seed, client_seed);
    let idx = 0; const draw = () => shoe[idx++];

    const first = draw();
    const second = draw();

    // Order by rank
    const v1 = rankVal(first.r, cfg.ace_high), v2 = rankVal(second.r, cfg.ace_high);
    const low = v1 <= v2 ? first : second;
    const high = v1 <= v2 ? second : first;
    const spread = Math.max(0, Math.abs(v1 - v2) - 1);

    // Debit base stake
    const txnId = randomUUID();
    if (mode === "demo") {
        const bal = await getDemoBalance(sess); if (bal < stake) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - stake).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: txnId, TransactionType: "PlaceBet", Amount: stake, CurrencyCode: sess.currency,
            TransactionInfo: { Source: "RedDog", GameName: "RedDog", RoundId: txnId, GameNumber: Date.now().toString(), ServerSeedHash: server_seed_hash, ClientSeed: client_seed, Config: cfg }
        });
    }

    const round: RoundState = {
        round_id: randomUUID(),
        sid: sess.sid,
        portalName: sess.portalName,
        currency: sess.currency,
        server_seed, server_seed_hash, client_seed,
        cfg, shoe, shoe_idx: idx,
        stake, extra_stake: 0,
        first, second, low, high, spread,
        status: "PENDING",
        settled: false,
        txn_placebet: txnId,
        created_at: Date.now(),
        mode,
        rtpDayKey: undefined,
        rtpEntered: 0
    };

    // RTP enter base stake (REAL)
    if (mode === "real") {
        const yymmdd = toYYMMDD();
        round.rtpDayKey = rk.day(GAME_CODE, yymmdd);
        await redisClient.hsetnx(round.rtpDayKey, "rtp_target", 0.90);
        await redisClient.spEnter(round.rtpDayKey, stake);
        round.rtpEntered = (round.rtpEntered ?? 0) + stake;
    }

    // Immediate outcomes: pair (draw third) or consecutive (spread=0)
    if (v1 === v2) {
        const third = shoe[round.shoe_idx++]; round.third = third;
        const vt = rankVal(third.r, cfg.ace_high);
        if (vt === v1) {
            const ret = 12.0; const payout = +(stake * ret).toFixed(2);
            round.result = { kind: "PAIR_TRIPLE", return_multiplier: ret, payout };
        } else {
            const ret = 1.0; const payout = +(stake * ret).toFixed(2);
            round.result = { kind: "PUSH", return_multiplier: ret, payout };
        }
        round.status = "SETTLED"; round.settled = true;
    } else if (spread === 0) {
        const ret = 1.0, payout = +(stake * ret).toFixed(2);
        round.result = { kind: "PUSH", return_multiplier: ret, payout };
        round.status = "SETTLED"; round.settled = true;
    }

    await saveRound(round);

    // If settled immediately → settle RTP and credit now
    let payload: any = statusPayload(round);
    if (round.settled) {
        payload = await creditAndFinalize(round, sess); // will spSettle (REAL) and credit
    }

    if (idem) await setIdem(mode, sess.sid, "deal", idem, payload);
    return payload;
}

export async function raiseSvc(
    sess: ProviderSession,
    input: { round_id: string; raise: boolean },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "raise", idem); if (hit) return hit; }

    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id);
        if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        if (r.settled) return statusPayload(r);
        if (r.status !== "PENDING") throw AppError.badRequest("NO_DECISION_REQUIRED");

        // Optional raise → debit extra stake & RTP enter
        if (input.raise) {
            if (mode === "demo") {
                const bal = await getDemoBalance(sess); if (bal < r.stake) throw AppError.badRequest("Insufficient FUN balance for raise");
                await setDemoBalance(sess, +(bal - r.stake).toFixed(2));
            } else {
                const operator = await findByPortalName(sess.portalName);
                const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                const txn = `${r.server_seed_hash}-RAISE`;
                await deposit(opCtx, {
                    TransactionId: txn, TransactionType: "PlaceBet", Amount: r.stake, CurrencyCode: r.currency,
                    TransactionInfo: { Source: "RedDog", GameName: "RedDog", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:raise` }
                });
                r.txn_raise = txn;

                // RTP enter extra stake
                if (r.rtpDayKey) { await redisClient.spEnter(r.rtpDayKey, r.stake); r.rtpEntered = (r.rtpEntered ?? 0) + r.stake; }
            }
            r.extra_stake = r.stake;
        }

        // Draw third and resolve
        const third = r.shoe[r.shoe_idx++]; r.third = third;
        const vLow = rankVal(r.low.r, r.cfg.ace_high);
        const vHigh = rankVal(r.high.r, r.cfg.ace_high);
        const vT = rankVal(third.r, r.cfg.ace_high);

        let kind: "WIN" | "LOSE" | "PUSH";
        if (vT > vLow && vT < vHigh) kind = "WIN";
        else if (vT === vLow || vT === vHigh) kind = "PUSH";
        else kind = "LOSE";

        const totalStake = r.stake + r.extra_stake;
        let ret = 0.0;
        if (kind === "WIN") ret = winReturnForSpread(r.spread);
        else if (kind === "PUSH") ret = 1.0;
        else ret = 0.0;

        const payout = +(totalStake * ret).toFixed(2);
        r.result = { kind, return_multiplier: ret, payout };
        r.status = "SETTLED"; r.settled = true;

        await saveRound(r);
        const resp = await creditAndFinalize(r, sess); // will spSettle (REAL) and credit
        if (idem) await setIdem(mode, sess.sid, "raise", idem, resp);
        return resp;
    });
}

export async function statusSvc(sess: ProviderSession, input: { round_id: string }) {
    const r = await loadRound(sess.sid, input.round_id);
    if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
    return statusPayload(r);
}

/** ============== credit, RTP settle & payload ============== */
async function creditAndFinalize(r: RoundState, sess: ProviderSession) {
    const payoutTotal = r.result?.payout ?? 0;

    // RTP: settle everything entered for this round (REAL mode)
    if (r.mode === "real" && r.rtpDayKey && (r.rtpEntered ?? 0) > 0) {
        await redisClient.spSettle(r.rtpDayKey, r.rtpEntered!, payoutTotal);
        r.rtpEntered = 0; // consumed
    }

    // Credit winners / pushes
    if (sess.mode === "demo") {
        const bal = await getDemoBalance(sess);
        await setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
    } else if (payoutTotal > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: `${r.server_seed_hash}-W`, TransactionType: "WinAmount", Amount: payoutTotal, CurrencyCode: r.currency,
            TransactionInfo: {
                Source: "RedDog", GameName: "RedDog", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}`,
                ServerSeed: r.server_seed, ServerSeedHash: r.server_seed_hash, ClientSeed: r.client_seed,
                FirstTwo: { first: fmt(r.first), second: fmt(r.second), low: fmt(r.low), high: fmt(r.high), spread: r.spread },
                Third: r.third ? fmt(r.third) : null,
                Result: r.result
            }
        });
    }

    return statusPayload(r);
}

function statusPayload(r: RoundState) {
    return {
        game: "RedDog",
        mode: r.mode,
        round_id: r.round_id,
        currency: r.currency,
        settled: r.settled,
        config: r.cfg,
        stake: r.stake,
        extra_stake: r.extra_stake,
        first_two: { first: fmt(r.first), second: fmt(r.second), low: fmt(r.low), high: fmt(r.high), spread: r.spread },
        third: r.third ? fmt(r.third) : null,
        decision: { needed: (!r.settled && r.status === "PENDING"), can_raise: (!r.settled && r.status === "PENDING"), total_stake_if_raise: r.stake + r.stake },
        result: r.result ?? null,
        fairness: {
            server_seed_hash: r.server_seed_hash,
            server_seed: r.settled ? r.server_seed : undefined,
            client_seed: r.client_seed,
            method: "Fisher–Yates shoe via HMAC-SHA256(server_seed, `${client_seed}:i:shoe`); Red Dog spread payout table"
        }
    };
}
