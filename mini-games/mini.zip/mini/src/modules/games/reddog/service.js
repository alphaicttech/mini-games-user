"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dealSvc = dealSvc;
exports.raiseSvc = raiseSvc;
exports.statusSvc = statusSvc;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP accounting (no clamping) ====
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const redis_2 = require("../../../config/redis");
/** ============== Config & types ============== */
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "reddog";
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];
/** ============== RNG & shoe helpers (provably fair) ============== */
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, i, tag) => u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;
function buildShoe(decks) {
    const one = [];
    for (let s = 0; s < 4; s++)
        for (let r = 0; r < 13; r++)
            one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => (Object.assign({}, c))));
}
function shuffle(arr, server, client) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k];
        a[k] = a[j];
        a[j] = t;
    }
    return a;
}
const fmt = (c) => ({ rank: RANKS[c.r], suit: SUITS[c.s] });
function rankVal(r, ace_high) {
    // Red Dog uses A high in casinos (toggleable)
    if (ace_high)
        return r === 0 ? 14 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
    return r === 0 ? 1 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
}
/** ============== Redis helpers ============== */
const rKey = (sid, id) => `reddog:round:${sid}:${id}`;
function saveRound(r) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(rKey(r.sid, r.round_id), JSON.stringify(r), 24 * 60 * 60); });
}
function loadRound(sid, id) {
    return __awaiter(this, void 0, void 0, function* () { const v = yield redis_1.redis.get(rKey(sid, id)); return v ? JSON.parse(v) : null; });
}
function withLock(sid, id, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const lk = `reddog:lock:${sid}:${id}`;
        //     const ok = await redis.acquireLock(lockKey, 3);
        // if (!ok) throw AppError.conflict("ROUND_BUSY");
        // try {
        //   // critical section
        // } finally {
        //   await redis.releaseLock(lockKey);
        // }
        const ok = yield redis_1.redis.acquireLock(lk, 3);
        if (!ok)
            throw errors_1.AppError.conflict("Round is busy, retry");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.redis.releaseLock(lk);
        }
    });
}
// Idempotency (mode-scoped)
function idemKey(mode, sid, action, key) { return `idem:${mode}:reddog:${action}:${sid}:${key}`; }
function getIdem(mode, sid, action, key) {
    return __awaiter(this, void 0, void 0, function* () { if (!key)
        return null; const v = yield redis_1.redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) : null; });
}
function setIdem(mode, sid, action, key, payload) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); });
}
/** ============== Demo wallet ============== */
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const k = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(k);
        if (v)
            return Number(v);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(k, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60); });
}
/** ============== Payout table (stake-INCLUDED returns) ==============
 * Spread = ranks strictly between low & high:
 *  - 1 → profit 5:1  => return 6.0x
 *  - 2 → profit 4:1  => return 5.0x
 *  - 3 → profit 2:1  => return 3.0x
 *  - 4+ → profit 1:1 => return 2.0x
 * Consecutive (spread = 0) → PUSH (1.0x).
 * Pair: draw third; if third same rank → "PAIR_TRIPLE" pays 11:1 profit (12.0x return), else PUSH.
 */
function winReturnForSpread(spread) {
    if (spread <= 0)
        return 1.0; // push (consecutive)
    if (spread === 1)
        return 6.0;
    if (spread === 2)
        return 5.0;
    if (spread === 3)
        return 3.0;
    return 2.0; // 4+
}
/** ============== Public services ============== */
function dealSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "deal", idem);
            if (hit)
                return hit;
        }
        const stake = Number(input.stake);
        const cfg = {
            decks: (_b = (_a = input.cfg) === null || _a === void 0 ? void 0 : _a.decks) !== null && _b !== void 0 ? _b : 6,
            ace_high: (_d = (_c = input.cfg) === null || _c === void 0 ? void 0 : _c.ace_high) !== null && _d !== void 0 ? _d : true,
            min_stake: (_f = (_e = input.cfg) === null || _e === void 0 ? void 0 : _e.min_stake) !== null && _f !== void 0 ? _f : 0.1,
            max_stake: (_h = (_g = input.cfg) === null || _g === void 0 ? void 0 : _g.max_stake) !== null && _h !== void 0 ? _h : 10000,
        };
        if (!(stake > 0))
            throw errors_1.AppError.badRequest("Invalid stake");
        if (stake < cfg.min_stake)
            throw errors_1.AppError.badRequest(`Min stake is ${cfg.min_stake}`);
        if (stake > cfg.max_stake)
            throw errors_1.AppError.badRequest(`Max stake is ${cfg.max_stake}`);
        const client_seed = (_l = (_k = (_j = input.client_seed) !== null && _j !== void 0 ? _j : sess.clientExternalKey) !== null && _k !== void 0 ? _k : sess.userName) !== null && _l !== void 0 ? _l : "client";
        const server_seed = crypto_1.default.randomBytes(32).toString("hex");
        const server_seed_hash = sha256(server_seed);
        const shoe = shuffle(buildShoe(cfg.decks), server_seed, client_seed);
        let idx = 0;
        const draw = () => shoe[idx++];
        const first = draw();
        const second = draw();
        // Order by rank
        const v1 = rankVal(first.r, cfg.ace_high), v2 = rankVal(second.r, cfg.ace_high);
        const low = v1 <= v2 ? first : second;
        const high = v1 <= v2 ? second : first;
        const spread = Math.max(0, Math.abs(v1 - v2) - 1);
        // Debit base stake
        const txnId = (0, crypto_1.randomUUID)();
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < stake)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - stake).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_m = sess.opSessionId) !== null && _m !== void 0 ? _m : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId, TransactionType: "PlaceBet", Amount: stake, CurrencyCode: sess.currency,
                TransactionInfo: { Source: "RedDog", GameName: "RedDog", RoundId: txnId, GameNumber: Date.now().toString(), ServerSeedHash: server_seed_hash, ClientSeed: client_seed, Config: cfg }
            });
        }
        const round = {
            round_id: (0, crypto_1.randomUUID)(),
            sid: sess.sid,
            portalName: sess.portalName,
            currency: sess.currency,
            server_seed, server_seed_hash, client_seed,
            cfg, shoe, shoe_idx: idx,
            stake, extra_stake: 0,
            first, second, low, high, spread,
            status: "PENDING",
            settled: false,
            txn_placebet: txnId,
            created_at: Date.now(),
            mode,
            rtpDayKey: undefined,
            rtpEntered: 0
        };
        // RTP enter base stake (REAL)
        if (mode === "real") {
            const yymmdd = (0, date_1.toYYMMDD)();
            round.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_2.redis.hsetnx(round.rtpDayKey, "rtp_target", 0.90);
            yield redis_2.redis.spEnter(round.rtpDayKey, stake);
            round.rtpEntered = ((_o = round.rtpEntered) !== null && _o !== void 0 ? _o : 0) + stake;
        }
        // Immediate outcomes: pair (draw third) or consecutive (spread=0)
        if (v1 === v2) {
            const third = shoe[round.shoe_idx++];
            round.third = third;
            const vt = rankVal(third.r, cfg.ace_high);
            if (vt === v1) {
                const ret = 12.0;
                const payout = +(stake * ret).toFixed(2);
                round.result = { kind: "PAIR_TRIPLE", return_multiplier: ret, payout };
            }
            else {
                const ret = 1.0;
                const payout = +(stake * ret).toFixed(2);
                round.result = { kind: "PUSH", return_multiplier: ret, payout };
            }
            round.status = "SETTLED";
            round.settled = true;
        }
        else if (spread === 0) {
            const ret = 1.0, payout = +(stake * ret).toFixed(2);
            round.result = { kind: "PUSH", return_multiplier: ret, payout };
            round.status = "SETTLED";
            round.settled = true;
        }
        yield saveRound(round);
        // If settled immediately → settle RTP and credit now
        let payload = statusPayload(round);
        if (round.settled) {
            payload = yield creditAndFinalize(round, sess); // will spSettle (REAL) and credit
        }
        if (idem)
            yield setIdem(mode, sess.sid, "deal", idem, payload);
        return payload;
    });
}
function raiseSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "raise", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (r.settled)
                return statusPayload(r);
            if (r.status !== "PENDING")
                throw errors_1.AppError.badRequest("NO_DECISION_REQUIRED");
            // Optional raise → debit extra stake & RTP enter
            if (input.raise) {
                if (mode === "demo") {
                    const bal = yield getDemoBalance(sess);
                    if (bal < r.stake)
                        throw errors_1.AppError.badRequest("Insufficient FUN balance for raise");
                    yield setDemoBalance(sess, +(bal - r.stake).toFixed(2));
                }
                else {
                    const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                    const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                    const txn = `${r.server_seed_hash}-RAISE`;
                    yield (0, client_1.deposit)(opCtx, {
                        TransactionId: txn, TransactionType: "PlaceBet", Amount: r.stake, CurrencyCode: r.currency,
                        TransactionInfo: { Source: "RedDog", GameName: "RedDog", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:raise` }
                    });
                    r.txn_raise = txn;
                    // RTP enter extra stake
                    if (r.rtpDayKey) {
                        yield redis_2.redis.spEnter(r.rtpDayKey, r.stake);
                        r.rtpEntered = ((_b = r.rtpEntered) !== null && _b !== void 0 ? _b : 0) + r.stake;
                    }
                }
                r.extra_stake = r.stake;
            }
            // Draw third and resolve
            const third = r.shoe[r.shoe_idx++];
            r.third = third;
            const vLow = rankVal(r.low.r, r.cfg.ace_high);
            const vHigh = rankVal(r.high.r, r.cfg.ace_high);
            const vT = rankVal(third.r, r.cfg.ace_high);
            let kind;
            if (vT > vLow && vT < vHigh)
                kind = "WIN";
            else if (vT === vLow || vT === vHigh)
                kind = "PUSH";
            else
                kind = "LOSE";
            const totalStake = r.stake + r.extra_stake;
            let ret = 0.0;
            if (kind === "WIN")
                ret = winReturnForSpread(r.spread);
            else if (kind === "PUSH")
                ret = 1.0;
            else
                ret = 0.0;
            const payout = +(totalStake * ret).toFixed(2);
            r.result = { kind, return_multiplier: ret, payout };
            r.status = "SETTLED";
            r.settled = true;
            yield saveRound(r);
            const resp = yield creditAndFinalize(r, sess); // will spSettle (REAL) and credit
            if (idem)
                yield setIdem(mode, sess.sid, "raise", idem, resp);
            return resp;
        }));
    });
}
function statusSvc(sess, input) {
    return __awaiter(this, void 0, void 0, function* () {
        const r = yield loadRound(sess.sid, input.round_id);
        if (!r)
            throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
        return statusPayload(r);
    });
}
/** ============== credit, RTP settle & payload ============== */
function creditAndFinalize(r, sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const payoutTotal = (_b = (_a = r.result) === null || _a === void 0 ? void 0 : _a.payout) !== null && _b !== void 0 ? _b : 0;
        // RTP: settle everything entered for this round (REAL mode)
        if (r.mode === "real" && r.rtpDayKey && ((_c = r.rtpEntered) !== null && _c !== void 0 ? _c : 0) > 0) {
            yield redis_2.redis.spSettle(r.rtpDayKey, r.rtpEntered, payoutTotal);
            r.rtpEntered = 0; // consumed
        }
        // Credit winners / pushes
        if (sess.mode === "demo") {
            const bal = yield getDemoBalance(sess);
            yield setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
        }
        else if (payoutTotal > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_d = sess.opSessionId) !== null && _d !== void 0 ? _d : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${r.server_seed_hash}-W`, TransactionType: "WinAmount", Amount: payoutTotal, CurrencyCode: r.currency,
                TransactionInfo: {
                    Source: "RedDog", GameName: "RedDog", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}`,
                    ServerSeed: r.server_seed, ServerSeedHash: r.server_seed_hash, ClientSeed: r.client_seed,
                    FirstTwo: { first: fmt(r.first), second: fmt(r.second), low: fmt(r.low), high: fmt(r.high), spread: r.spread },
                    Third: r.third ? fmt(r.third) : null,
                    Result: r.result
                }
            });
        }
        return statusPayload(r);
    });
}
function statusPayload(r) {
    var _a;
    return {
        game: "RedDog",
        mode: r.mode,
        round_id: r.round_id,
        currency: r.currency,
        settled: r.settled,
        config: r.cfg,
        stake: r.stake,
        extra_stake: r.extra_stake,
        first_two: { first: fmt(r.first), second: fmt(r.second), low: fmt(r.low), high: fmt(r.high), spread: r.spread },
        third: r.third ? fmt(r.third) : null,
        decision: { needed: (!r.settled && r.status === "PENDING"), can_raise: (!r.settled && r.status === "PENDING"), total_stake_if_raise: r.stake + r.stake },
        result: (_a = r.result) !== null && _a !== void 0 ? _a : null,
        fairness: {
            server_seed_hash: r.server_seed_hash,
            server_seed: r.settled ? r.server_seed : undefined,
            client_seed: r.client_seed,
            method: "Fisher–Yates shoe via HMAC-SHA256(server_seed, `${client_seed}:i:shoe`); Red Dog spread payout table"
        }
    };
}
