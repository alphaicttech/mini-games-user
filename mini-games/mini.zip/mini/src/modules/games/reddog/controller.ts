// /var/www/typesafe/alpha-mini/src/modules/games/reddog/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody, validateQuery } from "../../../middleware/validate";
import { dealSvc, raiseSvc, statusSvc } from "./service";

/** ---- Input validation ---- */
const DealBody = z.object({
    stake: z.number().positive(),
    client_seed: z.string().min(1).optional(),
    cfg: z.object({
        decks: z.number().int().min(1).max(8).default(6),
        ace_high: z.boolean().default(true),
        min_stake: z.number().positive().default(0.1),
        max_stake: z.number().positive().default(10000),
    }).default({} as any)
});
export const dealValidate = validateBody(DealBody);

export const deal = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof DealBody>;
    const data = await dealSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

/** ---- Input validation ---- */
const RaiseBody = z.object({
    round_id: z.string().uuid(),
    raise: z.boolean().default(false) // true = double by adding stake; false = stand (no extra)
});
export const raiseValidate = validateBody(RaiseBody);

export const raiseAction = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof RaiseBody>;
    const data = await raiseSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

/** ---- Input validation ---- */
const StatusQuery = z.object({ round_id: z.string().uuid() });
export const statusValidate = validateQuery(StatusQuery);

export const status = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const data = await statusSvc(sess, req.query as any);
    res.json({ ok: true, ...data });
});

