"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.status = exports.statusValidate = exports.raiseAction = exports.raiseValidate = exports.deal = exports.dealValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
/** ---- Input validation ---- */
const DealBody = zod_1.z.object({
    stake: zod_1.z.number().positive(),
    client_seed: zod_1.z.string().min(1).optional(),
    cfg: zod_1.z.object({
        decks: zod_1.z.number().int().min(1).max(8).default(6),
        ace_high: zod_1.z.boolean().default(true),
        min_stake: zod_1.z.number().positive().default(0.1),
        max_stake: zod_1.z.number().positive().default(10000),
    }).default({})
});
exports.dealValidate = (0, validate_1.validateBody)(DealBody);
exports.deal = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.dealSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
/** ---- Input validation ---- */
const RaiseBody = zod_1.z.object({
    round_id: zod_1.z.string().uuid(),
    raise: zod_1.z.boolean().default(false) // true = double by adding stake; false = stand (no extra)
});
exports.raiseValidate = (0, validate_1.validateBody)(RaiseBody);
exports.raiseAction = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.raiseSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
/** ---- Input validation ---- */
const StatusQuery = zod_1.z.object({ round_id: zod_1.z.string().uuid() });
exports.statusValidate = (0, validate_1.validateQuery)(StatusQuery);
exports.status = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const data = yield (0, service_1.statusSvc)(sess, req.query);
    res.json(Object.assign({ ok: true }, data));
}));
