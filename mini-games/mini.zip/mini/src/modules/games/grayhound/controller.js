"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.streamResultVideo = exports.streamValidate = exports.raceStatus = exports.settleRace = exports.startRace = exports.placeBets = exports.regenerate = exports.newRace = exports.statusValidate = exports.settleValidate = exports.startValidate = exports.placeValidate = exports.regenValidate = exports.newRaceValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const node_path_1 = __importDefault(require("node:path"));
const node_fs_1 = __importDefault(require("node:fs"));
const node_crypto_1 = __importDefault(require("node:crypto"));
const redis_1 = require("../../../config/redis");
/* ----------------- Schemas ----------------- */
const NewBody = zod_1.z.object({
    client_seed: zod_1.z.string().min(1).optional(),
    cfg: zod_1.z.object({
        margin_win: zod_1.z.number().min(0).max(0.2).default(0.08),
        margin_pair: zod_1.z.number().min(0).max(0.2).default(0.10),
        min_stake: zod_1.z.number().positive().default(0.1),
        max_stake: zod_1.z.number().positive().default(5000),
    }).default({})
});
exports.newRaceValidate = (0, validate_1.validateBody)(NewBody);
const RegenBody = zod_1.z.object({ race_id: zod_1.z.string().uuid() });
exports.regenValidate = (0, validate_1.validateBody)(RegenBody);
const BetType = zod_1.z.enum(["WIN", "PLACE", "SHOW", "EXACTA", "QUINELLA"]);
const Bet = zod_1.z.object({
    type: BetType,
    stake: zod_1.z.number().positive(),
    sel: zod_1.z.union([
        zod_1.z.object({ dog: zod_1.z.number().int().min(1).max(6) }),
        zod_1.z.object({ first: zod_1.z.number().int().min(1).max(6), second: zod_1.z.number().int().min(1).max(6) }),
        zod_1.z.object({ a: zod_1.z.number().int().min(1).max(6), b: zod_1.z.number().int().min(1).max(6) })
    ])
});
const PlaceBody = zod_1.z.object({
    race_id: zod_1.z.string().uuid(),
    revision: zod_1.z.number().int().min(1),
    bets: zod_1.z.array(Bet).min(1).max(200),
});
exports.placeValidate = (0, validate_1.validateBody)(PlaceBody);
const StartBody = zod_1.z.object({ race_id: zod_1.z.string().uuid(), stream_url: zod_1.z.string().url().optional() });
exports.startValidate = (0, validate_1.validateBody)(StartBody);
const SettleBody = zod_1.z.object({ race_id: zod_1.z.string().uuid() });
exports.settleValidate = (0, validate_1.validateBody)(SettleBody);
const StatusQuery = zod_1.z.object({ race_id: zod_1.z.string().uuid() });
exports.statusValidate = (0, validate_1.validateQuery)(StatusQuery);
/* ----------------- Handlers ----------------- */
exports.newRace = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = NewBody.parse(req.body);
    const data = yield (0, service_1.newRaceSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.regenerate = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = RegenBody.parse(req.body);
    const data = yield (0, service_1.regenerateSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.placeBets = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = PlaceBody.parse(req.body);
    const data = yield (0, service_1.placeBetsSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.startRace = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = StartBody.parse(req.body);
    const data = yield (0, service_1.startRaceSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.settleRace = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = SettleBody.parse(req.body);
    const data = yield (0, service_1.settleRaceSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.raceStatus = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const query = StatusQuery.parse(req.query);
    const data = yield (0, service_1.statusSvc)(sess, query);
    res.json(Object.assign({ ok: true }, data));
}));
/* ----------------- STREAM endpoint ----------------- */
const StreamParams = zod_1.z.object({ result_id: zod_1.z.string().regex(/^[1-6]{3}$/) });
const streamValidate = (req, res, next) => {
    try {
        req.params = StreamParams.parse(req.params);
        next();
    }
    catch (_a) {
        return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "Invalid result_id" });
    }
};
exports.streamValidate = streamValidate;
function b64url(buf) {
    return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function signToken(resultId, raceId, ts) {
    const key = process.env.MEDIA_TOKEN_SECRET || "";
    const data = `${resultId}:${raceId}:${ts}`;
    return b64url(node_crypto_1.default.createHmac("sha256", key).update(data).digest());
}
function safeEqual(a, b) {
    const A = Buffer.from(a);
    const B = Buffer.from(b);
    if (A.length !== B.length)
        return false;
    return node_crypto_1.default.timingSafeEqual(A, B);
}
function safeJoin(root, file) {
    const p = node_path_1.default.normalize(node_path_1.default.join(root, file));
    if (!p.startsWith(node_path_1.default.normalize(root)))
        throw new Error("PATH_TRAVERSAL");
    return p;
}
exports.streamResultVideo = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d;
    const { result_id } = StreamParams.parse(req.params);
    const t = String((_b = (_a = req.query) === null || _a === void 0 ? void 0 : _a.t) !== null && _b !== void 0 ? _b : "");
    const tsStr = String((_d = (_c = req.query) === null || _c === void 0 ? void 0 : _c.ts) !== null && _d !== void 0 ? _d : "");
    if (!t || !/^\d{10,13}$/.test(tsStr)) {
        return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "Missing or invalid token/ts" });
    }
    const ts = Number(tsStr);
    const maxSkew = Number(process.env.MEDIA_TOKEN_MAX_SKEW_MS || 5000);
    // Ensure ts is within TTL + skew of now
    if (Math.abs(Date.now() - ts) > (60000 + maxSkew)) {
        return res.status(403).json({ ok: false, code: "EXPIRED", message: "Token expired" });
    }
    // Lookup mapping
    const key = `gh:result:${result_id}`;
    const raw = yield redis_1.redis.get(key);
    if (!raw)
        return res.status(404).json({ ok: false, code: "NOT_FOUND", message: "Result expired or unknown" });
    const meta = JSON.parse(raw);
    // Verify HMAC
    const expected = signToken(result_id, meta.race_id, ts);
    if (!safeEqual(expected, t)) {
        return res.status(403).json({ ok: false, code: "BAD_TOKEN", message: "Invalid token" });
    }
    // Stream MP4 with Range support
    const mediaRoot = process.env.MEDIA_ROOT || "/var/media/greyhound";
    const filePath = safeJoin(mediaRoot, `${result_id}.mp4`);
    if (!node_fs_1.default.existsSync(filePath)) {
        return res.status(404).json({ ok: false, code: "NOT_FOUND", message: "Video not found" });
    }
    const stat = node_fs_1.default.statSync(filePath);
    const range = req.headers.range;
    res.setHeader("Content-Type", "video/mp4");
    res.setHeader("Accept-Ranges", "bytes");
    if (!range) {
        res.setHeader("Content-Length", String(stat.size));
        node_fs_1.default.createReadStream(filePath).pipe(res);
        return;
    }
    const m = /^bytes=(\d+)-(\d+)?$/.exec(range);
    if (!m)
        return res.status(416).end();
    const start = parseInt(m[1], 10);
    const end = m[2] ? parseInt(m[2], 10) : stat.size - 1;
    if (start >= stat.size || end >= stat.size) {
        res.status(416).setHeader("Content-Range", `bytes */${stat.size}`).end();
        return;
    }
    res.status(206);
    res.setHeader("Content-Range", `bytes ${start}-${end}/${stat.size}`);
    res.setHeader("Content-Length", String(end - start + 1));
    node_fs_1.default.createReadStream(filePath, { start, end }).pipe(res);
}));
