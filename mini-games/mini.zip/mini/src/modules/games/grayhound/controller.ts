// /var/www/typesafe/alpha-mini/src/modules/games/grayhound/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody, validateQuery } from "../../../middleware/validate";
import {
    newRaceSvc, regenerateSvc, placeBetsSvc, startRaceSvc, settleRaceSvc, statusSvc
} from "./service";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import { redis } from "../../../config/redis";

/* ----------------- Schemas ----------------- */
const NewBody = z.object({
    client_seed: z.string().min(1).optional(),
    cfg: z.object({
        margin_win: z.number().min(0).max(0.2).default(0.08),
        margin_pair: z.number().min(0).max(0.2).default(0.10),
        min_stake: z.number().positive().default(0.1),
        max_stake: z.number().positive().default(5000),
    }).default({} as any)
});
export const newRaceValidate = validateBody(NewBody);

const RegenBody = z.object({ race_id: z.string().uuid() });
export const regenValidate = validateBody(RegenBody);

const BetType = z.enum(["WIN", "PLACE", "SHOW", "EXACTA", "QUINELLA"]);
const Bet = z.object({
    type: BetType,
    stake: z.number().positive(),
    sel: z.union([
        z.object({ dog: z.number().int().min(1).max(6) }),
        z.object({ first: z.number().int().min(1).max(6), second: z.number().int().min(1).max(6) }),
        z.object({ a: z.number().int().min(1).max(6), b: z.number().int().min(1).max(6) })
    ])
});
const PlaceBody = z.object({
    race_id: z.string().uuid(),
    revision: z.number().int().min(1),
    bets: z.array(Bet).min(1).max(200),
});
export const placeValidate = validateBody(PlaceBody);

const StartBody = z.object({ race_id: z.string().uuid(), stream_url: z.string().url().optional() });
export const startValidate = validateBody(StartBody);

const SettleBody = z.object({ race_id: z.string().uuid() });
export const settleValidate = validateBody(SettleBody);

const StatusQuery = z.object({ race_id: z.string().uuid() });
export const statusValidate = validateQuery(StatusQuery);

/* ----------------- Handlers ----------------- */
export const newRace = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = NewBody.parse(req.body);
    const data = await newRaceSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const regenerate = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = RegenBody.parse(req.body);
    const data = await regenerateSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const placeBets = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = PlaceBody.parse(req.body);
    const data = await placeBetsSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const startRace = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = StartBody.parse(req.body);
    const data = await startRaceSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const settleRace = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = SettleBody.parse(req.body);
    const data = await settleRaceSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const raceStatus = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const query = StatusQuery.parse(req.query);
    const data = await statusSvc(sess, query);
    res.json({ ok: true, ...data });
});

/* ----------------- STREAM endpoint ----------------- */
const StreamParams = z.object({ result_id: z.string().regex(/^[1-6]{3}$/) });
export const streamValidate = (req: Request, res: Response, next: Function) => {
    try { req.params = StreamParams.parse(req.params); next(); }
    catch { return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "Invalid result_id" }); }
};

function b64url(buf: Buffer) {
    return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function signToken(resultId: string, raceId: string, ts: number) {
    const key = process.env.MEDIA_TOKEN_SECRET || "";
    const data = `${resultId}:${raceId}:${ts}`;
    return b64url(crypto.createHmac("sha256", key).update(data).digest());
}
function safeEqual(a: string, b: string) {
    const A = Buffer.from(a); const B = Buffer.from(b);
    if (A.length !== B.length) return false;
    return crypto.timingSafeEqual(A, B);
}
function safeJoin(root: string, file: string) {
    const p = path.normalize(path.join(root, file));
    if (!p.startsWith(path.normalize(root))) throw new Error("PATH_TRAVERSAL");
    return p;
}

export const streamResultVideo = asyncHandler(async (req: Request, res: Response) => {
    const { result_id } = StreamParams.parse(req.params);
    const t = String((req.query as any)?.t ?? "");
    const tsStr = String((req.query as any)?.ts ?? "");
    if (!t || !/^\d{10,13}$/.test(tsStr)) {
        return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "Missing or invalid token/ts" });
    }
    const ts = Number(tsStr);
    const maxSkew = Number(process.env.MEDIA_TOKEN_MAX_SKEW_MS || 5000);

    // Ensure ts is within TTL + skew of now
    if (Math.abs(Date.now() - ts) > (60_000 + maxSkew)) {
        return res.status(403).json({ ok: false, code: "EXPIRED", message: "Token expired" });
    }

    // Lookup mapping
    const key = `gh:result:${result_id}`;
    const raw = await redis.get(key);
    if (!raw) return res.status(404).json({ ok: false, code: "NOT_FOUND", message: "Result expired or unknown" });

    const meta = JSON.parse(raw) as { file: string; race_id: string; order: number[]; ts: number };

    // Verify HMAC
    const expected = signToken(result_id, meta.race_id, ts);
    if (!safeEqual(expected, t)) {
        return res.status(403).json({ ok: false, code: "BAD_TOKEN", message: "Invalid token" });
    }

    // Stream MP4 with Range support
    const mediaRoot = process.env.MEDIA_ROOT || "/var/media/greyhound";
    const filePath = safeJoin(mediaRoot, `${result_id}.mp4`);
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ ok: false, code: "NOT_FOUND", message: "Video not found" });
    }

    const stat = fs.statSync(filePath);
    const range = req.headers.range;

    res.setHeader("Content-Type", "video/mp4");
    res.setHeader("Accept-Ranges", "bytes");

    if (!range) {
        res.setHeader("Content-Length", String(stat.size));
        fs.createReadStream(filePath).pipe(res);
        return;
    }

    const m = /^bytes=(\d+)-(\d+)?$/.exec(range);
    if (!m) return res.status(416).end();

    const start = parseInt(m[1], 10);
    const end = m[2] ? parseInt(m[2], 10) : stat.size - 1;
    if (start >= stat.size || end >= stat.size) {
        res.status(416).setHeader("Content-Range", `bytes */${stat.size}`).end();
        return;
    }

    res.status(206);
    res.setHeader("Content-Range", `bytes ${start}-${end}/${stat.size}`);
    res.setHeader("Content-Length", String(end - start + 1));
    fs.createReadStream(filePath, { start, end }).pipe(res);
});
