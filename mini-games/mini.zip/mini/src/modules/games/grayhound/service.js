"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.newRaceSvc = newRaceSvc;
exports.regenerateSvc = regenerateSvc;
exports.placeBetsSvc = placeBetsSvc;
exports.startRaceSvc = startRaceSvc;
exports.settleRaceSvc = settleRaceSvc;
exports.statusSvc = statusSvc;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
/** ====== Config/types ====== */
const IDEM_TTL = 24 * 60 * 60;
const PICK_CANDIDATES = 6; // number of result candidates to evaluate vs RTP
const GAME_CODE = "greyhound"; // games.code
// result id mapping for video streaming (e.g., "123" => 123.mp4)
const RESULT_KEY = (id) => `gh:result:${id}`;
const RESULT_TTL = 60; // seconds
function buildResultId(order) { return order.slice(0, 3).join(""); }
function b64url(buf) { return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function signToken(resultId, raceId, ts) {
    const key = process.env.MEDIA_TOKEN_SECRET || "";
    const data = `${resultId}:${raceId}:${ts}`;
    return b64url(crypto_1.default.createHmac("sha256", key).update(data).digest());
}
/** ====== RNG helpers ====== */
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, i, tag) => u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;
// Plackett–Luce via Gumbel-Max
function sampleOrder(weights, server, client, tag = "order") {
    const scores = weights.map((w, i) => {
        const g = -Math.log(-Math.log(Math.max(1e-12, r01(server, client, i + 1, tag))));
        return Math.log(Math.max(1e-12, w)) + g;
    });
    const idxs = scores.map((v, i) => ({ v, i })).sort((a, b) => b.v - a.v).map(x => x.i);
    return idxs.map(i => i + 1);
}
/** ====== Redis storage/locks/idempotency ====== */
const rKey = (sid, raceId) => `gh:race:${sid}:${raceId}`;
function saveRace(r) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(rKey(r.sid, r.race_id), JSON.stringify(r), 24 * 60 * 60); });
}
function loadRace(sid, raceId) {
    return __awaiter(this, void 0, void 0, function* () { const v = yield redis_1.redis.get(rKey(sid, raceId)); return v ? JSON.parse(v) : null; });
}
function withLock(sid, raceId, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const lk = `gh:lock:${sid}:${raceId}`;
        const ok = yield redis_1.rawRedis.set(lk, "1", "EX", 3, "NX");
        if (ok !== "OK")
            throw errors_1.AppError.conflict("RACE_BUSY");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(lk);
        }
    });
}
// mode-scoped idempotency to avoid demo/real collisions
const idemKey = (mode, sid, action, key) => `idem:${mode}:gh:${action}:${sid}:${key}`;
function getIdem(mode, sid, action, key) {
    return __awaiter(this, void 0, void 0, function* () { if (!key)
        return null; const v = yield redis_1.redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) : null; });
}
function setIdem(mode, sid, action, key, payload) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); });
}
/** ====== Demo wallet ====== */
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const k = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(k);
        if (v)
            return Number(v);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(k, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amt) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60); });
}
/** ====== Odds generation ====== */
function genDogs() {
    return Array.from({ length: 6 }, (_, i) => ({
        no: i + 1,
        name: `Dog ${i + 1}`,
        score: Math.exp((Math.random() - 0.5) * 0.6)
    }));
}
function softmax(xs) {
    const mx = Math.max(...xs);
    const ex = xs.map(v => Math.exp(v - mx));
    const s = ex.reduce((a, b) => a + b, 0);
    return ex.map(v => v / s);
}
// rough pricing helpers
function toDecimalReturn(p, margin, floor = 1.05, cap = 101) {
    const fair = 1 / Math.max(1e-6, p);
    const dec = fair * (1 - margin);
    return Math.min(cap, Math.max(floor, +dec.toFixed(2)));
}
function exactaProbFromDec(dec, margin) {
    const fair = dec / (1 - margin);
    return Math.max(1e-6, 1 / fair);
}
function makeOdds(dogs, cfg, revision) {
    const w = dogs.map(d => d.score);
    const winP = softmax(w);
    const winDec = winP.map(p => toDecimalReturn(p, cfg.margin_win));
    const placeDec = winP.map(p => toDecimalReturn(Math.min(0.9, p * 1.6), cfg.margin_win, 1.02));
    const showDec = winP.map(p => toDecimalReturn(Math.min(0.95, p * 2.2), cfg.margin_win, 1.01));
    const exacta = Array.from({ length: 6 }, () => Array(6).fill(0));
    const quinDec = Array.from({ length: 6 }, () => Array(6).fill(0));
    for (let i = 0; i < 6; i++) {
        for (let j = 0; j < 6; j++) {
            if (i === j)
                continue;
            const pFirst = winP[i];
            const sumRest = w.reduce((a, b, idx) => idx === i ? a : a + b, 0);
            const pSecond = w[j] / Math.max(1e-6, sumRest);
            const pEx = Math.max(1e-6, pFirst * pSecond * 0.85);
            exacta[i][j] = toDecimalReturn(pEx, cfg.margin_pair, 1.1);
        }
    }
    for (let i = 0; i < 6; i++)
        for (let j = 0; j < 6; j++) {
            if (i === j)
                continue;
            const p = Math.max(1e-6, ((exactaProbFromDec(exacta[i][j], cfg.margin_pair) + exactaProbFromDec(exacta[j][i], cfg.margin_pair)) * 0.7));
            quinDec[i][j] = toDecimalReturn(p, cfg.margin_pair, 1.05);
        }
    return { revision, win: winDec, place: placeDec, show: showDec, exacta, quinella: quinDec };
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
// Evaluate payout for a given order over all priced bets
function evaluatePayout(bets, order) {
    const first = order[0], second = order[1], third = order[2];
    let total = 0;
    const lines = bets.map((b, idx) => {
        let win = false;
        switch (b.type) {
            case "WIN":
                win = (b.dog === first);
                break;
            case "PLACE":
                win = (b.dog === first || b.dog === second);
                break;
            case "SHOW":
                win = (b.dog === first || b.dog === second || b.dog === third);
                break;
            case "EXACTA":
                win = (b.first === first && b.second === second);
                break;
            case "QUINELLA":
                win = ((b.a === first && b.b === second) || (b.a === second && b.b === first));
                break;
        }
        const payout = win ? +(b.stake * b.price).toFixed(2) : 0;
        total += payout;
        return { index: idx, type: b.type, stake: b.stake, price: b.price, payout, win };
    });
    return { lines, total: +total.toFixed(2) };
}
/** ====== Services ====== */
function newRaceSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "new", idem);
            if (hit)
                return hit;
        }
        const cfg = {
            margin_win: (_b = (_a = input.cfg) === null || _a === void 0 ? void 0 : _a.margin_win) !== null && _b !== void 0 ? _b : 0.08,
            margin_pair: (_d = (_c = input.cfg) === null || _c === void 0 ? void 0 : _c.margin_pair) !== null && _d !== void 0 ? _d : 0.10,
            min_stake: (_f = (_e = input.cfg) === null || _e === void 0 ? void 0 : _e.min_stake) !== null && _f !== void 0 ? _f : 0.1,
            max_stake: (_h = (_g = input.cfg) === null || _g === void 0 ? void 0 : _g.max_stake) !== null && _h !== void 0 ? _h : 5000,
        };
        const server_seed = crypto_1.default.randomBytes(32).toString("hex");
        const server_seed_hash = sha256(server_seed);
        const client_seed = (_l = (_k = (_j = input.client_seed) !== null && _j !== void 0 ? _j : sess.clientExternalKey) !== null && _k !== void 0 ? _k : sess.userName) !== null && _l !== void 0 ? _l : "client";
        const dogs = genDogs();
        const odds = makeOdds(dogs, cfg, 1);
        const race = {
            race_id: (0, crypto_1.randomUUID)(),
            sid: sess.sid,
            currency: sess.currency,
            server_seed, server_seed_hash, client_seed,
            cfg, dogs, odds,
            state: "DRAFT",
            bets: [],
            stake_total: 0,
            created_at: Date.now()
        };
        yield saveRace(race);
        const resp = { race_id: race.race_id, state: race.state, server_seed_hash, revision: odds.revision, dogs, odds, mode };
        if (idem)
            yield setIdem(mode, sess.sid, "new", idem, resp);
        return resp;
    });
}
function regenerateSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "regen", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.race_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const r = yield loadRace(sess.sid, input.race_id);
            if (!r)
                throw errors_1.AppError.notFound("RACE_NOT_FOUND");
            if (r.state !== "DRAFT" && r.bets.length > 0)
                throw errors_1.AppError.badRequest("CANNOT_REGENERATE_AFTER_BETS");
            r.dogs = genDogs();
            r.odds = makeOdds(r.dogs, r.cfg, ((_b = (_a = r.odds) === null || _a === void 0 ? void 0 : _a.revision) !== null && _b !== void 0 ? _b : 0) + 1);
            r.bets = [];
            r.stake_total = 0;
            r.state = "DRAFT";
            yield saveRace(r);
            const resp = { race_id: r.race_id, state: r.state, revision: r.odds.revision, dogs: r.dogs, odds: r.odds, mode };
            if (idem)
                yield setIdem(mode, sess.sid, "regen", idem, resp);
            return resp;
        }));
    });
}
function placeBetsSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "place", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.race_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const r = yield loadRace(sess.sid, input.race_id);
            if (!r)
                throw errors_1.AppError.notFound("RACE_NOT_FOUND");
            if (!(r.state === "DRAFT" || r.state === "OPEN"))
                throw errors_1.AppError.badRequest("RACE_CLOSED");
            if (input.revision !== r.odds.revision)
                throw errors_1.AppError.badRequest("ODDS_STALE");
            const priced = [];
            let slipStake = 0;
            const ensureDog = (d) => { if (d < 1 || d > 6)
                throw errors_1.AppError.badRequest("BAD_DOG"); };
            const ensurePair = (x, y) => { if (x < 1 || x > 6 || y < 1 || y > 6 || x === y)
                throw errors_1.AppError.badRequest("PAIR_INVALID"); };
            for (const b of input.bets) {
                if (typeof b.stake !== "number" || b.stake <= 0)
                    throw errors_1.AppError.badRequest("INVALID_STAKE");
                if (b.stake < r.cfg.min_stake || b.stake > r.cfg.max_stake)
                    throw errors_1.AppError.badRequest("STAKE_OUT_OF_RANGE");
                switch (b.type) {
                    case "WIN":
                        ensureDog(b.sel.dog);
                        priced.push({ type: "WIN", stake: b.stake, dog: b.sel.dog, rev: r.odds.revision, price: r.odds.win[b.sel.dog - 1] });
                        break;
                    case "PLACE":
                        ensureDog(b.sel.dog);
                        priced.push({ type: "PLACE", stake: b.stake, dog: b.sel.dog, rev: r.odds.revision, price: r.odds.place[b.sel.dog - 1] });
                        break;
                    case "SHOW":
                        ensureDog(b.sel.dog);
                        priced.push({ type: "SHOW", stake: b.stake, dog: b.sel.dog, rev: r.odds.revision, price: r.odds.show[b.sel.dog - 1] });
                        break;
                    case "EXACTA":
                        ensurePair(b.sel.first, b.sel.second);
                        priced.push({ type: "EXACTA", stake: b.stake, first: b.sel.first, second: b.sel.second, rev: r.odds.revision, price: r.odds.exacta[b.sel.first - 1][b.sel.second - 1] });
                        break;
                    case "QUINELLA":
                        ensurePair(b.sel.a, b.sel.b);
                        priced.push({ type: "QUINELLA", stake: b.stake, a: b.sel.a, b: b.sel.b, rev: r.odds.revision, price: r.odds.quinella[b.sel.a - 1][b.sel.b - 1] });
                        break;
                    default: throw errors_1.AppError.badRequest("UNKNOWN_BET");
                }
                slipStake += b.stake;
            }
            // Ledger / RTP enter for REAL; demo only touches demo wallet
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                if (bal < slipStake)
                    throw errors_1.AppError.badRequest("Insufficient FUN balance");
                yield setDemoBalance(sess, +(bal - slipStake).toFixed(2));
            }
            else {
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opCtx = {
                    baseUrl: operator.baseUrl, secret: operator.secret,
                    session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
                };
                yield (0, client_1.deposit)(opCtx, {
                    TransactionId: `${r.race_id}-SLIP-${Date.now()}`,
                    TransactionType: "PlaceBet",
                    Amount: slipStake,
                    CurrencyCode: r.currency,
                    TransactionInfo: { Source: "Greyhound", GameName: "SixDog", RoundId: r.race_id, GameNumber: `${r.race_id}:bets:${Date.now()}`, Revision: r.odds.revision }
                });
                // RTP enter: accumulate payin & actives
                const yymmdd = (0, date_1.toYYMMDD)();
                r.rtpDayKey = (_b = r.rtpDayKey) !== null && _b !== void 0 ? _b : redis_keys_1.rk.day(GAME_CODE, yymmdd);
                yield redis_1.redis.hsetnx(r.rtpDayKey, "rtp_target", 0.90);
                yield redis_1.redis.spEnter(r.rtpDayKey, slipStake);
            }
            r.bets.push(...priced);
            r.stake_total = +(r.stake_total + slipStake).toFixed(2);
            r.state = "OPEN";
            yield saveRace(r);
            const resp = { race_id: r.race_id, state: r.state, revision: r.odds.revision, priced: r.bets, stake_total: r.stake_total, mode };
            if (idem)
                yield setIdem(mode, sess.sid, "place", idem, resp);
            return resp;
        }));
    });
}
function startRaceSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "start", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.race_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c;
            const r = yield loadRace(sess.sid, input.race_id);
            if (!r)
                throw errors_1.AppError.notFound("RACE_NOT_FOUND");
            if (r.state !== "OPEN" && r.state !== "DRAFT")
                throw errors_1.AppError.badRequest("ALREADY_RUNNING_OR_DONE");
            const cfg = yield loadGameCfg();
            // REAL: plan vs live RTP for the whole race stake_total; DEMO: synthetic plan feel
            let plan = { hardCap: 0, softCap: 0, target: 0 };
            let yymmdd = (0, date_1.toYYMMDD)();
            if (mode === "real") {
                r.rtpDayKey = (_a = r.rtpDayKey) !== null && _a !== void 0 ? _a : redis_keys_1.rk.day(GAME_CODE, yymmdd);
                yield redis_1.redis.hsetnx(r.rtpDayKey, "rtp_target", 0.90);
                plan = yield (0, governor_1.spPlan)(GAME_CODE, r.stake_total, cfg, yymmdd);
            }
            else {
                const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
                const softCap = Math.floor(hardCap * 0.6);
                const rr = Math.random();
                const target = Math.floor(softCap * (0.3 + 0.7 * rr));
                plan = { hardCap, softCap, target };
            }
            const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            // Pick result among K deterministic candidates (vary tag) to aim near target and <= cap
            const weights = r.dogs.map(d => d.score);
            let best = { score: Number.POSITIVE_INFINITY, order: [], pickIdx: 0, payout: 0, lines: [] };
            for (let k = 0; k < PICK_CANDIDATES; k++) {
                const order = sampleOrder(weights, r.server_seed, r.client_seed, `order:${k}`);
                const evald = evaluatePayout(r.bets, order);
                const capped = Math.min(evald.total, slipCap);
                const overPenalty = evald.total > slipCap ? (evald.total - slipCap) * 10 : 0;
                const softPenalty = capped > plan.softCap ? (capped - plan.softCap) * 0.5 : 0;
                const score = Math.abs(capped - plan.target) + overPenalty + softPenalty;
                if (score < best.score)
                    best = { score, order, pickIdx: k, payout: +capped.toFixed(2), lines: evald.lines };
            }
            r.order = best.order;
            r.state = "RUNNING";
            r.planTarget = plan.target;
            r.planHardCap = plan.hardCap;
            r.rtpSlipCap = slipCap;
            yield saveRace(r);
            // Build result_id + tokenized short-lived stream access
            const resultId = buildResultId(r.order);
            const ts = Date.now();
            yield redis_1.redis.set(RESULT_KEY(resultId), JSON.stringify({ race_id: r.race_id, order: r.order, file: `${resultId}.mp4`, ts }), RESULT_TTL);
            const token = signToken(resultId, r.race_id, ts);
            // Optional public URL
            const base = process.env.PUBLIC_API_BASE || "";
            r.stream_url = (_b = input.stream_url) !== null && _b !== void 0 ? _b : (base ? `${base}/v1/games/greyhound/race/stream/${resultId}?t=${token}&ts=${ts}` : undefined);
            yield saveRace(r);
            const resp = {
                race_id: r.race_id,
                state: r.state,
                result_id: resultId,
                token,
                ts,
                stream_url: (_c = r.stream_url) !== null && _c !== void 0 ? _c : null,
                server_seed_hash: r.server_seed_hash,
                result_ttl_seconds: RESULT_TTL,
                plan,
                pick_index: best.pickIdx
            };
            if (idem)
                yield setIdem(mode, sess.sid, "start", idem, resp);
            return resp;
        }));
    });
}
function settleRaceSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "settle", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.race_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const r = yield loadRace(sess.sid, input.race_id);
            if (!r)
                throw errors_1.AppError.notFound("RACE_NOT_FOUND");
            if (r.state !== "RUNNING")
                throw errors_1.AppError.badRequest("RACE_NOT_RUNNING");
            if (!r.order)
                throw errors_1.AppError.internal("MISSING_RESULT");
            const evald = evaluatePayout(r.bets, r.order);
            // Safety clamp (should already be <= rtpSlipCap from start)
            const cfg = yield loadGameCfg();
            const slipCap = Math.min((_a = r.rtpSlipCap) !== null && _a !== void 0 ? _a : Infinity, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            const payoutTotal = Math.min(evald.total, slipCap);
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                yield setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
            }
            else if (payoutTotal > 0) {
                // RTP settle for the race (use accumulated stake_total)
                if (!r.rtpDayKey) {
                    const yymmdd = (0, date_1.toYYMMDD)();
                    r.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
                }
                yield redis_1.redis.spSettle(r.rtpDayKey, r.stake_total, payoutTotal);
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opCtx = {
                    baseUrl: operator.baseUrl, secret: operator.secret,
                    session: { id: (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
                };
                yield (0, client_1.withdraw)(opCtx, {
                    TransactionId: `${r.race_id}-W`,
                    TransactionType: "WinAmount",
                    Amount: payoutTotal,
                    CurrencyCode: r.currency,
                    TransactionInfo: {
                        Source: "Greyhound", GameName: "SixDog",
                        RoundId: r.race_id, GameNumber: `${r.race_id}:settle:${Date.now()}`,
                        ServerSeed: r.server_seed, ServerSeedHash: r.server_seed_hash, ClientSeed: r.client_seed,
                        Order: r.order, Bets: evald.lines
                    }
                });
            }
            r.state = "SETTLED";
            r.settled = true;
            yield saveRace(r);
            const resp = {
                race_id: r.race_id, state: r.state, order: r.order,
                bets: evald.lines, stake_total: r.stake_total,
                payout_total: payoutTotal,
                fairness: { server_seed_hash: r.server_seed_hash, server_seed: r.server_seed, client_seed: r.client_seed },
                plan: (r.planTarget != null && r.planHardCap != null) ? { target: r.planTarget, hardCap: r.planHardCap } : undefined,
                mode
            };
            if (idem)
                yield setIdem(mode, sess.sid, "settle", idem, resp);
            return resp;
        }));
    });
}
function statusSvc(sess, input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const r = yield loadRace(sess.sid, input.race_id);
        if (!r)
            throw errors_1.AppError.notFound("RACE_NOT_FOUND");
        return {
            race_id: r.race_id,
            state: r.state,
            revision: r.odds.revision,
            dogs: r.dogs,
            odds: r.odds,
            bets: r.bets,
            stake_total: r.stake_total,
            stream_url: (_a = r.stream_url) !== null && _a !== void 0 ? _a : null,
            order: r.state === "SETTLED" ? r.order : undefined,
            fairness: {
                server_seed_hash: r.server_seed_hash,
                server_seed: r.state === "SETTLED" ? r.server_seed : undefined,
                client_seed: r.client_seed,
                method: "Finishing order via Gumbel-Max (Plackett–Luce), K candidates; pick RTP-aware best"
            },
            plan: (r.planTarget != null && r.planHardCap != null) ? { target: r.planTarget, hardCap: r.planHardCap, slipCap: r.rtpSlipCap } : undefined
        };
    });
}
