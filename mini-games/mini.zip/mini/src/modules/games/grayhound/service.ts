import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

/** ====== Config/types ====== */
const IDEM_TTL = 24 * 60 * 60;
const PICK_CANDIDATES = 6; // number of result candidates to evaluate vs RTP
const GAME_CODE = "greyhound"; // games.code

// result id mapping for video streaming (e.g., "123" => 123.mp4)
const RESULT_KEY = (id: string) => `gh:result:${id}`;
const RESULT_TTL = 60; // seconds
function buildResultId(order: number[]) { return order.slice(0, 3).join(""); }
function b64url(buf: Buffer) { return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function signToken(resultId: string, raceId: string, ts: number) {
    const key = process.env.MEDIA_TOKEN_SECRET || "";
    const data = `${resultId}:${raceId}:${ts}`;
    return b64url(crypto.createHmac("sha256", key).update(data).digest());
}

type Cfg = {
    margin_win: number;
    margin_pair: number;
    min_stake: number;
    max_stake: number;
};

type Dog = { no: number; name: string; score: number };
type MarketOdds = {
    revision: number;
    win: number[];
    place: number[];
    show: number[];
    exacta: number[][];
    quinella: number[][];
};

type BetLine =
    | { type: "WIN"; stake: number; dog: number; rev: number; price: number }
    | { type: "PLACE"; stake: number; dog: number; rev: number; price: number }
    | { type: "SHOW"; stake: number; dog: number; rev: number; price: number }
    | { type: "EXACTA"; stake: number; first: number; second: number; rev: number; price: number }
    | { type: "QUINELLA"; stake: number; a: number; b: number; rev: number; price: number };

type RaceState = {
    race_id: string;
    sid: string;
    currency: string;

    server_seed: string;
    server_seed_hash: string;
    client_seed: string;

    cfg: Cfg;
    dogs: Dog[];
    odds: MarketOdds;
    state: "DRAFT" | "OPEN" | "RUNNING" | "SETTLED";
    stream_url?: string;

    bets: BetLine[];
    stake_total: number;

    order?: number[];
    settled?: boolean;
    created_at: number;

    // RTP (REAL)
    rtpDayKey?: string;
    planTarget?: number;
    planHardCap?: number;
    rtpSlipCap?: number;
};

/** ====== RNG helpers ====== */
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (server: string, client: string, i: number, tag: string) =>
    u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;

// Plackett–Luce via Gumbel-Max
function sampleOrder(weights: number[], server: string, client: string, tag = "order") {
    const scores = weights.map((w, i) => {
        const g = -Math.log(-Math.log(Math.max(1e-12, r01(server, client, i + 1, tag))));
        return Math.log(Math.max(1e-12, w)) + g;
    });
    const idxs = scores.map((v, i) => ({ v, i })).sort((a, b) => b.v - a.v).map(x => x.i);
    return idxs.map(i => i + 1);
}

/** ====== Redis storage/locks/idempotency ====== */
const rKey = (sid: string, raceId: string) => `gh:race:${sid}:${raceId}`;
async function saveRace(r: RaceState) { await redis.set(rKey(r.sid, r.race_id), JSON.stringify(r), 24 * 60 * 60); }
async function loadRace(sid: string, raceId: string) { const v = await redis.get(rKey(sid, raceId)); return v ? JSON.parse(v) as RaceState : null; }
async function withLock<T>(sid: string, raceId: string, fn: () => Promise<T>) {
    const lk = `gh:lock:${sid}:${raceId}`;
    const ok = await (rawRedis as any).set(lk, "1", "EX", 3, "NX");
    if (ok !== "OK") throw AppError.conflict("RACE_BUSY");
    try { return await fn(); } finally { await rawRedis.del(lk); }
}
// mode-scoped idempotency to avoid demo/real collisions
const idemKey = (mode: "real" | "demo", sid: string, action: string, key: string) => `idem:${mode}:gh:${action}:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, action: string, key?: string) { if (!key) return null; const v = await redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) as any : null; }
async function setIdem(mode: "real" | "demo", sid: string, action: string, key: string, payload: any) { await redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); }

/** ====== Demo wallet ====== */
async function getDemoBalance(sess: ProviderSession) {
    const k = `demo:bal:${sess.sid}`; const v = await redis.get(k);
    if (v) return Number(v);
    const base = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(k, String(base), 2 * 60 * 60); return base;
}
async function setDemoBalance(sess: ProviderSession, amt: number) { await redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60); }

/** ====== Odds generation ====== */
function genDogs(): Dog[] {
    return Array.from({ length: 6 }, (_, i) => ({
        no: i + 1,
        name: `Dog ${i + 1}`,
        score: Math.exp((Math.random() - 0.5) * 0.6)
    }));
}
function softmax(xs: number[]) {
    const mx = Math.max(...xs);
    const ex = xs.map(v => Math.exp(v - mx));
    const s = ex.reduce((a, b) => a + b, 0);
    return ex.map(v => v / s);
}
// rough pricing helpers
function toDecimalReturn(p: number, margin: number, floor = 1.05, cap = 101) {
    const fair = 1 / Math.max(1e-6, p);
    const dec = fair * (1 - margin);
    return Math.min(cap, Math.max(floor, +dec.toFixed(2)));
}
function exactaProbFromDec(dec: number, margin: number) {
    const fair = dec / (1 - margin);
    return Math.max(1e-6, 1 / fair);
}
function makeOdds(dogs: Dog[], cfg: Cfg, revision: number): MarketOdds {
    const w = dogs.map(d => d.score);
    const winP = softmax(w);
    const winDec = winP.map(p => toDecimalReturn(p, cfg.margin_win));
    const placeDec = winP.map(p => toDecimalReturn(Math.min(0.9, p * 1.6), cfg.margin_win, 1.02));
    const showDec = winP.map(p => toDecimalReturn(Math.min(0.95, p * 2.2), cfg.margin_win, 1.01));
    const exacta: number[][] = Array.from({ length: 6 }, () => Array(6).fill(0));
    const quinDec: number[][] = Array.from({ length: 6 }, () => Array(6).fill(0));
    for (let i = 0; i < 6; i++) {
        for (let j = 0; j < 6; j++) {
            if (i === j) continue;
            const pFirst = winP[i];
            const sumRest = w.reduce((a, b, idx) => idx === i ? a : a + b, 0);
            const pSecond = w[j] / Math.max(1e-6, sumRest);
            const pEx = Math.max(1e-6, pFirst * pSecond * 0.85);
            exacta[i][j] = toDecimalReturn(pEx, cfg.margin_pair, 1.1);
        }
    }
    for (let i = 0; i < 6; i++) for (let j = 0; j < 6; j++) {
        if (i === j) continue;
        const p = Math.max(1e-6, ((exactaProbFromDec(exacta[i][j], cfg.margin_pair) + exactaProbFromDec(exacta[j][i], cfg.margin_pair)) * 0.7));
        quinDec[i][j] = toDecimalReturn(p, cfg.margin_pair, 1.05);
    }
    return { revision, win: winDec, place: placeDec, show: showDec, exacta, quinella: quinDec };
}

// ===== cfg / caps =====
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}

// Evaluate payout for a given order over all priced bets
function evaluatePayout(bets: BetLine[], order: number[]) {
    const first = order[0], second = order[1], third = order[2];
    let total = 0;
    const lines = bets.map((b, idx) => {
        let win = false;
        switch (b.type) {
            case "WIN": win = (b.dog === first); break;
            case "PLACE": win = (b.dog === first || b.dog === second); break;
            case "SHOW": win = (b.dog === first || b.dog === second || b.dog === third); break;
            case "EXACTA": win = (b.first === first && b.second === second); break;
            case "QUINELLA": win = ((b.a === first && b.b === second) || (b.a === second && b.b === first)); break;
        }
        const payout = win ? +(b.stake * (b as any).price).toFixed(2) : 0;
        total += payout;
        return { index: idx, type: b.type, stake: b.stake, price: (b as any).price, payout, win };
    });
    return { lines, total: +total.toFixed(2) };
}

/** ====== Services ====== */
export async function newRaceSvc(
    sess: ProviderSession,
    input: { client_seed?: string; cfg: Partial<Cfg> },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "new", idem); if (hit) return hit; }

    const cfg: Cfg = {
        margin_win: input.cfg?.margin_win ?? 0.08,
        margin_pair: input.cfg?.margin_pair ?? 0.10,
        min_stake: input.cfg?.min_stake ?? 0.1,
        max_stake: input.cfg?.max_stake ?? 5000,
    };

    const server_seed = crypto.randomBytes(32).toString("hex");
    const server_seed_hash = sha256(server_seed);
    const client_seed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    const dogs = genDogs();
    const odds = makeOdds(dogs, cfg, 1);

    const race: RaceState = {
        race_id: randomUUID(),
        sid: sess.sid,
        currency: sess.currency,
        server_seed, server_seed_hash, client_seed,
        cfg, dogs, odds,
        state: "DRAFT",
        bets: [],
        stake_total: 0,
        created_at: Date.now()
    };
    await saveRace(race);

    const resp = { race_id: race.race_id, state: race.state, server_seed_hash, revision: odds.revision, dogs, odds, mode };
    if (idem) await setIdem(mode, sess.sid, "new", idem, resp);
    return resp;
}

export async function regenerateSvc(
    sess: ProviderSession,
    input: { race_id: string },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "regen", idem); if (hit) return hit; }
    return withLock(sess.sid, input.race_id, async () => {
        const r = await loadRace(sess.sid, input.race_id);
        if (!r) throw AppError.notFound("RACE_NOT_FOUND");
        if (r.state !== "DRAFT" && r.bets.length > 0) throw AppError.badRequest("CANNOT_REGENERATE_AFTER_BETS");
        r.dogs = genDogs();
        r.odds = makeOdds(r.dogs, r.cfg, (r.odds?.revision ?? 0) + 1);
        r.bets = [];
        r.stake_total = 0;
        r.state = "DRAFT";
        await saveRace(r);
        const resp = { race_id: r.race_id, state: r.state, revision: r.odds.revision, dogs: r.dogs, odds: r.odds, mode };
        if (idem) await setIdem(mode, sess.sid, "regen", idem, resp);
        return resp;
    });
}

export async function placeBetsSvc(
    sess: ProviderSession,
    input: { race_id: string; revision: number; bets: any[] },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "place", idem); if (hit) return hit; }
    return withLock(sess.sid, input.race_id, async () => {
        const r = await loadRace(sess.sid, input.race_id);
        if (!r) throw AppError.notFound("RACE_NOT_FOUND");
        if (!(r.state === "DRAFT" || r.state === "OPEN")) throw AppError.badRequest("RACE_CLOSED");
        if (input.revision !== r.odds.revision) throw AppError.badRequest("ODDS_STALE");

        const priced: BetLine[] = [];
        let slipStake = 0;

        const ensureDog = (d: number) => { if (d < 1 || d > 6) throw AppError.badRequest("BAD_DOG"); };
        const ensurePair = (x: number, y: number) => { if (x < 1 || x > 6 || y < 1 || y > 6 || x === y) throw AppError.badRequest("PAIR_INVALID"); };

        for (const b of input.bets) {
            if (typeof b.stake !== "number" || b.stake <= 0) throw AppError.badRequest("INVALID_STAKE");
            if (b.stake < r.cfg.min_stake || b.stake > r.cfg.max_stake) throw AppError.badRequest("STAKE_OUT_OF_RANGE");
            switch (b.type) {
                case "WIN": ensureDog(b.sel.dog); priced.push({ type: "WIN", stake: b.stake, dog: b.sel.dog, rev: r.odds.revision, price: r.odds.win[b.sel.dog - 1] }); break;
                case "PLACE": ensureDog(b.sel.dog); priced.push({ type: "PLACE", stake: b.stake, dog: b.sel.dog, rev: r.odds.revision, price: r.odds.place[b.sel.dog - 1] }); break;
                case "SHOW": ensureDog(b.sel.dog); priced.push({ type: "SHOW", stake: b.stake, dog: b.sel.dog, rev: r.odds.revision, price: r.odds.show[b.sel.dog - 1] }); break;
                case "EXACTA": ensurePair(b.sel.first, b.sel.second); priced.push({ type: "EXACTA", stake: b.stake, first: b.sel.first, second: b.sel.second, rev: r.odds.revision, price: r.odds.exacta[b.sel.first - 1][b.sel.second - 1] }); break;
                case "QUINELLA": ensurePair(b.sel.a, b.sel.b); priced.push({ type: "QUINELLA", stake: b.stake, a: b.sel.a, b: b.sel.b, rev: r.odds.revision, price: r.odds.quinella[b.sel.a - 1][b.sel.b - 1] }); break;
                default: throw AppError.badRequest("UNKNOWN_BET");
            }
            slipStake += b.stake;
        }

        // Ledger / RTP enter for REAL; demo only touches demo wallet
        if (mode === "demo") {
            const bal = await getDemoBalance(sess);
            if (bal < slipStake) throw AppError.badRequest("Insufficient FUN balance");
            await setDemoBalance(sess, +(bal - slipStake).toFixed(2));
        } else {
            const operator = await findByPortalName(sess.portalName);
            const opCtx: any = {
                baseUrl: operator.baseUrl, secret: operator.secret,
                session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            await deposit(opCtx, {
                TransactionId: `${r.race_id}-SLIP-${Date.now()}`,
                TransactionType: "PlaceBet",
                Amount: slipStake,
                CurrencyCode: r.currency,
                TransactionInfo: { Source: "Greyhound", GameName: "SixDog", RoundId: r.race_id, GameNumber: `${r.race_id}:bets:${Date.now()}`, Revision: r.odds.revision }
            });

            // RTP enter: accumulate payin & actives
            const yymmdd = toYYMMDD();
            r.rtpDayKey = r.rtpDayKey ?? rk.day(GAME_CODE, yymmdd);
            await redis.hsetnx(r.rtpDayKey, "rtp_target", 0.90);
            await redis.spEnter(r.rtpDayKey, slipStake);
        }

        r.bets.push(...priced);
        r.stake_total = +(r.stake_total + slipStake).toFixed(2);
        r.state = "OPEN";
        await saveRace(r);

        const resp = { race_id: r.race_id, state: r.state, revision: r.odds.revision, priced: r.bets, stake_total: r.stake_total, mode };
        if (idem) await setIdem(mode, sess.sid, "place", idem, resp);
        return resp;
    });
}

export async function startRaceSvc(
    sess: ProviderSession,
    input: { race_id: string; stream_url?: string },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "start", idem); if (hit) return hit; }
    return withLock(sess.sid, input.race_id, async () => {
        const r = await loadRace(sess.sid, input.race_id);
        if (!r) throw AppError.notFound("RACE_NOT_FOUND");
        if (r.state !== "OPEN" && r.state !== "DRAFT") throw AppError.badRequest("ALREADY_RUNNING_OR_DONE");

        const cfg = await loadGameCfg();

        // REAL: plan vs live RTP for the whole race stake_total; DEMO: synthetic plan feel
        let plan = { hardCap: 0, softCap: 0, target: 0 };
        let yymmdd = toYYMMDD();
        if (mode === "real") {
            r.rtpDayKey = r.rtpDayKey ?? rk.day(GAME_CODE, yymmdd);
            await redis.hsetnx(r.rtpDayKey, "rtp_target", 0.90);
            plan = await spPlan(GAME_CODE, r.stake_total, cfg, yymmdd);
        } else {
            const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
            const softCap = Math.floor(hardCap * 0.6);
            const rr = Math.random();
            const target = Math.floor(softCap * (0.3 + 0.7 * rr));
            plan = { hardCap, softCap, target };
        }
        const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);

        // Pick result among K deterministic candidates (vary tag) to aim near target and <= cap
        const weights = r.dogs.map(d => d.score);
        let best = { score: Number.POSITIVE_INFINITY, order: [] as number[], pickIdx: 0, payout: 0, lines: [] as any[] };
        for (let k = 0; k < PICK_CANDIDATES; k++) {
            const order = sampleOrder(weights, r.server_seed, r.client_seed, `order:${k}`);
            const evald = evaluatePayout(r.bets, order);
            const capped = Math.min(evald.total, slipCap);
            const overPenalty = evald.total > slipCap ? (evald.total - slipCap) * 10 : 0;
            const softPenalty = capped > plan.softCap ? (capped - plan.softCap) * 0.5 : 0;
            const score = Math.abs(capped - plan.target) + overPenalty + softPenalty;
            if (score < best.score) best = { score, order, pickIdx: k, payout: +capped.toFixed(2), lines: evald.lines };
        }

        r.order = best.order;
        r.state = "RUNNING";
        r.planTarget = plan.target;
        r.planHardCap = plan.hardCap;
        r.rtpSlipCap = slipCap;
        await saveRace(r);

        // Build result_id + tokenized short-lived stream access
        const resultId = buildResultId(r.order);
        const ts = Date.now();
        await redis.set(RESULT_KEY(resultId), JSON.stringify({ race_id: r.race_id, order: r.order, file: `${resultId}.mp4`, ts }), RESULT_TTL);
        const token = signToken(resultId, r.race_id, ts);

        // Optional public URL
        const base = process.env.PUBLIC_API_BASE || "";
        r.stream_url = input.stream_url ?? (base ? `${base}/v1/games/greyhound/race/stream/${resultId}?t=${token}&ts=${ts}` : undefined);
        await saveRace(r);

        const resp = {
            race_id: r.race_id,
            state: r.state,
            result_id: resultId,
            token,
            ts,
            stream_url: r.stream_url ?? null,
            server_seed_hash: r.server_seed_hash,
            result_ttl_seconds: RESULT_TTL,
            plan,
            pick_index: best.pickIdx
        };
        if (idem) await setIdem(mode, sess.sid, "start", idem, resp);
        return resp;
    });
}

export async function settleRaceSvc(
    sess: ProviderSession,
    input: { race_id: string },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "settle", idem); if (hit) return hit; }
    return withLock(sess.sid, input.race_id, async () => {
        const r = await loadRace(sess.sid, input.race_id);
        if (!r) throw AppError.notFound("RACE_NOT_FOUND");
        if (r.state !== "RUNNING") throw AppError.badRequest("RACE_NOT_RUNNING");
        if (!r.order) throw AppError.internal("MISSING_RESULT");

        const evald = evaluatePayout(r.bets, r.order);
        // Safety clamp (should already be <= rtpSlipCap from start)
        const cfg = await loadGameCfg();
        const slipCap = Math.min(r.rtpSlipCap ?? Infinity, cfg.per_ticket_cap, cfg.per_user_daily_cap);
        const payoutTotal = Math.min(evald.total, slipCap);

        if (mode === "demo") {
            const bal = await getDemoBalance(sess);
            await setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
        } else if (payoutTotal > 0) {
            // RTP settle for the race (use accumulated stake_total)
            if (!r.rtpDayKey) {
                const yymmdd = toYYMMDD();
                r.rtpDayKey = rk.day(GAME_CODE, yymmdd);
            }
            await redis.spSettle(r.rtpDayKey!, r.stake_total, payoutTotal);

            const operator = await findByPortalName(sess.portalName);
            const opCtx: any = {
                baseUrl: operator.baseUrl, secret: operator.secret,
                session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            await withdraw(opCtx, {
                TransactionId: `${r.race_id}-W`,
                TransactionType: "WinAmount",
                Amount: payoutTotal,
                CurrencyCode: r.currency,
                TransactionInfo: {
                    Source: "Greyhound", GameName: "SixDog",
                    RoundId: r.race_id, GameNumber: `${r.race_id}:settle:${Date.now()}`,
                    ServerSeed: r.server_seed, ServerSeedHash: r.server_seed_hash, ClientSeed: r.client_seed,
                    Order: r.order, Bets: evald.lines
                }
            });
        }

        r.state = "SETTLED"; r.settled = true;
        await saveRace(r);

        const resp = {
            race_id: r.race_id, state: r.state, order: r.order,
            bets: evald.lines, stake_total: r.stake_total,
            payout_total: payoutTotal,
            fairness: { server_seed_hash: r.server_seed_hash, server_seed: r.server_seed, client_seed: r.client_seed },
            plan: (r.planTarget != null && r.planHardCap != null) ? { target: r.planTarget, hardCap: r.planHardCap } : undefined,
            mode
        };
        if (idem) await setIdem(mode, sess.sid, "settle", idem, resp);
        return resp;
    });
}

export async function statusSvc(sess: ProviderSession, input: { race_id: string }) {
    const r = await loadRace(sess.sid, input.race_id);
    if (!r) throw AppError.notFound("RACE_NOT_FOUND");
    return {
        race_id: r.race_id,
        state: r.state,
        revision: r.odds.revision,
        dogs: r.dogs,
        odds: r.odds,
        bets: r.bets,
        stake_total: r.stake_total,
        stream_url: r.stream_url ?? null,
        order: r.state === "SETTLED" ? r.order : undefined,
        fairness: {
            server_seed_hash: r.server_seed_hash,
            server_seed: r.state === "SETTLED" ? r.server_seed : undefined,
            client_seed: r.client_seed,
            method: "Finishing order via Gumbel-Max (Plackett–Luce), K candidates; pick RTP-aware best"
        },
        plan: (r.planTarget != null && r.planHardCap != null) ? { target: r.planTarget, hardCap: r.planHardCap, slipCap: r.rtpSlipCap } : undefined
    };
}
