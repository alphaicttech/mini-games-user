import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

/**
 * Config
 */
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { minStake: 0.1, maxStake: 10000, maxBets: 30 };
const GAME_CODE = "baccarat";
const CANDIDATES_K = 6;

// stake-included return multipliers
const MULT = {
    PLAYER: 2.0,                 // 1:1
    BANKER_COMMISSION: 1.95,     // 1:1 less 5% commission
    BANKER_NO_COMM: 2.0,         // 1:1, except with 6 (see below)
    BANKER_NO_COMM_6: 1.5,       // banker wins with 6
    TIE_9to1: 10.0,              // 9:1 (return includes stake)
    PAIR_11to1: 12.0,            // 11:1
};

// Demo balance helpers
async function getDemoBalance(sess: ProviderSession) {
    const key = `demo:bal:${sess.sid}`;
    const v = await redis.get(key);
    if (v) return Number(v);
    const base = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(key, String(base), 2 * 60 * 60);
    return base;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
    await redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
}

// Provably-fair shuffle (Fisher–Yates w/ HMAC RNG)
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (server: string, client: string, i: number, tag: string) =>
    u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;

type Card = { rank: number; suit: number }; // rank: 0..12 (A..K), suit: 0..3 (♠♥♦♣)
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];

function buildShoe(decks = 8): Card[] {
    const one: Card[] = [];
    for (let s = 0; s < 4; s++) for (let r = 0; r < 13; r++) one.push({ rank: r, suit: s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => ({ ...c })));
}
function shuffleCards(cards: Card[], serverSeed: string, clientSeed: string, tag = "shoe"): Card[] {
    const arr = cards.slice();
    for (let k = arr.length - 1; k > 0; k--) {
        const r = r01(serverSeed, clientSeed, k, tag);
        const j = Math.floor(r * (k + 1));
        const tmp = arr[k]; arr[k] = arr[j]; arr[j] = tmp;
    }
    return arr;
}

/**
 * Baccarat math
 */
function cardVal10(rank: number) {
    if (rank === 0) return 1;            // Ace
    if (rank >= 1 && rank <= 8) return rank + 1; // 2..9
    return 0;                            // 10/J/Q/K
}
function total10(hand: Card[]) {
    const sum = hand.reduce((s, c) => s + cardVal10(c.rank), 0);
    return sum % 10;
}
function isPair(firstTwo: Card[]) { return firstTwo.length >= 2 && firstTwo[0].rank === firstTwo[1].rank; }

type DealResult = {
    player: Card[]; banker: Card[];
    totals: { player: number; banker: number };
    natural: boolean;
    thirdCardPlayer?: Card;
    thirdCardBanker?: Card;
};
function dealBaccarat(shoe: Card[]): DealResult {
    const draw = () => shoe.shift()!;
    const player: Card[] = [draw(), draw()];
    const banker: Card[] = [draw(), draw()];

    let pt = total10(player);
    let bt = total10(banker);
    const natural = (pt >= 8) || (bt >= 8);

    let thirdP: Card | undefined;
    let thirdB: Card | undefined;

    if (!natural) {
        if (pt <= 5) { thirdP = draw(); player.push(thirdP); pt = total10(player); }
        if (!thirdP) { // player stood
            if (bt <= 5) { thirdB = draw(); banker.push(thirdB); bt = total10(banker); }
        } else {
            const pv = cardVal10(thirdP.rank); const bt0 = bt;
            let drawBanker = false;
            if (bt0 <= 2) drawBanker = true;
            else if (bt0 === 3 && pv !== 8) drawBanker = true;
            else if (bt0 === 4 && pv >= 2 && pv <= 7) drawBanker = true;
            else if (bt0 === 5 && pv >= 4 && pv <= 7) drawBanker = true;
            else if (bt0 === 6 && (pv === 6 || pv === 7)) drawBanker = true;
            if (drawBanker) { thirdB = draw(); banker.push(thirdB); bt = total10(banker); }
        }
    }

    return { player, banker, totals: { player: pt, banker: bt }, natural, thirdCardPlayer: thirdP, thirdCardBanker: thirdB };
}
function outcome(t: { player: number; banker: number }): "PLAYER" | "BANKER" | "TIE" {
    if (t.player === t.banker) return "TIE";
    return (t.player > t.banker) ? "PLAYER" : "BANKER";
}

/**
 * RTP config & helpers
 */
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

/**
 * Idempotency (mode-scoped)
 */
const idemKey = (mode: "real" | "demo", sid: string, key: string) => `idem:${mode}:baccarat:deal:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(idemKey(mode, sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, key: string, payload: any) {
    await redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

/** Per-bet payout calc (returns stake-included payout, already clamped by per-bet caps) */
function resolveBet(
    b: { type: "PLAYER" | "BANKER" | "TIE" | "PLAYER_PAIR" | "BANKER_PAIR"; stake: number },
    who: "PLAYER" | "BANKER" | "TIE",
    playerPair: boolean,
    bankerPair: boolean,
    bankerWinWith6: boolean,
    variant: "commission" | "no_commission_6",
    caps: { per_bet_cap: number; per_user_daily_cap: number }
) {
    let mult = 0;
    switch (b.type) {
        case "PLAYER":
            if (who === "PLAYER") mult = MULT.PLAYER;
            else if (who === "TIE") mult = 1.0; // push on tie
            break;
        case "BANKER":
            if (who === "BANKER") {
                mult = (variant === "commission")
                    ? MULT.BANKER_COMMISSION
                    : (bankerWinWith6 ? MULT.BANKER_NO_COMM_6 : MULT.BANKER_NO_COMM);
            } else if (who === "TIE") {
                mult = 1.0; // push on tie
            }
            break;
        case "TIE":
            mult = (who === "TIE") ? MULT.TIE_9to1 : 0;
            break;
        case "PLAYER_PAIR":
            mult = playerPair ? MULT.PAIR_11to1 : 0;
            break;
        case "BANKER_PAIR":
            mult = bankerPair ? MULT.PAIR_11to1 : 0;
            break;
    }
    let payout = +(b.stake * mult).toFixed(2);
    // per-bet caps (include per_user_daily_cap)
    payout = Math.min(payout, caps.per_bet_cap, caps.per_user_daily_cap);
    return { ...b, return_multiplier: mult, payout };
}

/**
 * Simulate a candidate deal (provably fair) and compute capped slip total
 */
function simulateDeal(
    serverSeed: string,
    clientSeed: string,
    variant: "commission" | "no_commission_6",
    bets: Array<{ type: "PLAYER" | "BANKER" | "TIE" | "PLAYER_PAIR" | "BANKER_PAIR"; stake: number }>,
    caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number }
) {
    const shoe = shuffleCards(buildShoe(8), serverSeed, clientSeed, "baccarat");
    const d = dealBaccarat(shoe);
    const who = outcome(d.totals);
    const playerPair = isPair(d.player.slice(0, 2));
    const bankerPair = isPair(d.banker.slice(0, 2));
    const bankerWinWith6 = (who === "BANKER" && d.totals.banker === 6);

    const resolved = bets.map(b => resolveBet(b, who, playerPair, bankerPair, bankerWinWith6, variant, {
        per_bet_cap: caps.per_bet_cap,
        per_user_daily_cap: caps.per_user_daily_cap
    }));
    const total = +resolved.reduce((s, r) => s + r.payout, 0).toFixed(2);

    return { resolved, total, deal: d, who, playerPair, bankerPair, bankerWinWith6, serverSeedHash: sha256(serverSeed), serverSeed };
}

/**
 * Main service — RTP-aware Baccarat
 */
export async function doBaccaratDeal(
    sess: ProviderSession,
    input: {
        variant?: "commission" | "no_commission_6";
        client_seed?: string;
        bets: Array<{ type: "PLAYER" | "BANKER" | "TIE" | "PLAYER_PAIR" | "BANKER_PAIR"; stake: number }>;
    },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";

    // Idempotency replay
    if (idem) {
        const hit = await getIdem(mode, sess.sid, idem);
        if (hit) return hit;
    }

    // Validate
    if (!Array.isArray(input.bets) || input.bets.length === 0)
        throw AppError.badRequest("No bets");
    if (input.bets.length > LIMITS.maxBets)
        throw AppError.badRequest("Too many bets");
    for (const b of input.bets) {
        if (!(b.stake > 0)) throw AppError.badRequest("Invalid stake");
        if (b.stake < LIMITS.minStake) throw AppError.badRequest(`Min stake is ${LIMITS.minStake}`);
        if (b.stake > LIMITS.maxStake) throw AppError.badRequest(`Max stake is ${LIMITS.maxStake}`);
    }

    const variant = input.variant ?? "commission";
    const clientSeed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    const stakeTotal = +input.bets.reduce((s, b) => s + b.stake, 0).toFixed(2);
    const txnId = randomUUID();

    // Debit
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < stakeTotal) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - stakeTotal).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = {
            baseUrl: operator.baseUrl,
            secret: operator.secret,
            session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
        };
        const probeSeed = crypto.randomBytes(32).toString("hex"); // only for metadata hash
        const probeHash = sha256(probeSeed);
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: stakeTotal,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Baccarat",
                GameName: "Baccarat",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                Variant: variant,
                ServerSeedHash: probeHash,
                ClientSeed: clientSeed
            }
        });
    }

    // RTP: enter/plan (REAL only)
    const cfg = await loadGameCfg();
    let plan = { hardCap: 0, softCap: 0, target: 0 };
    let dayKey: string | undefined;
    let yymmdd = toYYMMDD();
    if (mode === "real") {
        dayKey = rk.day(GAME_CODE, yymmdd);
        await redis.hsetnx(dayKey, "rtp_target", 0.90);
        await redis.spEnter(dayKey, stakeTotal);
        plan = await spPlan(GAME_CODE, stakeTotal, cfg, yymmdd);
    } else {
        plan = demoPlan(stakeTotal, cfg);
    }

    // Pick best of K candidates (provably fair)
    let best: any = null;
    let bestScore = Number.POSITIVE_INFINITY;
    const perCaps = { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap };

    for (let k = 0; k < CANDIDATES_K; k++) {
        const serverSeed = crypto.randomBytes(32).toString("hex");
        const sim = simulateDeal(serverSeed, clientSeed, variant, input.bets, perCaps);

        const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
        const cappedTotal = Math.min(sim.total, slipCap);
        const overPenalty = sim.total > slipCap ? (sim.total - slipCap) * 10 : 0;
        const softPenalty = cappedTotal > plan.softCap ? (cappedTotal - plan.softCap) * 0.5 : 0;
        const score = Math.abs(cappedTotal - plan.target) + overPenalty + softPenalty;

        if (score < bestScore) {
            bestScore = score;
            best = { ...sim, total: +cappedTotal.toFixed(2), pickIdx: k };
        }
    }

    const payoutTotal = best.total;

    // RTP settle (REAL only)
    if (mode === "real" && dayKey) {
        await redis.spSettle(dayKey, stakeTotal, payoutTotal);
    }

    // Credit winners (if any)
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        await setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
    } else if (payoutTotal > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = {
            baseUrl: operator.baseUrl,
            secret: operator.secret,
            session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
        };
        await withdraw(opCtx, {
            TransactionId: `${txnId}-W`,
            TransactionType: "WinAmount",
            Amount: payoutTotal,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Baccarat",
                GameName: "Baccarat",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                Variant: variant,
                ServerSeed: best.serverSeed,
                ServerSeedHash: best.serverSeedHash,
                ClientSeed: clientSeed,
                Outcome: best.who,
                Totals: best.deal.totals,
                PlayerPair: best.playerPair,
                BankerPair: best.bankerPair
            }
        });
    }

    // Build response
    const fmtCard = (c: Card) => ({ rank: RANKS[c.rank], suit: SUITS[c.suit], val: cardVal10(c.rank) });

    const resp = {
        game: "Baccarat",
        mode,
        variant,
        txn_id: txnId,
        currency: sess.currency,
        stake_total: stakeTotal,
        hands: {
            player: best.deal.player.map(fmtCard),
            banker: best.deal.banker.map(fmtCard),
            totals: best.deal.totals,
            natural: best.deal.natural,
            third_card_player: best.deal.thirdCardPlayer ? fmtCard(best.deal.thirdCardPlayer) : undefined,
            third_card_banker: best.deal.thirdCardBanker ? fmtCard(best.deal.thirdCardBanker) : undefined,
        },
        result: {
            outcome: best.who,
            player_pair: best.playerPair,
            banker_pair: best.bankerPair,
            banker_win_with_6: (best.who === "BANKER" && best.deal.totals.banker === 6)
        },
        bets: best.resolved.map((r: any, i: number) => ({
            index: i,
            type: r.type,
            stake: r.stake,
            return_multiplier: r.return_multiplier,
            payout: r.payout
        })),
        slip: {
            payout_total: payoutTotal,
            profit_total: +(payoutTotal - stakeTotal).toFixed(2)
        },
        fairness: {
            method: `Pick K=${CANDIDATES_K} HMAC-shuffled 8-deck shoes; choose deal closest to RTP target and ≤ hard cap`,
            server_seed_hash: best.serverSeedHash,
            server_seed: best.serverSeed,   // revealed post-resolution
            client_seed: clientSeed,
            pick_index: best.pickIdx
        },
        plan
    };

    if (idem) await setIdem(mode, sess.sid, idem, resp);
    return resp;
}
