// /var/www/typesafe/alpha-mini/src/modules/games/baccarat/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { doBaccaratDeal } from "./service";

const BetType = z.enum(["PLAYER", "BANKER", "TIE", "PLAYER_PAIR", "BANKER_PAIR"]);
const Variant = z.enum(["commission", "no_commission_6"]);

const Bet = z.object({
    type: BetType,
    stake: z.number().positive(),
});

const DealBody = z.object({
    variant: Variant.default("commission").optional(),
    client_seed: z.string().min(1).optional(),
    bets: z.array(Bet).min(1).max(30),
});

export const dealValidate = validateBody(DealBody);

export const deal = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const body = req.body as z.infer<typeof DealBody>;
    const data = await doBaccaratDeal(sess, body, idemKey);

    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});
