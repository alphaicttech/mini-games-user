"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.doBaccaratDeal = doBaccaratDeal;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
/**
 * Config
 */
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { minStake: 0.1, maxStake: 10000, maxBets: 30 };
const GAME_CODE = "baccarat";
const CANDIDATES_K = 6;
// stake-included return multipliers
const MULT = {
    PLAYER: 2.0, // 1:1
    BANKER_COMMISSION: 1.95, // 1:1 less 5% commission
    BANKER_NO_COMM: 2.0, // 1:1, except with 6 (see below)
    BANKER_NO_COMM_6: 1.5, // banker wins with 6
    TIE_9to1: 10.0, // 9:1 (return includes stake)
    PAIR_11to1: 12.0, // 11:1
};
// Demo balance helpers
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const key = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(key);
        if (v)
            return Number(v);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(key, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
    });
}
// Provably-fair shuffle (Fisher–Yates w/ HMAC RNG)
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, i, tag) => u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];
function buildShoe(decks = 8) {
    const one = [];
    for (let s = 0; s < 4; s++)
        for (let r = 0; r < 13; r++)
            one.push({ rank: r, suit: s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => (Object.assign({}, c))));
}
function shuffleCards(cards, serverSeed, clientSeed, tag = "shoe") {
    const arr = cards.slice();
    for (let k = arr.length - 1; k > 0; k--) {
        const r = r01(serverSeed, clientSeed, k, tag);
        const j = Math.floor(r * (k + 1));
        const tmp = arr[k];
        arr[k] = arr[j];
        arr[j] = tmp;
    }
    return arr;
}
/**
 * Baccarat math
 */
function cardVal10(rank) {
    if (rank === 0)
        return 1; // Ace
    if (rank >= 1 && rank <= 8)
        return rank + 1; // 2..9
    return 0; // 10/J/Q/K
}
function total10(hand) {
    const sum = hand.reduce((s, c) => s + cardVal10(c.rank), 0);
    return sum % 10;
}
function isPair(firstTwo) { return firstTwo.length >= 2 && firstTwo[0].rank === firstTwo[1].rank; }
function dealBaccarat(shoe) {
    const draw = () => shoe.shift();
    const player = [draw(), draw()];
    const banker = [draw(), draw()];
    let pt = total10(player);
    let bt = total10(banker);
    const natural = (pt >= 8) || (bt >= 8);
    let thirdP;
    let thirdB;
    if (!natural) {
        if (pt <= 5) {
            thirdP = draw();
            player.push(thirdP);
            pt = total10(player);
        }
        if (!thirdP) { // player stood
            if (bt <= 5) {
                thirdB = draw();
                banker.push(thirdB);
                bt = total10(banker);
            }
        }
        else {
            const pv = cardVal10(thirdP.rank);
            const bt0 = bt;
            let drawBanker = false;
            if (bt0 <= 2)
                drawBanker = true;
            else if (bt0 === 3 && pv !== 8)
                drawBanker = true;
            else if (bt0 === 4 && pv >= 2 && pv <= 7)
                drawBanker = true;
            else if (bt0 === 5 && pv >= 4 && pv <= 7)
                drawBanker = true;
            else if (bt0 === 6 && (pv === 6 || pv === 7))
                drawBanker = true;
            if (drawBanker) {
                thirdB = draw();
                banker.push(thirdB);
                bt = total10(banker);
            }
        }
    }
    return { player, banker, totals: { player: pt, banker: bt }, natural, thirdCardPlayer: thirdP, thirdCardBanker: thirdB };
}
function outcome(t) {
    if (t.player === t.banker)
        return "TIE";
    return (t.player > t.banker) ? "PLAYER" : "BANKER";
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function demoPlan(totalStake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
/**
 * Idempotency (mode-scoped)
 */
const idemKey = (mode, sid, key) => `idem:${mode}:baccarat:deal:${sid}:${key}`;
function getIdem(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(idemKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
/** Per-bet payout calc (returns stake-included payout, already clamped by per-bet caps) */
function resolveBet(b, who, playerPair, bankerPair, bankerWinWith6, variant, caps) {
    let mult = 0;
    switch (b.type) {
        case "PLAYER":
            if (who === "PLAYER")
                mult = MULT.PLAYER;
            else if (who === "TIE")
                mult = 1.0; // push on tie
            break;
        case "BANKER":
            if (who === "BANKER") {
                mult = (variant === "commission")
                    ? MULT.BANKER_COMMISSION
                    : (bankerWinWith6 ? MULT.BANKER_NO_COMM_6 : MULT.BANKER_NO_COMM);
            }
            else if (who === "TIE") {
                mult = 1.0; // push on tie
            }
            break;
        case "TIE":
            mult = (who === "TIE") ? MULT.TIE_9to1 : 0;
            break;
        case "PLAYER_PAIR":
            mult = playerPair ? MULT.PAIR_11to1 : 0;
            break;
        case "BANKER_PAIR":
            mult = bankerPair ? MULT.PAIR_11to1 : 0;
            break;
    }
    let payout = +(b.stake * mult).toFixed(2);
    // per-bet caps (include per_user_daily_cap)
    payout = Math.min(payout, caps.per_bet_cap, caps.per_user_daily_cap);
    return Object.assign(Object.assign({}, b), { return_multiplier: mult, payout });
}
/**
 * Simulate a candidate deal (provably fair) and compute capped slip total
 */
function simulateDeal(serverSeed, clientSeed, variant, bets, caps) {
    const shoe = shuffleCards(buildShoe(8), serverSeed, clientSeed, "baccarat");
    const d = dealBaccarat(shoe);
    const who = outcome(d.totals);
    const playerPair = isPair(d.player.slice(0, 2));
    const bankerPair = isPair(d.banker.slice(0, 2));
    const bankerWinWith6 = (who === "BANKER" && d.totals.banker === 6);
    const resolved = bets.map(b => resolveBet(b, who, playerPair, bankerPair, bankerWinWith6, variant, {
        per_bet_cap: caps.per_bet_cap,
        per_user_daily_cap: caps.per_user_daily_cap
    }));
    const total = +resolved.reduce((s, r) => s + r.payout, 0).toFixed(2);
    return { resolved, total, deal: d, who, playerPair, bankerPair, bankerWinWith6, serverSeedHash: sha256(serverSeed), serverSeed };
}
/**
 * Main service — RTP-aware Baccarat
 */
function doBaccaratDeal(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        // Idempotency replay
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, idem);
            if (hit)
                return hit;
        }
        // Validate
        if (!Array.isArray(input.bets) || input.bets.length === 0)
            throw errors_1.AppError.badRequest("No bets");
        if (input.bets.length > LIMITS.maxBets)
            throw errors_1.AppError.badRequest("Too many bets");
        for (const b of input.bets) {
            if (!(b.stake > 0))
                throw errors_1.AppError.badRequest("Invalid stake");
            if (b.stake < LIMITS.minStake)
                throw errors_1.AppError.badRequest(`Min stake is ${LIMITS.minStake}`);
            if (b.stake > LIMITS.maxStake)
                throw errors_1.AppError.badRequest(`Max stake is ${LIMITS.maxStake}`);
        }
        const variant = (_a = input.variant) !== null && _a !== void 0 ? _a : "commission";
        const clientSeed = (_d = (_c = (_b = input.client_seed) !== null && _b !== void 0 ? _b : sess.clientExternalKey) !== null && _c !== void 0 ? _c : sess.userName) !== null && _d !== void 0 ? _d : "client";
        const stakeTotal = +input.bets.reduce((s, b) => s + b.stake, 0).toFixed(2);
        const txnId = (0, crypto_1.randomUUID)();
        // Debit
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < stakeTotal)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - stakeTotal).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_e = sess.opSessionId) !== null && _e !== void 0 ? _e : sess.sessionId;
            const opCtx = {
                baseUrl: operator.baseUrl,
                secret: operator.secret,
                session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            const probeSeed = crypto_1.default.randomBytes(32).toString("hex"); // only for metadata hash
            const probeHash = sha256(probeSeed);
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: stakeTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Baccarat",
                    GameName: "Baccarat",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    Variant: variant,
                    ServerSeedHash: probeHash,
                    ClientSeed: clientSeed
                }
            });
        }
        // RTP: enter/plan (REAL only)
        const cfg = yield loadGameCfg();
        let plan = { hardCap: 0, softCap: 0, target: 0 };
        let dayKey;
        let yymmdd = (0, date_1.toYYMMDD)();
        if (mode === "real") {
            dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_1.redis.hsetnx(dayKey, "rtp_target", 0.90);
            yield redis_1.redis.spEnter(dayKey, stakeTotal);
            plan = yield (0, governor_1.spPlan)(GAME_CODE, stakeTotal, cfg, yymmdd);
        }
        else {
            plan = demoPlan(stakeTotal, cfg);
        }
        // Pick best of K candidates (provably fair)
        let best = null;
        let bestScore = Number.POSITIVE_INFINITY;
        const perCaps = { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap };
        for (let k = 0; k < CANDIDATES_K; k++) {
            const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
            const sim = simulateDeal(serverSeed, clientSeed, variant, input.bets, perCaps);
            const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            const cappedTotal = Math.min(sim.total, slipCap);
            const overPenalty = sim.total > slipCap ? (sim.total - slipCap) * 10 : 0;
            const softPenalty = cappedTotal > plan.softCap ? (cappedTotal - plan.softCap) * 0.5 : 0;
            const score = Math.abs(cappedTotal - plan.target) + overPenalty + softPenalty;
            if (score < bestScore) {
                bestScore = score;
                best = Object.assign(Object.assign({}, sim), { total: +cappedTotal.toFixed(2), pickIdx: k });
            }
        }
        const payoutTotal = best.total;
        // RTP settle (REAL only)
        if (mode === "real" && dayKey) {
            yield redis_1.redis.spSettle(dayKey, stakeTotal, payoutTotal);
        }
        // Credit winners (if any)
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            yield setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
        }
        else if (payoutTotal > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_f = sess.opSessionId) !== null && _f !== void 0 ? _f : sess.sessionId;
            const opCtx = {
                baseUrl: operator.baseUrl,
                secret: operator.secret,
                session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${txnId}-W`,
                TransactionType: "WinAmount",
                Amount: payoutTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Baccarat",
                    GameName: "Baccarat",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    Variant: variant,
                    ServerSeed: best.serverSeed,
                    ServerSeedHash: best.serverSeedHash,
                    ClientSeed: clientSeed,
                    Outcome: best.who,
                    Totals: best.deal.totals,
                    PlayerPair: best.playerPair,
                    BankerPair: best.bankerPair
                }
            });
        }
        // Build response
        const fmtCard = (c) => ({ rank: RANKS[c.rank], suit: SUITS[c.suit], val: cardVal10(c.rank) });
        const resp = {
            game: "Baccarat",
            mode,
            variant,
            txn_id: txnId,
            currency: sess.currency,
            stake_total: stakeTotal,
            hands: {
                player: best.deal.player.map(fmtCard),
                banker: best.deal.banker.map(fmtCard),
                totals: best.deal.totals,
                natural: best.deal.natural,
                third_card_player: best.deal.thirdCardPlayer ? fmtCard(best.deal.thirdCardPlayer) : undefined,
                third_card_banker: best.deal.thirdCardBanker ? fmtCard(best.deal.thirdCardBanker) : undefined,
            },
            result: {
                outcome: best.who,
                player_pair: best.playerPair,
                banker_pair: best.bankerPair,
                banker_win_with_6: (best.who === "BANKER" && best.deal.totals.banker === 6)
            },
            bets: best.resolved.map((r, i) => ({
                index: i,
                type: r.type,
                stake: r.stake,
                return_multiplier: r.return_multiplier,
                payout: r.payout
            })),
            slip: {
                payout_total: payoutTotal,
                profit_total: +(payoutTotal - stakeTotal).toFixed(2)
            },
            fairness: {
                method: `Pick K=${CANDIDATES_K} HMAC-shuffled 8-deck shoes; choose deal closest to RTP target and ≤ hard cap`,
                server_seed_hash: best.serverSeedHash,
                server_seed: best.serverSeed, // revealed post-resolution
                client_seed: clientSeed,
                pick_index: best.pickIdx
            },
            plan
        };
        if (idem)
            yield setIdem(mode, sess.sid, idem, resp);
        return resp;
    });
}
