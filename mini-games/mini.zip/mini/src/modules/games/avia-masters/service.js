"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.spinAvia = spinAvia;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
/** ---------- config ---------- */
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { min: 0.1, max: 10000 };
const GAME_CODE = "avia-masters";
const CANDIDATES_K = 6;
const PRESETS = {
    slow: { maxSteps: 20, p: { plus: .40, times: .20, minus: .15, div: .10, rocket: .05, land: .10 }, plusRange: [.05, .20], timesRange: [1.05, 1.40], minusRange: [.03, .10], divRange: [1.05, 1.20], boatProb: .65, multFloor: .5, multCeil: 6 },
    normal: { maxSteps: 24, p: { plus: .35, times: .25, minus: .15, div: .10, rocket: .05, land: .10 }, plusRange: [.05, .25], timesRange: [1.05, 1.60], minusRange: [.04, .12], divRange: [1.05, 1.25], boatProb: .60, multFloor: .5, multCeil: 8 },
    fast: { maxSteps: 28, p: { plus: .30, times: .30, minus: .15, div: .10, rocket: .07, land: .08 }, plusRange: [.08, .30], timesRange: [1.10, 1.85], minusRange: [.05, .16], divRange: [1.08, 1.30], boatProb: .58, multFloor: .5, multCeil: 12 },
    turbo: { maxSteps: 32, p: { plus: .28, times: .33, minus: .15, div: .12, rocket: .08, land: .04 }, plusRange: [.10, .35], timesRange: [1.15, 2.10], minusRange: [.06, .18], divRange: [1.10, 1.35], boatProb: .55, multFloor: .5, multCeil: 18 },
};
/** ---------- helpers ---------- */
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (srv, cli, i, tag) => u32(hmacHex(srv, `${cli}:${i}:${tag}`).slice(0, 8)) / 0xffffffff;
const rRange = (srv, cli, i, tag, [a, b]) => a + (b - a) * r01(srv, cli, i, tag);
// demo ledger helpers
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const k = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(k);
        if (v)
            return Number(v);
        const start = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(k, String(start), 2 * 60 * 60);
        return start;
    });
}
function setDemoBalance(sess, amt) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60);
    });
}
// idempotency (mode-scoped)
const idemKey = (mode, sid, k) => `idem:${mode}:avia:spin:${sid}:${k}`;
function getIdem(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(idemKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function demoPlan(totalStake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
/** Build deterministic animation script & compute final payout for a given serverSeed */
function simulateSpin(serverSeed, clientSeed, speed, amount, caps) {
    const preset = PRESETS[speed];
    let mult = 1.0;
    const script = [];
    for (let step = 1; step <= preset.maxSteps; step++) {
        const p = preset.p;
        const roll = r01(serverSeed, clientSeed, step, "ev");
        let ev;
        if (roll < p.plus)
            ev = "PLUS";
        else if (roll < p.plus + p.times)
            ev = "TIMES";
        else if (roll < p.plus + p.times + p.minus)
            ev = "MINUS";
        else if (roll < p.plus + p.times + p.minus + p.div)
            ev = "DIV";
        else if (roll < p.plus + p.times + p.minus + p.div + p.rocket)
            ev = "ROCKET";
        else
            ev = "LAND";
        if (ev === "PLUS") {
            const inc = +rRange(serverSeed, clientSeed, step, "plus", preset.plusRange).toFixed(2);
            mult = +(mult + inc).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "+", delta: inc, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "TIMES") {
            const factor = +rRange(serverSeed, clientSeed, step, "times", preset.timesRange).toFixed(2);
            mult = +(mult * factor).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "x", factor, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "MINUS") {
            const dec = +rRange(serverSeed, clientSeed, step, "minus", preset.minusRange).toFixed(2);
            mult = +(mult - dec).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "-", delta: dec, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "DIV") {
            const div = +rRange(serverSeed, clientSeed, step, "div", preset.divRange).toFixed(2);
            mult = +(mult / div).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "/", divisor: div, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "ROCKET") {
            mult = +(mult * 0.5).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "rocket", effect: "halve", multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        break; // LAND
    }
    // BOAT vs WATER
    const boatRoll = r01(serverSeed, clientSeed, 999, "boat");
    const landedOnBoat = boatRoll < PRESETS[speed].boatProb;
    const finalMultiplier = +(+mult.toFixed(2));
    let payout = landedOnBoat ? +(amount * finalMultiplier).toFixed(2) : 0;
    // per-bet/ user caps
    payout = Math.min(payout, caps.per_bet_cap, caps.per_user_daily_cap);
    return {
        script,
        landedOnBoat,
        finalMultiplier,
        payout,
        serverSeed,
        serverSeedHash: sha256(serverSeed),
    };
}
function spinAvia(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        // idem
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, idem);
            if (hit)
                return hit;
        }
        // validate
        if (input.amount < LIMITS.min)
            throw errors_1.AppError.badRequest(`Min bet is ${LIMITS.min}`);
        if (input.amount > LIMITS.max)
            throw errors_1.AppError.badRequest(`Max bet is ${LIMITS.max}`);
        // seeds (client)
        const clientSeed = (_c = (_b = (_a = input.clientSeed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        const txnId = (0, crypto_1.randomUUID)();
        // debit
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < input.amount)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - input.amount).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_d = sess.opSessionId) !== null && _d !== void 0 ? _d : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            // send a probe hash in metadata (we'll reveal actual seed chosen later)
            const probeSeed = crypto_1.default.randomBytes(32).toString("hex");
            const probeHash = sha256(probeSeed);
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: input.amount,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Avia", GameName: "AviaNode", RoundId: txnId, GameNumber: Date.now().toString(),
                    ServerSeedHash: probeHash, ClientSeed: clientSeed
                }
            });
        }
        // RTP enter/plan (REAL only)
        const cfg = yield loadGameCfg();
        let plan = { hardCap: 0, softCap: 0, target: 0 };
        let dayKey;
        let yymmdd = (0, date_1.toYYMMDD)();
        if (mode === "real") {
            dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_1.redis.hsetnx(dayKey, "rtp_target", 0.90);
            yield redis_1.redis.spEnter(dayKey, input.amount);
            plan = yield (0, governor_1.spPlan)(GAME_CODE, input.amount, cfg, yymmdd);
        }
        else {
            plan = demoPlan(input.amount, cfg);
        }
        // Simulate K candidate server seeds; pick best vs target but ≤ hardCap (also apply per-ticket/user caps)
        const perCaps = { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap };
        let best = null;
        let bestScore = Number.POSITIVE_INFINITY;
        for (let k = 0; k < CANDIDATES_K; k++) {
            const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
            const sim = simulateSpin(serverSeed, clientSeed, input.speed, input.amount, perCaps);
            const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            const capped = Math.min(sim.payout, slipCap);
            const overPenalty = sim.payout > slipCap ? (sim.payout - slipCap) * 10 : 0;
            const softPenalty = capped > plan.softCap ? (capped - plan.softCap) * 0.5 : 0;
            const score = Math.abs(capped - plan.target) + overPenalty + softPenalty;
            if (score < bestScore) {
                bestScore = score;
                best = Object.assign(Object.assign({}, sim), { payout: +capped.toFixed(2), pickIdx: k });
            }
        }
        const payout = best.payout;
        // RTP settle (REAL only)
        if (mode === "real" && dayKey) {
            yield redis_1.redis.spSettle(dayKey, input.amount, payout);
        }
        // credit (REAL win only)
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            yield setDemoBalance(sess, +(bal + payout).toFixed(2));
        }
        else if (payout > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_e = sess.opSessionId) !== null && _e !== void 0 ? _e : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${txnId}-W`,
                TransactionType: "WinAmount",
                Amount: payout,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Avia", GameName: "AviaNode", RoundId: txnId, GameNumber: Date.now().toString(),
                    ServerSeed: best.serverSeed, ServerSeedHash: best.serverSeedHash, ClientSeed: clientSeed,
                    FinalMultiplier: best.finalMultiplier
                }
            });
        }
        // Response: final outcome + animation script (from chosen candidate)
        const response = {
            game: "Avia",
            mode,
            txn_id: txnId,
            round_id: txnId,
            stake: input.amount,
            currency: sess.currency,
            speed: input.speed,
            result: best.landedOnBoat
                ? { outcome: "boat", final_multiplier: best.finalMultiplier, payout }
                : { outcome: "water", final_multiplier: best.finalMultiplier, payout: 0 },
            animation: {
                seed_hash: sha256(`${best.serverSeedHash}|script|${txnId}`),
                est_duration_sec: +(best.script.length * 0.25).toFixed(2),
                steps: best.script
            },
            fairness: {
                method: `Per-step HMAC-SHA256(server_seed, \`${clientSeed}:{step}:{tag}\`); pick K=${CANDIDATES_K} seeds vs RTP target`,
                server_seed_hash: best.serverSeedHash,
                server_seed: best.serverSeed, // reveal immediately (spin is resolved)
                client_seed: clientSeed,
                pick_index: best.pickIdx
            },
            plan
        };
        if (idem)
            yield setIdem(mode, sess.sid, idem, response);
        return response;
    });
}
