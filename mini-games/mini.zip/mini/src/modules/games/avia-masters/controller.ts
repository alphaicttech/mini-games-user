// /var/www/typesafe/alpha-mini/src/modules/games/avia-masters/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { spinAvia } from "./service";

const SpinBody = z.object({
    amount: z.number().positive(),
    speed: z.enum(["slow", "normal", "fast", "turbo"]).default("normal"),
    client_seed: z.string().min(1).optional()
});
export const spinValidate = validateBody(SpinBody);

export const spin = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { amount, speed, client_seed } = req.body as z.infer<typeof SpinBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await spinAvia(sess, { amount, speed, clientSeed: client_seed }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});
