import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

/** ---------- config ---------- */
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { min: 0.1, max: 10000 };
const GAME_CODE = "avia-masters";
const CANDIDATES_K = 6;

// Speed presets: controls volatility & visual script
type Speed = "slow" | "normal" | "fast" | "turbo";
const PRESETS: Record<Speed, {
    maxSteps: number;
    p: { plus: number; times: number; minus: number; div: number; rocket: number; land: number };
    plusRange: [number, number];
    timesRange: [number, number];
    minusRange: [number, number];
    divRange: [number, number];
    boatProb: number;   // prob of "boat" (win) vs "water" (loss)
    multFloor: number;  // floor for visual multiplier during script
    multCeil: number;   // soft visual cap (informational)
}> = {
    slow: { maxSteps: 20, p: { plus: .40, times: .20, minus: .15, div: .10, rocket: .05, land: .10 }, plusRange: [.05, .20], timesRange: [1.05, 1.40], minusRange: [.03, .10], divRange: [1.05, 1.20], boatProb: .65, multFloor: .5, multCeil: 6 },
    normal: { maxSteps: 24, p: { plus: .35, times: .25, minus: .15, div: .10, rocket: .05, land: .10 }, plusRange: [.05, .25], timesRange: [1.05, 1.60], minusRange: [.04, .12], divRange: [1.05, 1.25], boatProb: .60, multFloor: .5, multCeil: 8 },
    fast: { maxSteps: 28, p: { plus: .30, times: .30, minus: .15, div: .10, rocket: .07, land: .08 }, plusRange: [.08, .30], timesRange: [1.10, 1.85], minusRange: [.05, .16], divRange: [1.08, 1.30], boatProb: .58, multFloor: .5, multCeil: 12 },
    turbo: { maxSteps: 32, p: { plus: .28, times: .33, minus: .15, div: .12, rocket: .08, land: .04 }, plusRange: [.10, .35], timesRange: [1.15, 2.10], minusRange: [.06, .18], divRange: [1.10, 1.35], boatProb: .55, multFloor: .5, multCeil: 18 },
};

/** ---------- helpers ---------- */
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (srv: string, cli: string, i: number, tag: string) =>
    u32(hmacHex(srv, `${cli}:${i}:${tag}`).slice(0, 8)) / 0xffffffff;
const rRange = (srv: string, cli: string, i: number, tag: string, [a, b]: [number, number]) =>
    a + (b - a) * r01(srv, cli, i, tag);

// demo ledger helpers
async function getDemoBalance(sess: ProviderSession) {
    const k = `demo:bal:${sess.sid}`;
    const v = await redis.get(k);
    if (v) return Number(v);
    const start = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(k, String(start), 2 * 60 * 60);
    return start;
}
async function setDemoBalance(sess: ProviderSession, amt: number) {
    await redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60);
}

// idempotency (mode-scoped)
const idemKey = (mode: "real" | "demo", sid: string, k: string) => `idem:${mode}:avia:spin:${sid}:${k}`;
async function getIdem(mode: "real" | "demo", sid: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(idemKey(mode, sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, key: string, payload: any) {
    await redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

// RTP cfg + demo plan
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

/** Build deterministic animation script & compute final payout for a given serverSeed */
function simulateSpin(
    serverSeed: string,
    clientSeed: string,
    speed: Speed,
    amount: number,
    caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number }
) {
    const preset = PRESETS[speed];
    let mult = 1.0;
    const script: Array<
        | { t: number; event: "+"; delta: number; multiplier: number }
        | { t: number; event: "x"; factor: number; multiplier: number }
        | { t: number; event: "-"; delta: number; multiplier: number }
        | { t: number; event: "/"; divisor: number; multiplier: number }
        | { t: number; event: "rocket"; effect: "halve"; multiplier: number }
    > = [];

    for (let step = 1; step <= preset.maxSteps; step++) {
        const p = preset.p;
        const roll = r01(serverSeed, clientSeed, step, "ev");
        let ev: "PLUS" | "TIMES" | "MINUS" | "DIV" | "ROCKET" | "LAND";
        if (roll < p.plus) ev = "PLUS";
        else if (roll < p.plus + p.times) ev = "TIMES";
        else if (roll < p.plus + p.times + p.minus) ev = "MINUS";
        else if (roll < p.plus + p.times + p.minus + p.div) ev = "DIV";
        else if (roll < p.plus + p.times + p.minus + p.div + p.rocket) ev = "ROCKET";
        else ev = "LAND";

        if (ev === "PLUS") {
            const inc = +rRange(serverSeed, clientSeed, step, "plus", preset.plusRange).toFixed(2);
            mult = +(mult + inc).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "+", delta: inc, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "TIMES") {
            const factor = +rRange(serverSeed, clientSeed, step, "times", preset.timesRange).toFixed(2);
            mult = +(mult * factor).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "x", factor, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "MINUS") {
            const dec = +rRange(serverSeed, clientSeed, step, "minus", preset.minusRange).toFixed(2);
            mult = +(mult - dec).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "-", delta: dec, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "DIV") {
            const div = +rRange(serverSeed, clientSeed, step, "div", preset.divRange).toFixed(2);
            mult = +(mult / div).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "/", divisor: div, multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        if (ev === "ROCKET") {
            mult = +(mult * 0.5).toFixed(4);
            mult = Math.max(mult, preset.multFloor);
            script.push({ t: step * 0.25, event: "rocket", effect: "halve", multiplier: +(+mult.toFixed(2)) });
            continue;
        }
        break; // LAND
    }

    // BOAT vs WATER
    const boatRoll = r01(serverSeed, clientSeed, 999, "boat");
    const landedOnBoat = boatRoll < PRESETS[speed].boatProb;
    const finalMultiplier = +(+mult.toFixed(2));
    let payout = landedOnBoat ? +(amount * finalMultiplier).toFixed(2) : 0;

    // per-bet/ user caps
    payout = Math.min(payout, caps.per_bet_cap, caps.per_user_daily_cap);

    return {
        script,
        landedOnBoat,
        finalMultiplier,
        payout,
        serverSeed,
        serverSeedHash: sha256(serverSeed),
    };
}

type SpinInput = { amount: number; speed: Speed; clientSeed?: string };

export async function spinAvia(sess: ProviderSession, input: SpinInput, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";

    // idem
    if (idem) { const hit = await getIdem(mode, sess.sid, idem); if (hit) return hit; }

    // validate
    if (input.amount < LIMITS.min) throw AppError.badRequest(`Min bet is ${LIMITS.min}`);
    if (input.amount > LIMITS.max) throw AppError.badRequest(`Max bet is ${LIMITS.max}`);

    // seeds (client)
    const clientSeed = input.clientSeed ?? sess.clientExternalKey ?? sess.userName ?? "client";
    const txnId = randomUUID();

    // debit
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < input.amount) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - input.amount).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        // send a probe hash in metadata (we'll reveal actual seed chosen later)
        const probeSeed = crypto.randomBytes(32).toString("hex");
        const probeHash = sha256(probeSeed);
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: input.amount,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Avia", GameName: "AviaNode", RoundId: txnId, GameNumber: Date.now().toString(),
                ServerSeedHash: probeHash, ClientSeed: clientSeed
            }
        });
    }

    // RTP enter/plan (REAL only)
    const cfg = await loadGameCfg();
    let plan = { hardCap: 0, softCap: 0, target: 0 };
    let dayKey: string | undefined;
    let yymmdd = toYYMMDD();
    if (mode === "real") {
        dayKey = rk.day(GAME_CODE, yymmdd);
        await redis.hsetnx(dayKey, "rtp_target", 0.90);
        await redis.spEnter(dayKey, input.amount);
        plan = await spPlan(GAME_CODE, input.amount, cfg, yymmdd);
    } else {
        plan = demoPlan(input.amount, cfg);
    }

    // Simulate K candidate server seeds; pick best vs target but ≤ hardCap (also apply per-ticket/user caps)
    const perCaps = { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap };
    let best: any = null;
    let bestScore = Number.POSITIVE_INFINITY;

    for (let k = 0; k < CANDIDATES_K; k++) {
        const serverSeed = crypto.randomBytes(32).toString("hex");
        const sim = simulateSpin(serverSeed, clientSeed, input.speed, input.amount, perCaps);

        const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
        const capped = Math.min(sim.payout, slipCap);
        const overPenalty = sim.payout > slipCap ? (sim.payout - slipCap) * 10 : 0;
        const softPenalty = capped > plan.softCap ? (capped - plan.softCap) * 0.5 : 0;
        const score = Math.abs(capped - plan.target) + overPenalty + softPenalty;

        if (score < bestScore) {
            bestScore = score;
            best = { ...sim, payout: +capped.toFixed(2), pickIdx: k };
        }
    }

    const payout = best.payout;

    // RTP settle (REAL only)
    if (mode === "real" && dayKey) {
        await redis.spSettle(dayKey, input.amount, payout);
    }

    // credit (REAL win only)
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        await setDemoBalance(sess, +(bal + payout).toFixed(2));
    } else if (payout > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: `${txnId}-W`,
            TransactionType: "WinAmount",
            Amount: payout,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Avia", GameName: "AviaNode", RoundId: txnId, GameNumber: Date.now().toString(),
                ServerSeed: best.serverSeed, ServerSeedHash: best.serverSeedHash, ClientSeed: clientSeed,
                FinalMultiplier: best.finalMultiplier
            }
        });
    }

    // Response: final outcome + animation script (from chosen candidate)
    const response = {
        game: "Avia",
        mode,
        txn_id: txnId,
        round_id: txnId,
        stake: input.amount,
        currency: sess.currency,
        speed: input.speed,
        result: best.landedOnBoat
            ? { outcome: "boat" as const, final_multiplier: best.finalMultiplier, payout }
            : { outcome: "water" as const, final_multiplier: best.finalMultiplier, payout: 0 },
        animation: {
            seed_hash: sha256(`${best.serverSeedHash}|script|${txnId}`),
            est_duration_sec: +(best.script.length * 0.25).toFixed(2),
            steps: best.script
        },
        fairness: {
            method: `Per-step HMAC-SHA256(server_seed, \`${clientSeed}:{step}:{tag}\`); pick K=${CANDIDATES_K} seeds vs RTP target`,
            server_seed_hash: best.serverSeedHash,
            server_seed: best.serverSeed, // reveal immediately (spin is resolved)
            client_seed: clientSeed,
            pick_index: best.pickIdx
        },
        plan
    };

    if (idem) await setIdem(mode, sess.sid, idem, response);
    return response;
}
