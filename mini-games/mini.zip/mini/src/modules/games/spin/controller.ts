// /var/www/typesafe/alpha-mini/src/modules/games/spin/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { spinWheel } from "./service";

const BetType = z.enum([
    "STRAIGHT", "SPLIT", "STREET", "CORNER", "SIX_LINE", "FIRST_FOUR",
    "DOZEN", "COLUMN", "RED", "BLACK", "EVEN", "ODD", "LOW", "HIGH"
]);

// Accepts an array of heterogeneous bets (each with its own stake)
const Bet = z.object({
    type: BetType,
    stake: z.number().positive(),
    // Inside-bet payloads
    numbers: z.array(z.number().int().min(0).max(36)).optional(),   // STRAIGHT (len1), SPLIT(2), STREET(3), CORNER(4), SIX_LINE(6), FIRST_FOUR(4 = [0,1,2,3])
    // Outside selectors
    dozen: z.enum(["1", "2", "3"]).transform(Number).optional(),      // DOZEN 1..12, 13..24, 25..36
    column: z.enum(["1", "2", "3"]).transform(Number).optional(),     // COLUMN (1st, 2nd, 3rd)
});

const SpinBody = z.object({
    client_seed: z.string().min(1).optional(),
    zero_rule: z.enum(["lose", "la_partage"]).default("lose"), // optional rule for even-money when 0 hits
    bets: z.array(Bet).min(1),
});
export const spinValidate = validateBody(SpinBody);

export const spin = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const body = req.body as z.infer<typeof SpinBody>;
    const data = await spinWheel(sess, body, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});
