import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

/** ---------------------------- Config & Global Constants ---------------------------- */
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { minBet: 0.1, maxBet: 10000, maxSlipBets: 100 };
const CANDIDATES_K = 6;

export type OutsideZeroRule = "lose" | "la_partage";
export const ZERO_RULE_DEFAULT: OutsideZeroRule = "lose";

/**
 * With our “return includes stake” convention:
 *   1.0 = stake back (net 0) for la_partage on even-money bets when 0 hits.
 */
const LA_PARTAGE_RETURN_MULT = 1.0;

const REDS = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);

// Return multipliers (stake INCLUDED)
const RETURN_MULT = {
    ZERO: 36,        // explicit zero
    STRAIGHT: 36,
    SPLIT: 18,
    STREET: 12,
    CORNER: 9,
    SIX_LINE: 6,
    FIRST_FOUR: 9,   // 8:1 profit -> 9x return
    DOZEN: 3,
    COLUMN: 3,
    EVEN_MONEY: 2,   // RED/BLACK, EVEN/ODD, LOW/HIGH
};

/** ---------------------------- Provably Fair RNG ---------------------------- */
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (srv: string, cli: string, tag: string) => u32(hmacHex(srv, `${cli}:${tag}`).slice(0, 8)) / 0xffffffff;

/** ---------------------------- Board Geometry & Validators ---------------------------- */
function isRed(n: number) { return REDS.has(n); }
function colOf(n: number) { if (n === 0) return 0; return ((n - 1) % 3) + 1 as 1 | 2 | 3; }
function dozenOf(n: number) { if (n === 0) return 0; return (Math.floor((n - 1) / 12) + 1) as 1 | 2 | 3; }
function rowOf(n: number) { if (n === 0) return -1; return Math.floor((n - 1) / 3); } // 0..11

function isValidSplit(nums: number[]) {
    if (nums.length !== 2) return false;
    const [a, b] = nums.slice().sort((x, y) => x - y);
    if (a === 0 || b === 0) return false;
    const sameRow = rowOf(a) === rowOf(b) && Math.abs(a - b) === 1 && colOf(a) !== 3; // no wrap
    const vertical = Math.abs(a - b) === 3;
    return sameRow || vertical;
}
function isValidStreet(nums: number[]) {
    if (nums.length !== 3) return false;
    const r = rowOf(nums[0]); if (r < 0) return false;
    const expected = [r * 3 + 1, r * 3 + 2, r * 3 + 3];
    return new Set(nums).size === 3 && nums.every(n => expected.includes(n));
}
function isValidCorner(nums: number[]) {
    if (nums.length !== 4) return false;
    if (nums.some(n => n === 0)) return false;
    const s = new Set(nums);
    for (let r = 0; r < 11; r++) {
        for (let c = 1; c <= 2; c++) {
            const a = r * 3 + c, b = a + 1, d = a + 3, e = b + 3;
            const set = new Set([a, b, d, e]);
            if (set.size === 4 && nums.every(n => set.has(n))) return true;
        }
    }
    return false;
}
function isValidSixLine(nums: number[]) {
    if (nums.length !== 6) return false;
    const s = new Set(nums);
    for (let r = 0; r < 11; r++) {
        const A = [r * 3 + 1, r * 3 + 2, r * 3 + 3, (r + 1) * 3 + 1, (r + 1) * 3 + 2, (r + 1) * 3 + 3];
        if (A.every(n => s.has(n))) return true;
    }
    return false;
}

/** ---------------------------- Types ---------------------------- */
export type Bet =
    | { type: "ZERO"; stake: number; }
    | { type: "STRAIGHT"; stake: number; numbers: [number]; }
    | { type: "SPLIT"; stake: number; numbers: [number, number]; }
    | { type: "STREET"; stake: number; numbers: [number, number, number]; }
    | { type: "CORNER"; stake: number; numbers: [number, number, number, number]; }
    | { type: "SIX_LINE"; stake: number; numbers: [number, number, number, number, number, number]; }
    | { type: "FIRST_FOUR"; stake: number; }
    | { type: "DOZEN"; stake: number; dozen: 1 | 2 | 3; }
    | { type: "COLUMN"; stake: number; column: 1 | 2 | 3; }
    | { type: "RED" | "BLACK" | "EVEN" | "ODD" | "LOW" | "HIGH"; stake: number; };

export type SpinInput = {
    client_seed?: string;
    zero_rule: OutsideZeroRule;
    bets: any[];
};

/** Normalize & validate bet from controller. */
function validateBet(b: any): Bet {
    switch (b.type) {
        case "ZERO": return { type: "ZERO", stake: b.stake };

        case "STRAIGHT":
            if (!b.numbers || b.numbers.length !== 1) throw AppError.badRequest("STRAIGHT needs one number");
            if (b.numbers[0] < 0 || b.numbers[0] > 36) throw AppError.badRequest("Invalid number");
            return { type: "STRAIGHT", stake: b.stake, numbers: [b.numbers[0]] };

        case "SPLIT":
            if (!b.numbers) throw AppError.badRequest("SPLIT needs numbers");
            if (!isValidSplit(b.numbers)) throw AppError.badRequest("Invalid SPLIT");
            return { type: "SPLIT", stake: b.stake, numbers: b.numbers };

        case "STREET":
            if (!b.numbers) throw AppError.badRequest("STREET needs numbers");
            if (!isValidStreet(b.numbers)) throw AppError.badRequest("Invalid STREET");
            return { type: "STREET", stake: b.stake, numbers: b.numbers };

        case "CORNER":
            if (!b.numbers) throw AppError.badRequest("CORNER needs numbers");
            if (!isValidCorner(b.numbers)) throw AppError.badRequest("Invalid CORNER");
            return { type: "CORNER", stake: b.stake, numbers: b.numbers };

        case "SIX_LINE":
            if (!b.numbers) throw AppError.badRequest("SIX_LINE needs numbers");
            if (!isValidSixLine(b.numbers)) throw AppError.badRequest("Invalid SIX_LINE");
            return { type: "SIX_LINE", stake: b.stake, numbers: b.numbers };

        case "FIRST_FOUR":
            if (b.numbers) {
                const ok = new Set(b.numbers).size === 4 && [0, 1, 2, 3].every((x) => b.numbers.includes(x));
                if (!ok) throw AppError.badRequest("FIRST_FOUR must be [0,1,2,3]");
            }
            return { type: "FIRST_FOUR", stake: b.stake };

        case "DOZEN":
            if (![1, 2, 3].includes(Number(b.dozen))) throw AppError.badRequest("DOZEN must be 1|2|3");
            return { type: "DOZEN", stake: b.stake, dozen: Number(b.dozen) as 1 | 2 | 3 };

        case "COLUMN":
            if (![1, 2, 3].includes(Number(b.column))) throw AppError.badRequest("COLUMN must be 1|2|3");
            return { type: "COLUMN", stake: b.stake, column: Number(b.column) as 1 | 2 | 3 };

        case "RED":
        case "BLACK":
        case "EVEN":
        case "ODD":
        case "LOW":
        case "HIGH":
            return { type: b.type, stake: b.stake };

        default:
            throw AppError.badRequest("Unknown bet type");
    }
}

/** Return multiplier for a bet (includes stake). */
function betWins(b: Bet, n: number, zeroRule: OutsideZeroRule) {
    switch (b.type) {
        case "ZERO": return n === 0 ? RETURN_MULT.ZERO : 0;
        case "STRAIGHT": return ("numbers" in b && b.numbers[0] === n) ? RETURN_MULT.STRAIGHT : 0;
        case "SPLIT": return ("numbers" in b && b.numbers.includes(n)) ? RETURN_MULT.SPLIT : 0;
        case "STREET": return ("numbers" in b && b.numbers.includes(n)) ? RETURN_MULT.STREET : 0;
        case "CORNER": return ("numbers" in b && b.numbers.includes(n)) ? RETURN_MULT.CORNER : 0;
        case "SIX_LINE": return ("numbers" in b && b.numbers.includes(n)) ? RETURN_MULT.SIX_LINE : 0;
        case "FIRST_FOUR": return (n === 0 || n === 1 || n === 2 || n === 3) ? RETURN_MULT.FIRST_FOUR : 0;
        case "DOZEN": return dozenOf(n) === b.dozen ? RETURN_MULT.DOZEN : 0;
        case "COLUMN": return colOf(n) === b.column ? RETURN_MULT.COLUMN : 0;

        // Even-money
        case "RED":
            if (n === 0) return (zeroRule === "la_partage") ? LA_PARTAGE_RETURN_MULT : 0;
            return isRed(n) ? RETURN_MULT.EVEN_MONEY : 0;

        case "BLACK":
            if (n === 0) return (zeroRule === "la_partage") ? LA_PARTAGE_RETURN_MULT : 0;
            return (!isRed(n)) ? RETURN_MULT.EVEN_MONEY : 0;

        case "EVEN":
            if (n === 0) return (zeroRule === "la_partage") ? LA_PARTAGE_RETURN_MULT : 0;
            return (n % 2 === 0 && n !== 0) ? RETURN_MULT.EVEN_MONEY : 0;

        case "ODD":
            if (n === 0) return (zeroRule === "la_partage") ? LA_PARTAGE_RETURN_MULT : 0;
            return (n % 2 === 1) ? RETURN_MULT.EVEN_MONEY : 0;

        case "LOW":
            if (n === 0) return (zeroRule === "la_partage") ? LA_PARTAGE_RETURN_MULT : 0;
            return (n >= 1 && n <= 18) ? RETURN_MULT.EVEN_MONEY : 0;

        case "HIGH":
            if (n === 0) return (zeroRule === "la_partage") ? LA_PARTAGE_RETURN_MULT : 0;
            return (n >= 19 && n <= 36) ? RETURN_MULT.EVEN_MONEY : 0;
    }
}

/** ---------------------------- Idempotency (mode-scoped) ---------------------------- */
const modePrefix = (mode: "real" | "demo") => (mode === "demo" ? "demo" : "real");
const idemKey = (mode: "real" | "demo", sid: string, key: string) => `idem:${modePrefix(mode)}:roulette:spin:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, key?: string) { if (!key) return null; const v = await redis.get(idemKey(mode, sid, key)); return v ? JSON.parse(v) : null; }
async function setIdem(mode: "real" | "demo", sid: string, key: string, payload: any) { await redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL); }

/** ---------------------------- RTP wiring (Hybrid) ---------------------------- */
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor"; // REAL plan

const GAME_CODE = "spin";
const DEMO_START = Number(process.env.DEMO_START_BALANCE ?? 1000);

type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}

async function rtpEnterReal(totalStake: number) {
    const yymmdd = toYYMMDD();
    const dayKey = rk.day(GAME_CODE, yymmdd);
    await redis.hsetnx(dayKey, "rtp_target", 0.90);
    await redis.spEnter(dayKey, totalStake);
    return { dayKey, yymmdd };
}
async function rtpSettleReal(dayKey: string, totalStake: number, totalWin: number) {
    await redis.spSettle(dayKey, totalStake, totalWin);
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

/** ---------------------------- Candidate evaluation ---------------------------- */
type SlipDetails = {
    index: number; type: Bet["type"]; selection: any;
    stake: number; return_multiplier: number; payout: number; profit: number; win: boolean;
};
function evalSlipForNumber(
    bets: Bet[],
    winning: number,
    zeroRule: OutsideZeroRule,
    caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number; }
) {
    const details: SlipDetails[] = bets.map((b, i) => {
        const mult = betWins(b, winning, zeroRule);
        let payout = +(b.stake * mult).toFixed(2);
        payout = Math.min(payout, caps.per_bet_cap, caps.per_ticket_cap, caps.per_user_daily_cap);
        const profit = +(payout - b.stake).toFixed(2);

        const selection =
            b.type === "FIRST_FOUR" ? { numbers: [0, 1, 2, 3] } :
                ("numbers" in b && (b as any).numbers) ? { numbers: (b as any).numbers } :
                    ("dozen" in b) ? { dozen: (b as any).dozen } :
                        ("column" in b) ? { column: (b as any).column } : {};

        return { index: i, type: b.type, selection, stake: b.stake, return_multiplier: mult, payout, profit, win: mult > 0 };
    });
    const total = +details.reduce((s, d) => s + d.payout, 0).toFixed(2);
    return { details, total };
}

function pickWinningWithRtp(
    serverSeed: string,
    clientSeed: string,
    bets: Bet[],
    zeroRule: OutsideZeroRule,
    plan: { target: number; hardCap: number; softCap: number; },
    caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number; },
    K = CANDIDATES_K
) {
    let best = { score: Number.POSITIVE_INFINITY, winning: 0, pickIdx: 0, details: [] as SlipDetails[], totalWin: 0 };

    for (let pickIdx = 0; pickIdx < K; pickIdx++) {
        const winRaw = r01(serverSeed, clientSeed, `spin:${pickIdx}`);
        const winning = Math.floor(winRaw * 37); // 0..36

        const { details, total } = evalSlipForNumber(bets, winning, zeroRule, caps);

        const cappedTotal = Math.min(total, plan.hardCap);
        const overPenalty = total > plan.hardCap ? (total - plan.hardCap) * 10 : 0;
        const softPenalty = cappedTotal > plan.softCap ? (cappedTotal - plan.softCap) * 0.5 : 0;
        const score = Math.abs(cappedTotal - plan.target) + overPenalty + softPenalty;

        if (score < best.score) {
            let adjDetails = details;
            let totalWin = total;

            if (totalWin > plan.hardCap && totalWin > 0) {
                const factor = plan.hardCap / totalWin;
                adjDetails = details.map(d => ({ ...d, payout: +(d.payout * factor).toFixed(2), profit: +((d.payout * factor) - d.stake).toFixed(2) }));
                totalWin = +adjDetails.reduce((s, x) => s + x.payout, 0).toFixed(2);
            }

            best = { score, winning, pickIdx, details: adjDetails, totalWin };
        }
    }

    best.totalWin = Math.min(best.totalWin, plan.hardCap);
    return best;
}

/** ---------------------------- Spin (main entry) ---------------------------- */
export async function spinWheel(
    sess: ProviderSession,
    input: { client_seed?: string; zero_rule: OutsideZeroRule; bets: any[]; },
    idemKeyStr?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";

    if (idemKeyStr) {
        const hit = await getIdem(mode, sess.sid, idemKeyStr);
        if (hit) return hit;
    }

    // Validate bets
    if (!Array.isArray(input.bets) || input.bets.length === 0) throw AppError.badRequest("No bets");
    if (input.bets.length > LIMITS.maxSlipBets) throw AppError.badRequest("Too many bets");

    const bets: Bet[] = input.bets.map(validateBet);
    for (const b of bets) {
        if (b.stake < LIMITS.minBet) throw AppError.badRequest(`Min bet is ${LIMITS.minBet}`);
        if (b.stake > LIMITS.maxBet) throw AppError.badRequest(`Max bet is ${LIMITS.maxBet}`);
    }
    const totalStake = +bets.reduce((s, b) => s + b.stake, 0).toFixed(2);

    // Seeds
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);
    const clientSeed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";
    const zeroRule = input.zero_rule ?? ZERO_RULE_DEFAULT;

    // Ledger: debit
    const txnId = randomUUID();
    if (mode === "demo") {
        const key = `demo:bal:${sess.sid}`;
        const v = await redis.get(key);
        const bal = v ? Number(v) : DEMO_START;
        if (bal < totalStake) throw AppError.badRequest("Insufficient FUN balance");
        await redis.set(key, String(+(bal - totalStake).toFixed(2)), 2 * 60 * 60);
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: totalStake,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Roulette",
                GameName: "SpinAndWheel",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeedHash: serverSeedHash,
                ClientSeed: clientSeed
            }
        });
    }

    // RTP: enter (REAL only)
    let dayKey: string | null = null;
    let yymmdd = toYYMMDD();
    if (mode === "real") {
        const r = await rtpEnterReal(totalStake);
        dayKey = r.dayKey; yymmdd = r.yymmdd;
    }

    // Load cfg + plan
    const cfg = await loadGameCfg();
    const plan = (mode === "real")
        ? await spPlan(GAME_CODE, totalStake, cfg, yymmdd)
        : demoPlan(totalStake, cfg);

    // Choose winning number from K deterministic candidates
    const picked = pickWinningWithRtp(
        serverSeed, clientSeed, bets, zeroRule,
        { target: plan.target, hardCap: plan.hardCap, softCap: plan.softCap },
        { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap },
        CANDIDATES_K
    );

    const winning = picked.winning;
    const details = picked.details;
    const totalPayout = picked.totalWin;

    // RTP: settle (REAL only)
    if (mode === "real" && dayKey) {
        await rtpSettleReal(dayKey, totalStake, totalPayout);
    }

    // Credit
    if (mode === "demo") {
        const key = `demo:bal:${sess.sid}`;
        const v2 = await redis.get(key);
        const bal2 = v2 ? Number(v2) : DEMO_START;
        await redis.set(key, String(+(bal2 + totalPayout).toFixed(2)), 2 * 60 * 60);
    } else if (totalPayout > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: `${txnId}-W`,
            TransactionType: "WinAmount",
            Amount: totalPayout,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Roulette",
                GameName: "SpinAndWheel",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeed: serverSeed,
                ServerSeedHash: serverSeedHash,
                ClientSeed: clientSeed,
                Winning: winning
            }
        });
    }

    // Response
    const resp = {
        game: "SpinAndWheel",
        mode,
        txn_id: txnId,
        stake_total: totalStake,
        currency: sess.currency,
        wheel: {
            winning_number: winning,
            color: winning === 0 ? "GREEN" : (isRed(winning) ? "RED" : "BLACK"),
            column: colOf(winning) || null,
            dozen: dozenOf(winning) || null
        },
        slip: {
            zero_rule: zeroRule,
            bets: details,
            payout_total: totalPayout,
            profit_total: +(+totalPayout - +totalStake).toFixed(2)
        },
        fairness: {
            method: `HMAC-SHA256(server_seed, \`${clientSeed}:spin:k\`) % 37, pick best of K=${CANDIDATES_K} vs RTP target`,
            server_seed_hash: serverSeedHash,
            server_seed: serverSeed, // reveal post-spin
            client_seed: clientSeed,
            pick_index: picked.pickIdx
        },
        plan
    };

    if (idemKeyStr) await setIdem(mode, sess.sid, idemKeyStr, resp);
    return resp;
}
