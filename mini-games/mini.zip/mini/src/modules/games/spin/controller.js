"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.spin = exports.spinValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const BetType = zod_1.z.enum([
    "STRAIGHT", "SPLIT", "STREET", "CORNER", "SIX_LINE", "FIRST_FOUR",
    "DOZEN", "COLUMN", "RED", "BLACK", "EVEN", "ODD", "LOW", "HIGH"
]);
// Accepts an array of heterogeneous bets (each with its own stake)
const Bet = zod_1.z.object({
    type: BetType,
    stake: zod_1.z.number().positive(),
    // Inside-bet payloads
    numbers: zod_1.z.array(zod_1.z.number().int().min(0).max(36)).optional(), // STRAIGHT (len1), SPLIT(2), STREET(3), CORNER(4), SIX_LINE(6), FIRST_FOUR(4 = [0,1,2,3])
    // Outside selectors
    dozen: zod_1.z.enum(["1", "2", "3"]).transform(Number).optional(), // DOZEN 1..12, 13..24, 25..36
    column: zod_1.z.enum(["1", "2", "3"]).transform(Number).optional(), // COLUMN (1st, 2nd, 3rd)
});
const SpinBody = zod_1.z.object({
    client_seed: zod_1.z.string().min(1).optional(),
    zero_rule: zod_1.z.enum(["lose", "la_partage"]).default("lose"), // optional rule for even-money when 0 hits
    bets: zod_1.z.array(Bet).min(1),
});
exports.spinValidate = (0, validate_1.validateBody)(SpinBody);
exports.spin = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.spinWheel)(sess, body, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
