"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.gamesRouter = void 0;
const express_1 = require("express");
const sp_controller_1 = require("./common/sp.controller");
const controller_1 = require("./jetx/controller");
// very naive target matcher for now — we’ll replace per game
function naiveComputeWin(_a) {
    return __awaiter(this, arguments, void 0, function* ({ target, stake }) {
        // never exceed a simple multiple; you’ll replace per game logic
        return Math.min(target, stake * 100);
    });
}
exports.gamesRouter = (0, express_1.Router)();
exports.gamesRouter.post("/keno/bet", (0, sp_controller_1.makeSpBetHandler)("keno", naiveComputeWin));
exports.gamesRouter.post("/bingo/bet", (0, sp_controller_1.makeSpBetHandler)("bingo", naiveComputeWin));
exports.gamesRouter.post("/spin/bet", (0, sp_controller_1.makeSpBetHandler)("spin", naiveComputeWin));
exports.gamesRouter.post("/chicken-road/bet", (0, sp_controller_1.makeSpBetHandler)("chicken-road", naiveComputeWin));
exports.gamesRouter.post("/bomb/bet", (0, sp_controller_1.makeSpBetHandler)("bomb", naiveComputeWin));
exports.gamesRouter.post("/777slot/bet", (0, sp_controller_1.makeSpBetHandler)("777slot", naiveComputeWin));
exports.gamesRouter.post("/plinko/bet", (0, sp_controller_1.makeSpBetHandler)("plinko", naiveComputeWin));
exports.gamesRouter.use("/jetx", controller_1.jetxRouter);
