// /var/www/typesafe/alpha-mini/src/modules/games/777-slot/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { spinOnce } from "./service";

const SpinBody = z.object({
    amount: z.number().positive(),
    client_seed: z.string().min(1).optional()
});
export const spinValidate = validateBody(SpinBody);

export const spin = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { amount, client_seed } = req.body as z.infer<typeof SpinBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await spinOnce(sess, { amount, clientSeed: client_seed }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});
