"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.spinOnce = spinOnce;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====       
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
// ---------- config ----------
const GAME_CODE = "slot-777";
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { min: 0.1, max: 10000 };
const CANDIDATES_K = 6; // how many nonce candidates we evaluate
const HOUSE_EDGE = 0.02; // reserved if you add bonus/respins later
// Reel strips (weights via repetition; each reel can differ)
const REELS = [
    // Reel 1
    ["LEMON", "LEMON", "CHERRY", "BAR", "LEMON", "STAR", "BELL", "LEMON", "CHERRY", "SEVEN",
        "LEMON", "BAR", "LEMON", "CHERRY", "STAR", "LEMON", "BELL", "LEMON", "BAR", "LEMON"],
    // Reel 2
    ["LEMON", "CHERRY", "LEMON", "STAR", "BAR", "LEMON", "BELL", "LEMON", "CHERRY", "LEMON",
        "SEVEN", "LEMON", "STAR", "BAR", "LEMON", "CHERRY", "LEMON", "BELL", "LEMON", "LEMON"],
    // Reel 3
    ["LEMON", "STAR", "LEMON", "BELL", "LEMON", "CHERRY", "LEMON", "BAR", "LEMON", "LEMON",
        "SEVEN", "LEMON", "CHERRY", "LEMON", "STAR", "BAR", "LEMON", "BELL", "LEMON", "LEMON"],
];
// Simple paytable (multiplier of stake) for middle payline only
const PAYTABLE = {
    "SEVEN|SEVEN|SEVEN": 100,
    "BAR|BAR|BAR": 25,
    "BELL|BELL|BELL": 15,
    "STAR|STAR|STAR": 10,
    "CHERRY|CHERRY|CHERRY": 5,
    "LEMON|LEMON|LEMON": 3,
};
// Optional partial: any two cherries pay 1x (stake back)
const TWO_CHERRY_MULT = 1;
// ---------- idempotency (mode-scoped) ----------
const modePrefix = (mode) => (mode === "demo" ? "demo" : "real");
const reqKey = (mode, sid, k) => `idem:${modePrefix(mode)}:slot777:req:${sid}:${k}`;
function getIdemByKey(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(reqKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdemByKey(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
// Demo ledger helpers
const DEMO_START = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(key);
        if (v)
            return Number(v);
        yield redis_1.redis.set(key, String(DEMO_START), 2 * 60 * 60);
        return DEMO_START;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
    });
}
// ---------- fairness ----------
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
function hmacHex(key, msg) {
    return crypto_1.default.createHmac("sha256", key).update(msg).digest("hex");
}
/** Deterministically choose reel stop index for each reel from seeds. */
function reelStops(serverSeed, clientSeed, nonce) {
    return REELS.map((strip, i) => {
        const h = hmacHex(serverSeed, `${clientSeed}:${i}:${nonce}`);
        const val = parseInt(h.slice(0, 8), 16); // 32-bit
        return val % strip.length;
    });
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function rtpEnterReal(stake) {
    return __awaiter(this, void 0, void 0, function* () {
        const yymmdd = (0, date_1.toYYMMDD)();
        const dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
        yield redis_1.redis.hsetnx(dayKey, "rtp_target", 0.90);
        yield redis_1.redis.spEnter(dayKey, stake);
        return { dayKey, yymmdd };
    });
}
function rtpSettleReal(dayKey, stake, win) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.spSettle(dayKey, stake, win);
    });
}
function demoPlan(totalStake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
// ---------- payout evaluation ----------
function evaluateLine(stake, line, caps) {
    var _a;
    const key = `${line[0]}|${line[1]}|${line[2]}`;
    let mult = (_a = PAYTABLE[key]) !== null && _a !== void 0 ? _a : 0;
    if (mult === 0) {
        const cherries = line.filter(s => s === "CHERRY").length;
        if (cherries === 2)
            mult = TWO_CHERRY_MULT;
    }
    let win = +(stake * mult).toFixed(2);
    win = Math.min(win, caps.per_bet_cap, caps.per_ticket_cap, caps.per_user_daily_cap);
    return { mult, win, combo: mult > 0 ? key : "NONE" };
}
function gridFromStops(stops) {
    // Build 3x3 grid from each reel's window: [top, mid, bot]
    const grid = [[], [], []]; // rows: 0=top,1=mid,2=bot
    for (let r = 0; r < 3; r++) {
        const strip = REELS[r];
        const L = strip.length;
        const c = stops[r]; // center index for the middle row
        const top = (c - 1 + L) % L;
        const mid = c;
        const bot = (c + 1) % L;
        grid[0][r] = strip[top];
        grid[1][r] = strip[mid];
        grid[2][r] = strip[bot];
    }
    return grid;
}
function pickSpinWithRtp(serverSeed, clientSeed, stake, plan, caps, K = CANDIDATES_K) {
    let best = { score: Number.POSITIVE_INFINITY, nonce: 1, stops: [], grid: [], line: [], win: 0, mult: 0, combo: "NONE" };
    for (let nonce = 1; nonce <= K; nonce++) {
        const stops = reelStops(serverSeed, clientSeed, nonce);
        const grid = gridFromStops(stops);
        const line = [grid[1][0], grid[1][1], grid[1][2]];
        const { mult, win, combo } = evaluateLine(stake, line, caps);
        const capped = Math.min(win, plan.hardCap);
        const overPenalty = win > plan.hardCap ? (win - plan.hardCap) * 10 : 0;
        const softPenalty = capped > plan.softCap ? (capped - plan.softCap) * 0.5 : 0;
        const score = Math.abs(capped - plan.target) + overPenalty + softPenalty;
        if (score < best.score) {
            best = { score, nonce, stops, grid, line, win: +capped.toFixed(2), mult, combo };
        }
    }
    best.win = Math.min(best.win, plan.hardCap);
    return best;
}
function spinOnce(sess, spin, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        // Idempotency
        if (idemKey) {
            const hit = yield getIdemByKey(mode, sess.sid, idemKey);
            if (hit)
                return hit;
        }
        // Validate
        if (spin.amount < LIMITS.min)
            throw errors_1.AppError.badRequest(`Min bet is ${LIMITS.min}`);
        if (spin.amount > LIMITS.max)
            throw errors_1.AppError.badRequest(`Max bet is ${LIMITS.max}`);
        // Seeds
        const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
        const serverSeedHash = sha256(serverSeed);
        const clientSeed = (_c = (_b = (_a = spin.clientSeed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        // Ledger: debit
        const txnId = (0, crypto_1.randomUUID)();
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < spin.amount)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - spin.amount).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_d = sess.opSessionId) !== null && _d !== void 0 ? _d : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: spin.amount,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Slots",
                    GameName: "Lucky777",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeedHash: serverSeedHash,
                    ClientSeed: clientSeed
                }
            });
        }
        // RTP: enter & plan (REAL) or synthetic (DEMO)
        let dayKey = null;
        let yymmdd = (0, date_1.toYYMMDD)();
        const cfg = yield loadGameCfg();
        const plan = (mode === "real")
            ? (yield (() => __awaiter(this, void 0, void 0, function* () {
                const r = yield rtpEnterReal(spin.amount);
                dayKey = r.dayKey;
                yymmdd = r.yymmdd;
                return (0, governor_1.spPlan)(GAME_CODE, spin.amount, cfg, yymmdd);
            }))())
            : demoPlan(spin.amount, cfg);
        // Pick the best of K nonce candidates vs plan
        const caps = { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap };
        const picked = pickSpinWithRtp(serverSeed, clientSeed, spin.amount, plan, caps, CANDIDATES_K);
        const winningStops = picked.stops;
        const grid = picked.grid;
        const line = picked.line;
        const finalWin = picked.win; // already capped by hardCap, we'll clamp to global caps again to be safe
        const winAmount = Math.min(finalWin, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
        // RTP: settle (REAL only)
        if (mode === "real" && dayKey) {
            yield rtpSettleReal(dayKey, spin.amount, winAmount);
        }
        // Credit (wallet)
        let newBalance = 0;
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            yield setDemoBalance(sess, +(bal + winAmount).toFixed(2));
            newBalance = +(bal - spin.amount + winAmount).toFixed(2);
        }
        else if (winAmount > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_e = sess.opSessionId) !== null && _e !== void 0 ? _e : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            const wd = yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${txnId}-W`,
                TransactionType: "WinAmount",
                Amount: winAmount,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Slots",
                    GameName: "Lucky777",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: serverSeed,
                    ServerSeedHash: serverSeedHash,
                    ClientSeed: clientSeed,
                    Nonce: picked.nonce,
                    ReelStops: winningStops,
                    Payline: "MID"
                }
            });
            if ((wd === null || wd === void 0 ? void 0 : wd.Balance) != null)
                newBalance = Number(wd.Balance);
        }
        // Response
        const response = {
            game: "Lucky777",
            mode,
            txn_id: txnId,
            stake: spin.amount,
            currency: sess.currency,
            grid: {
                rows: 3,
                cols: 3,
                symbols: grid
            },
            payline: {
                line: "MID",
                symbols: line,
                win_multiplier: picked.mult,
                win_amount: winAmount,
                combo: picked.combo
            },
            balance: newBalance, // 0 if unknown in real mode
            fairness: {
                method: `Per-reel HMAC(server_seed, \`${clientSeed}:reelIndex:nonce\`) % reel_len; pick best of K=${CANDIDATES_K} nonces vs RTP`,
                server_seed_hash: serverSeedHash,
                server_seed: serverSeed, // reveal immediately (spin complete)
                client_seed: clientSeed,
                nonce: picked.nonce,
                reel_stops: winningStops
            },
            plan
        };
        if (idemKey)
            yield setIdemByKey(mode, sess.sid, idemKey, response);
        return response;
    });
}
