import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====       
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

// ---------- config ----------
const GAME_CODE = "slot-777";
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { min: 0.1, max: 10000 };
const CANDIDATES_K = 6;        // how many nonce candidates we evaluate
const HOUSE_EDGE = 0.02;       // reserved if you add bonus/respins later

// Classic symbols (ASCII only)
type Sym = "SEVEN" | "BAR" | "BELL" | "STAR" | "CHERRY" | "LEMON";

// Reel strips (weights via repetition; each reel can differ)
const REELS: Sym[][] = [
    // Reel 1
    ["LEMON", "LEMON", "CHERRY", "BAR", "LEMON", "STAR", "BELL", "LEMON", "CHERRY", "SEVEN",
        "LEMON", "BAR", "LEMON", "CHERRY", "STAR", "LEMON", "BELL", "LEMON", "BAR", "LEMON"],
    // Reel 2
    ["LEMON", "CHERRY", "LEMON", "STAR", "BAR", "LEMON", "BELL", "LEMON", "CHERRY", "LEMON",
        "SEVEN", "LEMON", "STAR", "BAR", "LEMON", "CHERRY", "LEMON", "BELL", "LEMON", "LEMON"],
    // Reel 3
    ["LEMON", "STAR", "LEMON", "BELL", "LEMON", "CHERRY", "LEMON", "BAR", "LEMON", "LEMON",
        "SEVEN", "LEMON", "CHERRY", "LEMON", "STAR", "BAR", "LEMON", "BELL", "LEMON", "LEMON"],
];

// Simple paytable (multiplier of stake) for middle payline only
const PAYTABLE: Record<string, number> = {
    "SEVEN|SEVEN|SEVEN": 100,
    "BAR|BAR|BAR": 25,
    "BELL|BELL|BELL": 15,
    "STAR|STAR|STAR": 10,
    "CHERRY|CHERRY|CHERRY": 5,
    "LEMON|LEMON|LEMON": 3,
};
// Optional partial: any two cherries pay 1x (stake back)
const TWO_CHERRY_MULT = 1;

// ---------- idempotency (mode-scoped) ----------
const modePrefix = (mode: "real" | "demo") => (mode === "demo" ? "demo" : "real");
const reqKey = (mode: "real" | "demo", sid: string, k: string) => `idem:${modePrefix(mode)}:slot777:req:${sid}:${k}`;
async function getIdemByKey(mode: "real" | "demo", sid: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(reqKey(mode, sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdemByKey(mode: "real" | "demo", sid: string, key: string, payload: any) {
    await redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

// Demo ledger helpers
const DEMO_START = Number(process.env.DEMO_START_BALANCE ?? 1000);
async function getDemoBalance(sess: ProviderSession) {
    const key = `demo:bal:${sess.sid}`;
    const v = await redis.get(key);
    if (v) return Number(v);
    await redis.set(key, String(DEMO_START), 2 * 60 * 60);
    return DEMO_START;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
    await redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
}

// ---------- fairness ----------
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
function hmacHex(key: string, msg: string) {
    return crypto.createHmac("sha256", key).update(msg).digest("hex");
}
/** Deterministically choose reel stop index for each reel from seeds. */
function reelStops(serverSeed: string, clientSeed: string, nonce: number): number[] {
    return REELS.map((strip, i) => {
        const h = hmacHex(serverSeed, `${clientSeed}:${i}:${nonce}`);
        const val = parseInt(h.slice(0, 8), 16); // 32-bit
        return val % strip.length;
    });
}

// ---------- cfg & RTP helpers ----------
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
async function rtpEnterReal(stake: number) {
    const yymmdd = toYYMMDD();
    const dayKey = rk.day(GAME_CODE, yymmdd);
    await redis.hsetnx(dayKey, "rtp_target", 0.90);
    await redis.spEnter(dayKey, stake);
    return { dayKey, yymmdd };
}
async function rtpSettleReal(dayKey: string, stake: number, win: number) {
    await redis.spSettle(dayKey, stake, win);
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

// ---------- payout evaluation ----------
function evaluateLine(stake: number, line: Sym[], caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number }) {
    const key = `${line[0]}|${line[1]}|${line[2]}`;
    let mult = PAYTABLE[key] ?? 0;
    if (mult === 0) {
        const cherries = line.filter(s => s === "CHERRY").length;
        if (cherries === 2) mult = TWO_CHERRY_MULT;
    }
    let win = +(stake * mult).toFixed(2);
    win = Math.min(win, caps.per_bet_cap, caps.per_ticket_cap, caps.per_user_daily_cap);
    return { mult, win, combo: mult > 0 ? key : "NONE" };
}

function gridFromStops(stops: number[]) {
    // Build 3x3 grid from each reel's window: [top, mid, bot]
    const grid: Sym[][] = [[], [], []]; // rows: 0=top,1=mid,2=bot
    for (let r = 0; r < 3; r++) {
        const strip = REELS[r];
        const L = strip.length;
        const c = stops[r]; // center index for the middle row
        const top = (c - 1 + L) % L;
        const mid = c;
        const bot = (c + 1) % L;
        grid[0][r] = strip[top];
        grid[1][r] = strip[mid];
        grid[2][r] = strip[bot];
    }
    return grid;
}

function pickSpinWithRtp(
    serverSeed: string,
    clientSeed: string,
    stake: number,
    plan: { target: number; hardCap: number; softCap: number },
    caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number },
    K = CANDIDATES_K
) {
    let best = { score: Number.POSITIVE_INFINITY, nonce: 1, stops: [] as number[], grid: [] as Sym[][], line: [] as Sym[], win: 0, mult: 0, combo: "NONE" };

    for (let nonce = 1; nonce <= K; nonce++) {
        const stops = reelStops(serverSeed, clientSeed, nonce);
        const grid = gridFromStops(stops);
        const line = [grid[1][0], grid[1][1], grid[1][2]] as Sym[];
        const { mult, win, combo } = evaluateLine(stake, line, caps);

        const capped = Math.min(win, plan.hardCap);
        const overPenalty = win > plan.hardCap ? (win - plan.hardCap) * 10 : 0;
        const softPenalty = capped > plan.softCap ? (capped - plan.softCap) * 0.5 : 0;
        const score = Math.abs(capped - plan.target) + overPenalty + softPenalty;

        if (score < best.score) {
            best = { score, nonce, stops, grid, line, win: +capped.toFixed(2), mult, combo };
        }
    }

    best.win = Math.min(best.win, plan.hardCap);
    return best;
}

// ---------- API ----------
type SpinInput = { amount: number; clientSeed?: string };

export async function spinOnce(sess: ProviderSession, spin: SpinInput, idemKey?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";

    // Idempotency
    if (idemKey) {
        const hit = await getIdemByKey(mode, sess.sid, idemKey);
        if (hit) return hit;
    }

    // Validate
    if (spin.amount < LIMITS.min) throw AppError.badRequest(`Min bet is ${LIMITS.min}`);
    if (spin.amount > LIMITS.max) throw AppError.badRequest(`Max bet is ${LIMITS.max}`);

    // Seeds
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);
    const clientSeed = spin.clientSeed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    // Ledger: debit
    const txnId = randomUUID();
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < spin.amount) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - spin.amount).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: spin.amount,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Slots",
                GameName: "Lucky777",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeedHash: serverSeedHash,
                ClientSeed: clientSeed
            }
        });
    }

    // RTP: enter & plan (REAL) or synthetic (DEMO)
    let dayKey: string | null = null;
    let yymmdd = toYYMMDD();
    const cfg = await loadGameCfg();

    const plan = (mode === "real")
        ? (await (async () => {
            const r = await rtpEnterReal(spin.amount);
            dayKey = r.dayKey; yymmdd = r.yymmdd;
            return spPlan(GAME_CODE, spin.amount, cfg, yymmdd);
        })())
        : demoPlan(spin.amount, cfg);

    // Pick the best of K nonce candidates vs plan
    const caps = { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap };
    const picked = pickSpinWithRtp(serverSeed, clientSeed, spin.amount, plan, caps, CANDIDATES_K);

    const winningStops = picked.stops;
    const grid = picked.grid;
    const line = picked.line;
    const finalWin = picked.win; // already capped by hardCap, we'll clamp to global caps again to be safe
    const winAmount = Math.min(finalWin, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);

    // RTP: settle (REAL only)
    if (mode === "real" && dayKey) {
        await rtpSettleReal(dayKey, spin.amount, winAmount);
    }

    // Credit (wallet)
    let newBalance = 0;
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        await setDemoBalance(sess, +(bal + winAmount).toFixed(2));
        newBalance = +(bal - spin.amount + winAmount).toFixed(2);
    } else if (winAmount > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        const wd = await withdraw(opCtx, {
            TransactionId: `${txnId}-W`,
            TransactionType: "WinAmount",
            Amount: winAmount,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Slots",
                GameName: "Lucky777",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeed: serverSeed,
                ServerSeedHash: serverSeedHash,
                ClientSeed: clientSeed,
                Nonce: picked.nonce,
                ReelStops: winningStops,
                Payline: "MID"
            }
        });
        if (wd?.Balance != null) newBalance = Number(wd.Balance);
    }

    // Response
    const response = {
        game: "Lucky777",
        mode,
        txn_id: txnId,
        stake: spin.amount,
        currency: sess.currency,
        grid: {
            rows: 3,
            cols: 3,
            symbols: grid
        },
        payline: {
            line: "MID",
            symbols: line,
            win_multiplier: picked.mult,
            win_amount: winAmount,
            combo: picked.combo
        },
        balance: newBalance, // 0 if unknown in real mode
        fairness: {
            method: `Per-reel HMAC(server_seed, \`${clientSeed}:reelIndex:nonce\`) % reel_len; pick best of K=${CANDIDATES_K} nonces vs RTP`,
            server_seed_hash: serverSeedHash,
            server_seed: serverSeed,   // reveal immediately (spin complete)
            client_seed: clientSeed,
            nonce: picked.nonce,
            reel_stops: winningStops
        },
        plan
    };

    if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, response);
    return response;
}
