// /var/www/typesafe/alpha-mini/src/modules/games/penality/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody, validateQuery } from "../../../middleware/validate";
import {
    startSeriesSvc, kickSvc, cashoutSvc, statusSvc,
} from "./service";

const StartBody = z.object({
    stake: z.number().positive(),
    client_seed: z.string().min(1).optional()
});
export const startValidate = validateBody(StartBody);

export const startSeries = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof StartBody>;
    const data = await startSeriesSvc(sess, body, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});

const KickBody = z.object({
    series_id: z.string().uuid(),
    // 3x5 grid (0-based): col in 0..2, row in 0..4 (row 0 = top)
    target: z.object({ col: z.number().int().min(0).max(2), row: z.number().int().min(0).max(4) }),
    client_seed: z.string().min(1).optional()
});
export const kickValidate = validateBody(KickBody);

export const kick = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof KickBody>;
    const data = await kickSvc(sess, body, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});

const CashoutBody = z.object({ series_id: z.string().uuid() });
export const cashoutValidate = validateBody(CashoutBody);

export const cashout = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof CashoutBody>;
    const data = await cashoutSvc(sess, body, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});

const StatusQuery = z.object({ series_id: z.string().uuid() });
export const statusValidate = validateQuery(StatusQuery);

export const status = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const q = req.query as unknown as z.infer<typeof StatusQuery>;
    const data = await statusSvc(sess, q);
    res.json({ ok: true, ...data });
});
