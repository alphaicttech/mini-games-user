"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.status = exports.statusValidate = exports.cashout = exports.cashoutValidate = exports.kick = exports.kickValidate = exports.startSeries = exports.startValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const StartBody = zod_1.z.object({
    stake: zod_1.z.number().positive(),
    client_seed: zod_1.z.string().min(1).optional()
});
exports.startValidate = (0, validate_1.validateBody)(StartBody);
exports.startSeries = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.startSeriesSvc)(sess, body, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
const KickBody = zod_1.z.object({
    series_id: zod_1.z.string().uuid(),
    // 3x5 grid (0-based): col in 0..2, row in 0..4 (row 0 = top)
    target: zod_1.z.object({ col: zod_1.z.number().int().min(0).max(2), row: zod_1.z.number().int().min(0).max(4) }),
    client_seed: zod_1.z.string().min(1).optional()
});
exports.kickValidate = (0, validate_1.validateBody)(KickBody);
exports.kick = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.kickSvc)(sess, body, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
const CashoutBody = zod_1.z.object({ series_id: zod_1.z.string().uuid() });
exports.cashoutValidate = (0, validate_1.validateBody)(CashoutBody);
exports.cashout = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.cashoutSvc)(sess, body, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
const StatusQuery = zod_1.z.object({ series_id: zod_1.z.string().uuid() });
exports.statusValidate = (0, validate_1.validateQuery)(StatusQuery);
exports.status = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const q = req.query;
    const data = yield (0, service_1.statusSvc)(sess, q);
    res.json(Object.assign({ ok: true }, data));
}));
