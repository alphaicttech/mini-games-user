"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startSeriesSvc = startSeriesSvc;
exports.kickSvc = kickSvc;
exports.cashoutSvc = cashoutSvc;
exports.statusSvc = statusSvc;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
/**
 * Mechanics
 * - Progressive levels: 1..5 with multipliers [2,4,12,20,32] (stake INCLUDED).
 * - Cashout allowed after any successful kick (level >= 1).
 * - Each kick deducts the same stake (per-kick debit).
 * - If a kick is saved → series ends LOST (no payout); all deducted stakes remain spent.
 * - We leave one RTP entry **open per kick** (REAL). On SAVE: settle all with win=0. On CASHOUT: settle (level-1) entries win=0 and last entry with the payout.
 */
const GAME_CODE = "penality"; // keep code to match your folder/name
const IDEM_TTL = 24 * 60 * 60;
const MAX_LEVELS = 5;
const MULTIPLIERS = [2, 4, 12, 20, 32]; // level 1..5 (index 0..4)
// Example per-level GOAL probabilities (tune to target your RTP)
const P_GOAL = [0.78, 0.62, 0.46, 0.33, 0.22];
// Demo helpers
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const key = `demo:bal:${sess.sid}`;
        const cached = yield redis_1.redis.get(key);
        if (cached)
            return Number(cached);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(key, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
    });
}
// RNG helpers (provably fair)
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, tag) => u32(hmacHex(server, `${client}:${tag}`).slice(0, 8)) / 4294967296;
// Idempotency helpers (mode-scoped)
const idemKey = (mode, sid, action, key) => `idem:${mode}:penladder:${action}:${sid}:${key}`;
function getIdem(mode, sid, action, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(idemKey(mode, sid, action, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, action, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL);
    });
}
const sKey = (sid, seriesId) => `plad:series:${sid}:${seriesId}`;
function loadSeries(sid, series_id) {
    return __awaiter(this, void 0, void 0, function* () {
        const v = yield redis_1.redis.get(sKey(sid, series_id));
        return v ? JSON.parse(v) : null;
    });
}
function saveSeries(state) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(sKey(state.sid, state.series_id), JSON.stringify(state), 24 * 60 * 60);
    });
}
/** Distributed lock per series to protect /kick & /cashout races */
function withSeriesLock(sid, seriesId, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const lockKey = `plad:lock:${sid}:${seriesId}`;
        const ok = yield redis_1.rawRedis.set(lockKey, "1", "EX", 3, "NX"); // string form to avoid TS typing issues
        if (ok !== "OK")
            throw errors_1.AppError.conflict("Series is busy, retry");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(lockKey);
        }
    });
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function demoPlan(stake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
/**
 * Start series
 */
function startSeriesSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "start", idem);
            if (hit)
                return hit;
        }
        const stake = Number(input.stake);
        if (!(stake > 0))
            throw errors_1.AppError.badRequest("Invalid stake");
        const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
        const serverSeedHash = sha256(serverSeed);
        const baseClientSeed = (_c = (_b = (_a = input.client_seed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        const series = {
            series_id: (0, crypto_1.randomUUID)(),
            sid: sess.sid,
            portalName: sess.portalName,
            currency: sess.currency,
            stake,
            level: 0,
            status: "ACTIVE",
            server_seed: serverSeed,
            server_seed_hash: serverSeedHash,
            client_seed_base: baseClientSeed,
            created_at: Date.now(),
            kicks: [],
            openEntries: 0,
            lastPlan: null,
        };
        yield saveSeries(series);
        const resp = {
            game: "PenaltyLadder",
            mode: mode,
            series_id: series.series_id,
            stake_per_kick: stake,
            level: series.level,
            next_multiplier: MULTIPLIERS[0],
            server_seed_hash: serverSeedHash,
            can_cashout: false,
            grid: { cols: 3, rows: 5 }
        };
        if (idem)
            yield setIdem(mode, sess.sid, "start", idem, resp);
        return resp;
    });
}
/**
 * Kick (attempt next level)
 */
function kickSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "kick", idem);
            if (hit)
                return hit;
        }
        return withSeriesLock(sess.sid, input.series_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d, _e, _f;
            const st = yield loadSeries(sess.sid, input.series_id);
            if (!st)
                throw errors_1.AppError.notFound("SERIES_NOT_FOUND");
            if (st.status !== "ACTIVE")
                throw errors_1.AppError.badRequest(`Series ${st.status}`);
            const nextLevel = st.level + 1;
            if (nextLevel > MAX_LEVELS)
                throw errors_1.AppError.badRequest("All levels already completed");
            // Debit stake for this kick
            const txnId = (0, crypto_1.randomUUID)();
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                if (bal < st.stake)
                    throw errors_1.AppError.badRequest("Insufficient FUN balance");
                yield setDemoBalance(sess, +(bal - st.stake).toFixed(2));
            }
            else {
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opSessionId = (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId;
                const opCtx = {
                    baseUrl: operator.baseUrl,
                    secret: operator.secret,
                    session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
                };
                yield (0, client_1.deposit)(opCtx, {
                    TransactionId: txnId,
                    TransactionType: "PlaceBet",
                    Amount: st.stake,
                    CurrencyCode: st.currency,
                    TransactionInfo: {
                        Source: "Penalty",
                        GameName: "PenaltyLadder",
                        RoundId: st.series_id,
                        GameNumber: `${st.series_id}:${nextLevel}`,
                        ServerSeedHash: st.server_seed_hash,
                        ClientSeed: (_b = input.client_seed) !== null && _b !== void 0 ? _b : st.client_seed_base,
                        Level: nextLevel,
                        Target: input.target
                    }
                });
                // RTP: enter one open entry for this kick
                const yymmdd = (0, date_1.toYYMMDD)();
                if (!st.rtpDayKey) {
                    st.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
                    yield redis_1.redis.hsetnx(st.rtpDayKey, "rtp_target", 0.90);
                }
                yield redis_1.redis.spEnter(st.rtpDayKey, st.stake);
                st.openEntries = ((_c = st.openEntries) !== null && _c !== void 0 ? _c : 0) + 1;
                // Optional: refresh plan snapshot for UI after each kick (not used for settlement here)
                const cfg = yield loadGameCfg();
                st.lastPlan = yield (0, governor_1.spPlan)(GAME_CODE, st.stake, cfg, yymmdd);
            }
            // Resolve (provably fair)
            const cseed = (_d = input.client_seed) !== null && _d !== void 0 ? _d : st.client_seed_base;
            const u = r01(st.server_seed, cseed, `kick:${st.series_id}:${nextLevel}`);
            const p = P_GOAL[nextLevel - 1];
            const isGoal = u < p;
            st.kicks.push({
                index: nextLevel,
                target: input.target,
                client_seed: cseed,
                u: +u.toFixed(8),
                p_goal: p,
                result: isGoal ? "GOAL" : "SAVE",
                txn_id: txnId,
            });
            if (isGoal) {
                // advance level; keep RTP entry OPEN (we will settle at CASHOUT or on SAVE)
                st.level = nextLevel;
                yield saveSeries(st);
                const potMult = MULTIPLIERS[st.level - 1];
                const cumCost = +(st.level * st.stake).toFixed(2);
                const cashoutValue = +(st.stake * potMult).toFixed(2);
                const profitIfCashout = +(cashoutValue - cumCost).toFixed(2);
                const lastKick = st.kicks[st.kicks.length - 1];
                const resp = {
                    game: "PenaltyLadder",
                    mode,
                    series_id: st.series_id,
                    level: st.level,
                    result: "GOAL",
                    target: input.target,
                    can_cashout: true,
                    potential: {
                        multiplier: potMult,
                        payout: cashoutValue,
                        cost_so_far: cumCost,
                        profit_if_cashout: profitIfCashout
                    },
                    next_multiplier: st.level < MAX_LEVELS ? MULTIPLIERS[st.level] : null,
                    rng: { u: lastKick.u, threshold: p },
                    fairness: { server_seed_hash: st.server_seed_hash },
                    plan: (_e = st.lastPlan) !== null && _e !== void 0 ? _e : null
                };
                if (idem)
                    yield setIdem(mode, sess.sid, "kick", idem, resp);
                return resp;
            }
            else {
                // SAVE (loss): settle ALL open entries with win=0 (REAL)
                if (mode === "real" && st.rtpDayKey && ((_f = st.openEntries) !== null && _f !== void 0 ? _f : 0) > 0) {
                    const count = st.openEntries;
                    for (let i = 0; i < count; i++) {
                        yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, 0);
                    }
                    st.openEntries = 0;
                }
                st.status = "LOST";
                yield saveSeries(st);
                const lastKick = st.kicks[st.kicks.length - 1];
                const resp = {
                    game: "PenaltyLadder",
                    mode,
                    series_id: st.series_id,
                    level: st.level, // unchanged
                    result: "SAVE",
                    target: input.target,
                    finished: true,
                    payout: 0,
                    server_seed: st.server_seed, // reveal at end
                    rng: { u: lastKick.u, threshold: p },
                };
                if (idem)
                    yield setIdem(mode, sess.sid, "kick", idem, resp);
                return resp;
            }
        }));
    });
}
/**
 * Cashout
 */
function cashoutSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "cashout", idem);
            if (hit)
                return hit;
        }
        return withSeriesLock(sess.sid, input.series_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c;
            const st = yield loadSeries(sess.sid, input.series_id);
            if (!st)
                throw errors_1.AppError.notFound("SERIES_NOT_FOUND");
            if (st.status !== "ACTIVE")
                throw errors_1.AppError.badRequest(`Series ${st.status}`);
            if (st.level < 1)
                throw errors_1.AppError.badRequest("Nothing to cash out yet");
            const mult = MULTIPLIERS[st.level - 1];
            let payout = +(st.stake * mult).toFixed(2);
            // Clamp to configured caps and live RTP hard cap (REAL)
            const cfg = yield loadGameCfg();
            if (mode === "real") {
                const yymmdd = (0, date_1.toYYMMDD)();
                // plan against current state (PI has accumulated through open entries)
                const plan = yield (0, governor_1.spPlan)(GAME_CODE, st.stake, cfg, yymmdd);
                st.lastPlan = plan;
                const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
                payout = Math.min(payout, slipCap);
            }
            // also apply per-user/per-bet caps always
            payout = Math.min(payout, cfg.per_bet_cap, cfg.per_user_daily_cap);
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                yield setDemoBalance(sess, +(bal + payout).toFixed(2));
            }
            else {
                // RTP settle: clear (level - 1) entries with 0, last with payout
                if (!st.rtpDayKey) {
                    const yymmdd = (0, date_1.toYYMMDD)();
                    st.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd); // fallback
                }
                const toClear = Math.max(0, ((_a = st.openEntries) !== null && _a !== void 0 ? _a : st.level) - 1);
                for (let i = 0; i < toClear; i++) {
                    yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, 0);
                }
                yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, payout);
                st.openEntries = 0;
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opSessionId = (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId;
                const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                yield (0, client_1.withdraw)(opCtx, {
                    TransactionId: `${st.series_id}-CASHOUT-${st.level}`,
                    TransactionType: "WinAmount",
                    Amount: payout,
                    CurrencyCode: st.currency,
                    TransactionInfo: {
                        Source: "Penalty",
                        GameName: "PenaltyLadder",
                        RoundId: st.series_id,
                        GameNumber: `${st.series_id}:cashout:${st.level}`,
                        ServerSeed: st.server_seed,
                        ServerSeedHash: st.server_seed_hash,
                        Level: st.level,
                        Kicks: st.kicks
                    }
                });
            }
            st.status = "CASHED";
            yield saveSeries(st);
            const cumCost = +(st.level * st.stake).toFixed(2);
            const resp = {
                game: "PenaltyLadder",
                mode,
                series_id: st.series_id,
                level: st.level,
                status: st.status,
                payout,
                cost_total: cumCost,
                profit: +(payout - cumCost).toFixed(2),
                server_seed: st.server_seed, // reveal now
                plan: (_c = st.lastPlan) !== null && _c !== void 0 ? _c : null
            };
            if (idem)
                yield setIdem(mode, sess.sid, "cashout", idem, resp);
            return resp;
        }));
    });
}
/**
 * Status
 */
function statusSvc(sess, input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const st = yield loadSeries(sess.sid, input.series_id);
        if (!st)
            throw errors_1.AppError.notFound("SERIES_NOT_FOUND");
        const potMult = st.level >= 1 ? MULTIPLIERS[st.level - 1] : MULTIPLIERS[0];
        const can_cashout = st.status === "ACTIVE" && st.level >= 1;
        return {
            game: "PenaltyLadder",
            series_id: st.series_id,
            level: st.level,
            status: st.status,
            stake_per_kick: st.stake,
            can_cashout,
            next_multiplier: st.level < MAX_LEVELS ? MULTIPLIERS[st.level] : null,
            potential: can_cashout ? {
                multiplier: potMult,
                payout: +(st.stake * potMult).toFixed(2),
                cost_so_far: +(st.level * st.stake).toFixed(2),
                profit_if_cashout: +((st.stake * potMult) - (st.level * st.stake)).toFixed(2)
            } : null,
            server_seed_hash: st.server_seed_hash,
            server_seed: st.status !== "ACTIVE" ? st.server_seed : undefined,
            kicks: st.kicks,
            plan: (_a = st.lastPlan) !== null && _a !== void 0 ? _a : null
        };
    });
}
