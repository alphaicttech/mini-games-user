import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

/**
 * Mechanics
 * - Progressive levels: 1..5 with multipliers [2,4,12,20,32] (stake INCLUDED).
 * - Cashout allowed after any successful kick (level >= 1).
 * - Each kick deducts the same stake (per-kick debit).
 * - If a kick is saved → series ends LOST (no payout); all deducted stakes remain spent.
 * - We leave one RTP entry **open per kick** (REAL). On SAVE: settle all with win=0. On CASHOUT: settle (level-1) entries win=0 and last entry with the payout.
 */

const GAME_CODE = "penality";             // keep code to match your folder/name
const IDEM_TTL = 24 * 60 * 60;
const MAX_LEVELS = 5;
const MULTIPLIERS = [2, 4, 12, 20, 32];   // level 1..5 (index 0..4)

// Example per-level GOAL probabilities (tune to target your RTP)
const P_GOAL = [0.78, 0.62, 0.46, 0.33, 0.22];

// Demo helpers
async function getDemoBalance(sess: ProviderSession) {
    const key = `demo:bal:${sess.sid}`;
    const cached = await redis.get(key);
    if (cached) return Number(cached);
    const base = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(key, String(base), 2 * 60 * 60);
    return base;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
    await redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
}

// RNG helpers (provably fair)
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (server: string, client: string, tag: string) =>
    u32(hmacHex(server, `${client}:${tag}`).slice(0, 8)) / 4294967296;

// Idempotency helpers (mode-scoped)
const idemKey = (mode: "real" | "demo", sid: string, action: string, key: string) => `idem:${mode}:penladder:${action}:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, action: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(idemKey(mode, sid, action, key));
    return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, action: string, key: string, payload: any) {
    await redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL);
}

// Series state
type SeriesState = {
    series_id: string;
    sid: string;
    portalName?: string;
    stake: number;
    currency: string;
    level: number;           // 0..5 (0 before first kick)
    status: "ACTIVE" | "CASHED" | "LOST";
    server_seed: string;
    server_seed_hash: string;
    client_seed_base: string | null;
    created_at: number;
    kicks: Array<{
        index: number; // 1..level attempted so far
        target: { col: number; row: number };
        client_seed: string;
        u: number;
        p_goal: number;
        result: "GOAL" | "SAVE";
        txn_id: string; // debit txn for that kick
    }>;

    // RTP (REAL)
    rtpDayKey?: string;
    openEntries?: number;     // how many kicks are RTP-entered but not yet settled
    lastPlan?: { target: number; hardCap: number; softCap: number } | null;
};

const sKey = (sid: string, seriesId: string) => `plad:series:${sid}:${seriesId}`;

async function loadSeries(sid: string, series_id: string): Promise<SeriesState | null> {
    const v = await redis.get(sKey(sid, series_id));
    return v ? JSON.parse(v) as SeriesState : null;
}
async function saveSeries(state: SeriesState) {
    await redis.set(sKey(state.sid, state.series_id), JSON.stringify(state), 24 * 60 * 60);
}

/** Distributed lock per series to protect /kick & /cashout races */
async function withSeriesLock<T>(sid: string, seriesId: string, fn: () => Promise<T>): Promise<T> {
    const lockKey = `plad:lock:${sid}:${seriesId}`;
    const ok = await (rawRedis as any).set(lockKey, "1", "EX", 3, "NX"); // string form to avoid TS typing issues
    if (ok !== "OK") throw AppError.conflict("Series is busy, retry");
    try { return await fn(); } finally { await rawRedis.del(lockKey); }
}

// ---- cfg / RTP helpers ----
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
function demoPlan(stake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

/**
 * Start series
 */
export async function startSeriesSvc(
    sess: ProviderSession,
    input: { stake: number; client_seed?: string },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) {
        const hit = await getIdem(mode, sess.sid, "start", idem);
        if (hit) return hit;
    }

    const stake = Number(input.stake);
    if (!(stake > 0)) throw AppError.badRequest("Invalid stake");

    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);
    const baseClientSeed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    const series: SeriesState = {
        series_id: randomUUID(),
        sid: sess.sid,
        portalName: sess.portalName,
        currency: sess.currency,
        stake,
        level: 0,
        status: "ACTIVE",
        server_seed: serverSeed,
        server_seed_hash: serverSeedHash,
        client_seed_base: baseClientSeed,
        created_at: Date.now(),
        kicks: [],
        openEntries: 0,
        lastPlan: null,
    };

    await saveSeries(series);

    const resp = {
        game: "PenaltyLadder",
        mode: mode,
        series_id: series.series_id,
        stake_per_kick: stake,
        level: series.level,
        next_multiplier: MULTIPLIERS[0],
        server_seed_hash: serverSeedHash,
        can_cashout: false,
        grid: { cols: 3, rows: 5 }
    };

    if (idem) await setIdem(mode, sess.sid, "start", idem, resp);
    return resp;
}

/**
 * Kick (attempt next level)
 */
export async function kickSvc(
    sess: ProviderSession,
    input: { series_id: string; target: { col: number; row: number }; client_seed?: string },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) {
        const hit = await getIdem(mode, sess.sid, "kick", idem);
        if (hit) return hit;
    }

    return withSeriesLock(sess.sid, input.series_id, async () => {
        const st = await loadSeries(sess.sid, input.series_id);
        if (!st) throw AppError.notFound("SERIES_NOT_FOUND");
        if (st.status !== "ACTIVE") throw AppError.badRequest(`Series ${st.status}`);

        const nextLevel = st.level + 1;
        if (nextLevel > MAX_LEVELS) throw AppError.badRequest("All levels already completed");

        // Debit stake for this kick
        const txnId = randomUUID();
        if (mode === "demo") {
            const bal = await getDemoBalance(sess);
            if (bal < st.stake) throw AppError.badRequest("Insufficient FUN balance");
            await setDemoBalance(sess, +(bal - st.stake).toFixed(2));
        } else {
            const operator = await findByPortalName(sess.portalName);
            const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
            const opCtx: any = {
                baseUrl: operator.baseUrl,
                secret: operator.secret,
                session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            await deposit(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: st.stake,
                CurrencyCode: st.currency,
                TransactionInfo: {
                    Source: "Penalty",
                    GameName: "PenaltyLadder",
                    RoundId: st.series_id,
                    GameNumber: `${st.series_id}:${nextLevel}`,
                    ServerSeedHash: st.server_seed_hash,
                    ClientSeed: input.client_seed ?? st.client_seed_base!,
                    Level: nextLevel,
                    Target: input.target
                }
            });

            // RTP: enter one open entry for this kick
            const yymmdd = toYYMMDD();
            if (!st.rtpDayKey) {
                st.rtpDayKey = rk.day(GAME_CODE, yymmdd);
                await redis.hsetnx(st.rtpDayKey, "rtp_target", 0.90);
            }
            await redis.spEnter(st.rtpDayKey, st.stake);
            st.openEntries = (st.openEntries ?? 0) + 1;

            // Optional: refresh plan snapshot for UI after each kick (not used for settlement here)
            const cfg = await loadGameCfg();
            st.lastPlan = await spPlan(GAME_CODE, st.stake, cfg, yymmdd);
        }

        // Resolve (provably fair)
        const cseed = input.client_seed ?? st.client_seed_base!;
        const u = r01(st.server_seed, cseed, `kick:${st.series_id}:${nextLevel}`);
        const p = P_GOAL[nextLevel - 1];
        const isGoal = u < p;

        st.kicks.push({
            index: nextLevel,
            target: input.target,
            client_seed: cseed,
            u: +u.toFixed(8),
            p_goal: p,
            result: isGoal ? "GOAL" : "SAVE",
            txn_id: txnId,
        });

        if (isGoal) {
            // advance level; keep RTP entry OPEN (we will settle at CASHOUT or on SAVE)
            st.level = nextLevel;
            await saveSeries(st);

            const potMult = MULTIPLIERS[st.level - 1];
            const cumCost = +(st.level * st.stake).toFixed(2);
            const cashoutValue = +(st.stake * potMult).toFixed(2);
            const profitIfCashout = +(cashoutValue - cumCost).toFixed(2);
            const lastKick = st.kicks[st.kicks.length - 1];

            const resp = {
                game: "PenaltyLadder",
                mode,
                series_id: st.series_id,
                level: st.level,
                result: "GOAL" as const,
                target: input.target,
                can_cashout: true,
                potential: {
                    multiplier: potMult,
                    payout: cashoutValue,
                    cost_so_far: cumCost,
                    profit_if_cashout: profitIfCashout
                },
                next_multiplier: st.level < MAX_LEVELS ? MULTIPLIERS[st.level] : null,
                rng: { u: lastKick.u, threshold: p },
                fairness: { server_seed_hash: st.server_seed_hash },
                plan: st.lastPlan ?? null
            };
            if (idem) await setIdem(mode, sess.sid, "kick", idem, resp);
            return resp;
        } else {
            // SAVE (loss): settle ALL open entries with win=0 (REAL)
            if (mode === "real" && st.rtpDayKey && (st.openEntries ?? 0) > 0) {
                const count = st.openEntries!;
                for (let i = 0; i < count; i++) {
                    await redis.spSettle(st.rtpDayKey, st.stake, 0);
                }
                st.openEntries = 0;
            }

            st.status = "LOST";
            await saveSeries(st);
            const lastKick = st.kicks[st.kicks.length - 1];
            const resp = {
                game: "PenaltyLadder",
                mode,
                series_id: st.series_id,
                level: st.level, // unchanged
                result: "SAVE" as const,
                target: input.target,
                finished: true,
                payout: 0,
                server_seed: st.server_seed, // reveal at end
                rng: { u: lastKick.u, threshold: p },
            };
            if (idem) await setIdem(mode, sess.sid, "kick", idem, resp);
            return resp;
        }
    });
}

/**
 * Cashout
 */
export async function cashoutSvc(
    sess: ProviderSession,
    input: { series_id: string },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) {
        const hit = await getIdem(mode, sess.sid, "cashout", idem);
        if (hit) return hit;
    }

    return withSeriesLock(sess.sid, input.series_id, async () => {
        const st = await loadSeries(sess.sid, input.series_id);
        if (!st) throw AppError.notFound("SERIES_NOT_FOUND");
        if (st.status !== "ACTIVE") throw AppError.badRequest(`Series ${st.status}`);
        if (st.level < 1) throw AppError.badRequest("Nothing to cash out yet");

        const mult = MULTIPLIERS[st.level - 1];
        let payout = +(st.stake * mult).toFixed(2);

        // Clamp to configured caps and live RTP hard cap (REAL)
        const cfg = await loadGameCfg();
        if (mode === "real") {
            const yymmdd = toYYMMDD();
            // plan against current state (PI has accumulated through open entries)
            const plan = await spPlan(GAME_CODE, st.stake, cfg, yymmdd);
            st.lastPlan = plan;
            const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            payout = Math.min(payout, slipCap);
        }
        // also apply per-user/per-bet caps always
        payout = Math.min(payout, cfg.per_bet_cap, cfg.per_user_daily_cap);

        if (mode === "demo") {
            const bal = await getDemoBalance(sess);
            await setDemoBalance(sess, +(bal + payout).toFixed(2));
        } else {
            // RTP settle: clear (level - 1) entries with 0, last with payout
            if (!st.rtpDayKey) {
                const yymmdd = toYYMMDD();
                st.rtpDayKey = rk.day(GAME_CODE, yymmdd); // fallback
            }
            const toClear = Math.max(0, (st.openEntries ?? st.level) - 1);
            for (let i = 0; i < toClear; i++) {
                await redis.spSettle(st.rtpDayKey!, st.stake, 0);
            }
            await redis.spSettle(st.rtpDayKey!, st.stake, payout);
            st.openEntries = 0;

            const operator = await findByPortalName(sess.portalName);
            const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
            const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            await withdraw(opCtx, {
                TransactionId: `${st.series_id}-CASHOUT-${st.level}`,
                TransactionType: "WinAmount",
                Amount: payout,
                CurrencyCode: st.currency,
                TransactionInfo: {
                    Source: "Penalty",
                    GameName: "PenaltyLadder",
                    RoundId: st.series_id,
                    GameNumber: `${st.series_id}:cashout:${st.level}`,
                    ServerSeed: st.server_seed,
                    ServerSeedHash: st.server_seed_hash,
                    Level: st.level,
                    Kicks: st.kicks
                }
            });
        }

        st.status = "CASHED";
        await saveSeries(st);

        const cumCost = +(st.level * st.stake).toFixed(2);
        const resp = {
            game: "PenaltyLadder",
            mode,
            series_id: st.series_id,
            level: st.level,
            status: st.status,
            payout,
            cost_total: cumCost,
            profit: +(payout - cumCost).toFixed(2),
            server_seed: st.server_seed, // reveal now
            plan: st.lastPlan ?? null
        };
        if (idem) await setIdem(mode, sess.sid, "cashout", idem, resp);
        return resp;
    });
}

/**
 * Status
 */
export async function statusSvc(
    sess: ProviderSession,
    input: { series_id: string }
) {
    const st = await loadSeries(sess.sid, input.series_id);
    if (!st) throw AppError.notFound("SERIES_NOT_FOUND");
    const potMult = st.level >= 1 ? MULTIPLIERS[st.level - 1] : MULTIPLIERS[0];
    const can_cashout = st.status === "ACTIVE" && st.level >= 1;
    return {
        game: "PenaltyLadder",
        series_id: st.series_id,
        level: st.level,
        status: st.status,
        stake_per_kick: st.stake,
        can_cashout,
        next_multiplier: st.level < MAX_LEVELS ? MULTIPLIERS[st.level] : null,
        potential: can_cashout ? {
            multiplier: potMult,
            payout: +(st.stake * potMult).toFixed(2),
            cost_so_far: +(st.level * st.stake).toFixed(2),
            profit_if_cashout: +((st.stake * potMult) - (st.level * st.stake)).toFixed(2)
        } : null,
        server_seed_hash: st.server_seed_hash,
        server_seed: st.status !== "ACTIVE" ? st.server_seed : undefined,
        kicks: st.kicks,
        plan: st.lastPlan ?? null
    };
}
