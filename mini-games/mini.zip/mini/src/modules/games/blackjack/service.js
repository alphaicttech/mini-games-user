"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startSvc = startSvc;
exports.hitSvc = hitSvc;
exports.standSvc = standSvc;
exports.doubleSvc = doubleSvc;
exports.splitSvc = splitSvc;
exports.finishSvc = finishSvc;
exports.statusSvc = statusSvc;
exports.insuranceSvc = insuranceSvc;
exports.surrenderSvc = surrenderSvc;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor"); // (not used to clamp results; can be returned for UI/analytics)
const redis_2 = require("../../../config/redis");
// =========================
// Config / constants
// =========================
const IDEM_TTL = 24 * 60 * 60; // seconds
const GAME_CODE = "blackjack";
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
// =========================
// RNG / cards
// =========================
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, i, tag) => u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;
function buildShoe(decks) {
    const one = [];
    for (let s = 0; s < 4; s++)
        for (let r = 0; r < 13; r++)
            one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => (Object.assign({}, c))));
}
function shuffle(arr, server, client) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k];
        a[k] = a[j];
        a[j] = t;
    }
    return a;
}
function bjValue(hand) {
    let total = 0, aces = 0;
    for (const c of hand) {
        if (c.r === 0) {
            aces++;
            total += 1;
        }
        else if (c.r >= 1 && c.r <= 9)
            total += (c.r + 1);
        else
            total += 10;
    }
    let soft = false;
    if (aces && total + 10 <= 21) {
        total += 10;
        soft = true;
    }
    const isBlackjack = (hand.length === 2 && total === 21);
    return { total, soft, isBlackjack };
}
function fmtCard(c) { return c ? { rank: RANKS[c.r], suit: SUITS[c.s] } : null; }
// =========================
// Redis helpers & idem
// =========================
const rKey = (sid, id) => `bj:round:${sid}:${id}`;
function saveRound(r) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(rKey(r.sid, r.round_id), JSON.stringify(r), 24 * 60 * 60); });
}
function loadRound(sid, id) {
    return __awaiter(this, void 0, void 0, function* () { const v = yield redis_1.redis.get(rKey(sid, id)); return v ? JSON.parse(v) : null; });
}
function withLock(sid, roundId, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const lk = `bj:lock:${sid}:${roundId}`;
        const ok = yield redis_1.rawRedis.set(lk, "1", "EX", 3, "NX");
        if (ok !== "OK")
            throw errors_1.AppError.conflict("Round is busy, retry");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(lk);
        }
    });
}
// Idempotency (mode-scoped)
function idemKey(mode, sid, action, key) { return `idem:${mode}:bj:${action}:${sid}:${key}`; }
function getIdem(mode, sid, action, key) {
    return __awaiter(this, void 0, void 0, function* () { if (!key)
        return null; const v = yield redis_1.redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) : null; });
}
function setIdem(mode, sid, action, key, payload) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); });
}
// =========================
// Demo wallet
// =========================
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const k = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(k);
        if (v)
            return Number(v);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(k, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amt) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60); });
}
// =========================
// Status helpers
// =========================
function deriveStatus(h) {
    if (h.surrendered)
        return "SURRENDERED";
    if (h.bust)
        return "BUST";
    if (h.blackjack)
        return "BLACKJACK";
    if (h.stood)
        return "STAND";
    const v = bjValue(h.cards);
    if (v.total > 21)
        return "BUST";
    if (v.total === 21)
        return "TWENTYONE";
    return "PLAYING";
}
function mustStand(h) {
    const v = bjValue(h.cards);
    return h.bust || h.stood || h.blackjack || v.total >= 21 || h.surrendered;
}
function ensurePlayable(r, idx) {
    if (r.settled)
        throw errors_1.AppError.badRequest("ROUND_ALREADY_SETTLED");
    const h = r.hands[idx];
    if (!h)
        throw errors_1.AppError.badRequest("INVALID_HAND");
    if (mustStand(h))
        throw errors_1.AppError.badRequest("HAND_CANNOT_ACT");
}
// =========================
// Public services
// =========================
function startSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "start", idem);
            if (hit)
                return hit;
        }
        const stake = Number(input.stake);
        if (!(stake > 0))
            throw errors_1.AppError.badRequest("Invalid stake");
        const cfg = {
            decks: (_b = (_a = input.cfg) === null || _a === void 0 ? void 0 : _a.decks) !== null && _b !== void 0 ? _b : 6,
            bj_pays: (_d = (_c = input.cfg) === null || _c === void 0 ? void 0 : _c.bj_pays) !== null && _d !== void 0 ? _d : 1.5,
            dealer_hit_soft_17: (_f = (_e = input.cfg) === null || _e === void 0 ? void 0 : _e.dealer_hit_soft_17) !== null && _f !== void 0 ? _f : false,
            allow_double: (_h = (_g = input.cfg) === null || _g === void 0 ? void 0 : _g.allow_double) !== null && _h !== void 0 ? _h : true,
            allow_split: (_k = (_j = input.cfg) === null || _j === void 0 ? void 0 : _j.allow_split) !== null && _k !== void 0 ? _k : true,
            allow_insurance: (_m = (_l = input.cfg) === null || _l === void 0 ? void 0 : _l.allow_insurance) !== null && _m !== void 0 ? _m : false,
            allow_surrender: (_p = (_o = input.cfg) === null || _o === void 0 ? void 0 : _o.allow_surrender) !== null && _p !== void 0 ? _p : false,
        };
        const server_seed = crypto_1.default.randomBytes(32).toString("hex");
        const server_seed_hash = sha256(server_seed);
        const client_seed = (_s = (_r = (_q = input.client_seed) !== null && _q !== void 0 ? _q : sess.clientExternalKey) !== null && _r !== void 0 ? _r : sess.userName) !== null && _s !== void 0 ? _s : "client";
        const shoe = shuffle(buildShoe(cfg.decks), server_seed, client_seed);
        let idx = 0;
        const draw = () => shoe[idx++];
        const player = { cards: [draw(), draw()], bet: stake };
        const dealer = [draw(), draw()];
        // Debit base stake
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < stake)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - stake).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_t = sess.opSessionId) !== null && _t !== void 0 ? _t : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: server_seed_hash, TransactionType: "PlaceBet", Amount: stake, CurrencyCode: sess.currency,
                TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: server_seed_hash, GameNumber: Date.now().toString(), ServerSeedHash: server_seed_hash, ClientSeed: client_seed }
            });
        }
        const round = {
            round_id: (0, crypto_1.randomUUID)(),
            sid: sess.sid,
            portalName: sess.portalName,
            currency: sess.currency,
            server_seed, server_seed_hash, client_seed,
            cfg,
            shoe, shoe_idx: idx,
            stake_base: stake,
            hands: [player],
            dealer,
            settled: false,
            created_at: Date.now(),
            mode,
            rtpEntered: 0,
            rtpSettled: 0,
            lastPlan: null
        };
        // RTP enter (REAL)
        if (mode === "real") {
            const yymmdd = (0, date_1.toYYMMDD)();
            round.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_2.redis.hsetnx(round.rtpDayKey, "rtp_target", 0.90);
            yield redis_2.redis.spEnter(round.rtpDayKey, stake);
            round.rtpEntered = ((_u = round.rtpEntered) !== null && _u !== void 0 ? _u : 0) + stake;
            // optional: snapshot plan (for UI / debugging)
            round.lastPlan = yield (0, governor_1.spPlan)(GAME_CODE, stake, yield loadGameCfg(), yymmdd);
        }
        // Insurance availability (dealer upcard Ace + feature flag)
        const dealerUpIsAce = (dealer[0].r === 0);
        round.insurance = {
            allowed: dealerUpIsAce && !!cfg.allow_insurance,
            decided: false,
            taken: false,
            stake: +(stake / 2).toFixed(2),
        };
        // Natural checks (do NOT auto-settle if insurance offered)
        const pV = bjValue(player.cards), dV = bjValue(dealer.slice(0, 2));
        player.blackjack = pV.isBlackjack;
        let autoSettle = false;
        if (!(round.insurance.allowed)) {
            if (pV.isBlackjack || dV.isBlackjack)
                autoSettle = true;
        }
        yield saveRound(round);
        let payload = {
            game: "Blackjack",
            round_id: round.round_id,
            currency: round.currency,
            mode,
            server_seed_hash,
            dealer: { upcard: fmtCard(dealer[0]), hole: null },
            hands: round.hands.map(h => ({ cards: h.cards.map(fmtCard), bet: h.bet, status: deriveStatus(h) })),
            actions: {
                can_insure: !!(((_v = round.insurance) === null || _v === void 0 ? void 0 : _v.allowed) && !round.insurance.decided && round.hands.length === 1 && round.hands[0].cards.length === 2 && !round.hands[0].doubled && !round.hands[0].surrendered),
                can_surrender: round.hands.map(h => (h.cards.length === 2 && !h.doubled && !h.surrendered && !h.blackjack))
            },
            settled: false,
            plan: (_w = round.lastPlan) !== null && _w !== void 0 ? _w : undefined
        };
        if (autoSettle) {
            payload = yield finalizeRound(round, sess);
        }
        if (idem)
            yield setIdem(mode, sess.sid, "start", idem, payload);
        return payload;
    });
}
function hitSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "hit", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            ensurePlayable(r, input.hand_index);
            const draw = () => r.shoe[r.shoe_idx++];
            r.hands[input.hand_index].cards.push(draw());
            if (bjValue(r.hands[input.hand_index].cards).total > 21)
                r.hands[input.hand_index].bust = true;
            yield saveRound(r);
            const resp = yield maybeAutoFinish(r, sess);
            if (idem)
                yield setIdem(mode, sess.sid, "hit", idem, resp);
            return resp;
        }));
    });
}
function standSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "stand", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            ensurePlayable(r, input.hand_index);
            r.hands[input.hand_index].stood = true;
            yield saveRound(r);
            const resp = yield maybeAutoFinish(r, sess);
            if (idem)
                yield setIdem(mode, sess.sid, "stand", idem, resp);
            return resp;
        }));
    });
}
function doubleSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "double", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            const h = r.hands[input.hand_index];
            ensurePlayable(r, input.hand_index);
            if (!r.cfg.allow_double)
                throw errors_1.AppError.badRequest("DOUBLE_NOT_ALLOWED");
            if (h.cards.length !== 2)
                throw errors_1.AppError.badRequest("DOUBLE_ONLY_ON_FIRST_TWO");
            // Debit extra stake
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                if (bal < h.bet)
                    throw errors_1.AppError.badRequest("Insufficient FUN balance");
                yield setDemoBalance(sess, +(bal - h.bet).toFixed(2));
            }
            else {
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                yield (0, client_1.deposit)(opCtx, {
                    TransactionId: `${r.server_seed_hash}-D-${input.hand_index}`,
                    TransactionType: "PlaceBet", Amount: h.bet, CurrencyCode: r.currency,
                    TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:double:${input.hand_index}` }
                });
                // RTP enter extra stake
                if (r.rtpDayKey) {
                    yield redis_2.redis.spEnter(r.rtpDayKey, h.bet);
                    r.rtpEntered = ((_b = r.rtpEntered) !== null && _b !== void 0 ? _b : 0) + h.bet;
                }
            }
            const draw = () => r.shoe[r.shoe_idx++];
            h.cards.push(draw());
            h.doubled = true;
            h.stood = true;
            if (bjValue(h.cards).total > 21)
                h.bust = true;
            yield saveRound(r);
            const resp = yield maybeAutoFinish(r, sess);
            if (idem)
                yield setIdem(mode, sess.sid, "double", idem, resp);
            return resp;
        }));
    });
}
function splitSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "split", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (!r.cfg.allow_split)
                throw errors_1.AppError.badRequest("SPLIT_NOT_ALLOWED");
            if (r.hands.length !== 1)
                throw errors_1.AppError.badRequest("ONLY_ONE_SPLIT_SUPPORTED");
            const h0 = r.hands[0];
            if (h0.cards.length !== 2)
                throw errors_1.AppError.badRequest("SPLIT_ONLY_ON_FIRST_TWO");
            const v0 = (c) => (c.r >= 9 ? 10 : (c.r === 0 ? 11 : c.r + 1));
            if (v0(h0.cards[0]) !== v0(h0.cards[1]))
                throw errors_1.AppError.badRequest("PAIR_REQUIRED_TO_SPLIT");
            // Debit stake for second hand
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                if (bal < r.stake_base)
                    throw errors_1.AppError.badRequest("Insufficient FUN balance");
                yield setDemoBalance(sess, +(bal - r.stake_base).toFixed(2));
            }
            else {
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                yield (0, client_1.deposit)(opCtx, {
                    TransactionId: `${r.server_seed_hash}-S`, TransactionType: "PlaceBet", Amount: r.stake_base, CurrencyCode: r.currency,
                    TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:split` }
                });
                // RTP enter extra stake
                if (r.rtpDayKey) {
                    yield redis_2.redis.spEnter(r.rtpDayKey, r.stake_base);
                    r.rtpEntered = ((_b = r.rtpEntered) !== null && _b !== void 0 ? _b : 0) + r.stake_base;
                }
            }
            const draw = () => r.shoe[r.shoe_idx++];
            const c1 = h0.cards[0], c2 = h0.cards[1];
            const hA = { cards: [c1, draw()], bet: r.stake_base, split_from: true };
            const hB = { cards: [c2, draw()], bet: r.stake_base, split_from: true };
            hA.blackjack = false;
            hB.blackjack = false;
            r.hands = [hA, hB];
            yield saveRound(r);
            const resp = yield statusPayload(r, false);
            if (idem)
                yield setIdem(mode, sess.sid, "split", idem, resp);
            return resp;
        }));
    });
}
function finishSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "finish", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            const resp = yield finalizeRound(r, sess);
            if (idem)
                yield setIdem(mode, sess.sid, "finish", idem, resp);
            return resp;
        }));
    });
}
function statusSvc(sess, input) {
    return __awaiter(this, void 0, void 0, function* () {
        const r = yield loadRound(sess.sid, input.round_id);
        if (!r)
            throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
        return statusPayload(r, !!r.settled);
    });
}
// =========================
// Insurance & Surrender
// =========================
function insuranceSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "insurance", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d;
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (r.settled)
                throw errors_1.AppError.badRequest("ROUND_ALREADY_SETTLED");
            if (!((_a = r.insurance) === null || _a === void 0 ? void 0 : _a.allowed))
                throw errors_1.AppError.badRequest("INSURANCE_NOT_AVAILABLE");
            if (r.insurance.decided)
                throw errors_1.AppError.conflict("INSURANCE_ALREADY_DECIDED");
            if (!(r.hands.length === 1 && r.hands[0].cards.length === 2 && !r.hands[0].doubled && !r.hands[0].surrendered))
                throw errors_1.AppError.badRequest("INVALID_STATE_FOR_INSURANCE");
            r.insurance.decided = true;
            r.insurance.taken = !!input.take;
            if (!input.take) {
                yield saveRound(r);
                const resp = statusPayload(r, false);
                if (idem)
                    yield setIdem(mode, sess.sid, "insurance", idem, resp);
                return resp;
            }
            // TAKE insurance: debit stake/2
            const insStake = r.insurance.stake;
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                if (bal < insStake)
                    throw errors_1.AppError.badRequest("Insufficient FUN balance for insurance");
                yield setDemoBalance(sess, +(bal - insStake).toFixed(2));
            }
            else {
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                yield (0, client_1.deposit)(opCtx, {
                    TransactionId: `${r.server_seed_hash}-INS`, TransactionType: "PlaceBet", Amount: insStake, CurrencyCode: r.currency,
                    TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:insurance` }
                });
                // RTP enter insurance stake
                if (r.rtpDayKey) {
                    yield redis_2.redis.spEnter(r.rtpDayKey, insStake);
                    r.rtpEntered = ((_c = r.rtpEntered) !== null && _c !== void 0 ? _c : 0) + insStake;
                }
            }
            // Resolve immediately by peeking dealer hole
            const dealerHasBJ = bjValue(r.dealer.slice(0, 2)).isBlackjack;
            r.insurance.resolved = true;
            r.insurance.payout = dealerHasBJ ? +(insStake * 3.0).toFixed(2) : 0; // stake-included (2:1 profit)
            // RTP settle insurance immediately (REAL)
            if (mode === "real" && r.rtpDayKey) {
                yield redis_2.redis.spSettle(r.rtpDayKey, insStake, r.insurance.payout);
                r.rtpSettled = ((_d = r.rtpSettled) !== null && _d !== void 0 ? _d : 0) + r.insurance.payout;
            }
            yield saveRound(r);
            if (dealerHasBJ) {
                const resp = yield finalizeRound(r, sess); // round ends
                if (idem)
                    yield setIdem(mode, sess.sid, "insurance", idem, resp);
                return resp;
            }
            else {
                const resp = statusPayload(r, false);
                if (idem)
                    yield setIdem(mode, sess.sid, "insurance", idem, resp);
                return resp;
            }
        }));
    });
}
function surrenderSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "surrender", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (r.settled)
                throw errors_1.AppError.badRequest("ROUND_ALREADY_SETTLED");
            if (!r.cfg.allow_surrender)
                throw errors_1.AppError.badRequest("SURRENDER_DISABLED");
            const h = r.hands[input.hand_index];
            if (!h)
                throw errors_1.AppError.badRequest("INVALID_HAND");
            if (!(h.cards.length === 2 && !h.doubled && !h.surrendered && !h.blackjack))
                throw errors_1.AppError.badRequest("INVALID_STATE_FOR_SURRENDER");
            if (bjValue(r.dealer.slice(0, 2)).isBlackjack)
                throw errors_1.AppError.badRequest("CANNOT_SURRENDER_AFTER_DEALER_BJ");
            h.surrendered = true;
            h.stood = true;
            yield saveRound(r);
            const resp = yield maybeAutoFinish(r, sess);
            if (idem)
                yield setIdem(mode, sess.sid, "surrender", idem, resp);
            return resp;
        }));
    });
}
// =========================
// Finishing & status
// =========================
function maybeAutoFinish(r, sess) {
    return __awaiter(this, void 0, void 0, function* () {
        const allDone = r.hands.every(h => {
            const v = bjValue(h.cards);
            return h.surrendered || h.stood || h.bust || h.blackjack || v.total >= 21;
        });
        if (!allDone)
            return statusPayload(r, false);
        return finalizeRound(r, sess);
    });
}
function finalizeRound(r, sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g;
        if (r.settled)
            return statusPayload(r, true);
        // Dealer plays out
        let d = r.dealer.slice();
        while (true) {
            const v = bjValue(d);
            const soft17 = (v.total === 17 && v.soft === true);
            const mustHit = v.total < 17 || (r.cfg.dealer_hit_soft_17 && soft17);
            if (mustHit) {
                d.push(r.shoe[r.shoe_idx++]);
            }
            else
                break;
        }
        r.dealer = d;
        // Resolve each hand
        const dv = bjValue(r.dealer);
        let payoutTotal = 0;
        for (const h of r.hands) {
            const pv = bjValue(h.cards);
            let mult = 0;
            if (h.surrendered)
                mult = 0.5;
            else if (h.bust)
                mult = 0.0;
            else if (pv.isBlackjack && !dv.isBlackjack)
                mult = 1 + r.cfg.bj_pays;
            else if (dv.isBlackjack && !pv.isBlackjack)
                mult = 0.0;
            else if (dv.total > 21)
                mult = 2.0;
            else if (pv.total > dv.total)
                mult = 2.0;
            else if (pv.total < dv.total)
                mult = 0.0;
            else
                mult = 1.0;
            const bet = h.doubled ? h.bet * 2 : h.bet;
            payoutTotal += +(bet * mult).toFixed(2);
        }
        // Add insurance payout if not already settled in RTP (RoundState keeps monetary insurance payout)
        const insPayout = (((_a = r.insurance) === null || _a === void 0 ? void 0 : _a.taken) && r.insurance.resolved) ? ((_b = r.insurance.payout) !== null && _b !== void 0 ? _b : 0) : 0;
        payoutTotal = +(payoutTotal + insPayout).toFixed(2);
        // Credit once
        if (sess.mode === "demo") {
            const bal = yield getDemoBalance(sess);
            yield setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
        }
        else if (payoutTotal > 0) {
            // RTP settle remaining (exclude already-settled insurance)
            const alreadySettled = (_c = r.rtpSettled) !== null && _c !== void 0 ? _c : 0;
            const remainingPayout = Math.max(0, +(payoutTotal - alreadySettled).toFixed(2));
            if (!r.rtpDayKey) {
                const yymmdd = (0, date_1.toYYMMDD)();
                r.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
                yield redis_2.redis.hsetnx(r.rtpDayKey, "rtp_target", 0.90);
            }
            // We entered r.rtpEntered over the round (base stake + doubles/split + insurance); settle only the remaining payout here
            yield redis_2.redis.spSettle(r.rtpDayKey, (_d = r.rtpEntered) !== null && _d !== void 0 ? _d : 0, remainingPayout);
            r.rtpSettled = ((_e = r.rtpSettled) !== null && _e !== void 0 ? _e : 0) + remainingPayout;
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_f = sess.opSessionId) !== null && _f !== void 0 ? _f : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${r.server_seed_hash}-W`, TransactionType: "WinAmount", Amount: payoutTotal, CurrencyCode: r.currency,
                TransactionInfo: {
                    Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}`,
                    ServerSeed: r.server_seed, ServerSeedHash: r.server_seed_hash, ClientSeed: r.client_seed,
                    Dealer: r.dealer.map(fmtCard),
                    Hands: r.hands.map(h => ({ cards: h.cards.map(fmtCard), bet: h.bet, doubled: !!h.doubled, surrendered: !!h.surrendered })),
                    Insurance: r.insurance ? { taken: r.insurance.taken, stake: r.insurance.stake, payout: (_g = r.insurance.payout) !== null && _g !== void 0 ? _g : 0 } : undefined
                }
            });
        }
        r.settled = true;
        yield saveRound(r);
        return statusPayload(r, true);
    });
}
function statusPayload(r, settled) {
    var _a, _b, _c, _d;
    return {
        game: "Blackjack",
        round_id: r.round_id,
        currency: r.currency,
        mode: r.mode,
        settled,
        dealer: {
            upcard: fmtCard(r.dealer[0]),
            hole: settled ? fmtCard(r.dealer[1]) : null,
            cards: settled ? r.dealer.map(fmtCard) : [fmtCard(r.dealer[0]), null]
        },
        hands: r.hands.map(h => ({ cards: h.cards.map(fmtCard), bet: h.doubled ? h.bet * 2 : h.bet, status: deriveStatus(h) })),
        insurance: r.insurance ? {
            allowed: r.insurance.allowed, decided: r.insurance.decided, taken: r.insurance.taken,
            stake: r.insurance.stake, resolved: (_a = r.insurance.resolved) !== null && _a !== void 0 ? _a : false, payout: (_b = r.insurance.payout) !== null && _b !== void 0 ? _b : 0
        } : undefined,
        actions: {
            can_insure: !!(((_c = r.insurance) === null || _c === void 0 ? void 0 : _c.allowed) && !r.insurance.decided && r.hands.length === 1 && r.hands[0].cards.length === 2 && !r.hands[0].doubled && !r.hands[0].surrendered),
            can_surrender: r.hands.map(h => (h.cards.length === 2 && !h.doubled && !h.surrendered && !h.blackjack))
        },
        plan: (_d = r.lastPlan) !== null && _d !== void 0 ? _d : undefined
    };
}
