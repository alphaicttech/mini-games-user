import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor"; // (not used to clamp results; can be returned for UI/analytics)
import { redis as redisClient } from "../../../config/redis";

// =========================
// Config / constants
// =========================
const IDEM_TTL = 24 * 60 * 60; // seconds

const GAME_CODE = "blackjack";

// =========================
// Types / RTP cfg
// =========================
type RulesCfg = {
    decks: number;
    bj_pays: number;
    dealer_hit_soft_17: boolean;
    allow_double: boolean;
    allow_split: boolean;
    allow_insurance?: boolean;
    allow_surrender?: boolean;
};

type Card = { r: number; s: number }; // rank 0..12, suit 0..3
type HandState = {
    cards: Card[];
    bet: number;
    doubled?: boolean;
    stood?: boolean;
    bust?: boolean;
    blackjack?: boolean;
    split_from?: boolean;
    surrendered?: boolean;
};

type InsuranceState = {
    allowed: boolean;
    decided: boolean;
    taken: boolean;
    stake: number;      // stake/2
    resolved?: boolean;
    payout?: number;    // stake-included payout (3× stake) or 0
};

type RoundState = {
    round_id: string;
    sid: string;
    portalName?: string;
    currency: string;

    server_seed: string;
    server_seed_hash: string;
    client_seed: string;

    cfg: RulesCfg;
    shoe: Card[];
    shoe_idx: number;

    stake_base: number;
    hands: HandState[];
    dealer: Card[];
    insurance?: InsuranceState;

    settled?: boolean;
    created_at: number;

    // RTP (REAL mode only)
    mode: "real" | "demo";
    rtpDayKey?: string;
    rtpEntered?: number; // sum of stakes we have spEnter-ed
    rtpSettled?: number; // sum of payouts we have already spSettle-d (e.g., insurance)
    lastPlan?: { target: number; hardCap: number; softCap: number } | null;
};

type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};

async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}

// =========================
// RNG / cards
// =========================
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];

const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (server: string, client: string, i: number, tag: string) =>
    u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;

function buildShoe(decks: number): Card[] {
    const one: Card[] = [];
    for (let s = 0; s < 4; s++) for (let r = 0; r < 13; r++) one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => ({ ...c })));
}
function shuffle(arr: Card[], server: string, client: string) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k]; a[k] = a[j]; a[j] = t;
    }
    return a;
}
function bjValue(hand: Card[]) {
    let total = 0, aces = 0;
    for (const c of hand) {
        if (c.r === 0) { aces++; total += 1; }
        else if (c.r >= 1 && c.r <= 9) total += (c.r + 1);
        else total += 10;
    }
    let soft = false;
    if (aces && total + 10 <= 21) { total += 10; soft = true; }
    const isBlackjack = (hand.length === 2 && total === 21);
    return { total, soft, isBlackjack };
}
function fmtCard(c: Card | null) { return c ? { rank: RANKS[c.r], suit: SUITS[c.s] } : null; }

// =========================
// Redis helpers & idem
// =========================
const rKey = (sid: string, id: string) => `bj:round:${sid}:${id}`;
async function saveRound(r: RoundState) { await redis.set(rKey(r.sid, r.round_id), JSON.stringify(r), 24 * 60 * 60); }
async function loadRound(sid: string, id: string) { const v = await redis.get(rKey(sid, id)); return v ? JSON.parse(v) as RoundState : null; }
async function withLock<T>(sid: string, roundId: string, fn: () => Promise<T>) {
    const lk = `bj:lock:${sid}:${roundId}`; const ok = await (rawRedis as any).set(lk, "1", "EX", 3, "NX");
    if (ok !== "OK") throw AppError.conflict("Round is busy, retry"); try { return await fn(); } finally { await rawRedis.del(lk); }
}
// Idempotency (mode-scoped)
function idemKey(mode: "real" | "demo", sid: string, action: string, key: string) { return `idem:${mode}:bj:${action}:${sid}:${key}`; }
async function getIdem(mode: "real" | "demo", sid: string, action: string, key?: string) { if (!key) return null; const v = await redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) : null; }
async function setIdem(mode: "real" | "demo", sid: string, action: string, key: string, payload: any) { await redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); }

// =========================
// Demo wallet
// =========================
async function getDemoBalance(sess: ProviderSession) {
    const k = `demo:bal:${sess.sid}`; const v = await redis.get(k); if (v) return Number(v);
    const base = Number(process.env.DEMO_START_BALANCE ?? 1000); await redis.set(k, String(base), 2 * 60 * 60); return base;
}
async function setDemoBalance(sess: ProviderSession, amt: number) { await redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60); }

// =========================
// Status helpers
// =========================
function deriveStatus(h: HandState) {
    if (h.surrendered) return "SURRENDERED";
    if (h.bust) return "BUST";
    if (h.blackjack) return "BLACKJACK";
    if (h.stood) return "STAND";
    const v = bjValue(h.cards);
    if (v.total > 21) return "BUST";
    if (v.total === 21) return "TWENTYONE";
    return "PLAYING";
}
function mustStand(h: HandState) {
    const v = bjValue(h.cards);
    return h.bust || h.stood || h.blackjack || v.total >= 21 || h.surrendered;
}
function ensurePlayable(r: RoundState, idx: number) {
    if (r.settled) throw AppError.badRequest("ROUND_ALREADY_SETTLED");
    const h = r.hands[idx]; if (!h) throw AppError.badRequest("INVALID_HAND");
    if (mustStand(h)) throw AppError.badRequest("HAND_CANNOT_ACT");
}

// =========================
// Public services
// =========================
export async function startSvc(
    sess: ProviderSession,
    input: { stake: number; client_seed?: string; cfg: Partial<RulesCfg> },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "start", idem); if (hit) return hit; }

    const stake = Number(input.stake); if (!(stake > 0)) throw AppError.badRequest("Invalid stake");

    const cfg: RulesCfg = {
        decks: input.cfg?.decks ?? 6,
        bj_pays: input.cfg?.bj_pays ?? 1.5,
        dealer_hit_soft_17: input.cfg?.dealer_hit_soft_17 ?? false,
        allow_double: input.cfg?.allow_double ?? true,
        allow_split: input.cfg?.allow_split ?? true,
        allow_insurance: input.cfg?.allow_insurance ?? false,
        allow_surrender: input.cfg?.allow_surrender ?? false,
    };

    const server_seed = crypto.randomBytes(32).toString("hex");
    const server_seed_hash = sha256(server_seed);
    const client_seed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    const shoe = shuffle(buildShoe(cfg.decks), server_seed, client_seed);
    let idx = 0; const draw = () => shoe[idx++];

    const player: HandState = { cards: [draw(), draw()], bet: stake };
    const dealer: Card[] = [draw(), draw()];

    // Debit base stake
    if (mode === "demo") {
        const bal = await getDemoBalance(sess); if (bal < stake) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - stake).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: server_seed_hash, TransactionType: "PlaceBet", Amount: stake, CurrencyCode: sess.currency,
            TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: server_seed_hash, GameNumber: Date.now().toString(), ServerSeedHash: server_seed_hash, ClientSeed: client_seed }
        });
    }

    const round: RoundState = {
        round_id: randomUUID(),
        sid: sess.sid,
        portalName: sess.portalName,
        currency: sess.currency,
        server_seed, server_seed_hash, client_seed,
        cfg,
        shoe, shoe_idx: idx,
        stake_base: stake,
        hands: [player],
        dealer,
        settled: false,
        created_at: Date.now(),
        mode,
        rtpEntered: 0,
        rtpSettled: 0,
        lastPlan: null
    };

    // RTP enter (REAL)
    if (mode === "real") {
        const yymmdd = toYYMMDD();
        round.rtpDayKey = rk.day(GAME_CODE, yymmdd);
        await redisClient.hsetnx(round.rtpDayKey, "rtp_target", 0.90);
        await redisClient.spEnter(round.rtpDayKey, stake);
        round.rtpEntered = (round.rtpEntered ?? 0) + stake;
        // optional: snapshot plan (for UI / debugging)
        round.lastPlan = await spPlan(GAME_CODE, stake, await loadGameCfg(), yymmdd);
    }

    // Insurance availability (dealer upcard Ace + feature flag)
    const dealerUpIsAce = (dealer[0].r === 0);
    round.insurance = {
        allowed: dealerUpIsAce && !!cfg.allow_insurance,
        decided: false,
        taken: false,
        stake: +(stake / 2).toFixed(2),
    };

    // Natural checks (do NOT auto-settle if insurance offered)
    const pV = bjValue(player.cards), dV = bjValue(dealer.slice(0, 2));
    player.blackjack = pV.isBlackjack;

    let autoSettle = false;
    if (!(round.insurance.allowed)) {
        if (pV.isBlackjack || dV.isBlackjack) autoSettle = true;
    }

    await saveRound(round);

    let payload: any = {
        game: "Blackjack",
        round_id: round.round_id,
        currency: round.currency,
        mode,
        server_seed_hash,
        dealer: { upcard: fmtCard(dealer[0]), hole: null },
        hands: round.hands.map(h => ({ cards: h.cards.map(fmtCard), bet: h.bet, status: deriveStatus(h) })),
        actions: {
            can_insure: !!(round.insurance?.allowed && !round.insurance.decided && round.hands.length === 1 && round.hands[0].cards.length === 2 && !round.hands[0].doubled && !round.hands[0].surrendered),
            can_surrender: round.hands.map(h => (h.cards.length === 2 && !h.doubled && !h.surrendered && !h.blackjack))
        },
        settled: false,
        plan: round.lastPlan ?? undefined
    };

    if (autoSettle) {
        payload = await finalizeRound(round, sess);
    }

    if (idem) await setIdem(mode, sess.sid, "start", idem, payload);
    return payload;
}

export async function hitSvc(sess: ProviderSession, input: { round_id: string; hand_index: number }, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "hit", idem); if (hit) return hit; }
    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        ensurePlayable(r, input.hand_index);
        const draw = () => r.shoe[r.shoe_idx++]; r.hands[input.hand_index].cards.push(draw());
        if (bjValue(r.hands[input.hand_index].cards).total > 21) r.hands[input.hand_index].bust = true;
        await saveRound(r);
        const resp = await maybeAutoFinish(r, sess);
        if (idem) await setIdem(mode, sess.sid, "hit", idem, resp);
        return resp;
    });
}

export async function standSvc(sess: ProviderSession, input: { round_id: string; hand_index: number }, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "stand", idem); if (hit) return hit; }
    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        ensurePlayable(r, input.hand_index); r.hands[input.hand_index].stood = true; await saveRound(r);
        const resp = await maybeAutoFinish(r, sess);
        if (idem) await setIdem(mode, sess.sid, "stand", idem, resp);
        return resp;
    });
}

export async function doubleSvc(sess: ProviderSession, input: { round_id: string; hand_index: number }, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "double", idem); if (hit) return hit; }
    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        const h = r.hands[input.hand_index]; ensurePlayable(r, input.hand_index);
        if (!r.cfg.allow_double) throw AppError.badRequest("DOUBLE_NOT_ALLOWED");
        if (h.cards.length !== 2) throw AppError.badRequest("DOUBLE_ONLY_ON_FIRST_TWO");

        // Debit extra stake
        if (mode === "demo") {
            const bal = await getDemoBalance(sess); if (bal < h.bet) throw AppError.badRequest("Insufficient FUN balance");
            await setDemoBalance(sess, +(bal - h.bet).toFixed(2));
        } else {
            const operator = await findByPortalName(sess.portalName);
            const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            await deposit(opCtx, {
                TransactionId: `${r.server_seed_hash}-D-${input.hand_index}`,
                TransactionType: "PlaceBet", Amount: h.bet, CurrencyCode: r.currency,
                TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:double:${input.hand_index}` }
            });
            // RTP enter extra stake
            if (r.rtpDayKey) { await redisClient.spEnter(r.rtpDayKey, h.bet); r.rtpEntered = (r.rtpEntered ?? 0) + h.bet; }
        }

        const draw = () => r.shoe[r.shoe_idx++]; h.cards.push(draw()); h.doubled = true; h.stood = true;
        if (bjValue(h.cards).total > 21) h.bust = true;

        await saveRound(r);
        const resp = await maybeAutoFinish(r, sess);
        if (idem) await setIdem(mode, sess.sid, "double", idem, resp);
        return resp;
    });
}

export async function splitSvc(sess: ProviderSession, input: { round_id: string }, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "split", idem); if (hit) return hit; }
    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        if (!r.cfg.allow_split) throw AppError.badRequest("SPLIT_NOT_ALLOWED");
        if (r.hands.length !== 1) throw AppError.badRequest("ONLY_ONE_SPLIT_SUPPORTED");
        const h0 = r.hands[0];
        if (h0.cards.length !== 2) throw AppError.badRequest("SPLIT_ONLY_ON_FIRST_TWO");
        const v0 = (c: Card) => (c.r >= 9 ? 10 : (c.r === 0 ? 11 : c.r + 1));
        if (v0(h0.cards[0]) !== v0(h0.cards[1])) throw AppError.badRequest("PAIR_REQUIRED_TO_SPLIT");

        // Debit stake for second hand
        if (mode === "demo") {
            const bal = await getDemoBalance(sess); if (bal < r.stake_base) throw AppError.badRequest("Insufficient FUN balance");
            await setDemoBalance(sess, +(bal - r.stake_base).toFixed(2));
        } else {
            const operator = await findByPortalName(sess.portalName);
            const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            await deposit(opCtx, {
                TransactionId: `${r.server_seed_hash}-S`, TransactionType: "PlaceBet", Amount: r.stake_base, CurrencyCode: r.currency,
                TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:split` }
            });
            // RTP enter extra stake
            if (r.rtpDayKey) { await redisClient.spEnter(r.rtpDayKey, r.stake_base); r.rtpEntered = (r.rtpEntered ?? 0) + r.stake_base; }
        }

        const draw = () => r.shoe[r.shoe_idx++]; const c1 = h0.cards[0], c2 = h0.cards[1];
        const hA: HandState = { cards: [c1, draw()], bet: r.stake_base, split_from: true };
        const hB: HandState = { cards: [c2, draw()], bet: r.stake_base, split_from: true };
        hA.blackjack = false; hB.blackjack = false;
        r.hands = [hA, hB];

        await saveRound(r);
        const resp = await statusPayload(r, false);
        if (idem) await setIdem(mode, sess.sid, "split", idem, resp);
        return resp;
    });
}

export async function finishSvc(sess: ProviderSession, input: { round_id: string }, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "finish", idem); if (hit) return hit; }
    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        const resp = await finalizeRound(r, sess);
        if (idem) await setIdem(mode, sess.sid, "finish", idem, resp);
        return resp;
    });
}

export async function statusSvc(sess: ProviderSession, input: { round_id: string }) {
    const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
    return statusPayload(r, !!r.settled);
}

// =========================
// Insurance & Surrender
// =========================
export async function insuranceSvc(sess: ProviderSession, input: { round_id: string; take: boolean }, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "insurance", idem); if (hit) return hit; }

    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        if (r.settled) throw AppError.badRequest("ROUND_ALREADY_SETTLED");
        if (!r.insurance?.allowed) throw AppError.badRequest("INSURANCE_NOT_AVAILABLE");
        if (r.insurance.decided) throw AppError.conflict("INSURANCE_ALREADY_DECIDED");
        if (!(r.hands.length === 1 && r.hands[0].cards.length === 2 && !r.hands[0].doubled && !r.hands[0].surrendered)) throw AppError.badRequest("INVALID_STATE_FOR_INSURANCE");

        r.insurance.decided = true; r.insurance.taken = !!input.take;

        if (!input.take) { await saveRound(r); const resp = statusPayload(r, false); if (idem) await setIdem(mode, sess.sid, "insurance", idem, resp); return resp; }

        // TAKE insurance: debit stake/2
        const insStake = r.insurance.stake;
        if (mode === "demo") {
            const bal = await getDemoBalance(sess); if (bal < insStake) throw AppError.badRequest("Insufficient FUN balance for insurance");
            await setDemoBalance(sess, +(bal - insStake).toFixed(2));
        } else {
            const operator = await findByPortalName(sess.portalName);
            const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            await deposit(opCtx, {
                TransactionId: `${r.server_seed_hash}-INS`, TransactionType: "PlaceBet", Amount: insStake, CurrencyCode: r.currency,
                TransactionInfo: { Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:insurance` }
            });
            // RTP enter insurance stake
            if (r.rtpDayKey) { await redisClient.spEnter(r.rtpDayKey, insStake); r.rtpEntered = (r.rtpEntered ?? 0) + insStake; }
        }

        // Resolve immediately by peeking dealer hole
        const dealerHasBJ = bjValue(r.dealer.slice(0, 2)).isBlackjack;
        r.insurance.resolved = true;
        r.insurance.payout = dealerHasBJ ? +(insStake * 3.0).toFixed(2) : 0; // stake-included (2:1 profit)

        // RTP settle insurance immediately (REAL)
        if (mode === "real" && r.rtpDayKey) {
            await redisClient.spSettle(r.rtpDayKey, insStake, r.insurance.payout!);
            r.rtpSettled = (r.rtpSettled ?? 0) + r.insurance.payout!;
        }

        await saveRound(r);

        if (dealerHasBJ) {
            const resp = await finalizeRound(r, sess); // round ends
            if (idem) await setIdem(mode, sess.sid, "insurance", idem, resp);
            return resp;
        } else {
            const resp = statusPayload(r, false);
            if (idem) await setIdem(mode, sess.sid, "insurance", idem, resp);
            return resp;
        }
    });
}

export async function surrenderSvc(sess: ProviderSession, input: { round_id: string; hand_index: number }, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "surrender", idem); if (hit) return hit; }

    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id); if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        if (r.settled) throw AppError.badRequest("ROUND_ALREADY_SETTLED");
        if (!r.cfg.allow_surrender) throw AppError.badRequest("SURRENDER_DISABLED");
        const h = r.hands[input.hand_index]; if (!h) throw AppError.badRequest("INVALID_HAND");
        if (!(h.cards.length === 2 && !h.doubled && !h.surrendered && !h.blackjack)) throw AppError.badRequest("INVALID_STATE_FOR_SURRENDER");
        if (bjValue(r.dealer.slice(0, 2)).isBlackjack) throw AppError.badRequest("CANNOT_SURRENDER_AFTER_DEALER_BJ");

        h.surrendered = true; h.stood = true;
        await saveRound(r);
        const resp = await maybeAutoFinish(r, sess);
        if (idem) await setIdem(mode, sess.sid, "surrender", idem, resp);
        return resp;
    });
}

// =========================
// Finishing & status
// =========================
async function maybeAutoFinish(r: RoundState, sess: ProviderSession) {
    const allDone = r.hands.every(h => {
        const v = bjValue(h.cards);
        return h.surrendered || h.stood || h.bust || h.blackjack || v.total >= 21;
    });
    if (!allDone) return statusPayload(r, false);
    return finalizeRound(r, sess);
}

async function finalizeRound(r: RoundState, sess: ProviderSession) {
    if (r.settled) return statusPayload(r, true);

    // Dealer plays out
    let d = r.dealer.slice();
    while (true) {
        const v = bjValue(d); const soft17 = (v.total === 17 && v.soft === true);
        const mustHit = v.total < 17 || (r.cfg.dealer_hit_soft_17 && soft17);
        if (mustHit) { d.push(r.shoe[r.shoe_idx++]); } else break;
    }
    r.dealer = d;

    // Resolve each hand
    const dv = bjValue(r.dealer);
    let payoutTotal = 0;

    for (const h of r.hands) {
        const pv = bjValue(h.cards);
        let mult = 0;

        if (h.surrendered) mult = 0.5;
        else if (h.bust) mult = 0.0;
        else if (pv.isBlackjack && !dv.isBlackjack) mult = 1 + r.cfg.bj_pays;
        else if (dv.isBlackjack && !pv.isBlackjack) mult = 0.0;
        else if (dv.total > 21) mult = 2.0;
        else if (pv.total > dv.total) mult = 2.0;
        else if (pv.total < dv.total) mult = 0.0;
        else mult = 1.0;

        const bet = h.doubled ? h.bet * 2 : h.bet;
        payoutTotal += +(bet * mult).toFixed(2);
    }

    // Add insurance payout if not already settled in RTP (RoundState keeps monetary insurance payout)
    const insPayout = (r.insurance?.taken && r.insurance.resolved) ? (r.insurance.payout ?? 0) : 0;
    payoutTotal = +(payoutTotal + insPayout).toFixed(2);

    // Credit once
    if (sess.mode === "demo") {
        const bal = await getDemoBalance(sess);
        await setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
    } else if (payoutTotal > 0) {
        // RTP settle remaining (exclude already-settled insurance)
        const alreadySettled = r.rtpSettled ?? 0;
        const remainingPayout = Math.max(0, +(payoutTotal - alreadySettled).toFixed(2));
        if (!r.rtpDayKey) {
            const yymmdd = toYYMMDD(); r.rtpDayKey = rk.day(GAME_CODE, yymmdd); await redisClient.hsetnx(r.rtpDayKey, "rtp_target", 0.90);
        }
        // We entered r.rtpEntered over the round (base stake + doubles/split + insurance); settle only the remaining payout here
        await redisClient.spSettle(r.rtpDayKey!, r.rtpEntered ?? 0, remainingPayout);
        r.rtpSettled = (r.rtpSettled ?? 0) + remainingPayout;

        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: `${r.server_seed_hash}-W`, TransactionType: "WinAmount", Amount: payoutTotal, CurrencyCode: r.currency,
            TransactionInfo: {
                Source: "Blackjack", GameName: "Blackjack", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}`,
                ServerSeed: r.server_seed, ServerSeedHash: r.server_seed_hash, ClientSeed: r.client_seed,
                Dealer: r.dealer.map(fmtCard),
                Hands: r.hands.map(h => ({ cards: h.cards.map(fmtCard), bet: h.bet, doubled: !!h.doubled, surrendered: !!h.surrendered })),
                Insurance: r.insurance ? { taken: r.insurance.taken, stake: r.insurance.stake, payout: r.insurance.payout ?? 0 } : undefined
            }
        });
    }

    r.settled = true; await saveRound(r);
    return statusPayload(r, true);
}

function statusPayload(r: RoundState, settled: boolean) {
    return {
        game: "Blackjack",
        round_id: r.round_id,
        currency: r.currency,
        mode: r.mode,
        settled,
        dealer: {
            upcard: fmtCard(r.dealer[0]),
            hole: settled ? fmtCard(r.dealer[1]) : null,
            cards: settled ? r.dealer.map(fmtCard) : [fmtCard(r.dealer[0]), null]
        },
        hands: r.hands.map(h => ({ cards: h.cards.map(fmtCard), bet: h.doubled ? h.bet * 2 : h.bet, status: deriveStatus(h) })),
        insurance: r.insurance ? {
            allowed: r.insurance.allowed, decided: r.insurance.decided, taken: r.insurance.taken,
            stake: r.insurance.stake, resolved: r.insurance.resolved ?? false, payout: r.insurance.payout ?? 0
        } : undefined,
        actions: {
            can_insure: !!(r.insurance?.allowed && !r.insurance.decided && r.hands.length === 1 && r.hands[0].cards.length === 2 && !r.hands[0].doubled && !r.hands[0].surrendered),
            can_surrender: r.hands.map(h => (h.cards.length === 2 && !h.doubled && !h.surrendered && !h.blackjack))
        },
        plan: r.lastPlan ?? undefined
    };
}
