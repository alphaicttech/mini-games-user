"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.surrenderAction = exports.surrenderValidate = exports.insuranceAction = exports.insuranceValidate = exports.statusRound = exports.statusValidate = exports.finishRound = exports.finishValidate = exports.splitHand = exports.splitValidate = exports.doubleDown = exports.stand = exports.hit = exports.doubleValidate = exports.standValidate = exports.hitValidate = exports.startRound = exports.startValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const StartBody = zod_1.z.object({
    stake: zod_1.z.number().positive(),
    client_seed: zod_1.z.string().min(1).optional(),
    cfg: zod_1.z.object({
        decks: zod_1.z.number().int().min(1).max(8).default(6),
        bj_pays: zod_1.z.number().positive().default(1.5), // 3:2
        dealer_hit_soft_17: zod_1.z.boolean().default(false),
        allow_double: zod_1.z.boolean().default(true),
        allow_split: zod_1.z.boolean().default(true),
        allow_insurance: zod_1.z.boolean().default(false), // NEW
        allow_surrender: zod_1.z.boolean().default(false), // NEW
    }).default({})
});
exports.startValidate = (0, validate_1.validateBody)(StartBody);
exports.startRound = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.startSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
const IdWithHand = zod_1.z.object({ round_id: zod_1.z.string().uuid(), hand_index: zod_1.z.number().int().min(0).default(0) });
exports.hitValidate = (0, validate_1.validateBody)(IdWithHand);
exports.standValidate = (0, validate_1.validateBody)(IdWithHand);
exports.doubleValidate = (0, validate_1.validateBody)(IdWithHand);
exports.hit = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.hitSvc)(sess, req.body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.stand = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.standSvc)(sess, req.body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.doubleDown = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.doubleSvc)(sess, req.body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
const SplitBody = zod_1.z.object({ round_id: zod_1.z.string().uuid() });
exports.splitValidate = (0, validate_1.validateBody)(SplitBody);
exports.splitHand = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.splitSvc)(sess, req.body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
const FinishBody = zod_1.z.object({ round_id: zod_1.z.string().uuid() });
exports.finishValidate = (0, validate_1.validateBody)(FinishBody);
exports.finishRound = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.finishSvc)(sess, req.body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
const StatusQuery = zod_1.z.object({ round_id: zod_1.z.string().uuid() });
exports.statusValidate = (0, validate_1.validateQuery)(StatusQuery);
exports.statusRound = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const data = yield (0, service_1.statusSvc)(sess, req.query);
    res.json(Object.assign({ ok: true }, data));
}));
const InsuranceBody = zod_1.z.object({
    round_id: zod_1.z.string().uuid(),
    take: zod_1.z.boolean(), // true = take insurance; false = explicitly decline
});
exports.insuranceValidate = (0, validate_1.validateBody)(InsuranceBody);
exports.insuranceAction = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.insuranceSvc)(sess, req.body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
// NEW: surrender
const SurrenderBody = zod_1.z.object({
    round_id: zod_1.z.string().uuid(),
    hand_index: zod_1.z.number().int().min(0).default(0),
});
exports.surrenderValidate = (0, validate_1.validateBody)(SurrenderBody);
exports.surrenderAction = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.surrenderSvc)(sess, req.body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
