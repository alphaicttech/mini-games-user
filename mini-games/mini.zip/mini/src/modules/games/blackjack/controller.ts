// /var/www/typesafe/alpha-mini/src/modules/games/blackjack/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody, validateQuery } from "../../../middleware/validate";
import {
    startSvc, hitSvc, standSvc, doubleSvc, splitSvc, finishSvc, statusSvc, insuranceSvc, surrenderSvc
} from "./service";

const StartBody = z.object({
    stake: z.number().positive(),
    client_seed: z.string().min(1).optional(),
    cfg: z.object({
        decks: z.number().int().min(1).max(8).default(6),
        bj_pays: z.number().positive().default(1.5), // 3:2
        dealer_hit_soft_17: z.boolean().default(false),
        allow_double: z.boolean().default(true),
        allow_split: z.boolean().default(true),
        allow_insurance: z.boolean().default(false),   // NEW
        allow_surrender: z.boolean().default(false),   // NEW
    }).default({} as any)
});
export const startValidate = validateBody(StartBody);

export const startRound = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof StartBody>;
    const data = await startSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

const IdWithHand = z.object({ round_id: z.string().uuid(), hand_index: z.number().int().min(0).default(0) });
export const hitValidate = validateBody(IdWithHand);
export const standValidate = validateBody(IdWithHand);
export const doubleValidate = validateBody(IdWithHand);

export const hit = asyncHandler(async (req, res) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = await hitSvc(sess, req.body as z.infer<typeof IdWithHand>, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const stand = asyncHandler(async (req, res) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = await standSvc(sess, req.body as z.infer<typeof IdWithHand>, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const doubleDown = asyncHandler(async (req, res) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = await doubleSvc(sess, req.body as z.infer<typeof IdWithHand>, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

const SplitBody = z.object({ round_id: z.string().uuid() });
export const splitValidate = validateBody(SplitBody);

export const splitHand = asyncHandler(async (req, res) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = await splitSvc(sess, req.body as z.infer<typeof SplitBody>, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

const FinishBody = z.object({ round_id: z.string().uuid() });
export const finishValidate = validateBody(FinishBody);

export const finishRound = asyncHandler(async (req, res) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = await finishSvc(sess, req.body as z.infer<typeof FinishBody>, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

const StatusQuery = z.object({ round_id: z.string().uuid() });
export const statusValidate = validateQuery(StatusQuery);

export const statusRound = asyncHandler(async (req, res) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const data = await statusSvc(sess, req.query as any);
    res.json({ ok: true, ...data });
});


const InsuranceBody = z.object({
    round_id: z.string().uuid(),
    take: z.boolean(), // true = take insurance; false = explicitly decline
});
export const insuranceValidate = validateBody(InsuranceBody);

export const insuranceAction = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = await insuranceSvc(sess, req.body as z.infer<typeof InsuranceBody>, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

// NEW: surrender
const SurrenderBody = z.object({
    round_id: z.string().uuid(),
    hand_index: z.number().int().min(0).default(0),
});
export const surrenderValidate = validateBody(SurrenderBody);

export const surrenderAction = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const data = await surrenderSvc(sess, req.body as z.infer<typeof SurrenderBody>, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});