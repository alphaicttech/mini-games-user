"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.spin = exports.spinValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
/** Bet schema (controller is permissive, service does strict validation) */
const BetType = zod_1.z.enum([
    "STRAIGHT", "ODD", "EVEN", "RED", "BLACK", "LOW", "HIGH"
]);
const Bet = zod_1.z.object({
    type: BetType,
    stake: zod_1.z.number().positive(),
    numbers: zod_1.z.array(zod_1.z.number().int().min(1).max(12)).optional() // only for STRAIGHT (length 1)
});
const SpinBody = zod_1.z.object({
    client_seed: zod_1.z.string().min(1).optional(),
    bets: zod_1.z.array(Bet).min(1).max(100)
});
exports.spinValidate = (0, validate_1.validateBody)(SpinBody);
exports.spin = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = SpinBody.parse(req.body);
    const data = yield (0, service_1.spinMini)(sess, body, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
