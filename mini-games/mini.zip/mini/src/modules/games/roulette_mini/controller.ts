// /var/www/typesafe/alpha-mini/src/modules/games/roulette_mini/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { spinMini } from "./service";

/** Bet schema (controller is permissive, service does strict validation) */
const BetType = z.enum([
    "STRAIGHT", "ODD", "EVEN", "RED", "BLACK", "LOW", "HIGH"
]);

const Bet = z.object({
    type: BetType,
    stake: z.number().positive(),
    numbers: z.array(z.number().int().min(1).max(12)).optional() // only for STRAIGHT (length 1)
});

const SpinBody = z.object({
    client_seed: z.string().min(1).optional(),
    bets: z.array(Bet).min(1).max(100)
});

export const spinValidate = validateBody(SpinBody);

export const spin = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = SpinBody.parse(req.body);

    const data = await spinMini(sess, body, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);

    res.json({ ok: true, ...data });
});
