import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP (accounting only) ====
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { redis as redisClient } from "../../../config/redis";
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { spPlan } from "../../rtp/governor";

/** =========================
 * Config / constants
 * ========================= */
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "roulette_mini"; // adjust if your games table uses a different code

// Red/Black mapping for 1..12
const REDS = new Set([1, 3, 5, 7, 9, 11]);
const BLACKS = new Set([2, 4, 6, 8, 10, 12]);

// stake-included return multipliers
const RETURN = {
    STRAIGHT: 12.0,     // profit 11:1
    EVEN: 2.0           // ODD/EVEN/RED/BLACK/LOW/HIGH
} as const;

/** =========================
 * RTP cfg (optional snapshot)
 * ========================= */
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}

/** =========================
 * Provably-fair RNG
 * ========================= */
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;

/** uniform [0,1) derived from HMAC */
const r01 = (server: string, client: string, tag: string) =>
    u32(hmacHex(server, `${client}:${tag}`).slice(0, 8)) / 0xffffffff;

/** =========================
 * Idempotency (mode-scoped)
 * ========================= */
const idemKey = (mode: "real" | "demo", sid: string, key: string) => `idem:${mode}:roulette-mini:spin:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(idemKey(mode, sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, key: string, payload: any) {
    await redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

/** =========================
 * Types & strict validation
 * ========================= */
type MiniBet =
    | { type: "STRAIGHT"; stake: number; numbers: [number]; }
    | { type: "ODD" | "EVEN" | "RED" | "BLACK" | "LOW" | "HIGH"; stake: number };

function validateBet(b: any): MiniBet {
    switch (b.type) {
        case "STRAIGHT": {
            if (!Array.isArray(b.numbers) || b.numbers.length !== 1) {
                throw AppError.badRequest("STRAIGHT requires one number");
            }
            const n = b.numbers[0];
            if (!Number.isInteger(n) || n < 1 || n > 12) throw AppError.badRequest("Number must be 1..12");
            return { type: "STRAIGHT", stake: b.stake, numbers: [n] };
        }
        case "ODD": case "EVEN": case "RED": case "BLACK": case "LOW": case "HIGH":
            return { type: b.type, stake: b.stake };
        default:
            throw AppError.badRequest("UNKNOWN_BET");
    }
}

function betWins(b: MiniBet, n: number): number {
    switch (b.type) {
        case "STRAIGHT": return b.numbers[0] === n ? RETURN.STRAIGHT : 0;
        case "ODD": return (n % 2 === 1) ? RETURN.EVEN : 0;
        case "EVEN": return (n % 2 === 0) ? RETURN.EVEN : 0;
        case "RED": return REDS.has(n) ? RETURN.EVEN : 0;
        case "BLACK": return BLACKS.has(n) ? RETURN.EVEN : 0;
        case "LOW": return (n >= 1 && n <= 6) ? RETURN.EVEN : 0;
        case "HIGH": return (n >= 7 && n <= 12) ? RETURN.EVEN : 0;
    }
}

/** =========================
 * Wallet helpers (demo vs real)
 * ========================= */
async function debit(sess: ProviderSession, amount: number, info: any) {
    if (sess.mode === "demo") {
        const key = `demo:bal:${sess.sid}`;
        const v = await redis.get(key);
        const bal = v ? Number(v) : Number(process.env.DEMO_START_BALANCE ?? 1000);
        if (bal < amount) throw AppError.badRequest("INSUFFICIENT_FUN");
        await redis.set(key, String(+(bal - amount).toFixed(2)), 2 * 60 * 60);
    } else {
        const op = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: info.txn,
            TransactionType: "PlaceBet",
            Amount: amount,
            CurrencyCode: sess.currency,
            TransactionInfo: info
        });
    }
}
async function credit(sess: ProviderSession, amount: number, info: any) {
    if (amount <= 0) return;
    if (sess.mode === "demo") {
        const key = `demo:bal:${sess.sid}`;
        const v = await redis.get(key);
        const bal = v ? Number(v) : Number(process.env.DEMO_START_BALANCE ?? 1000);
        await redis.set(key, String(+(bal + amount).toFixed(2)), 2 * 60 * 60);
    } else {
        const op = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: info.txn,
            TransactionType: "WinAmount",
            Amount: amount,
            CurrencyCode: sess.currency,
            TransactionInfo: info
        });
    }
}

/** =========================
 * Main
 * ========================= */
export async function spinMini(
    sess: ProviderSession,
    input: {
        client_seed?: string;
        bets: Array<{ type: string; stake: number; numbers?: number[] }>;
    },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";

    if (idem) {
        const hit = await getIdem(mode, sess.sid, idem);
        if (hit) return hit;
    }

    // Validate bets
    if (!Array.isArray(input.bets) || input.bets.length === 0) {
        throw AppError.badRequest("No bets");
    }
    if (input.bets.length > 100) throw AppError.badRequest("Too many bets");

    const bets: MiniBet[] = input.bets.map(validateBet);
    const stakeTotal = +bets.reduce((s, b) => s + b.stake, 0).toFixed(2);

    // Seeds & winning number 1..12 (provably fair)
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);
    const clientSeed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";
    const winRaw = r01(serverSeed, clientSeed, "spin"); // 0..1
    const winning = Math.floor(winRaw * 12) + 1;        // 1..12

    // Ledger: debit once
    const txnId = randomUUID();
    await debit(sess, stakeTotal, {
        txn: txnId,
        Source: "RouletteMini",
        GameName: "RouletteMini",
        RoundId: txnId,
        GameNumber: Date.now().toString(),
        ServerSeedHash: serverSeedHash,
        ClientSeed: clientSeed
    });

    // RTP: enter (REAL) — accounting only
    let dayKey: string | undefined;
    let plan: { target: number; hardCap: number; softCap: number } | undefined;
    if (mode === "real") {
        const yymmdd = toYYMMDD();
        dayKey = rk.day(GAME_CODE, yymmdd);
        await redisClient.hsetnx(dayKey, "rtp_target", 0.90);
        await redisClient.spEnter(dayKey, stakeTotal);
        // optional snapshot for observability (no clamping)
        try {
            plan = await spPlan(GAME_CODE, stakeTotal, await loadGameCfg(), yymmdd);
        } catch { /* non-fatal */ }
    }

    // Resolve slip
    const details = bets.map((b, i) => {
        const mult = betWins(b, winning);
        const payout = +(b.stake * mult).toFixed(2);
        const selection =
            b.type === "STRAIGHT" ? { numbers: b.numbers } :
                b.type === "LOW" ? { range: "1-6" } :
                    b.type === "HIGH" ? { range: "7-12" } :
                        { type: b.type };
        return {
            index: i,
            type: b.type,
            selection,
            stake: b.stake,
            return_multiplier: mult,
            payout,
            win: mult > 0
        };
    });

    const payoutTotal = +details.reduce((s, d) => s + d.payout, 0).toFixed(2);

    // RTP: settle (REAL) — pair with the single enter above
    if (mode === "real" && dayKey) {
        await redisClient.spSettle(dayKey, stakeTotal, payoutTotal);
    }

    // Credit winners
    await credit(sess, payoutTotal, {
        txn: `${txnId}-W`,
        Source: "RouletteMini",
        GameName: "RouletteMini",
        RoundId: txnId,
        GameNumber: Date.now().toString(),
        ServerSeed: serverSeed,
        ServerSeedHash: serverSeedHash,
        ClientSeed: clientSeed,
        Winning: winning
    });

    // Response
    const resp = {
        game: "RouletteMini",
        mode,
        txn_id: txnId,
        stake_total: stakeTotal,
        currency: sess.currency,
        wheel: {
            winning_number: winning,
            color: REDS.has(winning) ? "RED" : "BLACK",
            parity: winning % 2 === 0 ? "EVEN" : "ODD",
            half: winning <= 6 ? "LOW" : "HIGH"
        },
        slip: {
            bets: details,
            payout_total: payoutTotal,
            profit_total: +(payoutTotal - stakeTotal).toFixed(2)
        },
        fairness: {
            method: "HMAC-SHA256(server_seed, `${client_seed}:spin`) % 12 + 1 -> 1..12",
            server_seed_hash: serverSeedHash,
            server_seed: serverSeed,
            client_seed: clientSeed
        },
        plan // optional snapshot for UI/ops
    };

    if (idem) await setIdem(mode, sess.sid, idem, resp);
    return resp;
}
