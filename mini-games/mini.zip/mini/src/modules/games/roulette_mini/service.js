"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.spinMini = spinMini;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP (accounting only) ====
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const redis_2 = require("../../../config/redis");
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const governor_1 = require("../../rtp/governor");
/** =========================
 * Config / constants
 * ========================= */
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "roulette_mini"; // adjust if your games table uses a different code
// Red/Black mapping for 1..12
const REDS = new Set([1, 3, 5, 7, 9, 11]);
const BLACKS = new Set([2, 4, 6, 8, 10, 12]);
// stake-included return multipliers
const RETURN = {
    STRAIGHT: 12.0, // profit 11:1
    EVEN: 2.0 // ODD/EVEN/RED/BLACK/LOW/HIGH
};
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
/** =========================
 * Provably-fair RNG
 * ========================= */
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
/** uniform [0,1) derived from HMAC */
const r01 = (server, client, tag) => u32(hmacHex(server, `${client}:${tag}`).slice(0, 8)) / 0xffffffff;
/** =========================
 * Idempotency (mode-scoped)
 * ========================= */
const idemKey = (mode, sid, key) => `idem:${mode}:roulette-mini:spin:${sid}:${key}`;
function getIdem(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(idemKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
function validateBet(b) {
    switch (b.type) {
        case "STRAIGHT": {
            if (!Array.isArray(b.numbers) || b.numbers.length !== 1) {
                throw errors_1.AppError.badRequest("STRAIGHT requires one number");
            }
            const n = b.numbers[0];
            if (!Number.isInteger(n) || n < 1 || n > 12)
                throw errors_1.AppError.badRequest("Number must be 1..12");
            return { type: "STRAIGHT", stake: b.stake, numbers: [n] };
        }
        case "ODD":
        case "EVEN":
        case "RED":
        case "BLACK":
        case "LOW":
        case "HIGH":
            return { type: b.type, stake: b.stake };
        default:
            throw errors_1.AppError.badRequest("UNKNOWN_BET");
    }
}
function betWins(b, n) {
    switch (b.type) {
        case "STRAIGHT": return b.numbers[0] === n ? RETURN.STRAIGHT : 0;
        case "ODD": return (n % 2 === 1) ? RETURN.EVEN : 0;
        case "EVEN": return (n % 2 === 0) ? RETURN.EVEN : 0;
        case "RED": return REDS.has(n) ? RETURN.EVEN : 0;
        case "BLACK": return BLACKS.has(n) ? RETURN.EVEN : 0;
        case "LOW": return (n >= 1 && n <= 6) ? RETURN.EVEN : 0;
        case "HIGH": return (n >= 7 && n <= 12) ? RETURN.EVEN : 0;
    }
}
/** =========================
 * Wallet helpers (demo vs real)
 * ========================= */
function debit(sess, amount, info) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        if (sess.mode === "demo") {
            const key = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(key);
            const bal = v ? Number(v) : Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
            if (bal < amount)
                throw errors_1.AppError.badRequest("INSUFFICIENT_FUN");
            yield redis_1.redis.set(key, String(+(bal - amount).toFixed(2)), 2 * 60 * 60);
        }
        else {
            const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: info.txn,
                TransactionType: "PlaceBet",
                Amount: amount,
                CurrencyCode: sess.currency,
                TransactionInfo: info
            });
        }
    });
}
function credit(sess, amount, info) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        if (amount <= 0)
            return;
        if (sess.mode === "demo") {
            const key = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(key);
            const bal = v ? Number(v) : Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
            yield redis_1.redis.set(key, String(+(bal + amount).toFixed(2)), 2 * 60 * 60);
        }
        else {
            const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: info.txn,
                TransactionType: "WinAmount",
                Amount: amount,
                CurrencyCode: sess.currency,
                TransactionInfo: info
            });
        }
    });
}
/** =========================
 * Main
 * ========================= */
function spinMini(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, idem);
            if (hit)
                return hit;
        }
        // Validate bets
        if (!Array.isArray(input.bets) || input.bets.length === 0) {
            throw errors_1.AppError.badRequest("No bets");
        }
        if (input.bets.length > 100)
            throw errors_1.AppError.badRequest("Too many bets");
        const bets = input.bets.map(validateBet);
        const stakeTotal = +bets.reduce((s, b) => s + b.stake, 0).toFixed(2);
        // Seeds & winning number 1..12 (provably fair)
        const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
        const serverSeedHash = sha256(serverSeed);
        const clientSeed = (_c = (_b = (_a = input.client_seed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        const winRaw = r01(serverSeed, clientSeed, "spin"); // 0..1
        const winning = Math.floor(winRaw * 12) + 1; // 1..12
        // Ledger: debit once
        const txnId = (0, crypto_1.randomUUID)();
        yield debit(sess, stakeTotal, {
            txn: txnId,
            Source: "RouletteMini",
            GameName: "RouletteMini",
            RoundId: txnId,
            GameNumber: Date.now().toString(),
            ServerSeedHash: serverSeedHash,
            ClientSeed: clientSeed
        });
        // RTP: enter (REAL) — accounting only
        let dayKey;
        let plan;
        if (mode === "real") {
            const yymmdd = (0, date_1.toYYMMDD)();
            dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_2.redis.hsetnx(dayKey, "rtp_target", 0.90);
            yield redis_2.redis.spEnter(dayKey, stakeTotal);
            // optional snapshot for observability (no clamping)
            try {
                plan = yield (0, governor_1.spPlan)(GAME_CODE, stakeTotal, yield loadGameCfg(), yymmdd);
            }
            catch ( /* non-fatal */_d) { /* non-fatal */ }
        }
        // Resolve slip
        const details = bets.map((b, i) => {
            const mult = betWins(b, winning);
            const payout = +(b.stake * mult).toFixed(2);
            const selection = b.type === "STRAIGHT" ? { numbers: b.numbers } :
                b.type === "LOW" ? { range: "1-6" } :
                    b.type === "HIGH" ? { range: "7-12" } :
                        { type: b.type };
            return {
                index: i,
                type: b.type,
                selection,
                stake: b.stake,
                return_multiplier: mult,
                payout,
                win: mult > 0
            };
        });
        const payoutTotal = +details.reduce((s, d) => s + d.payout, 0).toFixed(2);
        // RTP: settle (REAL) — pair with the single enter above
        if (mode === "real" && dayKey) {
            yield redis_2.redis.spSettle(dayKey, stakeTotal, payoutTotal);
        }
        // Credit winners
        yield credit(sess, payoutTotal, {
            txn: `${txnId}-W`,
            Source: "RouletteMini",
            GameName: "RouletteMini",
            RoundId: txnId,
            GameNumber: Date.now().toString(),
            ServerSeed: serverSeed,
            ServerSeedHash: serverSeedHash,
            ClientSeed: clientSeed,
            Winning: winning
        });
        // Response
        const resp = {
            game: "RouletteMini",
            mode,
            txn_id: txnId,
            stake_total: stakeTotal,
            currency: sess.currency,
            wheel: {
                winning_number: winning,
                color: REDS.has(winning) ? "RED" : "BLACK",
                parity: winning % 2 === 0 ? "EVEN" : "ODD",
                half: winning <= 6 ? "LOW" : "HIGH"
            },
            slip: {
                bets: details,
                payout_total: payoutTotal,
                profit_total: +(payoutTotal - stakeTotal).toFixed(2)
            },
            fairness: {
                method: "HMAC-SHA256(server_seed, `${client_seed}:spin`) % 12 + 1 -> 1..12",
                server_seed_hash: serverSeedHash,
                server_seed: serverSeed,
                client_seed: clientSeed
            },
            plan // optional snapshot for UI/ops
        };
        if (idem)
            yield setIdem(mode, sess.sid, idem, resp);
        return resp;
    });
}
