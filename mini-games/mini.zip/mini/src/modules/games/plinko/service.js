"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPlinkoBoard = getPlinkoBoard;
exports.doPlinkoDrop = doPlinkoDrop;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
/**
 * ----------------------------
 * Config
 * ----------------------------
 */
const IDEM_TTL = 24 * 60 * 60;
const ALLOWED_ROWS = new Set([8, 10, 12, 14, 16]);
const GAME_CODE = "plinko";
const CANDIDATES_K = 6;
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
// Return multipliers (stake INCLUDED) per (rows, risk). Arrays are symmetric and index by bin 0..rows.
const TABLES = {
    8: {
        low: [0.5, 0.7, 0.9, 1.1, 1.3, 1.1, 0.9, 0.7, 0.5],
        normal: [0.2, 0.5, 0.8, 1.2, 2.0, 1.2, 0.8, 0.5, 0.2],
        high: [0.0, 0.2, 0.5, 1.0, 5.0, 1.0, 0.5, 0.2, 0.0],
    },
    10: {
        low: [0.5, 0.6, 0.8, 1.0, 1.2, 1.4, 1.2, 1.0, 0.8, 0.6, 0.5],
        normal: [0.2, 0.4, 0.7, 1.0, 1.5, 2.2, 1.5, 1.0, 0.7, 0.4, 0.2],
        high: [0.0, 0.2, 0.4, 0.8, 1.2, 8.0, 1.2, 0.8, 0.4, 0.2, 0.0],
    },
    12: {
        low: [0.5, 0.6, 0.8, 0.9, 1.1, 1.3, 1.5, 1.3, 1.1, 0.9, 0.8, 0.6, 0.5],
        normal: [0.2, 0.3, 0.5, 0.8, 1.1, 1.5, 2.5, 1.5, 1.1, 0.8, 0.5, 0.3, 0.2],
        high: [0.0, 0.1, 0.3, 0.6, 0.9, 1.2, 12.0, 1.2, 0.9, 0.6, 0.3, 0.1, 0.0],
    },
    14: {
        low: [0.5, 0.6, 0.7, 0.9, 1.0, 1.2, 1.4, 1.6, 1.4, 1.2, 1.0, 0.9, 0.7, 0.6, 0.5],
        normal: [0.2, 0.3, 0.4, 0.6, 0.9, 1.2, 1.6, 2.8, 1.6, 1.2, 0.9, 0.6, 0.4, 0.3, 0.2],
        high: [0.0, 0.1, 0.2, 0.4, 0.7, 1.0, 1.3, 15.0, 1.3, 1.0, 0.7, 0.4, 0.2, 0.1, 0.0],
    },
    16: {
        low: [0.5, 0.55, 0.7, 0.85, 1.0, 1.15, 1.3, 1.6, 1.8, 1.6, 1.3, 1.15, 1.0, 0.85, 0.7, 0.55, 0.5],
        normal: [0.2, 0.25, 0.35, 0.5, 0.7, 1.0, 1.3, 1.8, 3.2, 1.8, 1.3, 1.0, 0.7, 0.5, 0.35, 0.25, 0.2],
        high: [0.0, 0.05, 0.1, 0.2, 0.4, 0.7, 1.0, 1.4, 20.0, 1.4, 1.0, 0.7, 0.4, 0.2, 0.1, 0.05, 0.0],
    }
};
// Demo balance helpers
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const key = `demo:bal:${sess.sid}`;
        const cached = yield redis_1.redis.get(key);
        if (cached)
            return Number(cached);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(key, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = `demo:bal:${sess.sid}`;
        yield redis_1.redis.set(key, String(amount), 2 * 60 * 60);
    });
}
// Provably fair helpers
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
/** uniform bit from HMAC(server, `${client}:${ballIndex}:${row}`) */
const randBit = (serverSeed, clientSeed, ballIndex, row) => (u32(hmacHex(serverSeed, `${clientSeed}:${ballIndex}:${row}`).slice(0, 8)) & 1);
// Idempotency (mode-scoped)
const reqKey = (mode, sid, key) => `idem:${mode}:plinko:drop:${sid}:${key}`;
function getIdem(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(reqKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
// Multipliers table fetch
function getMultipliers(rows, risk) {
    var _a;
    if (!ALLOWED_ROWS.has(rows))
        throw errors_1.AppError.badRequest("rows must be one of 8,10,12,14,16");
    const t = (_a = TABLES[rows]) === null || _a === void 0 ? void 0 : _a[risk];
    if (!t || t.length !== rows + 1)
        throw new Error("Multiplier table misconfigured");
    return t;
}
/** Public odds endpoint helper */
function getPlinkoBoard(rows, risk) {
    if (!ALLOWED_ROWS.has(rows))
        throw errors_1.AppError.badRequest("rows must be one of 8,10,12,14,16");
    if (!["low", "normal", "high"].includes(risk))
        throw errors_1.AppError.badRequest("invalid risk");
    return { rows, risk, bins: getMultipliers(rows, risk) };
}
/** Simulate a whole slip under a serverSeed to get per-ball results and totals (with per-ball caps). */
function simulateSlip(serverSeed, clientSeedDefault, sess, input, caps) {
    const multipliers = getMultipliers(input.rows, input.risk);
    const results = input.balls.map((ball, i) => {
        var _a, _b, _c, _d;
        const cseed = (_d = (_c = (_b = (_a = ball.client_seed) !== null && _a !== void 0 ? _a : clientSeedDefault) !== null && _b !== void 0 ? _b : sess.clientExternalKey) !== null && _c !== void 0 ? _c : sess.userName) !== null && _d !== void 0 ? _d : "client";
        let pos = 0;
        const pathBits = [];
        for (let r = 0; r < input.rows; r++) {
            const bit = randBit(serverSeed, cseed, i, r);
            pathBits.push(bit);
            pos += bit;
        }
        const bin = pos; // 0..rows
        const mult = multipliers[bin];
        let payout = +(ball.stake * mult).toFixed(2);
        // per-ball caps (bet-level)
        payout = Math.min(payout, caps.per_bet_cap, caps.per_user_daily_cap);
        return {
            index: i,
            stake: ball.stake,
            client_seed: cseed,
            rows: input.rows,
            risk: input.risk,
            path_bits: pathBits,
            bin_index: bin,
            return_multiplier: mult,
            final_multiplier: mult,
            payout
        };
    });
    const total = +results.reduce((s, r) => s + r.payout, 0).toFixed(2);
    return { results, total };
}
/**
 * Main entry
 */
function doPlinkoDrop(sess, input, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        // Idempotency replay
        if (idemKey) {
            const hit = yield getIdem(mode, sess.sid, idemKey);
            if (hit)
                return hit;
        }
        // Validate
        if (!ALLOWED_ROWS.has(input.rows))
            throw errors_1.AppError.badRequest("rows must be one of 8,10,12,14,16");
        if (!["low", "normal", "high"].includes(input.risk))
            throw errors_1.AppError.badRequest("invalid risk");
        if (!Array.isArray(input.balls) || input.balls.length === 0)
            throw errors_1.AppError.badRequest("No balls");
        if (input.balls.length > 200)
            throw errors_1.AppError.badRequest("Too many balls");
        for (const b of input.balls) {
            if (typeof b.stake !== "number" || b.stake <= 0)
                throw errors_1.AppError.badRequest("Invalid stake");
        }
        const stakeTotal = +input.balls.reduce((s, b) => s + b.stake, 0).toFixed(2);
        // Seeds (we will PICK the server seed among K candidates for RTP)
        const clientSeedDefault = (_a = input.client_seed) !== null && _a !== void 0 ? _a : null;
        // Ledger: debit
        const txnId = (0, crypto_1.randomUUID)();
        let balance = undefined;
        if (mode === "demo") {
            const start = yield getDemoBalance(sess);
            if (start < stakeTotal)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(start - stakeTotal).toFixed(2));
            balance = +(start - stakeTotal).toFixed(2);
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId;
            const opCtx = {
                baseUrl: operator.baseUrl,
                secret: operator.secret,
                session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            const probeSeed = crypto_1.default.randomBytes(32).toString("hex"); // for metadata hash only
            const probeHash = sha256(probeSeed);
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: stakeTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Plinko",
                    GameName: "Plinko",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeedHash: probeHash,
                    ClientSeed: clientSeedDefault !== null && clientSeedDefault !== void 0 ? clientSeedDefault : ((_d = (_c = sess.clientExternalKey) !== null && _c !== void 0 ? _c : sess.userName) !== null && _d !== void 0 ? _d : "client")
                }
            });
        }
        // --- RTP: enter/plan (REAL only)
        const cfg = yield loadGameCfg();
        let plan = { hardCap: 0, softCap: 0, target: 0 };
        let dayKey;
        let yymmdd = (0, date_1.toYYMMDD)();
        if (mode === "real") {
            dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_1.redis.hsetnx(dayKey, "rtp_target", 0.90);
            yield redis_1.redis.spEnter(dayKey, stakeTotal); // active counters++
            plan = yield (0, governor_1.spPlan)(GAME_CODE, stakeTotal, cfg, yymmdd);
        }
        else {
            // Synthetic plan for demo feel
            const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
            const softCap = Math.floor(hardCap * 0.6);
            const r = Math.random();
            const target = Math.floor(softCap * (0.3 + 0.7 * r));
            plan = { hardCap, softCap, target };
        }
        // --- Pick best serverSeed among K candidates (provably fair + RTP-aware)
        let pick = { serverSeed: "", results: [], total: 0, pickIdx: 0, serverSeedHash: "" };
        let bestScore = Number.POSITIVE_INFINITY;
        for (let k = 0; k < CANDIDATES_K; k++) {
            const candidateSeed = crypto_1.default.randomBytes(32).toString("hex");
            const sim = simulateSlip(candidateSeed, clientSeedDefault, sess, input, {
                per_bet_cap: cfg.per_bet_cap,
                per_ticket_cap: cfg.per_ticket_cap,
                per_user_daily_cap: cfg.per_user_daily_cap,
            });
            // Cap slip by hardCap (and per_ticket/user caps) for scoring
            const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            const cappedTotal = Math.min(sim.total, slipCap);
            const overPenalty = sim.total > slipCap ? (sim.total - slipCap) * 10 : 0;
            const softPenalty = cappedTotal > plan.softCap ? (cappedTotal - plan.softCap) * 0.5 : 0;
            const score = Math.abs(cappedTotal - plan.target) + overPenalty + softPenalty;
            if (score < bestScore) {
                bestScore = score;
                pick = {
                    serverSeed: candidateSeed,
                    serverSeedHash: sha256(candidateSeed),
                    results: sim.results,
                    total: +cappedTotal.toFixed(2),
                    pickIdx: k
                };
            }
        }
        // Final totals
        const payoutTotal = pick.total;
        // Build odds strip for UI (also available via GET /v1/games/plinko/odds)
        const board = { rows: input.rows, risk: input.risk, bins: getMultipliers(input.rows, input.risk) };
        // --- RTP settle (REAL only)
        if (mode === "real" && dayKey) {
            yield redis_1.redis.spSettle(dayKey, stakeTotal, payoutTotal);
        }
        // Credit winners
        if (mode === "demo") {
            const afterDebit = yield getDemoBalance(sess); // after debit
            const finalBal = +(afterDebit + payoutTotal).toFixed(2);
            yield setDemoBalance(sess, finalBal);
            balance = finalBal;
        }
        else if (payoutTotal > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_e = sess.opSessionId) !== null && _e !== void 0 ? _e : sess.sessionId;
            const opCtx = {
                baseUrl: operator.baseUrl,
                secret: operator.secret,
                session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${txnId}-W`,
                TransactionType: "WinAmount",
                Amount: payoutTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Plinko",
                    GameName: "Plinko",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: pick.serverSeed,
                    ServerSeedHash: pick.serverSeedHash,
                    FinalBins: pick.results.map(r => r.bin_index)
                }
            });
            if (process.env.PLINKO_INCLUDE_BALANCE === "true") {
                try {
                    const b = yield (0, client_1.getBalance)(opCtx); // { amount, currencyCode }
                    balance = Number(b.amount);
                }
                catch ( /* ignore */_h) { /* ignore */ }
            }
        }
        const resp = {
            game: "Plinko",
            mode,
            txn_id: txnId,
            currency: sess.currency,
            stake_total: stakeTotal,
            balance, // updated balance (demo always; real if env flag)
            board, // bins array for the odds strip
            balls: pick.results,
            slip: {
                payout_total: payoutTotal,
                profit_total: +(payoutTotal - stakeTotal).toFixed(2)
            },
            fairness: {
                method: `Path bits from HMAC-SHA256(server_seed, \`${clientSeedDefault !== null && clientSeedDefault !== void 0 ? clientSeedDefault : ((_g = (_f = sess.clientExternalKey) !== null && _f !== void 0 ? _f : sess.userName) !== null && _g !== void 0 ? _g : "client")}:ballIndex:row\`); K=${CANDIDATES_K} candidate seeds, pick best vs RTP target`,
                server_seed_hash: pick.serverSeedHash,
                server_seed: pick.serverSeed, // reveal post-resolution
                pick_index: pick.pickIdx
            },
            plan
        };
        if (idemKey)
            yield setIdem(mode, sess.sid, idemKey, resp);
        return resp;
    });
}
