import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw, getBalance as opGetBalance } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

/**
 * ----------------------------
 * Config
 * ----------------------------
 */
const IDEM_TTL = 24 * 60 * 60;

export type Risk = "low" | "normal" | "high";
const ALLOWED_ROWS = new Set([8, 10, 12, 14, 16]);
const GAME_CODE = "plinko";
const CANDIDATES_K = 6;

type GameCfg = {
  rtp_target: number; alpha: number; kappa: number; beta: number;
  per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};

async function loadGameCfg(): Promise<GameCfg> {
  const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
  if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
  const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
  if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
  return {
    rtp_target: Number(cfg.rtp_target),
    alpha: Number(cfg.alpha),
    kappa: Number(cfg.kappa),
    beta: Number(cfg.beta),
    per_bet_cap: Number(cfg.per_bet_cap),
    per_ticket_cap: Number(cfg.per_ticket_cap),
    per_user_daily_cap: Number(cfg.per_user_daily_cap),
  };
}

// Return multipliers (stake INCLUDED) per (rows, risk). Arrays are symmetric and index by bin 0..rows.
const TABLES: Record<number, Record<Risk, number[]>> = {
  8: {
    low: [0.5, 0.7, 0.9, 1.1, 1.3, 1.1, 0.9, 0.7, 0.5],
    normal: [0.2, 0.5, 0.8, 1.2, 2.0, 1.2, 0.8, 0.5, 0.2],
    high: [0.0, 0.2, 0.5, 1.0, 5.0, 1.0, 0.5, 0.2, 0.0],
  },
  10: {
    low: [0.5, 0.6, 0.8, 1.0, 1.2, 1.4, 1.2, 1.0, 0.8, 0.6, 0.5],
    normal: [0.2, 0.4, 0.7, 1.0, 1.5, 2.2, 1.5, 1.0, 0.7, 0.4, 0.2],
    high: [0.0, 0.2, 0.4, 0.8, 1.2, 8.0, 1.2, 0.8, 0.4, 0.2, 0.0],
  },
  12: {
    low: [0.5, 0.6, 0.8, 0.9, 1.1, 1.3, 1.5, 1.3, 1.1, 0.9, 0.8, 0.6, 0.5],
    normal: [0.2, 0.3, 0.5, 0.8, 1.1, 1.5, 2.5, 1.5, 1.1, 0.8, 0.5, 0.3, 0.2],
    high: [0.0, 0.1, 0.3, 0.6, 0.9, 1.2, 12.0, 1.2, 0.9, 0.6, 0.3, 0.1, 0.0],
  },
  14: {
    low: [0.5, 0.6, 0.7, 0.9, 1.0, 1.2, 1.4, 1.6, 1.4, 1.2, 1.0, 0.9, 0.7, 0.6, 0.5],
    normal: [0.2, 0.3, 0.4, 0.6, 0.9, 1.2, 1.6, 2.8, 1.6, 1.2, 0.9, 0.6, 0.4, 0.3, 0.2],
    high: [0.0, 0.1, 0.2, 0.4, 0.7, 1.0, 1.3, 15.0, 1.3, 1.0, 0.7, 0.4, 0.2, 0.1, 0.0],
  },
  16: {
    low: [0.5, 0.55, 0.7, 0.85, 1.0, 1.15, 1.3, 1.6, 1.8, 1.6, 1.3, 1.15, 1.0, 0.85, 0.7, 0.55, 0.5],
    normal: [0.2, 0.25, 0.35, 0.5, 0.7, 1.0, 1.3, 1.8, 3.2, 1.8, 1.3, 1.0, 0.7, 0.5, 0.35, 0.25, 0.2],
    high: [0.0, 0.05, 0.1, 0.2, 0.4, 0.7, 1.0, 1.4, 20.0, 1.4, 1.0, 0.7, 0.4, 0.2, 0.1, 0.05, 0.0],
  }
};

// Demo balance helpers
async function getDemoBalance(sess: ProviderSession) {
  const key = `demo:bal:${sess.sid}`;
  const cached = await redis.get(key);
  if (cached) return Number(cached);
  const base = Number(process.env.DEMO_START_BALANCE ?? 1000);
  await redis.set(key, String(base), 2 * 60 * 60);
  return base;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
  const key = `demo:bal:${sess.sid}`;
  await redis.set(key, String(amount), 2 * 60 * 60);
}

// Provably fair helpers
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
/** uniform bit from HMAC(server, `${client}:${ballIndex}:${row}`) */
const randBit = (serverSeed: string, clientSeed: string, ballIndex: number, row: number) =>
  (u32(hmacHex(serverSeed, `${clientSeed}:${ballIndex}:${row}`).slice(0, 8)) & 1) as 0 | 1;

// Idempotency (mode-scoped)
const reqKey = (mode: "real" | "demo", sid: string, key: string) => `idem:${mode}:plinko:drop:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, key?: string) {
  if (!key) return null;
  const v = await redis.get(reqKey(mode, sid, key));
  return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, key: string, payload: any) {
  await redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

// Multipliers table fetch
function getMultipliers(rows: number, risk: Risk): number[] {
  if (!ALLOWED_ROWS.has(rows)) throw AppError.badRequest("rows must be one of 8,10,12,14,16");
  const t = TABLES[rows]?.[risk];
  if (!t || t.length !== rows + 1) throw new Error("Multiplier table misconfigured");
  return t;
}

/** Public odds endpoint helper */
export function getPlinkoBoard(rows: number, risk: Risk) {
  if (!ALLOWED_ROWS.has(rows)) throw AppError.badRequest("rows must be one of 8,10,12,14,16");
  if (!["low", "normal", "high"].includes(risk)) throw AppError.badRequest("invalid risk");
  return { rows, risk, bins: getMultipliers(rows, risk) };
}

/** Simulate a whole slip under a serverSeed to get per-ball results and totals (with per-ball caps). */
function simulateSlip(
  serverSeed: string,
  clientSeedDefault: string | null,
  sess: ProviderSession,
  input: { rows: number; risk: Risk; balls: Array<{ stake: number; client_seed?: string }> },
  caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number; }
) {
  const multipliers = getMultipliers(input.rows, input.risk);
  const results = input.balls.map((ball, i) => {
    const cseed = ball.client_seed ?? clientSeedDefault ?? sess.clientExternalKey ?? sess.userName ?? "client";
    let pos = 0;
    const pathBits: number[] = [];
    for (let r = 0; r < input.rows; r++) {
      const bit = randBit(serverSeed, cseed, i, r);
      pathBits.push(bit);
      pos += bit;
    }
    const bin = pos; // 0..rows
    const mult = multipliers[bin];
    let payout = +(ball.stake * mult).toFixed(2);
    // per-ball caps (bet-level)
    payout = Math.min(payout, caps.per_bet_cap, caps.per_user_daily_cap);
    return {
      index: i,
      stake: ball.stake,
      client_seed: cseed,
      rows: input.rows,
      risk: input.risk,
      path_bits: pathBits,
      bin_index: bin,
      return_multiplier: mult,
      final_multiplier: mult,
      payout
    };
  });
  const total = +results.reduce((s, r) => s + r.payout, 0).toFixed(2);
  return { results, total };
}

/**
 * Main entry
 */
export async function doPlinkoDrop(
  sess: ProviderSession,
  input: {
    rows: number;
    risk: Risk;
    client_seed?: string;
    balls: Array<{ stake: number; client_seed?: string }>;
  },
  idemKey?: string
) {
  const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";

  // Idempotency replay
  if (idemKey) {
    const hit = await getIdem(mode, sess.sid, idemKey);
    if (hit) return hit;
  }

  // Validate
  if (!ALLOWED_ROWS.has(input.rows)) throw AppError.badRequest("rows must be one of 8,10,12,14,16");
  if (!["low", "normal", "high"].includes(input.risk)) throw AppError.badRequest("invalid risk");
  if (!Array.isArray(input.balls) || input.balls.length === 0) throw AppError.badRequest("No balls");
  if (input.balls.length > 200) throw AppError.badRequest("Too many balls");
  for (const b of input.balls) {
    if (typeof b.stake !== "number" || b.stake <= 0) throw AppError.badRequest("Invalid stake");
  }

  const stakeTotal = +input.balls.reduce((s, b) => s + b.stake, 0).toFixed(2);

  // Seeds (we will PICK the server seed among K candidates for RTP)
  const clientSeedDefault = input.client_seed ?? null;

  // Ledger: debit
  const txnId = randomUUID();
  let balance: number | undefined = undefined;

  if (mode === "demo") {
    const start = await getDemoBalance(sess);
    if (start < stakeTotal) throw AppError.badRequest("Insufficient FUN balance");
    await setDemoBalance(sess, +(start - stakeTotal).toFixed(2));
    balance = +(start - stakeTotal).toFixed(2);
  } else {
    const operator = await findByPortalName(sess.portalName);
    const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
    const opCtx: any = {
      baseUrl: operator.baseUrl,
      secret: operator.secret,
      session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
    };
    const probeSeed = crypto.randomBytes(32).toString("hex"); // for metadata hash only
    const probeHash = sha256(probeSeed);
    await deposit(opCtx, {
      TransactionId: txnId,
      TransactionType: "PlaceBet",
      Amount: stakeTotal,
      CurrencyCode: sess.currency,
      TransactionInfo: {
        Source: "Plinko",
        GameName: "Plinko",
        RoundId: txnId,
        GameNumber: Date.now().toString(),
        ServerSeedHash: probeHash,
        ClientSeed: clientSeedDefault ?? (sess.clientExternalKey ?? sess.userName ?? "client")
      }
    });
  }

  // --- RTP: enter/plan (REAL only)
  const cfg = await loadGameCfg();
  let plan = { hardCap: 0, softCap: 0, target: 0 };
  let dayKey: string | undefined;
  let yymmdd = toYYMMDD();
  if (mode === "real") {
    dayKey = rk.day(GAME_CODE, yymmdd);
    await redis.hsetnx(dayKey, "rtp_target", 0.90);
    await redis.spEnter(dayKey, stakeTotal);               // active counters++
    plan = await spPlan(GAME_CODE, stakeTotal, cfg, yymmdd);
  } else {
    // Synthetic plan for demo feel
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    plan = { hardCap, softCap, target };
  }

  // --- Pick best serverSeed among K candidates (provably fair + RTP-aware)
  let pick = { serverSeed: "", results: [] as any[], total: 0, pickIdx: 0, serverSeedHash: "" };
  let bestScore = Number.POSITIVE_INFINITY;

  for (let k = 0; k < CANDIDATES_K; k++) {
    const candidateSeed = crypto.randomBytes(32).toString("hex");
    const sim = simulateSlip(candidateSeed, clientSeedDefault, sess, input, {
      per_bet_cap: cfg.per_bet_cap,
      per_ticket_cap: cfg.per_ticket_cap,
      per_user_daily_cap: cfg.per_user_daily_cap,
    });

    // Cap slip by hardCap (and per_ticket/user caps) for scoring
    const slipCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
    const cappedTotal = Math.min(sim.total, slipCap);
    const overPenalty = sim.total > slipCap ? (sim.total - slipCap) * 10 : 0;
    const softPenalty = cappedTotal > plan.softCap ? (cappedTotal - plan.softCap) * 0.5 : 0;
    const score = Math.abs(cappedTotal - plan.target) + overPenalty + softPenalty;

    if (score < bestScore) {
      bestScore = score;
      pick = {
        serverSeed: candidateSeed,
        serverSeedHash: sha256(candidateSeed),
        results: sim.results,
        total: +cappedTotal.toFixed(2),
        pickIdx: k
      };
    }
  }

  // Final totals
  const payoutTotal = pick.total;

  // Build odds strip for UI (also available via GET /v1/games/plinko/odds)
  const board = { rows: input.rows, risk: input.risk, bins: getMultipliers(input.rows, input.risk) };

  // --- RTP settle (REAL only)
  if (mode === "real" && dayKey) {
    await redis.spSettle(dayKey, stakeTotal, payoutTotal);
  }

  // Credit winners
  if (mode === "demo") {
    const afterDebit = await getDemoBalance(sess); // after debit
    const finalBal = +(afterDebit + payoutTotal).toFixed(2);
    await setDemoBalance(sess, finalBal);
    balance = finalBal;
  } else if (payoutTotal > 0) {
    const operator = await findByPortalName(sess.portalName);
    const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
    const opCtx: any = {
      baseUrl: operator.baseUrl,
      secret: operator.secret,
      session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
    };
    await withdraw(opCtx, {
      TransactionId: `${txnId}-W`,
      TransactionType: "WinAmount",
      Amount: payoutTotal,
      CurrencyCode: sess.currency,
      TransactionInfo: {
        Source: "Plinko",
        GameName: "Plinko",
        RoundId: txnId,
        GameNumber: Date.now().toString(),
        ServerSeed: pick.serverSeed,
        ServerSeedHash: pick.serverSeedHash,
        FinalBins: pick.results.map(r => r.bin_index)
      }
    });

    if (process.env.PLINKO_INCLUDE_BALANCE === "true") {
      try {
        const b = await opGetBalance(opCtx); // { amount, currencyCode }
        balance = Number(b.amount);
      } catch { /* ignore */ }
    }
  }

  const resp = {
    game: "Plinko",
    mode,
    txn_id: txnId,
    currency: sess.currency,
    stake_total: stakeTotal,
    balance,                 // updated balance (demo always; real if env flag)
    board,                   // bins array for the odds strip
    balls: pick.results,
    slip: {
      payout_total: payoutTotal,
      profit_total: +(payoutTotal - stakeTotal).toFixed(2)
    },
    fairness: {
      method: `Path bits from HMAC-SHA256(server_seed, \`${clientSeedDefault ?? (sess.clientExternalKey ?? sess.userName ?? "client")}:ballIndex:row\`); K=${CANDIDATES_K} candidate seeds, pick best vs RTP target`,
      server_seed_hash: pick.serverSeedHash,
      server_seed: pick.serverSeed,   // reveal post-resolution
      pick_index: pick.pickIdx
    },
    plan
  };

  if (idemKey) await setIdem(mode, sess.sid, idemKey, resp);
  return resp;
}
