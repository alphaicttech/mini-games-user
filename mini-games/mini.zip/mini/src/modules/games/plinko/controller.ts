// /var/www/typesafe/alpha-mini/src/modules/games/plinko/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { doPlinkoDrop, getPlinkoBoard } from "./service";

// rows we support (board has rows + 1 bins)
const Rows = z.enum(["8", "10", "12", "14", "16"]).transform(Number);
const Risk = z.enum(["low", "normal", "high"]);

const Ball = z.object({
    stake: z.number().positive(),
    client_seed: z.string().min(1).optional(), // optional per-ball override
});

const DropBody = z.object({
    rows: Rows,
    risk: Risk,
    client_seed: z.string().min(1).optional(), // slip-level default
    balls: z.array(Ball).min(1).max(200),
});

export const dropValidate = validateBody(DropBody);

export const drop = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const body = req.body as z.infer<typeof DropBody>;
    const result = await doPlinkoDrop(sess, body, idemKey);

    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});


// NEW: odds (board) fetch
const OddsQuery = z.object({
    rows: z.enum(["8", "10", "12", "14", "16"]).transform(Number),
    risk: z.enum(["low", "normal", "high"]),
});
export const odds = asyncHandler(async (req, res) => {
    const rows = Number(req.query.rows);
    const risk = String(req.query.risk) as "low" | "normal" | "high";
    const board = getPlinkoBoard(rows, risk);
    res.json({ ok: true, board });
});