"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.odds = exports.drop = exports.dropValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
// rows we support (board has rows + 1 bins)
const Rows = zod_1.z.enum(["8", "10", "12", "14", "16"]).transform(Number);
const Risk = zod_1.z.enum(["low", "normal", "high"]);
const Ball = zod_1.z.object({
    stake: zod_1.z.number().positive(),
    client_seed: zod_1.z.string().min(1).optional(), // optional per-ball override
});
const DropBody = zod_1.z.object({
    rows: Rows,
    risk: Risk,
    client_seed: zod_1.z.string().min(1).optional(), // slip-level default
    balls: zod_1.z.array(Ball).min(1).max(200),
});
exports.dropValidate = (0, validate_1.validateBody)(DropBody);
exports.drop = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const result = yield (0, service_1.doPlinkoDrop)(sess, body, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
// NEW: odds (board) fetch
const OddsQuery = zod_1.z.object({
    rows: zod_1.z.enum(["8", "10", "12", "14", "16"]).transform(Number),
    risk: zod_1.z.enum(["low", "normal", "high"]),
});
exports.odds = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const rows = Number(req.query.rows);
    const risk = String(req.query.risk);
    const board = (0, service_1.getPlinkoBoard)(rows, risk);
    res.json({ ok: true, board });
}));
