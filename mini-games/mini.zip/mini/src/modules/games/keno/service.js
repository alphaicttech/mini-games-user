"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.doKenoDraw = doKenoDraw;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
/** ---------------------------- Config ---------------------------- */
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { minStake: 0.1, maxStake: 10000, minPicks: 1, maxPicks: 10, maxTickets: 100 };
const BOARD_MIN = 1, BOARD_MAX = 80, DRAW_COUNT = 20;
/** Paytable: returns include stake (1.0 = push) */
const PAYTABLE = {
    1: { 1: 3 },
    2: { 2: 9 },
    3: { 3: 16, 2: 2 },
    4: { 4: 50, 3: 5, 2: 1 },
    5: { 5: 150, 4: 15, 3: 2 },
    6: { 6: 450, 5: 45, 4: 6, 3: 1 },
    7: { 7: 1000, 6: 150, 5: 12, 4: 2, 3: 1 },
    8: { 8: 2300, 7: 500, 6: 50, 5: 8, 4: 1 },
    9: { 9: 4500, 8: 1000, 7: 100, 6: 12, 5: 2, 4: 1 },
    10: { 10: 9000, 9: 2000, 8: 300, 7: 30, 6: 5, 5: 1 },
};
/** ---------------------------- Provably Fair RNG ---------------------------- */
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (srv, cli, i, tag) => u32(hmacHex(srv, `${cli}:${i}:${tag}`).slice(0, 8)) / 4294967296;
function shuffle1toN(n, serverSeed, clientSeed, tag = "shuffle") {
    const arr = Array.from({ length: n }, (_, i) => i + 1);
    for (let k = n - 1; k > 0; k--) {
        const r = r01(serverSeed, clientSeed, k, tag);
        const j = Math.floor(r * (k + 1));
        const tmp = arr[k];
        arr[k] = arr[j];
        arr[j] = tmp;
    }
    return arr;
}
/** ---------------------------- Idempotency ---------------------------- */
const modePrefix = (mode) => (mode === "demo" ? "demo" : "real");
const idemKeyFor = (mode, sid, key) => `idem:${modePrefix(mode)}:keno:draw:${sid}:${key}`;
function getIdem(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () { if (!key)
        return null; const v = yield redis_1.redis.get(idemKeyFor(mode, sid, key)); return v ? JSON.parse(v) : null; });
}
function setIdem(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(idemKeyFor(mode, sid, key), JSON.stringify(payload), IDEM_TTL); });
}
/** ---------------------------- RTP wiring ---------------------------- */
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor"); // REAL plan
const GAME_CODE = "keno";
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function rtpEnterTotalReal(stakeTotal) {
    return __awaiter(this, void 0, void 0, function* () {
        const yymmdd = (0, date_1.toYYMMDD)();
        const dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
        yield redis_1.redis.hsetnx(dayKey, "rtp_target", 0.90);
        yield redis_1.redis.spEnter(dayKey, stakeTotal);
        return { dayKey, yymmdd };
    });
}
function rtpSettleTotalReal(dayKey, stakeTotal, winTotal) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.spSettle(dayKey, stakeTotal, winTotal);
    });
}
function demoPlan(totalStake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
/** ---------------------------- Validation helpers ---------------------------- */
function validateTicket(t) {
    if (t.stake < LIMITS.minStake)
        throw errors_1.AppError.badRequest(`Min stake is ${LIMITS.minStake}`);
    if (t.stake > LIMITS.maxStake)
        throw errors_1.AppError.badRequest(`Max stake is ${LIMITS.maxStake}`);
    if (!Array.isArray(t.picks))
        throw errors_1.AppError.badRequest("picks must be an array");
    if (t.picks.length < LIMITS.minPicks || t.picks.length > LIMITS.maxPicks) {
        throw errors_1.AppError.badRequest(`picks must be ${LIMITS.minPicks}..${LIMITS.maxPicks} numbers`);
    }
    const set = new Set();
    for (const n of t.picks) {
        if (!Number.isInteger(n) || n < BOARD_MIN || n > BOARD_MAX)
            throw errors_1.AppError.badRequest("picks must be integers in 1..80");
        if (set.has(n))
            throw errors_1.AppError.badRequest("picks must be unique");
        set.add(n);
    }
}
function retMult(spots, hits) {
    var _a;
    const row = PAYTABLE[spots] || {};
    return (_a = row[hits]) !== null && _a !== void 0 ? _a : 0;
}
function evaluateTicketsForDraw(tickets, drawn, perCaps) {
    const drawnSet = new Set(drawn);
    const results = tickets.map((t, i) => {
        const spots = t.picks.length;
        const hit_numbers = t.picks.filter(n => drawnSet.has(n)).sort((a, b) => a - b);
        const hits = hit_numbers.length;
        const mult = retMult(spots, hits);
        let payout = +(t.stake * mult).toFixed(2);
        payout = Math.min(payout, perCaps.per_bet_cap, perCaps.per_ticket_cap, perCaps.per_user_daily_cap);
        return { index: i, spots, stake: t.stake, hits, hit_numbers, return_multiplier: mult, payout };
    });
    const total = +results.reduce((s, r) => s + r.payout, 0).toFixed(2);
    return { results, total };
}
function pickKenoDrawWithRtp(serverSeed, clientSeed, tickets, plan, caps, K = 6) {
    let best = { score: Number.POSITIVE_INFINITY, drawn: [], pickIdx: 0, ticketResults: [], totalWin: 0 };
    for (let pickIdx = 0; pickIdx < K; pickIdx++) {
        const shuffled = shuffle1toN(BOARD_MAX, serverSeed, clientSeed, `keno:${pickIdx}`);
        const drawn = shuffled.slice(0, DRAW_COUNT).sort((a, b) => a - b);
        const evald = evaluateTicketsForDraw(tickets, drawn, caps);
        const cappedTotal = Math.min(evald.total, plan.hardCap);
        const overPenalty = evald.total > plan.hardCap ? (evald.total - plan.hardCap) * 10 : 0;
        const softPenalty = cappedTotal > plan.softCap ? (cappedTotal - plan.softCap) * 0.5 : 0;
        const score = Math.abs(cappedTotal - plan.target) + overPenalty + softPenalty;
        if (score < best.score) {
            let ticketResults = evald.results;
            let totalWin = evald.total;
            if (totalWin > plan.hardCap && totalWin > 0) {
                const factor = plan.hardCap / totalWin;
                ticketResults = ticketResults.map(r => (Object.assign(Object.assign({}, r), { payout: +(r.payout * factor).toFixed(2) })));
                totalWin = +ticketResults.reduce((s, r) => s + r.payout, 0).toFixed(2);
            }
            best = { score, drawn, pickIdx, ticketResults, totalWin };
        }
    }
    best.totalWin = Math.min(best.totalWin, plan.hardCap);
    return best;
}
/** ---------------------------- Main: doKenoDraw (REAL vs DEMO) ---------------------------- */
function doKenoDraw(sess, input, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g;
        const mode = sess.mode === "demo" ? "demo" : "real";
        if (idemKey) {
            const hit = yield getIdem(mode, sess.sid, idemKey);
            if (hit)
                return hit;
        }
        if (!Array.isArray(input.tickets) || input.tickets.length === 0)
            throw errors_1.AppError.badRequest("No tickets");
        if (input.tickets.length > LIMITS.maxTickets)
            throw errors_1.AppError.badRequest("Too many tickets");
        input.tickets.forEach(validateTicket);
        const stakeTotal = +input.tickets.reduce((s, t) => s + t.stake, 0).toFixed(2);
        // Seeds
        const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
        const serverSeedHash = sha256(serverSeed);
        const clientSeed = (_c = (_b = (_a = input.client_seed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        // Ledger: debit
        const txnId = (0, crypto_1.randomUUID)();
        if (mode === "demo") {
            const key = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(key);
            const bal = v ? Number(v) : Number((_d = process.env.DEMO_START_BALANCE) !== null && _d !== void 0 ? _d : 1000);
            if (bal < stakeTotal)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield redis_1.redis.set(key, String(+(bal - stakeTotal).toFixed(2)), 2 * 60 * 60);
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_e = sess.opSessionId) !== null && _e !== void 0 ? _e : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: stakeTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Keno", GameName: "Keno", RoundId: txnId,
                    GameNumber: Date.now().toString(), ServerSeedHash: serverSeedHash, ClientSeed: clientSeed
                }
            });
        }
        // RTP: enter (REAL only)
        let dayKey = null;
        let yymmdd = (0, date_1.toYYMMDD)();
        if (mode === "real") {
            const r = yield rtpEnterTotalReal(stakeTotal);
            dayKey = r.dayKey;
            yymmdd = r.yymmdd;
        }
        // Load config & plan
        const cfg = yield loadGameCfg();
        const plan = (mode === "real")
            ? yield (0, governor_1.spPlan)(GAME_CODE, stakeTotal, cfg, yymmdd)
            : demoPlan(stakeTotal, cfg);
        // Pick draw near target & under hardCap
        const picked = pickKenoDrawWithRtp(serverSeed, clientSeed, input.tickets, { target: plan.target, hardCap: plan.hardCap, softCap: plan.softCap }, { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap }, 6);
        const drawn = picked.drawn;
        const ticketResults = picked.ticketResults;
        const payoutTotal = picked.totalWin;
        // RTP: settle (REAL only)
        if (mode === "real" && dayKey) {
            yield rtpSettleTotalReal(dayKey, stakeTotal, payoutTotal);
        }
        // Credit
        if (mode === "demo") {
            const key = `demo:bal:${sess.sid}`;
            const v2 = yield redis_1.redis.get(key);
            const bal2 = v2 ? Number(v2) : Number((_f = process.env.DEMO_START_BALANCE) !== null && _f !== void 0 ? _f : 1000);
            yield redis_1.redis.set(key, String(+(bal2 + payoutTotal).toFixed(2)), 2 * 60 * 60);
        }
        else if (payoutTotal > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_g = sess.opSessionId) !== null && _g !== void 0 ? _g : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${txnId}-W`,
                TransactionType: "WinAmount",
                Amount: payoutTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Keno", GameName: "Keno", RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: serverSeed, ServerSeedHash: serverSeedHash, ClientSeed: clientSeed,
                    Drawn: drawn
                }
            });
        }
        const resp = {
            game: "Keno",
            mode,
            txn_id: txnId,
            currency: sess.currency,
            stake_total: stakeTotal,
            draw: { numbers: drawn, seed_hash: serverSeedHash },
            tickets: ticketResults,
            slip: { payout_total: payoutTotal, profit_total: +(payoutTotal - stakeTotal).toFixed(2) },
            fairness: {
                method: "Pick K deterministic 20-of-80 draws via HMAC; choose RTP-aware best",
                server_seed_hash: serverSeedHash,
                server_seed: serverSeed, // revealed after resolution
                client_seed: clientSeed,
                K: 6
            },
            plan
        };
        if (idemKey)
            yield setIdem(mode, sess.sid, idemKey, resp);
        return resp;
    });
}
