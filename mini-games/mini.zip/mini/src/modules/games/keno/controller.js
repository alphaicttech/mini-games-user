"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.draw = exports.drawValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const Ticket = zod_1.z.object({
    stake: zod_1.z.number().positive(),
    picks: zod_1.z.array(zod_1.z.number().int().min(1).max(80)).min(1).max(10)
        .refine((arr) => new Set(arr).size === arr.length, "picks must be unique"),
});
const DrawBody = zod_1.z.object({
    client_seed: zod_1.z.string().min(1).optional(),
    tickets: zod_1.z.array(Ticket).min(1).max(100),
});
exports.drawValidate = (0, validate_1.validateBody)(DrawBody);
exports.draw = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const data = yield (0, service_1.doKenoDraw)(sess, body, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
