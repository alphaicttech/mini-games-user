// /var/www/typesafe/alpha-mini/src/modules/games/keno/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { doKenoDraw } from "./service";

const Ticket = z.object({
    stake: z.number().positive(),
    picks: z.array(z.number().int().min(1).max(80)).min(1).max(10)
        .refine((arr) => new Set(arr).size === arr.length, "picks must be unique"),
});

const DrawBody = z.object({
    client_seed: z.string().min(1).optional(),
    tickets: z.array(Ticket).min(1).max(100),
});

export const drawValidate = validateBody(DrawBody);

export const draw = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const body = req.body as z.infer<typeof DrawBody>;
    const data = await doKenoDraw(sess, body, idemKey);

    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});
