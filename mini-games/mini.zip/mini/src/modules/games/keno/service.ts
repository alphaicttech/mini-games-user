import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

/** ---------------------------- Config ---------------------------- */
const IDEM_TTL = 24 * 60 * 60;
const LIMITS = { minStake: 0.1, maxStake: 10000, minPicks: 1, maxPicks: 10, maxTickets: 100 };
const BOARD_MIN = 1, BOARD_MAX = 80, DRAW_COUNT = 20;

/** Paytable: returns include stake (1.0 = push) */
const PAYTABLE: Record<number, Record<number, number>> = {
    1: { 1: 3 },
    2: { 2: 9 },
    3: { 3: 16, 2: 2 },
    4: { 4: 50, 3: 5, 2: 1 },
    5: { 5: 150, 4: 15, 3: 2 },
    6: { 6: 450, 5: 45, 4: 6, 3: 1 },
    7: { 7: 1000, 6: 150, 5: 12, 4: 2, 3: 1 },
    8: { 8: 2300, 7: 500, 6: 50, 5: 8, 4: 1 },
    9: { 9: 4500, 8: 1000, 7: 100, 6: 12, 5: 2, 4: 1 },
    10: { 10: 9000, 9: 2000, 8: 300, 7: 30, 6: 5, 5: 1 },
};

/** ---------------------------- Provably Fair RNG ---------------------------- */
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (srv: string, cli: string, i: number, tag: string) =>
    u32(hmacHex(srv, `${cli}:${i}:${tag}`).slice(0, 8)) / 4294967296;

function shuffle1toN(n: number, serverSeed: string, clientSeed: string, tag = "shuffle"): number[] {
    const arr = Array.from({ length: n }, (_, i) => i + 1);
    for (let k = n - 1; k > 0; k--) {
        const r = r01(serverSeed, clientSeed, k, tag);
        const j = Math.floor(r * (k + 1));
        const tmp = arr[k]; arr[k] = arr[j]; arr[j] = tmp;
    }
    return arr;
}

/** ---------------------------- Idempotency ---------------------------- */
const modePrefix = (mode: "real" | "demo") => (mode === "demo" ? "demo" : "real");
const idemKeyFor = (mode: "real" | "demo", sid: string, key: string) => `idem:${modePrefix(mode)}:keno:draw:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, key?: string) { if (!key) return null; const v = await redis.get(idemKeyFor(mode, sid, key)); return v ? JSON.parse(v) : null; }
async function setIdem(mode: "real" | "demo", sid: string, key: string, payload: any) { await redis.set(idemKeyFor(mode, sid, key), JSON.stringify(payload), IDEM_TTL); }

/** ---------------------------- RTP wiring ---------------------------- */
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor"; // REAL plan

const GAME_CODE = "keno";

type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
async function rtpEnterTotalReal(stakeTotal: number) {
    const yymmdd = toYYMMDD();
    const dayKey = rk.day(GAME_CODE, yymmdd);
    await redis.hsetnx(dayKey, "rtp_target", 0.90);
    await redis.spEnter(dayKey, stakeTotal);
    return { dayKey, yymmdd };
}
async function rtpSettleTotalReal(dayKey: string, stakeTotal: number, winTotal: number) {
    await redis.spSettle(dayKey, stakeTotal, winTotal);
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

/** ---------------------------- Validation helpers ---------------------------- */
function validateTicket(t: { stake: number; picks: number[] }) {
    if (t.stake < LIMITS.minStake) throw AppError.badRequest(`Min stake is ${LIMITS.minStake}`);
    if (t.stake > LIMITS.maxStake) throw AppError.badRequest(`Max stake is ${LIMITS.maxStake}`);
    if (!Array.isArray(t.picks)) throw AppError.badRequest("picks must be an array");
    if (t.picks.length < LIMITS.minPicks || t.picks.length > LIMITS.maxPicks) {
        throw AppError.badRequest(`picks must be ${LIMITS.minPicks}..${LIMITS.maxPicks} numbers`);
    }
    const set = new Set<number>();
    for (const n of t.picks) {
        if (!Number.isInteger(n) || n < BOARD_MIN || n > BOARD_MAX) throw AppError.badRequest("picks must be integers in 1..80");
        if (set.has(n)) throw AppError.badRequest("picks must be unique");
        set.add(n);
    }
}

function retMult(spots: number, hits: number): number {
    const row = PAYTABLE[spots] || {};
    return row[hits] ?? 0;
}

/** ---------------------------- RTP-aware candidate selection ---------------------------- */
type TicketIn = { stake: number; picks: number[] };
type TicketOut = { index: number; spots: number; stake: number; hits: number; hit_numbers: number[]; return_multiplier: number; payout: number };

function evaluateTicketsForDraw(
    tickets: TicketIn[],
    drawn: number[],
    perCaps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number; }
): { results: TicketOut[]; total: number } {
    const drawnSet = new Set(drawn);
    const results: TicketOut[] = tickets.map((t, i) => {
        const spots = t.picks.length;
        const hit_numbers = t.picks.filter(n => drawnSet.has(n)).sort((a, b) => a - b);
        const hits = hit_numbers.length;
        const mult = retMult(spots, hits);
        let payout = +(t.stake * mult).toFixed(2);
        payout = Math.min(payout, perCaps.per_bet_cap, perCaps.per_ticket_cap, perCaps.per_user_daily_cap);
        return { index: i, spots, stake: t.stake, hits, hit_numbers, return_multiplier: mult, payout };
    });
    const total = +results.reduce((s, r) => s + r.payout, 0).toFixed(2);
    return { results, total };
}

function pickKenoDrawWithRtp(
    serverSeed: string, clientSeed: string,
    tickets: TicketIn[],
    plan: { target: number; hardCap: number; softCap: number; },
    caps: { per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number; },
    K = 6
): { drawn: number[]; pickIdx: number; ticketResults: TicketOut[]; totalWin: number } {
    let best = { score: Number.POSITIVE_INFINITY, drawn: [] as number[], pickIdx: 0, ticketResults: [] as TicketOut[], totalWin: 0 };

    for (let pickIdx = 0; pickIdx < K; pickIdx++) {
        const shuffled = shuffle1toN(BOARD_MAX, serverSeed, clientSeed, `keno:${pickIdx}`);
        const drawn = shuffled.slice(0, DRAW_COUNT).sort((a, b) => a - b);

        const evald = evaluateTicketsForDraw(tickets, drawn, caps);
        const cappedTotal = Math.min(evald.total, plan.hardCap);
        const overPenalty = evald.total > plan.hardCap ? (evald.total - plan.hardCap) * 10 : 0;
        const softPenalty = cappedTotal > plan.softCap ? (cappedTotal - plan.softCap) * 0.5 : 0;
        const score = Math.abs(cappedTotal - plan.target) + overPenalty + softPenalty;

        if (score < best.score) {
            let ticketResults = evald.results;
            let totalWin = evald.total;

            if (totalWin > plan.hardCap && totalWin > 0) {
                const factor = plan.hardCap / totalWin;
                ticketResults = ticketResults.map(r => ({ ...r, payout: + (r.payout * factor).toFixed(2) }));
                totalWin = +ticketResults.reduce((s, r) => s + r.payout, 0).toFixed(2);
            }

            best = { score, drawn, pickIdx, ticketResults, totalWin };
        }
    }
    best.totalWin = Math.min(best.totalWin, plan.hardCap);
    return best;
}

/** ---------------------------- Main: doKenoDraw (REAL vs DEMO) ---------------------------- */
export async function doKenoDraw(
    sess: ProviderSession,
    input: { client_seed?: string; tickets: Array<{ stake: number; picks: number[] }> },
    idemKey?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";

    if (idemKey) {
        const hit = await getIdem(mode, sess.sid, idemKey);
        if (hit) return hit;
    }

    if (!Array.isArray(input.tickets) || input.tickets.length === 0) throw AppError.badRequest("No tickets");
    if (input.tickets.length > LIMITS.maxTickets) throw AppError.badRequest("Too many tickets");
    input.tickets.forEach(validateTicket);

    const stakeTotal = +input.tickets.reduce((s, t) => s + t.stake, 0).toFixed(2);

    // Seeds
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);
    const clientSeed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    // Ledger: debit
    const txnId = randomUUID();
    if (mode === "demo") {
        const key = `demo:bal:${sess.sid}`;
        const v = await redis.get(key);
        const bal = v ? Number(v) : Number(process.env.DEMO_START_BALANCE ?? 1000);
        if (bal < stakeTotal) throw AppError.badRequest("Insufficient FUN balance");
        await redis.set(key, String(+(bal - stakeTotal).toFixed(2)), 2 * 60 * 60);
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: stakeTotal,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Keno", GameName: "Keno", RoundId: txnId,
                GameNumber: Date.now().toString(), ServerSeedHash: serverSeedHash, ClientSeed: clientSeed
            }
        });
    }

    // RTP: enter (REAL only)
    let dayKey: string | null = null;
    let yymmdd = toYYMMDD();
    if (mode === "real") {
        const r = await rtpEnterTotalReal(stakeTotal);
        dayKey = r.dayKey; yymmdd = r.yymmdd;
    }

    // Load config & plan
    const cfg = await loadGameCfg();
    const plan = (mode === "real")
        ? await spPlan(GAME_CODE, stakeTotal, cfg, yymmdd)
        : demoPlan(stakeTotal, cfg);

    // Pick draw near target & under hardCap
    const picked = pickKenoDrawWithRtp(
        serverSeed, clientSeed,
        input.tickets,
        { target: plan.target, hardCap: plan.hardCap, softCap: plan.softCap },
        { per_bet_cap: cfg.per_bet_cap, per_ticket_cap: cfg.per_ticket_cap, per_user_daily_cap: cfg.per_user_daily_cap },
        6
    );

    const drawn = picked.drawn;
    const ticketResults = picked.ticketResults;
    const payoutTotal = picked.totalWin;

    // RTP: settle (REAL only)
    if (mode === "real" && dayKey) {
        await rtpSettleTotalReal(dayKey, stakeTotal, payoutTotal);
    }

    // Credit
    if (mode === "demo") {
        const key = `demo:bal:${sess.sid}`;
        const v2 = await redis.get(key);
        const bal2 = v2 ? Number(v2) : Number(process.env.DEMO_START_BALANCE ?? 1000);
        await redis.set(key, String(+(bal2 + payoutTotal).toFixed(2)), 2 * 60 * 60);
    } else if (payoutTotal > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: `${txnId}-W`,
            TransactionType: "WinAmount",
            Amount: payoutTotal,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Keno", GameName: "Keno", RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeed: serverSeed, ServerSeedHash: serverSeedHash, ClientSeed: clientSeed,
                Drawn: drawn
            }
        });
    }

    const resp = {
        game: "Keno",
        mode,
        txn_id: txnId,
        currency: sess.currency,
        stake_total: stakeTotal,
        draw: { numbers: drawn, seed_hash: serverSeedHash },
        tickets: ticketResults,
        slip: { payout_total: payoutTotal, profit_total: +(payoutTotal - stakeTotal).toFixed(2) },
        fairness: {
            method: "Pick K deterministic 20-of-80 draws via HMAC; choose RTP-aware best",
            server_seed_hash: serverSeedHash,
            server_seed: serverSeed,   // revealed after resolution
            client_seed: clientSeed,
            K: 6
        },
        plan
    };

    if (idemKey) await setIdem(mode, sess.sid, idemKey, resp);
    return resp;
}
