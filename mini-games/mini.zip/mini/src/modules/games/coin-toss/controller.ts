// /var/www/typesafe/alpha-mini/src/modules/games/coin-toss/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { placeCoinBet } from "./service";

const BetBody = z.object({
    amount: z.number().positive(),
    side: z.enum(["HEADS", "TAILS"]),
    client_seed: z.string().min(1).optional()
});

export const betValidate = validateBody(BetBody);

export const bet = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { amount, side, client_seed } = req.body as z.infer<typeof BetBody>;

    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await placeCoinBet(sess, { amount, side, clientSeed: client_seed }, idemKey);

    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});
