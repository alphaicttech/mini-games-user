// /var/www/typesafe/alpha-mini/src/modules/games/coin-toss/service.ts
import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { rawRedis, redis } from "../../../config/redis";
// ⚠️ make sure this path matches your store filename (operators.ts vs operator.ts)
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";
import { AppError } from "../../../errors";

const PAYOUT_MULTIPLIER = 1.98;
const IDEM_TTL = 24 * 60 * 60;

// ---------------- helpers ----------------
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const randHex32 = () => crypto.randomBytes(32).toString("hex");

const reqKey = (sid: string, key: string) => `idem:coin:req:${sid}:${key}`;
const txnKey = (sid: string, txn: string) => `idem:coin:txn:${sid}:${txn}`;

async function getIdemByTxn(sid: string, txnId: string) {
    const v = await redis.get(txnKey(sid, txnId));
    return v ? JSON.parse(v) : null;
}
async function setIdemByTxn(sid: string, txnId: string, payload: any) {
    await redis.set(txnKey(sid, txnId), JSON.stringify(payload), IDEM_TTL);
}
async function getIdemByKey(sid: string, key: string) {
    const v = await redis.get(reqKey(sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdemByKey(sid: string, key: string, payload: any) {
    await redis.set(reqKey(sid, key), JSON.stringify(payload), IDEM_TTL);
}

// Deterministic result from seeds
function tossFromSeeds(serverSeed: string, clientSeed: string, nonce: number): "HEADS" | "TAILS" {
    const msg = `${clientSeed}:${nonce}`;
    const hmac = crypto.createHmac("sha256", serverSeed).update(msg).digest("hex");
    const val = parseInt(hmac.slice(0, 8), 16);
    return (val % 2 === 0) ? "HEADS" : "TAILS";
}

// Demo balance helpers
async function getDemoBalance(sess: ProviderSession) {
    const key = `demo:bal:${sess.sid}`;
    const cached = await redis.get(key);
    if (cached) return Number(cached);
    const base = 1_000_000.00; // your current default — change if you meant 100_000
    await redis.set(key, String(base), 2 * 60 * 60);
    return base;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
    const key = `demo:bal:${sess.sid}`;
    await redis.set(key, String(amount), 2 * 60 * 60);
}

// --------------- main ---------------
type BetInput = { amount: number; side: "HEADS" | "TAILS"; clientSeed?: string };

export async function placeCoinBet(sess: ProviderSession, bet: BetInput, idemKey?: string) {
    // 1) REQUEST-level idempotency (client retries)
    if (idemKey) {
        const hit = await getIdemByKey(sess.sid, idemKey);   // ✅ use request cache
        if (hit) return hit;
    }

    const txnId = randomUUID(); // canonical txn id (server-generated)

    // 2) Validate limits
    if (bet.amount < 0.1) throw AppError.badRequest("Min bet is 0.1");
    if (bet.amount > 10000) throw AppError.badRequest("Max bet is 10000");

    // 3) Provably fair
    const serverSeed = randHex32();
    const serverSeedHash = sha256(serverSeed);
    const clientSeed = bet.clientSeed ?? sess.clientExternalKey ?? sess.userName ?? "client";
    const nonce = 1;

    // 4) Flip
    const resultSide = tossFromSeeds(serverSeed, clientSeed, nonce);
    const win = (resultSide === bet.side) ? Number((bet.amount * PAYOUT_MULTIPLIER).toFixed(2)) : 0;

    // 5) Balance
    let newBalance = 0;

    if (sess.mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < bet.amount) throw AppError.badRequest("Insufficient FUN balance");

        const afterDebit = +(bal - bet.amount).toFixed(2);
        const after = +(afterDebit + win).toFixed(2);
        await setDemoBalance(sess, after);
        newBalance = after;
    } else {
        // REAL — call operator wallet
        const operator = await findByPortalName(sess.portalName);

        // Your operator client may expect session.id or session.sessionId — pick one and stick to it.
        const operatorSessionId = (sess as any).sessionId ?? (sess as any).opSessionId; // support both
        const opCtx = {
            baseUrl: operator.baseUrl,
            secret: operator.secret,
            session: {
                // If your operator/client.ts expects { id, userName, clientExternalKey }, then use:
                id: operatorSessionId,
                userName: sess.userName,
                clientExternalKey: sess.clientExternalKey,
            }
            // If it expects { sessionId, userName, clientExternalKey }, rename the key accordingly.
        } as any;

        // 1) Debit (PlaceBet)
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: bet.amount,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Coin",
                GameName: "CoinToss",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeedHash: serverSeedHash,
                ClientSeed: clientSeed,
                Nonce: nonce
            }
        });

        // 2) Credit (WinAmount) if win
        if (win > 0) {
            const wd = await withdraw(opCtx, {
                TransactionId: `${txnId}-W`,
                TransactionType: "WinAmount",
                Amount: win,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Coin",
                    GameName: "CoinToss",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: serverSeed,
                    ServerSeedHash: serverSeedHash,
                    ClientSeed: clientSeed,
                    Nonce: nonce,
                    CoinResult: resultSide
                }
            });
            if (wd?.Balance != null) newBalance = Number(wd.Balance);
        }
    }

    // 6) Build result
    const response = {
        game: "CoinToss",
        round_id: txnId,
        txn_id: txnId,
        stake: bet.amount,
        side_chosen: bet.side,
        result: resultSide,
        win_amount: win,
        currency: sess.currency,
        balance: newBalance, // 0 if unknown (real mode)
        fairness: {
            method: "HMAC-SHA256(server_seed, client_seed:nonce) mod 2",
            server_seed_hash: serverSeedHash,
            server_seed: serverSeed,
            client_seed: clientSeed,
            nonce
        }
    };

    // 7) Cache both ways
    await setIdemByTxn(sess.sid, txnId, response);     // canonical txn cache
    if (idemKey) await setIdemByKey(sess.sid, idemKey, response); // request retry cache

    return response;
}
