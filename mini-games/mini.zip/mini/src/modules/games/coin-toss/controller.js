"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bet = exports.betValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const BetBody = zod_1.z.object({
    amount: zod_1.z.number().positive(),
    side: zod_1.z.enum(["HEADS", "TAILS"]),
    client_seed: zod_1.z.string().min(1).optional()
});
exports.betValidate = (0, validate_1.validateBody)(BetBody);
exports.bet = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { amount, side, client_seed } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const result = yield (0, service_1.placeCoinBet)(sess, { amount, side, clientSeed: client_seed }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
