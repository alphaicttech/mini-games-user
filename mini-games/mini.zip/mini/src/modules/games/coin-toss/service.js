"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.placeCoinBet = placeCoinBet;
// /var/www/typesafe/alpha-mini/src/modules/games/coin-toss/service.ts
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
// ⚠️ make sure this path matches your store filename (operators.ts vs operator.ts)
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
const errors_1 = require("../../../errors");
const PAYOUT_MULTIPLIER = 1.98;
const IDEM_TTL = 24 * 60 * 60;
// ---------------- helpers ----------------
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const randHex32 = () => crypto_1.default.randomBytes(32).toString("hex");
const reqKey = (sid, key) => `idem:coin:req:${sid}:${key}`;
const txnKey = (sid, txn) => `idem:coin:txn:${sid}:${txn}`;
function getIdemByTxn(sid, txnId) {
    return __awaiter(this, void 0, void 0, function* () {
        const v = yield redis_1.redis.get(txnKey(sid, txnId));
        return v ? JSON.parse(v) : null;
    });
}
function setIdemByTxn(sid, txnId, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(txnKey(sid, txnId), JSON.stringify(payload), IDEM_TTL);
    });
}
function getIdemByKey(sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        const v = yield redis_1.redis.get(reqKey(sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdemByKey(sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(reqKey(sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
// Deterministic result from seeds
function tossFromSeeds(serverSeed, clientSeed, nonce) {
    const msg = `${clientSeed}:${nonce}`;
    const hmac = crypto_1.default.createHmac("sha256", serverSeed).update(msg).digest("hex");
    const val = parseInt(hmac.slice(0, 8), 16);
    return (val % 2 === 0) ? "HEADS" : "TAILS";
}
// Demo balance helpers
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = `demo:bal:${sess.sid}`;
        const cached = yield redis_1.redis.get(key);
        if (cached)
            return Number(cached);
        const base = 1000000; // your current default — change if you meant 100_000
        yield redis_1.redis.set(key, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = `demo:bal:${sess.sid}`;
        yield redis_1.redis.set(key, String(amount), 2 * 60 * 60);
    });
}
function placeCoinBet(sess, bet, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        // 1) REQUEST-level idempotency (client retries)
        if (idemKey) {
            const hit = yield getIdemByKey(sess.sid, idemKey); // ✅ use request cache
            if (hit)
                return hit;
        }
        const txnId = (0, crypto_1.randomUUID)(); // canonical txn id (server-generated)
        // 2) Validate limits
        if (bet.amount < 0.1)
            throw errors_1.AppError.badRequest("Min bet is 0.1");
        if (bet.amount > 10000)
            throw errors_1.AppError.badRequest("Max bet is 10000");
        // 3) Provably fair
        const serverSeed = randHex32();
        const serverSeedHash = sha256(serverSeed);
        const clientSeed = (_c = (_b = (_a = bet.clientSeed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        const nonce = 1;
        // 4) Flip
        const resultSide = tossFromSeeds(serverSeed, clientSeed, nonce);
        const win = (resultSide === bet.side) ? Number((bet.amount * PAYOUT_MULTIPLIER).toFixed(2)) : 0;
        // 5) Balance
        let newBalance = 0;
        if (sess.mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < bet.amount)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            const afterDebit = +(bal - bet.amount).toFixed(2);
            const after = +(afterDebit + win).toFixed(2);
            yield setDemoBalance(sess, after);
            newBalance = after;
        }
        else {
            // REAL — call operator wallet
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            // Your operator client may expect session.id or session.sessionId — pick one and stick to it.
            const operatorSessionId = (_d = sess.sessionId) !== null && _d !== void 0 ? _d : sess.opSessionId; // support both
            const opCtx = {
                baseUrl: operator.baseUrl,
                secret: operator.secret,
                session: {
                    // If your operator/client.ts expects { id, userName, clientExternalKey }, then use:
                    id: operatorSessionId,
                    userName: sess.userName,
                    clientExternalKey: sess.clientExternalKey,
                }
                // If it expects { sessionId, userName, clientExternalKey }, rename the key accordingly.
            };
            // 1) Debit (PlaceBet)
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: bet.amount,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Coin",
                    GameName: "CoinToss",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeedHash: serverSeedHash,
                    ClientSeed: clientSeed,
                    Nonce: nonce
                }
            });
            // 2) Credit (WinAmount) if win
            if (win > 0) {
                const wd = yield (0, client_1.withdraw)(opCtx, {
                    TransactionId: `${txnId}-W`,
                    TransactionType: "WinAmount",
                    Amount: win,
                    CurrencyCode: sess.currency,
                    TransactionInfo: {
                        Source: "Coin",
                        GameName: "CoinToss",
                        RoundId: txnId,
                        GameNumber: Date.now().toString(),
                        ServerSeed: serverSeed,
                        ServerSeedHash: serverSeedHash,
                        ClientSeed: clientSeed,
                        Nonce: nonce,
                        CoinResult: resultSide
                    }
                });
                if ((wd === null || wd === void 0 ? void 0 : wd.Balance) != null)
                    newBalance = Number(wd.Balance);
            }
        }
        // 6) Build result
        const response = {
            game: "CoinToss",
            round_id: txnId,
            txn_id: txnId,
            stake: bet.amount,
            side_chosen: bet.side,
            result: resultSide,
            win_amount: win,
            currency: sess.currency,
            balance: newBalance, // 0 if unknown (real mode)
            fairness: {
                method: "HMAC-SHA256(server_seed, client_seed:nonce) mod 2",
                server_seed_hash: serverSeedHash,
                server_seed: serverSeed,
                client_seed: clientSeed,
                nonce
            }
        };
        // 7) Cache both ways
        yield setIdemByTxn(sess.sid, txnId, response); // canonical txn cache
        if (idemKey)
            yield setIdemByKey(sess.sid, idemKey, response); // request retry cache
        return response;
    });
}
