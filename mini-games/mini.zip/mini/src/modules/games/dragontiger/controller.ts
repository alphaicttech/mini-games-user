// /var/www/typesafe/alpha-mini/src/modules/games/dragontiger/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { doDeal } from "./service";

/** ---- Input validation ---- */
const BetType = z.enum(["DRAGON", "TIGER", "TIE"]);

const DealBody = z.object({
    client_seed: z.string().min(1).optional(),
    cfg: z.object({
        decks: z.number().int().min(1).max(8).default(8),
        // stake-included return for Tie: 12.0 = 11:1, 9.0 = 8:1
        tie_return: z.number().min(2).max(20).default(12.0),
        // what happens to DRAGON/TIGER bets when the result is TIE
        // "lose_half" (50% refund), "lose_all", or "push" (full refund)
        tie_on_main: z.enum(["lose_half", "lose_all", "push"]).default("lose_half"),
        min_stake: z.number().positive().default(0.1),
        max_stake: z.number().positive().default(10000),
        max_bets: z.number().int().min(1).max(50).default(10),
    }).default({} as any),
    bets: z.array(z.object({
        type: BetType,
        stake: z.number().positive(),
    })).min(1)
});

export const dealValidate = validateBody(DealBody);

export const deal = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof DealBody>;
    const result = await doDeal(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...result });
});
