import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP (accounting) ====
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { redis as redisClient } from "../../../config/redis";
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { spPlan } from "../../rtp/governor";

/** ---- Config ---- */
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "dragontiger";

type Cfg = {
    decks: number;
    tie_return: number;                    // stake-included multiplier for TIE (e.g., 12.0 = 11:1)
    tie_on_main: "lose_half" | "lose_all" | "push";
    min_stake: number;
    max_stake: number;
    max_bets: number;
};

type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}

/** ---- Cards & RNG ---- */
type Card = { r: number; s: number };    // rank 0..12 (A..K), suit 0..3
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];

// Dragon Tiger ranking: Ace is LOW (A=1) … K=13
function rankValueDT(r: number) {
    if (r === 0) return 1;
    if (r >= 1 && r <= 9) return r + 1;
    return 10 + (r - 9);
}

const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (server: string, client: string, i: number, tag: string) =>
    u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;

function buildShoe(decks: number): Card[] {
    const one: Card[] = [];
    for (let s = 0; s < 4; s++) for (let r = 0; r < 13; r++) one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => ({ ...c })));
}
function shuffle(arr: Card[], server: string, client: string) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k]; a[k] = a[j]; a[j] = t;
    }
    return a;
}
const fmt = (c: Card) => ({ rank: RANKS[c.r], suit: SUITS[c.s], val: rankValueDT(c.r) });

/** ---- Demo wallet ---- */
async function getDemoBalance(sess: ProviderSession) {
    const k = `demo:bal:${sess.sid}`;
    const v = await redis.get(k);
    if (v) return Number(v);
    const base = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(k, String(base), 2 * 60 * 60);
    return base;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
    await redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
}

/** ---- Idempotency (mode-scoped) ---- */
const idemKey = (mode: "real" | "demo", sid: string, key: string) => `idem:${mode}:dragontiger:deal:${sid}:${key}`;
async function getIdem(mode: "real" | "demo", sid: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(idemKey(mode, sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, key: string, payload: any) {
    await redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

/** ---- Main service ---- */
export async function doDeal(
    sess: ProviderSession,
    input: {
        client_seed?: string;
        cfg?: Partial<Cfg>;
        bets: Array<{ type: "DRAGON" | "TIGER" | "TIE"; stake: number }>;
    },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, idem); if (hit) return hit; }

    // Merge config & validate
    const cfg: Cfg = {
        decks: input.cfg?.decks ?? 8,
        tie_return: input.cfg?.tie_return ?? 12.0,
        tie_on_main: input.cfg?.tie_on_main ?? "lose_half",
        min_stake: input.cfg?.min_stake ?? 0.1,
        max_stake: input.cfg?.max_stake ?? 10000,
        max_bets: input.cfg?.max_bets ?? 10
    };

    if (!Array.isArray(input.bets) || input.bets.length === 0) throw AppError.badRequest("No bets");
    if (input.bets.length > cfg.max_bets) throw AppError.badRequest("Too many bets");
    for (const b of input.bets) {
        if (!(b.stake > 0)) throw AppError.badRequest("Invalid stake");
        if (b.stake < cfg.min_stake) throw AppError.badRequest(`Min stake is ${cfg.min_stake}`);
        if (b.stake > cfg.max_stake) throw AppError.badRequest(`Max stake is ${cfg.max_stake}`);
    }

    const clientSeed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);

    // Shuffle shoe & deal two cards
    const shoe = shuffle(buildShoe(cfg.decks), serverSeed, clientSeed);
    const dragon = shoe[0];
    const tiger = shoe[1];

    const dv = rankValueDT(dragon.r);
    const tv = rankValueDT(tiger.r);

    let winner: "DRAGON" | "TIGER" | "TIE";
    if (dv > tv) winner = "DRAGON";
    else if (tv > dv) winner = "TIGER";
    else winner = "TIE";

    // Debit all stakes once
    const stakeTotal = +input.bets.reduce((s, b) => s + b.stake, 0).toFixed(2);
    const txnId = randomUUID();

    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < stakeTotal) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - stakeTotal).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: stakeTotal,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "DragonTiger",
                GameName: "DragonTiger",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeedHash: serverSeedHash,
                ClientSeed: clientSeed,
                Config: cfg
            }
        });
    }

    // RTP enter (REAL) — accounting only
    let dayKey: string | undefined;
    let yymmdd = toYYMMDD();
    let plan: { target: number; hardCap: number; softCap: number } | undefined;
    if (mode === "real") {
        dayKey = rk.day(GAME_CODE, yymmdd);
        await redisClient.hsetnx(dayKey, "rtp_target", 0.90);
        await redisClient.spEnter(dayKey, stakeTotal);
        // optional snapshot for observability (no clamping in DT)
        try {
            plan = await spPlan(GAME_CODE, stakeTotal, await loadGameCfg(), yymmdd);
        } catch { /* non-fatal */ }
    }

    // Resolve bets (stake-included returns)
    const resolved = input.bets.map((b, i) => {
        let mult = 0;
        if (b.type === "TIE") {
            mult = (winner === "TIE") ? cfg.tie_return : 0;
        } else {
            if (winner === b.type) {
                mult = 2.0; // even money (stake-included)
            } else if (winner === "TIE") {
                mult = (cfg.tie_on_main === "lose_half") ? 0.5 : (cfg.tie_on_main === "push" ? 1.0 : 0.0);
            } else {
                mult = 0.0;
            }
        }
        const payout = +(b.stake * mult).toFixed(2);
        return { index: i, type: b.type, stake: b.stake, return_multiplier: mult, payout };
    });

    const payoutTotal = +resolved.reduce((s, r) => s + r.payout, 0).toFixed(2);

    // RTP settle (REAL) — pair with the single enter above
    if (mode === "real" && dayKey) {
        await redisClient.spSettle(dayKey, stakeTotal, payoutTotal);
    }

    // Credit once
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        await setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
    } else if (payoutTotal > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: `${txnId}-W`,
            TransactionType: "WinAmount",
            Amount: payoutTotal,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "DragonTiger",
                GameName: "DragonTiger",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeed: serverSeed,
                ServerSeedHash: serverSeedHash,
                ClientSeed: clientSeed,
                Winner: winner,
                Cards: { Dragon: fmt(dragon), Tiger: fmt(tiger) },
                Config: cfg
            }
        });
    }

    const response = {
        game: "DragonTiger",
        mode,
        txn_id: txnId,
        currency: sess.currency,
        stake_total: stakeTotal,
        cards: { dragon: fmt(dragon), tiger: fmt(tiger) },
        outcome: { winner },
        bets: resolved,
        slip: {
            payout_total: payoutTotal,
            profit_total: +(payoutTotal - stakeTotal).toFixed(2)
        },
        fairness: {
            method: "Draw = first two cards of Fisher–Yates shoe using HMAC-SHA256(server_seed, `${client_seed}:i:shoe`); Ace is low",
            server_seed_hash: serverSeedHash,
            server_seed: serverSeed,
            client_seed: clientSeed
        },
        plan // optional snapshot for UI/ops
    };

    if (idem) await setIdem(mode, sess.sid, idem, response);
    return response;
}
