"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.doDeal = doDeal;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP (accounting) ====
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const redis_2 = require("../../../config/redis");
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const governor_1 = require("../../rtp/governor");
/** ---- Config ---- */
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "dragontiger";
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];
// Dragon Tiger ranking: Ace is LOW (A=1) … K=13
function rankValueDT(r) {
    if (r === 0)
        return 1;
    if (r >= 1 && r <= 9)
        return r + 1;
    return 10 + (r - 9);
}
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, i, tag) => u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;
function buildShoe(decks) {
    const one = [];
    for (let s = 0; s < 4; s++)
        for (let r = 0; r < 13; r++)
            one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => (Object.assign({}, c))));
}
function shuffle(arr, server, client) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k];
        a[k] = a[j];
        a[j] = t;
    }
    return a;
}
const fmt = (c) => ({ rank: RANKS[c.r], suit: SUITS[c.s], val: rankValueDT(c.r) });
/** ---- Demo wallet ---- */
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const k = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(k);
        if (v)
            return Number(v);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(k, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
    });
}
/** ---- Idempotency (mode-scoped) ---- */
const idemKey = (mode, sid, key) => `idem:${mode}:dragontiger:deal:${sid}:${key}`;
function getIdem(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(idemKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(idemKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
/** ---- Main service ---- */
function doDeal(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, idem);
            if (hit)
                return hit;
        }
        // Merge config & validate
        const cfg = {
            decks: (_b = (_a = input.cfg) === null || _a === void 0 ? void 0 : _a.decks) !== null && _b !== void 0 ? _b : 8,
            tie_return: (_d = (_c = input.cfg) === null || _c === void 0 ? void 0 : _c.tie_return) !== null && _d !== void 0 ? _d : 12.0,
            tie_on_main: (_f = (_e = input.cfg) === null || _e === void 0 ? void 0 : _e.tie_on_main) !== null && _f !== void 0 ? _f : "lose_half",
            min_stake: (_h = (_g = input.cfg) === null || _g === void 0 ? void 0 : _g.min_stake) !== null && _h !== void 0 ? _h : 0.1,
            max_stake: (_k = (_j = input.cfg) === null || _j === void 0 ? void 0 : _j.max_stake) !== null && _k !== void 0 ? _k : 10000,
            max_bets: (_m = (_l = input.cfg) === null || _l === void 0 ? void 0 : _l.max_bets) !== null && _m !== void 0 ? _m : 10
        };
        if (!Array.isArray(input.bets) || input.bets.length === 0)
            throw errors_1.AppError.badRequest("No bets");
        if (input.bets.length > cfg.max_bets)
            throw errors_1.AppError.badRequest("Too many bets");
        for (const b of input.bets) {
            if (!(b.stake > 0))
                throw errors_1.AppError.badRequest("Invalid stake");
            if (b.stake < cfg.min_stake)
                throw errors_1.AppError.badRequest(`Min stake is ${cfg.min_stake}`);
            if (b.stake > cfg.max_stake)
                throw errors_1.AppError.badRequest(`Max stake is ${cfg.max_stake}`);
        }
        const clientSeed = (_q = (_p = (_o = input.client_seed) !== null && _o !== void 0 ? _o : sess.clientExternalKey) !== null && _p !== void 0 ? _p : sess.userName) !== null && _q !== void 0 ? _q : "client";
        const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
        const serverSeedHash = sha256(serverSeed);
        // Shuffle shoe & deal two cards
        const shoe = shuffle(buildShoe(cfg.decks), serverSeed, clientSeed);
        const dragon = shoe[0];
        const tiger = shoe[1];
        const dv = rankValueDT(dragon.r);
        const tv = rankValueDT(tiger.r);
        let winner;
        if (dv > tv)
            winner = "DRAGON";
        else if (tv > dv)
            winner = "TIGER";
        else
            winner = "TIE";
        // Debit all stakes once
        const stakeTotal = +input.bets.reduce((s, b) => s + b.stake, 0).toFixed(2);
        const txnId = (0, crypto_1.randomUUID)();
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < stakeTotal)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - stakeTotal).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_r = sess.opSessionId) !== null && _r !== void 0 ? _r : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: stakeTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "DragonTiger",
                    GameName: "DragonTiger",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeedHash: serverSeedHash,
                    ClientSeed: clientSeed,
                    Config: cfg
                }
            });
        }
        // RTP enter (REAL) — accounting only
        let dayKey;
        let yymmdd = (0, date_1.toYYMMDD)();
        let plan;
        if (mode === "real") {
            dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_2.redis.hsetnx(dayKey, "rtp_target", 0.90);
            yield redis_2.redis.spEnter(dayKey, stakeTotal);
            // optional snapshot for observability (no clamping in DT)
            try {
                plan = yield (0, governor_1.spPlan)(GAME_CODE, stakeTotal, yield loadGameCfg(), yymmdd);
            }
            catch ( /* non-fatal */_t) { /* non-fatal */ }
        }
        // Resolve bets (stake-included returns)
        const resolved = input.bets.map((b, i) => {
            let mult = 0;
            if (b.type === "TIE") {
                mult = (winner === "TIE") ? cfg.tie_return : 0;
            }
            else {
                if (winner === b.type) {
                    mult = 2.0; // even money (stake-included)
                }
                else if (winner === "TIE") {
                    mult = (cfg.tie_on_main === "lose_half") ? 0.5 : (cfg.tie_on_main === "push" ? 1.0 : 0.0);
                }
                else {
                    mult = 0.0;
                }
            }
            const payout = +(b.stake * mult).toFixed(2);
            return { index: i, type: b.type, stake: b.stake, return_multiplier: mult, payout };
        });
        const payoutTotal = +resolved.reduce((s, r) => s + r.payout, 0).toFixed(2);
        // RTP settle (REAL) — pair with the single enter above
        if (mode === "real" && dayKey) {
            yield redis_2.redis.spSettle(dayKey, stakeTotal, payoutTotal);
        }
        // Credit once
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            yield setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
        }
        else if (payoutTotal > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_s = sess.opSessionId) !== null && _s !== void 0 ? _s : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${txnId}-W`,
                TransactionType: "WinAmount",
                Amount: payoutTotal,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "DragonTiger",
                    GameName: "DragonTiger",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: serverSeed,
                    ServerSeedHash: serverSeedHash,
                    ClientSeed: clientSeed,
                    Winner: winner,
                    Cards: { Dragon: fmt(dragon), Tiger: fmt(tiger) },
                    Config: cfg
                }
            });
        }
        const response = {
            game: "DragonTiger",
            mode,
            txn_id: txnId,
            currency: sess.currency,
            stake_total: stakeTotal,
            cards: { dragon: fmt(dragon), tiger: fmt(tiger) },
            outcome: { winner },
            bets: resolved,
            slip: {
                payout_total: payoutTotal,
                profit_total: +(payoutTotal - stakeTotal).toFixed(2)
            },
            fairness: {
                method: "Draw = first two cards of Fisher–Yates shoe using HMAC-SHA256(server_seed, `${client_seed}:i:shoe`); Ace is low",
                server_seed_hash: serverSeedHash,
                server_seed: serverSeed,
                client_seed: clientSeed
            },
            plan // optional snapshot for UI/ops
        };
        if (idem)
            yield setIdem(mode, sess.sid, idem, response);
        return response;
    });
}
