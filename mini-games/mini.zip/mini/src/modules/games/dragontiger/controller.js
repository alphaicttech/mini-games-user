"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deal = exports.dealValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
/** ---- Input validation ---- */
const BetType = zod_1.z.enum(["DRAGON", "TIGER", "TIE"]);
const DealBody = zod_1.z.object({
    client_seed: zod_1.z.string().min(1).optional(),
    cfg: zod_1.z.object({
        decks: zod_1.z.number().int().min(1).max(8).default(8),
        // stake-included return for Tie: 12.0 = 11:1, 9.0 = 8:1
        tie_return: zod_1.z.number().min(2).max(20).default(12.0),
        // what happens to DRAGON/TIGER bets when the result is TIE
        // "lose_half" (50% refund), "lose_all", or "push" (full refund)
        tie_on_main: zod_1.z.enum(["lose_half", "lose_all", "push"]).default("lose_half"),
        min_stake: zod_1.z.number().positive().default(0.1),
        max_stake: zod_1.z.number().positive().default(10000),
        max_bets: zod_1.z.number().int().min(1).max(50).default(10),
    }).default({}),
    bets: zod_1.z.array(zod_1.z.object({
        type: BetType,
        stake: zod_1.z.number().positive(),
    })).min(1)
});
exports.dealValidate = (0, validate_1.validateBody)(DealBody);
exports.deal = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body;
    const result = yield (0, service_1.doDeal)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, result));
}));
