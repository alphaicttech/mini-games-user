"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.state = exports.cashout = exports.cashoutValidate = exports.inflate = exports.inflateValidate = exports.start = exports.startValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const StartBody = zod_1.z.object({
    amount: zod_1.z.number().positive(),
    speed: zod_1.z.enum(["slow", "normal", "fast", "turbo"]).default("normal"),
    client_seed: zod_1.z.string().min(1).optional()
});
exports.startValidate = (0, validate_1.validateBody)(StartBody);
exports.start = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { amount, speed, client_seed } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.startBalloon)(sess, { amount, speed, clientSeed: client_seed }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
const InflateBody = zod_1.z.object({ round_id: zod_1.z.string().uuid() });
exports.inflateValidate = (0, validate_1.validateBody)(InflateBody);
exports.inflate = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { round_id } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.pumpBalloon)(sess, { roundId: round_id }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
const CashoutBody = zod_1.z.object({ round_id: zod_1.z.string().uuid() });
exports.cashoutValidate = (0, validate_1.validateBody)(CashoutBody);
exports.cashout = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { round_id } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const data = yield (0, service_1.cashoutBalloon)(sess, { roundId: round_id }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, data));
}));
exports.state = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const rid = String(req.query.round_id || "");
    if (!rid)
        return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "round_id required" });
    const pub = yield (0, service_1.getState)(sess, rid);
    if (!pub)
        return res.status(404).json({ ok: false, code: "NOT_FOUND", message: "ROUND_NOT_FOUND" });
    res.json({ ok: true, state: pub });
}));
