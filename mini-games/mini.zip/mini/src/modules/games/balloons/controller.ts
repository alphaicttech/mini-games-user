// /var/www/typesafe/alpha-mini/src/modules/games/balloons/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { startBalloon, pumpBalloon, cashoutBalloon, getState } from "./service";

const StartBody = z.object({
    amount: z.number().positive(),
    speed: z.enum(["slow", "normal", "fast", "turbo"]).default("normal"),
    client_seed: z.string().min(1).optional()
});
export const startValidate = validateBody(StartBody);

export const start = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { amount, speed, client_seed } = req.body as z.infer<typeof StartBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const data = await startBalloon(sess, { amount, speed, clientSeed: client_seed }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});

const InflateBody = z.object({ round_id: z.string().uuid() });
export const inflateValidate = validateBody(InflateBody);

export const inflate = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { round_id } = req.body as z.infer<typeof InflateBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const data = await pumpBalloon(sess, { roundId: round_id }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});

const CashoutBody = z.object({ round_id: z.string().uuid() });
export const cashoutValidate = validateBody(CashoutBody);

export const cashout = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { round_id } = req.body as z.infer<typeof CashoutBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const data = await cashoutBalloon(sess, { roundId: round_id }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...data });
});

export const state = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const rid = String(req.query.round_id || "");
    if (!rid) return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "round_id required" });

    const pub = await getState(sess, rid);
    if (!pub) return res.status(404).json({ ok: false, code: "NOT_FOUND", message: "ROUND_NOT_FOUND" });
    res.json({ ok: true, state: pub });
});
