import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

// -------- config ----------
const LIMITS = { min: 0.1, max: 10000 };
const MAX_MULT = 10000.0;
const ROUND_TTL = 2 * 60 * 60;
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "balloons";

type Speed = "slow" | "normal" | "fast" | "turbo";
const SPEEDS: Record<Speed, { stepInc: [number, number] }> = {
    slow: { stepInc: [0.01, 0.05] },  // per pump multiplicative increment in [1+..]
    normal: { stepInc: [0.02, 0.10] },
    fast: { stepInc: [0.03, 0.15] },
    turbo: { stepInc: [0.05, 0.25] },
};

// -------- helpers ----------
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (srv: string, cli: string, i: number, tag: string) => u32(hmacHex(srv, `${cli}:${i}:${tag}`).slice(0, 8)) / 0xffffffff;
const rRange = (srv: string, cli: string, i: number, tag: string, [a, b]: [number, number]) => a + (b - a) * r01(srv, cli, i, tag);

const roundKey = (sid: string, rid: string) => `round:balloon:${sid}:${rid}`;
const lockKey = (sid: string, rid: string) => `lock:balloon:${sid}:${rid}`;
const idemKey = (mode: "real" | "demo", sid: string, k: string) => `idem:${mode}:balloon:${sid}:${k}`;

// demo ledger
async function getDemoBalance(sess: ProviderSession) {
    const k = `demo:bal:${sess.sid}`;
    const v = await redis.get(k);
    if (v) return Number(v);
    const start = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(k, String(start), 2 * 60 * 60);
    return start;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
    await redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
}

// idem (mode-scoped)
async function getIdem(mode: "real" | "demo", sid: string, k?: string) {
    if (!k) return null;
    const v = await redis.get(idemKey(mode, sid, k));
    return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, k: string, payload: any) {
    await redis.set(idemKey(mode, sid, k), JSON.stringify(payload), IDEM_TTL);
}

// lock
async function withLock<T>(sid: string, rid: string, fn: () => Promise<T>) {
    const k = lockKey(sid, rid);
    const ok = await (rawRedis as any).set(k, "1", "EX", 3, "NX");
    if (ok !== "OK") throw AppError.badRequest("ROUND_BUSY");
    try { return await fn(); } finally { await rawRedis.del(k); }
}

// cfg / RTP
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

// state
type RoundState = {
    sid: string;
    roundId: string;
    mode: "demo" | "real";
    currency: string;
    stake: number;
    speed: Speed;
    step: number;           // pumps done
    multiplier: number;     // starts 1.00
    popAt: number;          // predetermined crash multiplier (>1.0 .. 10000]
    serverSeed: string;
    serverSeedHash: string;
    clientSeed: string;
    status: "active" | "bust" | "cashed";
    createdAt: number;

    // RTP (REAL)
    rtpDayKey?: string;
    rtpCap?: number;        // absolute cap for this round
    plan?: { target: number; hardCap: number; softCap: number };
};

async function saveRound(st: RoundState) {
    await redis.set(roundKey(st.sid, st.roundId), JSON.stringify(st), ROUND_TTL);
}
async function loadRound(sid: string, rid: string): Promise<RoundState | null> {
    const v = await redis.get(roundKey(sid, rid));
    return v ? JSON.parse(v) as RoundState : null;
}

// ---- START ----
type StartInput = { amount: number; speed: Speed; clientSeed?: string };

export async function startBalloon(sess: ProviderSession, input: StartInput, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, idem); if (hit) return hit; }
    if (input.amount < LIMITS.min) throw AppError.badRequest(`Min bet is ${LIMITS.min}`);
    if (input.amount > LIMITS.max) throw AppError.badRequest(`Max bet is ${LIMITS.max}`);

    // Debit stake
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < input.amount) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - input.amount).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = {
            baseUrl: operator.baseUrl, secret: operator.secret,
            session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
        };
        const txnId = randomUUID();
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: input.amount,
            CurrencyCode: sess.currency,
            TransactionInfo: { Source: "Balloon", GameName: "Balloon", RoundId: txnId, GameNumber: Date.now().toString() }
        });
    }

    // Seeds & crash point
    const roundId = randomUUID();
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);
    const clientSeed = input.clientSeed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    // Deterministic heavy-tail crash multiplier, capped at 10k
    const u = Math.max(1e-12, r01(serverSeed, clientSeed, 1, "pop")); // (0,1)
    const raw = 1.0 / (1.0 - u);                 // heavy tail
    const popAt = Math.min(MAX_MULT, Math.max(1.0, raw)); // >= 1.0

    // RTP: enter + plan (REAL only)
    let plan = { hardCap: 0, softCap: 0, target: 0 };
    let rtpDayKey: string | undefined;
    if (mode === "real") {
        const cfg = await loadGameCfg();
        const yymmdd = toYYMMDD();
        rtpDayKey = rk.day(GAME_CODE, yymmdd);
        await redis.hsetnx(rtpDayKey, "rtp_target", 0.90);
        await redis.spEnter(rtpDayKey, input.amount);
        plan = await spPlan(GAME_CODE, input.amount, cfg, yymmdd);
    } else {
        const cfg = await loadGameCfg();
        plan = demoPlan(input.amount, cfg);
    }

    const st: RoundState = {
        sid: sess.sid, roundId,
        mode, currency: sess.currency, stake: input.amount,
        speed: input.speed, step: 0, multiplier: 1.0,
        popAt,
        serverSeed, serverSeedHash, clientSeed,
        status: "active",
        createdAt: Date.now(),
        rtpDayKey,
        rtpCap: undefined,
        plan
    };

    // Precompute an absolute per-round cap for display (REAL): min(hardCap, per caps)
    if (mode === "real") {
        const cfg = await loadGameCfg();
        st.rtpCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
    }

    await saveRound(st);

    const resp = {
        game: "Balloon",
        mode,
        round_id: roundId,
        stake: input.amount,
        currency: sess.currency,
        speed: input.speed,
        multiplier: 1.00,
        color: "yellow",
        server_seed_hash: serverSeedHash,
        plan
    };
    if (idem) await setIdem(mode, sess.sid, idem, resp);
    return resp;
}

// ---- INFLATE ----
type InflateInput = { roundId: string };

export async function pumpBalloon(sess: ProviderSession, input: InflateInput, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, idem); if (hit) return hit; }

    return await withLock(sess.sid, input.roundId, async () => {
        const st = await loadRound(sess.sid, input.roundId);
        if (!st) throw AppError.notFound("ROUND_NOT_FOUND");
        if (st.status !== "active") {
            if (st.status === "bust") throw AppError.badRequest("ROUND_BUST");
            if (st.status === "cashed") throw AppError.badRequest("ROUND_FINISHED");
        }

        // Next step increment (deterministic)
        const [a, b] = SPEEDS[st.speed].stepInc;
        const inc = rRange(st.serverSeed, st.clientSeed, st.step + 1, "step", [a, b]);
        const factor = 1.0 + inc;

        // Apply
        const next = +(st.multiplier * factor).toFixed(4);
        st.step += 1;

        // POP check
        if (next >= st.popAt) {
            // REAL: settle with win=0
            if (mode === "real" && st.rtpDayKey) {
                await redis.spSettle(st.rtpDayKey, st.stake, 0);
            }

            st.status = "bust";
            await saveRound(st);
            const resp = {
                game: "Balloon",
                mode,
                round_id: st.roundId,
                event: "pop",
                at_multiplier: +(+st.popAt.toFixed(2)),
                result: { outcome: "bust", payout: 0 },
                fairness: {
                    method: "Crash at M = min(10000, 1/(1-u)) from HMAC(server_seed, client_seed:1:'pop')",
                    server_seed_hash: st.serverSeedHash,
                    server_seed: st.serverSeed,
                    client_seed: st.clientSeed
                }
            };
            if (idem) await setIdem(mode, sess.sid, idem, resp);
            return resp;
        }

        // Still alive → update multiplier
        st.multiplier = next;
        await saveRound(st);

        // Potential payout (display-only) — clamp by per caps and rtpCap in REAL
        const cfg = await loadGameCfg();
        const rawPotential = +(st.stake * Math.max(1, +st.multiplier.toFixed(2))).toFixed(2);
        const potential = Math.min(
            rawPotential,
            cfg.per_bet_cap,
            cfg.per_user_daily_cap,
            ...(mode === "real" && st.rtpCap != null ? [st.rtpCap] : [])
        );

        const ratio = st.multiplier / st.popAt; // danger level
        let color: "yellow" | "orange" | "red" = "yellow";
        if (ratio >= 0.8) color = "red"; else if (ratio >= 0.5) color = "orange";

        const resp = {
            game: "Balloon",
            mode,
            round_id: st.roundId,
            event: "inflate",
            step: st.step,
            multiplier: +(+st.multiplier.toFixed(2)),
            potential_payout: potential,
            color,
            can_cashout: true
        };
        if (idem) await setIdem(mode, sess.sid, idem, resp);
        return resp;
    });
}

// ---- CASHOUT ----
type CashoutInput = { roundId: string };

export async function cashoutBalloon(sess: ProviderSession, input: CashoutInput, idem?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, idem); if (hit) return hit; }

    return await withLock(sess.sid, input.roundId, async () => {
        const st = await loadRound(sess.sid, input.roundId);
        if (!st) throw AppError.notFound("ROUND_NOT_FOUND");
        if (st.status !== "active") {
            if (st.status === "bust") throw AppError.badRequest("ROUND_BUST");
            if (st.status === "cashed") throw AppError.badRequest("ROUND_FINISHED");
        }

        // finalize payout
        const finalMult = +(+st.multiplier.toFixed(2));
        let payout = +(st.stake * Math.max(1, finalMult)).toFixed(2);

        // Clamp payout to caps (and live hard cap in REAL)
        const cfg = await loadGameCfg();
        if (mode === "real") {
            const yymmdd = toYYMMDD();
            // refresh plan snapshot (PI may have changed due to concurrency)
            const livePlan = await spPlan(GAME_CODE, st.stake, cfg, yymmdd);
            const slipCap = Math.min(livePlan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            payout = Math.min(payout, slipCap);
            st.plan = livePlan;
        }
        payout = Math.min(payout, cfg.per_bet_cap, cfg.per_user_daily_cap);

        // credit / settle
        if (mode === "demo") {
            const bal = await getDemoBalance(sess);
            await setDemoBalance(sess, +(bal + payout).toFixed(2));
        } else {
            if (!st.rtpDayKey) {
                const yymmdd = toYYMMDD();
                st.rtpDayKey = rk.day(GAME_CODE, yymmdd); // fallback (should already exist)
            }
            await redis.spSettle(st.rtpDayKey!, st.stake, payout);

            const operator = await findByPortalName(sess.portalName);
            const opSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
            const opCtx: any = {
                baseUrl: operator.baseUrl, secret: operator.secret,
                session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            await withdraw(opCtx, {
                TransactionId: `${st.roundId}-W`,
                TransactionType: "WinAmount",
                Amount: payout,
                CurrencyCode: st.currency,
                TransactionInfo: {
                    Source: "Balloon",
                    GameName: "Balloon",
                    RoundId: st.roundId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: st.serverSeed,
                    ServerSeedHash: st.serverSeedHash,
                    ClientSeed: st.clientSeed,
                    FinalMultiplier: finalMult
                }
            });
        }

        st.status = "cashed";
        await saveRound(st);

        const resp = {
            game: "Balloon",
            mode,
            round_id: st.roundId,
            result: { outcome: "cashed", final_multiplier: finalMult, payout, currency: st.currency },
            fairness: {
                method: "Crash at M = min(10000, 1/(1-u)) from HMAC(server_seed, client_seed:1:'pop')",
                server_seed_hash: st.serverSeedHash,
                server_seed: st.serverSeed,
                client_seed: st.clientSeed
            },
            plan: st.plan ?? undefined
        };
        if (idem) await setIdem(mode, sess.sid, idem, resp);
        return resp;
    });
}

// ---- STATE (no spoilers) ----
export async function getState(sess: ProviderSession, roundId: string) {
    const st = await loadRound(sess.sid, roundId);
    if (!st) return null;
    const pub: any = {
        round_id: st.roundId,
        mode: st.mode,
        status: st.status,
        step: st.step,
        multiplier: +(+st.multiplier.toFixed(2)),
        color: st.multiplier / st.popAt >= 0.8 ? "red" : (st.multiplier / st.popAt >= 0.5 ? "orange" : "yellow")
    };
    if (st.status !== "active") {
        pub.fairness = {
            server_seed_hash: st.serverSeedHash,
            server_seed: st.serverSeed,
            client_seed: st.clientSeed,
            popped_at: +(+st.popAt.toFixed(2))
        };
    }
    return pub;
}
