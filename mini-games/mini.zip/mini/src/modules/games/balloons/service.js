"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startBalloon = startBalloon;
exports.pumpBalloon = pumpBalloon;
exports.cashoutBalloon = cashoutBalloon;
exports.getState = getState;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
// -------- config ----------
const LIMITS = { min: 0.1, max: 10000 };
const MAX_MULT = 10000.0;
const ROUND_TTL = 2 * 60 * 60;
const IDEM_TTL = 24 * 60 * 60;
const GAME_CODE = "balloons";
const SPEEDS = {
    slow: { stepInc: [0.01, 0.05] }, // per pump multiplicative increment in [1+..]
    normal: { stepInc: [0.02, 0.10] },
    fast: { stepInc: [0.03, 0.15] },
    turbo: { stepInc: [0.05, 0.25] },
};
// -------- helpers ----------
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (srv, cli, i, tag) => u32(hmacHex(srv, `${cli}:${i}:${tag}`).slice(0, 8)) / 0xffffffff;
const rRange = (srv, cli, i, tag, [a, b]) => a + (b - a) * r01(srv, cli, i, tag);
const roundKey = (sid, rid) => `round:balloon:${sid}:${rid}`;
const lockKey = (sid, rid) => `lock:balloon:${sid}:${rid}`;
const idemKey = (mode, sid, k) => `idem:${mode}:balloon:${sid}:${k}`;
// demo ledger
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const k = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(k);
        if (v)
            return Number(v);
        const start = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(k, String(start), 2 * 60 * 60);
        return start;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60);
    });
}
// idem (mode-scoped)
function getIdem(mode, sid, k) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!k)
            return null;
        const v = yield redis_1.redis.get(idemKey(mode, sid, k));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, k, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(idemKey(mode, sid, k), JSON.stringify(payload), IDEM_TTL);
    });
}
// lock
function withLock(sid, rid, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const k = lockKey(sid, rid);
        const ok = yield redis_1.rawRedis.set(k, "1", "EX", 3, "NX");
        if (ok !== "OK")
            throw errors_1.AppError.badRequest("ROUND_BUSY");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(k);
        }
    });
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function demoPlan(totalStake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
function saveRound(st) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(roundKey(st.sid, st.roundId), JSON.stringify(st), ROUND_TTL);
    });
}
function loadRound(sid, rid) {
    return __awaiter(this, void 0, void 0, function* () {
        const v = yield redis_1.redis.get(roundKey(sid, rid));
        return v ? JSON.parse(v) : null;
    });
}
function startBalloon(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, idem);
            if (hit)
                return hit;
        }
        if (input.amount < LIMITS.min)
            throw errors_1.AppError.badRequest(`Min bet is ${LIMITS.min}`);
        if (input.amount > LIMITS.max)
            throw errors_1.AppError.badRequest(`Max bet is ${LIMITS.max}`);
        // Debit stake
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < input.amount)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - input.amount).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opSessionId = (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId;
            const opCtx = {
                baseUrl: operator.baseUrl, secret: operator.secret,
                session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
            };
            const txnId = (0, crypto_1.randomUUID)();
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: input.amount,
                CurrencyCode: sess.currency,
                TransactionInfo: { Source: "Balloon", GameName: "Balloon", RoundId: txnId, GameNumber: Date.now().toString() }
            });
        }
        // Seeds & crash point
        const roundId = (0, crypto_1.randomUUID)();
        const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
        const serverSeedHash = sha256(serverSeed);
        const clientSeed = (_d = (_c = (_b = input.clientSeed) !== null && _b !== void 0 ? _b : sess.clientExternalKey) !== null && _c !== void 0 ? _c : sess.userName) !== null && _d !== void 0 ? _d : "client";
        // Deterministic heavy-tail crash multiplier, capped at 10k
        const u = Math.max(1e-12, r01(serverSeed, clientSeed, 1, "pop")); // (0,1)
        const raw = 1.0 / (1.0 - u); // heavy tail
        const popAt = Math.min(MAX_MULT, Math.max(1.0, raw)); // >= 1.0
        // RTP: enter + plan (REAL only)
        let plan = { hardCap: 0, softCap: 0, target: 0 };
        let rtpDayKey;
        if (mode === "real") {
            const cfg = yield loadGameCfg();
            const yymmdd = (0, date_1.toYYMMDD)();
            rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_1.redis.hsetnx(rtpDayKey, "rtp_target", 0.90);
            yield redis_1.redis.spEnter(rtpDayKey, input.amount);
            plan = yield (0, governor_1.spPlan)(GAME_CODE, input.amount, cfg, yymmdd);
        }
        else {
            const cfg = yield loadGameCfg();
            plan = demoPlan(input.amount, cfg);
        }
        const st = {
            sid: sess.sid, roundId,
            mode, currency: sess.currency, stake: input.amount,
            speed: input.speed, step: 0, multiplier: 1.0,
            popAt,
            serverSeed, serverSeedHash, clientSeed,
            status: "active",
            createdAt: Date.now(),
            rtpDayKey,
            rtpCap: undefined,
            plan
        };
        // Precompute an absolute per-round cap for display (REAL): min(hardCap, per caps)
        if (mode === "real") {
            const cfg = yield loadGameCfg();
            st.rtpCap = Math.min(plan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
        }
        yield saveRound(st);
        const resp = {
            game: "Balloon",
            mode,
            round_id: roundId,
            stake: input.amount,
            currency: sess.currency,
            speed: input.speed,
            multiplier: 1.00,
            color: "yellow",
            server_seed_hash: serverSeedHash,
            plan
        };
        if (idem)
            yield setIdem(mode, sess.sid, idem, resp);
        return resp;
    });
}
function pumpBalloon(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, idem);
            if (hit)
                return hit;
        }
        return yield withLock(sess.sid, input.roundId, () => __awaiter(this, void 0, void 0, function* () {
            const st = yield loadRound(sess.sid, input.roundId);
            if (!st)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (st.status !== "active") {
                if (st.status === "bust")
                    throw errors_1.AppError.badRequest("ROUND_BUST");
                if (st.status === "cashed")
                    throw errors_1.AppError.badRequest("ROUND_FINISHED");
            }
            // Next step increment (deterministic)
            const [a, b] = SPEEDS[st.speed].stepInc;
            const inc = rRange(st.serverSeed, st.clientSeed, st.step + 1, "step", [a, b]);
            const factor = 1.0 + inc;
            // Apply
            const next = +(st.multiplier * factor).toFixed(4);
            st.step += 1;
            // POP check
            if (next >= st.popAt) {
                // REAL: settle with win=0
                if (mode === "real" && st.rtpDayKey) {
                    yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, 0);
                }
                st.status = "bust";
                yield saveRound(st);
                const resp = {
                    game: "Balloon",
                    mode,
                    round_id: st.roundId,
                    event: "pop",
                    at_multiplier: +(+st.popAt.toFixed(2)),
                    result: { outcome: "bust", payout: 0 },
                    fairness: {
                        method: "Crash at M = min(10000, 1/(1-u)) from HMAC(server_seed, client_seed:1:'pop')",
                        server_seed_hash: st.serverSeedHash,
                        server_seed: st.serverSeed,
                        client_seed: st.clientSeed
                    }
                };
                if (idem)
                    yield setIdem(mode, sess.sid, idem, resp);
                return resp;
            }
            // Still alive → update multiplier
            st.multiplier = next;
            yield saveRound(st);
            // Potential payout (display-only) — clamp by per caps and rtpCap in REAL
            const cfg = yield loadGameCfg();
            const rawPotential = +(st.stake * Math.max(1, +st.multiplier.toFixed(2))).toFixed(2);
            const potential = Math.min(rawPotential, cfg.per_bet_cap, cfg.per_user_daily_cap, ...(mode === "real" && st.rtpCap != null ? [st.rtpCap] : []));
            const ratio = st.multiplier / st.popAt; // danger level
            let color = "yellow";
            if (ratio >= 0.8)
                color = "red";
            else if (ratio >= 0.5)
                color = "orange";
            const resp = {
                game: "Balloon",
                mode,
                round_id: st.roundId,
                event: "inflate",
                step: st.step,
                multiplier: +(+st.multiplier.toFixed(2)),
                potential_payout: potential,
                color,
                can_cashout: true
            };
            if (idem)
                yield setIdem(mode, sess.sid, idem, resp);
            return resp;
        }));
    });
}
function cashoutBalloon(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, idem);
            if (hit)
                return hit;
        }
        return yield withLock(sess.sid, input.roundId, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const st = yield loadRound(sess.sid, input.roundId);
            if (!st)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (st.status !== "active") {
                if (st.status === "bust")
                    throw errors_1.AppError.badRequest("ROUND_BUST");
                if (st.status === "cashed")
                    throw errors_1.AppError.badRequest("ROUND_FINISHED");
            }
            // finalize payout
            const finalMult = +(+st.multiplier.toFixed(2));
            let payout = +(st.stake * Math.max(1, finalMult)).toFixed(2);
            // Clamp payout to caps (and live hard cap in REAL)
            const cfg = yield loadGameCfg();
            if (mode === "real") {
                const yymmdd = (0, date_1.toYYMMDD)();
                // refresh plan snapshot (PI may have changed due to concurrency)
                const livePlan = yield (0, governor_1.spPlan)(GAME_CODE, st.stake, cfg, yymmdd);
                const slipCap = Math.min(livePlan.hardCap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
                payout = Math.min(payout, slipCap);
                st.plan = livePlan;
            }
            payout = Math.min(payout, cfg.per_bet_cap, cfg.per_user_daily_cap);
            // credit / settle
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                yield setDemoBalance(sess, +(bal + payout).toFixed(2));
            }
            else {
                if (!st.rtpDayKey) {
                    const yymmdd = (0, date_1.toYYMMDD)();
                    st.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd); // fallback (should already exist)
                }
                yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, payout);
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opSessionId = (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId;
                const opCtx = {
                    baseUrl: operator.baseUrl, secret: operator.secret,
                    session: { id: opSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey }
                };
                yield (0, client_1.withdraw)(opCtx, {
                    TransactionId: `${st.roundId}-W`,
                    TransactionType: "WinAmount",
                    Amount: payout,
                    CurrencyCode: st.currency,
                    TransactionInfo: {
                        Source: "Balloon",
                        GameName: "Balloon",
                        RoundId: st.roundId,
                        GameNumber: Date.now().toString(),
                        ServerSeed: st.serverSeed,
                        ServerSeedHash: st.serverSeedHash,
                        ClientSeed: st.clientSeed,
                        FinalMultiplier: finalMult
                    }
                });
            }
            st.status = "cashed";
            yield saveRound(st);
            const resp = {
                game: "Balloon",
                mode,
                round_id: st.roundId,
                result: { outcome: "cashed", final_multiplier: finalMult, payout, currency: st.currency },
                fairness: {
                    method: "Crash at M = min(10000, 1/(1-u)) from HMAC(server_seed, client_seed:1:'pop')",
                    server_seed_hash: st.serverSeedHash,
                    server_seed: st.serverSeed,
                    client_seed: st.clientSeed
                },
                plan: (_b = st.plan) !== null && _b !== void 0 ? _b : undefined
            };
            if (idem)
                yield setIdem(mode, sess.sid, idem, resp);
            return resp;
        }));
    });
}
// ---- STATE (no spoilers) ----
function getState(sess, roundId) {
    return __awaiter(this, void 0, void 0, function* () {
        const st = yield loadRound(sess.sid, roundId);
        if (!st)
            return null;
        const pub = {
            round_id: st.roundId,
            mode: st.mode,
            status: st.status,
            step: st.step,
            multiplier: +(+st.multiplier.toFixed(2)),
            color: st.multiplier / st.popAt >= 0.8 ? "red" : (st.multiplier / st.popAt >= 0.5 ? "orange" : "yellow")
        };
        if (st.status !== "active") {
            pub.fairness = {
                server_seed_hash: st.serverSeedHash,
                server_seed: st.serverSeed,
                client_seed: st.clientSeed,
                popped_at: +(+st.popAt.toFixed(2))
            };
        }
        return pub;
    });
}
