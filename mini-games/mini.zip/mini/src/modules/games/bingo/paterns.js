"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.r01 = exports.PATTERN_ODDS = void 0;
exports.generateCard75 = generateCard75;
exports.validateGrid75 = validateGrid75;
exports.checkPattern = checkPattern;
// /var/www/typesafe/alpha-mini/src/modules/games/bingo/paterns.ts
const crypto_1 = __importDefault(require("crypto"));
const errors_1 = require("../../../errors");
exports.PATTERN_ODDS = {
    ONE_LINE: 3.0,
    TWO_LINES: 8.0,
    FOUR_CORNERS: 5.0,
    OUTSIDE_EDGE: 20.0,
    BLACKOUT: 60.0,
    X_LINES: 12.0,
    PLUS: 8.0,
    T_SHAPE: 10.0,
    SMALL_DIAMOND: 6.0,
    POSTAGE_STAMP: 4.0,
};
const ROWS = 5, COLS = 5;
const CENTER_R = 2, CENTER_C = 2;
const COL_RANGES = [[1, 15], [16, 30], [31, 45], [46, 60], [61, 75]];
/** ====== Provable fairness helpers ====== */
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, i, tag) => u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;
exports.r01 = r01;
/** ====== Grid creation & validation ====== */
function randInt(min, max, rnd = Math.random) {
    return Math.floor(rnd() * (max - min + 1)) + min;
}
function sampleWithoutReplacement(min, max, count, rnd = Math.random) {
    const arr = [];
    const used = new Set();
    while (arr.length < count) {
        const n = randInt(min, max, rnd);
        if (!used.has(n)) {
            used.add(n);
            arr.push(n);
        }
    }
    return arr;
}
function generateCard75(rnd = Math.random) {
    const cols = COL_RANGES.map(([lo, hi], idx) => {
        const count = idx === 2 ? 4 : 5; // middle column has the free center
        const picks = sampleWithoutReplacement(lo, hi, count, rnd).sort((a, b) => a - b);
        return picks;
    });
    const grid = Array.from({ length: ROWS }, () => Array.from({ length: COLS }, () => 0));
    for (let c = 0; c < COLS; c++) {
        if (c === 2) {
            let rIdx = 0;
            for (let r = 0; r < ROWS; r++) {
                if (r === CENTER_R)
                    continue;
                grid[r][c] = cols[c][rIdx++];
            }
        }
        else {
            for (let r = 0; r < ROWS; r++)
                grid[r][c] = cols[c][r];
        }
    }
    grid[CENTER_R][CENTER_C] = null;
    return grid;
}
function validateGrid75(grid) {
    if (!Array.isArray(grid) || grid.length !== 5 || grid.some(r => !Array.isArray(r) || r.length !== 5)) {
        throw errors_1.AppError.badRequest("GRID_NOT_5x5");
    }
    if (grid[CENTER_R][CENTER_C] !== null)
        throw errors_1.AppError.badRequest("CENTER_MUST_BE_FREE");
    const seen = new Set();
    for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
            if (r === CENTER_R && c === CENTER_C)
                continue;
            const v = grid[r][c];
            if (v == null)
                throw errors_1.AppError.badRequest("INVALID_NULL_CELL");
            const [lo, hi] = COL_RANGES[c];
            if (v < lo || v > hi)
                throw errors_1.AppError.badRequest(`VALUE_OUT_OF_RANGE_${v}_COL_${c + 1}`);
            if (seen.has(v))
                throw errors_1.AppError.badRequest(`DUPLICATE_VALUE_${v}`);
            seen.add(v);
        }
    }
}
/** ====== Pattern checking ====== */
function isDaubed(grid, r, c, called) {
    if (r === CENTER_R && c === CENTER_C)
        return true;
    const v = grid[r][c];
    return v != null && called.has(v);
}
function rowComplete(grid, r, called) {
    for (let c = 0; c < COLS; c++)
        if (!isDaubed(grid, r, c, called))
            return false;
    return true;
}
function colComplete(grid, c, called) {
    for (let r = 0; r < ROWS; r++)
        if (!isDaubed(grid, r, c, called))
            return false;
    return true;
}
function diagMain(grid, called) {
    for (let i = 0; i < ROWS; i++)
        if (!isDaubed(grid, i, i, called))
            return false;
    return true;
}
function diagAnti(grid, called) {
    for (let i = 0; i < ROWS; i++) {
        const c = COLS - 1 - i;
        if (!isDaubed(grid, i, c, called))
            return false;
    }
    return true;
}
function countLines(grid, called) {
    let lines = 0;
    for (let r = 0; r < ROWS; r++)
        if (rowComplete(grid, r, called))
            lines++;
    for (let c = 0; c < COLS; c++)
        if (colComplete(grid, c, called))
            lines++;
    if (diagMain(grid, called))
        lines++;
    if (diagAnti(grid, called))
        lines++;
    return lines;
}
function fourCorners(grid, called) {
    const coords = [[0, 0], [0, COLS - 1], [ROWS - 1, 0], [ROWS - 1, COLS - 1]];
    return coords.every(([r, c]) => isDaubed(grid, r, c, called));
}
function outsideEdge(grid, called) {
    for (let c = 0; c < COLS; c++) {
        if (!isDaubed(grid, 0, c, called))
            return false;
        if (!isDaubed(grid, ROWS - 1, c, called))
            return false;
    }
    for (let r = 1; r < ROWS - 1; r++) {
        if (!isDaubed(grid, r, 0, called))
            return false;
        if (!isDaubed(grid, r, COLS - 1, called))
            return false;
    }
    return true;
}
function blackout(grid, called) {
    for (let r = 0; r < ROWS; r++)
        for (let c = 0; c < COLS; c++)
            if (!isDaubed(grid, r, c, called))
                return false;
    return true;
}
function xLines(grid, called) { return diagMain(grid, called) && diagAnti(grid, called); }
function plusShape(grid, called) { return rowComplete(grid, 2, called) && colComplete(grid, 2, called); }
function tShape(grid, called) { return rowComplete(grid, 0, called) && colComplete(grid, 2, called); }
function smallDiamond(grid, called) {
    const pts = [[1, 2], [2, 1], [2, 3], [3, 2]];
    return pts.every(([r, c]) => isDaubed(grid, r, c, called));
}
function postageStamp(grid, called) {
    const corners = [
        [[0, 0], [0, 1], [1, 0], [1, 1]],
        [[0, 3], [0, 4], [1, 3], [1, 4]],
        [[3, 0], [3, 1], [4, 0], [4, 1]],
        [[3, 3], [3, 4], [4, 3], [4, 4]],
    ];
    return corners.some(stamp => stamp.every(([r, c]) => isDaubed(grid, r, c, called)));
}
function checkPattern(grid, called, pattern) {
    switch (pattern) {
        case "ONE_LINE": return countLines(grid, called) >= 1;
        case "TWO_LINES": return countLines(grid, called) >= 2;
        case "FOUR_CORNERS": return fourCorners(grid, called);
        case "OUTSIDE_EDGE": return outsideEdge(grid, called);
        case "BLACKOUT": return blackout(grid, called);
        case "X_LINES": return xLines(grid, called);
        case "PLUS": return plusShape(grid, called);
        case "T_SHAPE": return tShape(grid, called);
        case "SMALL_DIAMOND": return smallDiamond(grid, called);
        case "POSTAGE_STAMP": return postageStamp(grid, called);
    }
}
