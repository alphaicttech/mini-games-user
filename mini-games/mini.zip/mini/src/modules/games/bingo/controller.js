"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.drawBatch = exports.placeBetsBatch = exports.status = exports.draw = exports.placeBets = exports.regenCard = exports.newCard = exports.drawBatchValidate = exports.placeBatchValidate = exports.statusValidate = exports.drawValidate = exports.placeValidate = exports.regenCardValidate = exports.newCardValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
/** ====== Schemas ====== */
const GridCell = zod_1.z.union([zod_1.z.number().int().min(1).max(75), zod_1.z.null()]);
const Grid75 = zod_1.z.array(zod_1.z.array(GridCell)).refine(a => a.length === 5 && a.every(r => r.length === 5), "grid must be 5x5");
const NewBody = zod_1.z.object({ client_seed: zod_1.z.string().min(1).optional() });
exports.newCardValidate = (0, validate_1.validateBody)(NewBody);
const RegenBody = zod_1.z.object({ card_id: zod_1.z.string().uuid() });
exports.regenCardValidate = (0, validate_1.validateBody)(RegenBody);
const PlaceBody = zod_1.z.object({
    card_id: zod_1.z.string().uuid(),
    revision: zod_1.z.number().int().min(1),
    grid: Grid75.optional(),
    stake: zod_1.z.number().positive()
});
exports.placeValidate = (0, validate_1.validateBody)(PlaceBody);
const DrawBody = zod_1.z.object({ card_id: zod_1.z.string().uuid() });
exports.drawValidate = (0, validate_1.validateBody)(DrawBody);
const StatusQuery = zod_1.z.object({ card_id: zod_1.z.string().uuid() });
exports.statusValidate = (0, validate_1.validateQuery)(StatusQuery);
/** Batch */
const PlaceBatchBody = zod_1.z.object({
    items: zod_1.z.array(zod_1.z.object({
        card_id: zod_1.z.string().uuid(),
        revision: zod_1.z.number().int().min(1),
        grid: Grid75.optional(),
        stake: zod_1.z.number().positive()
    })).min(1).max(4)
});
exports.placeBatchValidate = (0, validate_1.validateBody)(PlaceBatchBody);
const DrawBatchBody = zod_1.z.object({ batch_id: zod_1.z.string().uuid() });
exports.drawBatchValidate = (0, validate_1.validateBody)(DrawBatchBody);
/** ====== Handlers ====== */
exports.newCard = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = NewBody.parse(req.body);
    const data = yield (0, service_1.newCardSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.regenCard = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = RegenBody.parse(req.body);
    const data = yield (0, service_1.regenCardSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.placeBets = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = PlaceBody.parse(req.body);
    const data = yield (0, service_1.placeBetsSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.draw = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = DrawBody.parse(req.body);
    const data = yield (0, service_1.drawSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.status = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const query = StatusQuery.parse(req.query);
    const data = yield (0, service_1.statusSvc)(sess, query);
    res.json(Object.assign({ ok: true }, data));
}));
/** ====== Batch ====== */
exports.placeBetsBatch = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = PlaceBatchBody.parse(req.body);
    const data = yield (0, service_1.placeBetsBatchSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
exports.drawBatch = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = DrawBatchBody.parse(req.body);
    const data = yield (0, service_1.drawBatchSvc)(sess, body, idem);
    if (idem)
        res.setHeader("Idempotency-Key", idem);
    res.json(Object.assign({ ok: true }, data));
}));
