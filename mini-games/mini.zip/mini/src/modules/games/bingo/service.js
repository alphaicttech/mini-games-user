"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.newCardSvc = newCardSvc;
exports.regenCardSvc = regenCardSvc;
exports.placeBetsSvc = placeBetsSvc;
exports.drawSvc = drawSvc;
exports.statusSvc = statusSvc;
exports.placeBetsBatchSvc = placeBetsBatchSvc;
exports.drawBatchSvc = drawBatchSvc;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
const paterns_1 = require("./paterns");
// ==== RTP + Config imports ====   
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor"); // live plan for REAL mode
/** ====== Redis keys & idempotency ====== */
const CARD_TTL = 24 * 60 * 60;
const BATCH_TTL = 24 * 60 * 60;
const IDEM_TTL = 24 * 60 * 60;
const modePrefix = (mode) => (mode === "demo" ? "demo" : "real");
const rKey = (sid, id) => `bingo:card:${sid}:${id}`;
const rBatchKey = (sid, batch_id) => `bingo:batch:${sid}:${batch_id}`;
const idemKey = (mode, sid, action, key) => `idem:${modePrefix(mode)}:bingo:${action}:${sid}:${key}`;
function saveCard(c) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(rKey(c.sid, c.card_id), JSON.stringify(c), CARD_TTL); });
}
function loadCard(sid, id) {
    return __awaiter(this, void 0, void 0, function* () { const v = yield redis_1.redis.get(rKey(sid, id)); return v ? JSON.parse(v) : null; });
}
function saveBatch(b) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(rBatchKey(b.sid, b.batch_id), JSON.stringify(b), BATCH_TTL); });
}
function loadBatch(sid, batch_id) {
    return __awaiter(this, void 0, void 0, function* () { const v = yield redis_1.redis.get(rBatchKey(sid, batch_id)); return v ? JSON.parse(v) : null; });
}
function getIdem(mode, sid, action, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(idemKey(mode, sid, action, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdem(mode, sid, action, key, p) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(idemKey(mode, sid, action, key), JSON.stringify(p), IDEM_TTL);
    });
}
/** ====== Utils ====== */
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
// simple per-card lock
function withLock(sid, id, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const lk = `bingo:lock:${sid}:${id}`;
        const ok = yield redis_1.rawRedis.set(lk, "1", "EX", 3, "NX");
        if (ok !== "OK")
            throw errors_1.AppError.conflict("CARD_BUSY");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(lk);
        }
    });
}
/** ====== Wallet helpers ====== */
const DEMO_START = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
function debit(sess, amount, info, mode) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        if (!(amount > 0))
            return;
        if (mode === "demo") {
            const k = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(k);
            const bal = v ? Number(v) : DEMO_START;
            if (bal < amount)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield redis_1.redis.set(k, String(+(bal - amount).toFixed(2)), 2 * 60 * 60);
        }
        else {
            const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, { TransactionId: info.txn, TransactionType: "PlaceBet", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: info });
        }
    });
}
function credit(sess, amount, info, mode) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        if (!(amount > 0))
            return;
        if (mode === "demo") {
            const k = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(k);
            const bal = v ? Number(v) : DEMO_START;
            yield redis_1.redis.set(k, String(+(bal + amount).toFixed(2)), 2 * 60 * 60);
        }
        else {
            const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, { TransactionId: info.txn, TransactionType: "WinAmount", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: info });
        }
    });
}
/** ====== RTP helpers for Bingo ====== */
const GAME_CODE = "bingo";
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
/** REAL: Enter RTP (active counters++) */
function rtpEnterReal(stake) {
    return __awaiter(this, void 0, void 0, function* () {
        const yymmdd = (0, date_1.toYYMMDD)();
        const dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd); // real keyspace
        yield redis_1.redis.hsetnx(dayKey, "rtp_target", 0.90);
        yield redis_1.redis.spEnter(dayKey, stake);
        return { dayKey, yymmdd };
    });
}
/** DEMO: no-op for counters, but we may still compute a “feel” plan */
function demoPlan(stake, cfg) {
    // soft synthetic: aim target around 60% of per-ticket cap, no hard coupling
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
/** REAL: Settle RTP (payin+=stake, payout+=win, counters--) */
function rtpSettleReal(dayKey, stake, win) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.spSettle(dayKey, stake, win);
    });
}
/** Evaluate all patterns for a card & return total payout */
function evaluateCard(grid, stake, called) {
    const results = Object.keys(paterns_1.PATTERN_ODDS).map(pattern => {
        const hit = (0, paterns_1.checkPattern)(grid, called, pattern);
        const odd = paterns_1.PATTERN_ODDS[pattern];
        const payout_contrib = hit ? +(stake * odd).toFixed(2) : 0;
        return { pattern, hit, odd, payout_contrib };
    });
    const total = +results.reduce((s, r) => s + r.payout_contrib, 0).toFixed(2);
    return { results, total };
}
/** Pick K candidate draws to approach target without exceeding hardCap */
function pickDrawWithRtp(server_seed, client_seed, grid, stake, target, hardCap, softCap, K = 6) {
    let best = { score: Number.POSITIVE_INFINITY, draw25: [], pickIdx: 0, payout: 0, results: [] };
    for (let pickIdx = 0; pickIdx < K; pickIdx++) {
        const nums = Array.from({ length: 75 }, (_, i) => i + 1);
        for (let k = nums.length - 1; k > 0; k--) {
            const j = Math.floor((0, paterns_1.r01)(server_seed, client_seed, k + 1000 * pickIdx, "draw") * (k + 1));
            const t = nums[k];
            nums[k] = nums[j];
            nums[j] = t;
        }
        const draw25 = nums.slice(0, 25).sort((a, b) => a - b);
        const called = new Set(draw25);
        const { results, total } = evaluateCard(grid, stake, called);
        const capped = Math.min(total, hardCap);
        const overPenalty = total > hardCap ? (total - hardCap) * 10 : 0;
        const softPenalty = capped > softCap ? (capped - softCap) * 0.5 : 0;
        const score = Math.abs(capped - target) + overPenalty + softPenalty;
        if (score < best.score)
            best = { score, draw25, pickIdx, payout: +capped.toFixed(2), results };
    }
    return best;
}
/** ====== Public services ====== */
function newCardSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const mode = sess.mode === "demo" ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "new", idem);
            if (hit)
                return hit;
        }
        const server_seed = crypto_1.default.randomBytes(32).toString("hex");
        const server_seed_hash = sha256(server_seed);
        const client_seed = (_c = (_b = (_a = input.client_seed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        const grid = (0, paterns_1.generateCard75)();
        const card = {
            card_id: (0, crypto_1.randomUUID)(),
            sid: sess.sid,
            currency: sess.currency,
            server_seed, server_seed_hash, client_seed,
            grid, revision: 1,
            state: "DRAFT",
            created_at: Date.now()
        };
        yield saveCard(card);
        const resp = { card_id: card.card_id, state: card.state, server_seed_hash, revision: card.revision, grid: card.grid };
        if (idem)
            yield setIdem(mode, sess.sid, "new", idem, resp);
        return resp;
    });
}
function regenCardSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = sess.mode === "demo" ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "regen", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.card_id, () => __awaiter(this, void 0, void 0, function* () {
            const c = yield loadCard(sess.sid, input.card_id);
            if (!c)
                throw errors_1.AppError.notFound("CARD_NOT_FOUND_2");
            if (c.state !== "DRAFT")
                throw errors_1.AppError.badRequest("CANNOT_REGENERATE_AFTER_BET");
            c.grid = (0, paterns_1.generateCard75)();
            c.revision++;
            yield saveCard(c);
            const resp = { card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid };
            if (idem)
                yield setIdem(mode, sess.sid, "regen", idem, resp);
            return resp;
        }));
    });
}
/** Place single stake — REAL enters RTP; DEMO doesn’t */
function placeBetsSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = sess.mode === "demo" ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "place", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.card_id, () => __awaiter(this, void 0, void 0, function* () {
            const c = yield loadCard(sess.sid, input.card_id);
            if (!c)
                throw errors_1.AppError.notFound("CARD_NOT_FOUND_1");
            if (c.state !== "DRAFT")
                throw errors_1.AppError.badRequest("ALREADY_PLACED_OR_RESOLVED");
            if (input.revision !== c.revision)
                throw errors_1.AppError.badRequest("REVISION_STALE");
            if (input.grid) {
                (0, paterns_1.validateGrid75)(input.grid);
                c.grid = input.grid;
            }
            const stake = +input.stake.toFixed(2);
            if (!(stake > 0))
                throw errors_1.AppError.badRequest("INVALID_STAKE");
            const txn = `${c.server_seed_hash}-BET-${Date.now()}`;
            yield debit(sess, stake, { txn, Source: "Bingo", GameName: "Bingo75", RoundId: c.server_seed_hash, Revision: c.revision }, mode);
            c.stake = stake;
            c.state = "BET_PLACED";
            yield saveCard(c);
            // RTP enter only for REAL
            if (mode === "real") {
                yield rtpEnterReal(stake);
            }
            const resp = { card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid, stake: c.stake };
            if (idem)
                yield setIdem(mode, sess.sid, "place", idem, resp);
            return resp;
        }));
    });
}
/** Draw single card, evaluate; REAL uses live plan+settle, DEMO uses synthetic plan (no settle) */
function drawSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = sess.mode === "demo" ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "draw", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.card_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const c = yield loadCard(sess.sid, input.card_id);
            if (!c)
                throw errors_1.AppError.notFound("CARD_NOT_FOUND_3");
            if (c.state !== "BET_PLACED" && c.state !== "DRAWN" && c.state !== "SETTLED")
                throw errors_1.AppError.badRequest("NO_BETS_TO_DRAW");
            const stake = +((_a = c.stake) !== null && _a !== void 0 ? _a : 0);
            if (!(stake > 0))
                throw errors_1.AppError.badRequest("NO_STAKE");
            const cfg = yield loadGameCfg();
            // Plan: REAL from live RTP; DEMO synthetic
            const plan = (mode === "real")
                ? yield (0, governor_1.spPlan)(GAME_CODE, stake, cfg, (0, date_1.toYYMMDD)())
                : demoPlan(stake, cfg);
            // Produce deterministic draw that aims near target but never above hardCap
            let draw25, pickIdx = 0, results = [], plannedPayout = 0;
            if (!c.draw25) {
                const picked = pickDrawWithRtp(c.server_seed, c.client_seed, c.grid, stake, plan.target, plan.hardCap, plan.softCap, 6);
                draw25 = picked.draw25;
                pickIdx = picked.pickIdx;
                plannedPayout = picked.payout;
                results = picked.results;
                c.draw25 = draw25;
                c.draw_pick_index = pickIdx;
                c.state = "DRAWN";
            }
            else {
                draw25 = c.draw25;
                const called = new Set(draw25);
                const ev = evaluateCard(c.grid, stake, called);
                plannedPayout = Math.min(ev.total, plan.hardCap);
                results = ev.results;
            }
            const win = Math.min(plannedPayout, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            // REAL: RTP settle + credit. DEMO: credit only.
            if (mode === "real") {
                const yymmdd = (0, date_1.toYYMMDD)();
                const dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
                yield rtpSettleReal(dayKey, stake, win);
            }
            if (c.state !== "SETTLED") {
                const txn = `${c.server_seed_hash}-W`;
                yield credit(sess, win, {
                    txn, Source: "Bingo", GameName: "Bingo75", RoundId: c.server_seed_hash,
                    Draw: c.draw25, Results: results, Stake: stake, Mode: mode,
                    RtpTarget: plan.target, HardCap: plan.hardCap
                }, mode);
                c.state = "SETTLED";
            }
            c.results = results;
            yield saveCard(c);
            const resp = {
                card_id: c.card_id, state: c.state, grid: c.grid,
                stake: c.stake, draw25: c.draw25, results: c.results, total_payout: win,
                fairness: {
                    server_seed_hash: c.server_seed_hash,
                    server_seed: c.state === "SETTLED" ? c.server_seed : undefined,
                    client_seed: c.client_seed,
                    pick_index: (_b = c.draw_pick_index) !== null && _b !== void 0 ? _b : 0,
                    method: "Pick K deterministic shuffles via HMAC; choose RTP-aware best"
                },
                plan,
                mode
            };
            if (idem)
                yield setIdem(mode, sess.sid, "draw", idem, resp);
            return resp;
        }));
    });
}
function statusSvc(sess, input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const c = yield loadCard(sess.sid, input.card_id);
        if (!c)
            throw errors_1.AppError.notFound("CARD_NOT_FOUND_4");
        return {
            card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid,
            stake: c.stake, results: c.results, draw25: (c.state === "SETTLED" || c.state === "DRAWN") ? c.draw25 : undefined,
            fairness: {
                server_seed_hash: c.server_seed_hash,
                server_seed: c.state === "SETTLED" ? c.server_seed : undefined,
                client_seed: c.client_seed,
                pick_index: (_a = c.draw_pick_index) !== null && _a !== void 0 ? _a : (c.state === "SETTLED" ? 0 : undefined)
            }
        };
    });
}
/** ====== Batch (up to 4 cards, one shared result) ====== */
function placeBetsBatchSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const mode = sess.mode === "demo" ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "place_batch", idem);
            if (hit)
                return hit;
        }
        const unique = new Set(input.items.map(i => i.card_id));
        if (unique.size !== input.items.length)
            throw errors_1.AppError.badRequest("DUP_CARD_IDS");
        if (input.items.length > 4)
            throw errors_1.AppError.badRequest("MAX_4_CARDS");
        const releases = [];
        try {
            const cards = [];
            for (const it of input.items) {
                const lk = `bingo:lock:${sess.sid}:${it.card_id}`;
                const ok = yield redis_1.rawRedis.set(lk, "1", "EX", 3, "NX");
                if (ok !== "OK")
                    throw errors_1.AppError.conflict("CARD_BUSY");
                releases.push(() => redis_1.rawRedis.del(lk));
                const c = yield loadCard(sess.sid, it.card_id);
                if (!c)
                    throw errors_1.AppError.notFound("CARD_NOT_FOUND_BATCH");
                if (c.state !== "DRAFT")
                    throw errors_1.AppError.badRequest("ALREADY_PLACED_OR_RESOLVED");
                if (it.revision !== c.revision)
                    throw errors_1.AppError.badRequest("REVISION_STALE");
                if (!(it.stake > 0))
                    throw errors_1.AppError.badRequest("INVALID_STAKE");
                if (it.grid) {
                    (0, paterns_1.validateGrid75)(it.grid);
                    c.grid = it.grid;
                }
                c.stake = +it.stake.toFixed(2);
                cards.push(c);
            }
            const totalStake = +cards.reduce((s, c) => { var _a; return s + ((_a = c.stake) !== null && _a !== void 0 ? _a : 0); }, 0).toFixed(2);
            const batch_id = (0, crypto_1.randomUUID)();
            const group_server_seed = crypto_1.default.randomBytes(32).toString("hex");
            const group_server_seed_hash = sha256(group_server_seed);
            const client_seed = (_b = (_a = sess.clientExternalKey) !== null && _a !== void 0 ? _a : sess.userName) !== null && _b !== void 0 ? _b : "client";
            if (mode === "real") {
                const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_c = sess.opSessionId) !== null && _c !== void 0 ? _c : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                const placeTxn = `${group_server_seed_hash}-BATCH-${Date.now()}`;
                yield (0, client_1.deposit)(opCtx, {
                    TransactionId: placeTxn,
                    TransactionType: "PlaceBet",
                    Amount: totalStake,
                    CurrencyCode: sess.currency,
                    TransactionInfo: {
                        Source: "Bingo", GameName: "Bingo75",
                        BatchId: batch_id,
                        GroupSeedHash: group_server_seed_hash,
                        Items: cards.map(c => ({ CardId: c.card_id, Revision: c.revision, Stake: c.stake }))
                    }
                });
            }
            else {
                // demo debit from local balance
                const k = `demo:bal:${sess.sid}`;
                const v = yield redis_1.redis.get(k);
                const bal = v ? Number(v) : DEMO_START;
                if (bal < totalStake)
                    throw errors_1.AppError.badRequest("Insufficient FUN balance");
                yield redis_1.redis.set(k, String(+(bal - totalStake).toFixed(2)), 2 * 60 * 60);
            }
            // Save cards and optionally mark RTP active (REAL only)
            if (mode === "real") {
                const yymmdd = (0, date_1.toYYMMDD)();
                const dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
                yield redis_1.redis.hsetnx(dayKey, "rtp_target", 0.90);
                for (const c of cards) {
                    c.state = "BET_PLACED";
                    c.batch_id = batch_id;
                    c.group_server_seed_hash = group_server_seed_hash;
                    yield saveCard(c);
                    yield redis_1.redis.spEnter(dayKey, c.stake);
                }
            }
            else {
                for (const c of cards) {
                    c.state = "BET_PLACED";
                    c.batch_id = batch_id;
                    c.group_server_seed_hash = group_server_seed_hash;
                    yield saveCard(c);
                }
            }
            const batch = {
                batch_id,
                sid: sess.sid,
                currency: sess.currency,
                group_server_seed,
                group_server_seed_hash,
                client_seed,
                card_ids: cards.map(c => c.card_id),
                created_at: Date.now()
            };
            yield saveBatch(batch);
            const resp = {
                batch_id,
                server_seed_hash: group_server_seed_hash,
                total_stake: totalStake,
                items: cards.map(c => ({ card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid, stake: c.stake })),
                mode
            };
            if (idem)
                yield setIdem(mode, sess.sid, "place_batch", idem, resp);
            return resp;
        }
        finally {
            for (const r of releases) {
                try {
                    yield r();
                }
                catch (_d) { }
            }
        }
    });
}
function drawBatchSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const mode = sess.mode === "demo" ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "draw_batch", idem);
            if (hit)
                return hit;
        }
        const batch = yield loadBatch(sess.sid, input.batch_id);
        if (!batch)
            throw errors_1.AppError.notFound("BATCH_NOT_FOUND");
        const cards = [];
        for (const card_id of batch.card_ids) {
            const c = yield loadCard(sess.sid, card_id);
            if (!c)
                throw errors_1.AppError.notFound("CARD_NOT_FOUND_BATCH_DRAW");
            if (c.state !== "BET_PLACED" && c.state !== "DRAWN" && c.state !== "SETTLED")
                throw errors_1.AppError.badRequest("NO_BETS_TO_DRAW");
            if (!c.stake || !(c.stake > 0))
                throw errors_1.AppError.badRequest("NO_STAKE");
            cards.push(c);
        }
        if (!batch.draw25) {
            const nums = Array.from({ length: 75 }, (_, i) => i + 1);
            for (let k = nums.length - 1; k > 0; k--) {
                const j = Math.floor((0, paterns_1.r01)(batch.group_server_seed, batch.client_seed, k, "draw") * (k + 1));
                const t = nums[k];
                nums[k] = nums[j];
                nums[j] = t;
            }
            batch.draw25 = nums.slice(0, 25).sort((a, b) => a - b);
            yield saveBatch(batch);
        }
        const cfg = yield loadGameCfg();
        const called = new Set(batch.draw25);
        const yymmdd = (0, date_1.toYYMMDD)();
        const dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
        const perCard = [];
        let totalPayout = 0;
        for (const c of cards) {
            const stake = c.stake;
            const plan = (mode === "real")
                ? yield (0, governor_1.spPlan)(GAME_CODE, stake, cfg, yymmdd)
                : demoPlan(stake, cfg);
            const ev = (function evaluate(grid, stake, called) {
                const results = Object.keys(paterns_1.PATTERN_ODDS).map(pattern => {
                    const hit = (0, paterns_1.checkPattern)(grid, called, pattern);
                    const odd = paterns_1.PATTERN_ODDS[pattern];
                    const payout_contrib = hit ? +(stake * odd).toFixed(2) : 0;
                    return { pattern, hit, odd, payout_contrib };
                });
                const total = +results.reduce((s, r) => s + r.payout_contrib, 0).toFixed(2);
                return { results, total };
            })(c.grid, stake, called);
            const win = Math.min(Math.min(ev.total, plan.hardCap), cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
            if (mode === "real") {
                yield redis_1.redis.spSettle(dayKey, stake, win);
            }
            c.results = ev.results;
            c.draw25 = batch.draw25;
            c.state = "SETTLED";
            yield saveCard(c);
            perCard.push({ c, payout: win });
            totalPayout = +(totalPayout + win).toFixed(2);
        }
        // credit once
        if (mode === "demo") {
            const k = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(k);
            const bal = v ? Number(v) : DEMO_START;
            yield redis_1.redis.set(k, String(+(bal + totalPayout).toFixed(2)), 2 * 60 * 60);
        }
        else if (totalPayout > 0) {
            const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            const winTxn = `${batch.group_server_seed_hash}-W`;
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: winTxn,
                TransactionType: "WinAmount",
                Amount: totalPayout,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Bingo", GameName: "Bingo75",
                    BatchId: batch.batch_id,
                    GroupSeedHash: batch.group_server_seed_hash,
                    Draw: batch.draw25,
                    Items: perCard.map(({ c, payout }) => ({
                        CardId: c.card_id, Stake: c.stake, Results: c.results, Payout: payout
                    }))
                }
            });
        }
        batch.settled = true;
        yield saveBatch(batch);
        const resp = {
            batch_id: batch.batch_id,
            draw25: batch.draw25,
            total_payout: totalPayout,
            items: perCard.map(({ c, payout }) => ({
                card_id: c.card_id, stake: c.stake, results: c.results, payout, grid: c.grid
            })),
        };
        if (idem)
            yield setIdem(mode, sess.sid, "draw_batch", idem, resp);
        return resp;
    });
}
