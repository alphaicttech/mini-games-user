import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

import {
    Pattern, PATTERN_ODDS, Grid75, generateCard75, validateGrid75,
    checkPattern, r01
} from "./paterns";

// ==== RTP + Config imports ====   
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";       // live plan for REAL mode

/** ====== Redis keys & idempotency ====== */
const CARD_TTL = 24 * 60 * 60;
const BATCH_TTL = 24 * 60 * 60;
const IDEM_TTL = 24 * 60 * 60;

const modePrefix = (mode: "real" | "demo") => (mode === "demo" ? "demo" : "real");

const rKey = (sid: string, id: string) => `bingo:card:${sid}:${id}`;
const rBatchKey = (sid: string, batch_id: string) => `bingo:batch:${sid}:${batch_id}`;
const idemKey = (mode: "real" | "demo", sid: string, action: string, key: string) => `idem:${modePrefix(mode)}:bingo:${action}:${sid}:${key}`;

async function saveCard(c: CardState) { await redis.set(rKey(c.sid, c.card_id), JSON.stringify(c), CARD_TTL); }
async function loadCard(sid: string, id: string) { const v = await redis.get(rKey(sid, id)); return v ? JSON.parse(v) as CardState : null; }
async function saveBatch(b: BatchState) { await redis.set(rBatchKey(b.sid, b.batch_id), JSON.stringify(b), BATCH_TTL); }
async function loadBatch(sid: string, batch_id: string) { const v = await redis.get(rBatchKey(sid, batch_id)); return v ? JSON.parse(v) as BatchState : null; }

async function getIdem(mode: "real" | "demo", sid: string, action: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(idemKey(mode, sid, action, key));
    return v ? JSON.parse(v) : null;
}
async function setIdem(mode: "real" | "demo", sid: string, action: string, key: string, p: any) {
    await redis.set(idemKey(mode, sid, action, key), JSON.stringify(p), IDEM_TTL);
}

/** ====== Types ====== */
export type CardState = {
    card_id: string;
    sid: string;
    currency: string;

    server_seed: string;
    server_seed_hash: string;
    client_seed: string;

    grid: Grid75;
    revision: number;
    state: "DRAFT" | "BET_PLACED" | "DRAWN" | "SETTLED";

    stake?: number; // single stake for the card

    draw25?: number[];
    draw_pick_index?: number; // which candidate we picked for RTP (for fairness)
    results?: Array<{ pattern: Pattern; hit: boolean; odd: number; payout_contrib: number }>;

    // optional links to batch
    batch_id?: string;
    group_server_seed_hash?: string;

    created_at: number;
};

export type BatchState = {
    batch_id: string;
    sid: string;
    currency: string;
    group_server_seed: string;
    group_server_seed_hash: string;
    client_seed: string;
    card_ids: string[];
    draw25?: number[];
    settled?: boolean;
    created_at: number;
};

/** ====== Utils ====== */
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");

// simple per-card lock
async function withLock<T>(sid: string, id: string, fn: () => Promise<T>) {
    const lk = `bingo:lock:${sid}:${id}`;
    const ok = await (rawRedis as any).set(lk, "1", "EX", 3, "NX");
    if (ok !== "OK") throw AppError.conflict("CARD_BUSY");
    try { return await fn(); } finally { await rawRedis.del(lk); }
}

/** ====== Wallet helpers ====== */
const DEMO_START = Number(process.env.DEMO_START_BALANCE ?? 1000);

async function debit(sess: ProviderSession, amount: number, info: any, mode: "real" | "demo") {
    if (!(amount > 0)) return;
    if (mode === "demo") {
        const k = `demo:bal:${sess.sid}`; const v = await redis.get(k);
        const bal = v ? Number(v) : DEMO_START;
        if (bal < amount) throw AppError.badRequest("Insufficient FUN balance");
        await redis.set(k, String(+(bal - amount).toFixed(2)), 2 * 60 * 60);
    } else {
        const op = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, { TransactionId: info.txn, TransactionType: "PlaceBet", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: info });
    }
}
async function credit(sess: ProviderSession, amount: number, info: any, mode: "real" | "demo") {
    if (!(amount > 0)) return;
    if (mode === "demo") {
        const k = `demo:bal:${sess.sid}`; const v = await redis.get(k);
        const bal = v ? Number(v) : DEMO_START;
        await redis.set(k, String(+(bal + amount).toFixed(2)), 2 * 60 * 60);
    } else {
        const op = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, { TransactionId: info.txn, TransactionType: "WinAmount", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: info });
    }
}

/** ====== RTP helpers for Bingo ====== */
const GAME_CODE = "bingo";

type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};

async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}

/** REAL: Enter RTP (active counters++) */
async function rtpEnterReal(stake: number) {
    const yymmdd = toYYMMDD();
    const dayKey = rk.day(GAME_CODE, yymmdd); // real keyspace
    await redis.hsetnx(dayKey, "rtp_target", 0.90);
    await redis.spEnter(dayKey, stake);
    return { dayKey, yymmdd };
}
/** DEMO: no-op for counters, but we may still compute a “feel” plan */
function demoPlan(stake: number, cfg: GameCfg) {
    // soft synthetic: aim target around 60% of per-ticket cap, no hard coupling
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
/** REAL: Settle RTP (payin+=stake, payout+=win, counters--) */
async function rtpSettleReal(dayKey: string, stake: number, win: number) {
    await redis.spSettle(dayKey, stake, win);
}

/** Evaluate all patterns for a card & return total payout */
function evaluateCard(grid: Grid75, stake: number, called: Set<number>) {
    const results = (Object.keys(PATTERN_ODDS) as Pattern[]).map(pattern => {
        const hit = checkPattern(grid, called, pattern);
        const odd = PATTERN_ODDS[pattern];
        const payout_contrib = hit ? +(stake * odd).toFixed(2) : 0;
        return { pattern, hit, odd, payout_contrib };
    });
    const total = +results.reduce((s, r) => s + r.payout_contrib, 0).toFixed(2);
    return { results, total };
}

/** Pick K candidate draws to approach target without exceeding hardCap */
function pickDrawWithRtp(
    server_seed: string, client_seed: string,
    grid: Grid75, stake: number,
    target: number, hardCap: number, softCap: number,
    K = 6
): { draw25: number[]; pickIdx: number; payout: number; results: Array<{ pattern: Pattern; hit: boolean; odd: number; payout_contrib: number }>; } {
    let best = { score: Number.POSITIVE_INFINITY, draw25: [] as number[], pickIdx: 0, payout: 0, results: [] as any[] };
    for (let pickIdx = 0; pickIdx < K; pickIdx++) {
        const nums = Array.from({ length: 75 }, (_, i) => i + 1);
        for (let k = nums.length - 1; k > 0; k--) {
            const j = Math.floor(r01(server_seed, client_seed, k + 1000 * pickIdx, "draw") * (k + 1));
            const t = nums[k]; nums[k] = nums[j]; nums[j] = t;
        }
        const draw25 = nums.slice(0, 25).sort((a, b) => a - b);
        const called = new Set<number>(draw25);
        const { results, total } = evaluateCard(grid, stake, called);

        const capped = Math.min(total, hardCap);
        const overPenalty = total > hardCap ? (total - hardCap) * 10 : 0;
        const softPenalty = capped > softCap ? (capped - softCap) * 0.5 : 0;
        const score = Math.abs(capped - target) + overPenalty + softPenalty;
        if (score < best.score) best = { score, draw25, pickIdx, payout: +capped.toFixed(2), results };
    }
    return best;
}

/** ====== Public services ====== */
export async function newCardSvc(
    sess: ProviderSession, input: { client_seed?: string }, idem?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "new", idem); if (hit) return hit; }

    const server_seed = crypto.randomBytes(32).toString("hex");
    const server_seed_hash = sha256(server_seed);
    const client_seed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    const grid = generateCard75();
    const card: CardState = {
        card_id: randomUUID(),
        sid: sess.sid,
        currency: sess.currency,
        server_seed, server_seed_hash, client_seed,
        grid, revision: 1,
        state: "DRAFT",
        created_at: Date.now()
    };
    await saveCard(card);

    const resp = { card_id: card.card_id, state: card.state, server_seed_hash, revision: card.revision, grid: card.grid };
    if (idem) await setIdem(mode, sess.sid, "new", idem, resp);
    return resp;
}

export async function regenCardSvc(
    sess: ProviderSession, input: { card_id: string }, idem?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "regen", idem); if (hit) return hit; }
    return withLock(sess.sid, input.card_id, async () => {
        const c = await loadCard(sess.sid, input.card_id);
        if (!c) throw AppError.notFound("CARD_NOT_FOUND_2");
        if (c.state !== "DRAFT") throw AppError.badRequest("CANNOT_REGENERATE_AFTER_BET");
        c.grid = generateCard75(); c.revision++;
        await saveCard(c);
        const resp = { card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid };
        if (idem) await setIdem(mode, sess.sid, "regen", idem, resp);
        return resp;
    });
}

/** Place single stake — REAL enters RTP; DEMO doesn’t */
export async function placeBetsSvc(
    sess: ProviderSession, input: { card_id: string; revision: number; grid?: Grid75; stake: number }, idem?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "place", idem); if (hit) return hit; }
    return withLock(sess.sid, input.card_id, async () => {
        const c = await loadCard(sess.sid, input.card_id);
        if (!c) throw AppError.notFound("CARD_NOT_FOUND_1");
        if (c.state !== "DRAFT") throw AppError.badRequest("ALREADY_PLACED_OR_RESOLVED");
        if (input.revision !== c.revision) throw AppError.badRequest("REVISION_STALE");
        if (input.grid) { validateGrid75(input.grid); c.grid = input.grid; }

        const stake = +input.stake.toFixed(2);
        if (!(stake > 0)) throw AppError.badRequest("INVALID_STAKE");

        const txn = `${c.server_seed_hash}-BET-${Date.now()}`;
        await debit(sess, stake, { txn, Source: "Bingo", GameName: "Bingo75", RoundId: c.server_seed_hash, Revision: c.revision }, mode);

        c.stake = stake; c.state = "BET_PLACED";
        await saveCard(c);

        // RTP enter only for REAL
        if (mode === "real") {
            await rtpEnterReal(stake);
        }

        const resp = { card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid, stake: c.stake };
        if (idem) await setIdem(mode, sess.sid, "place", idem, resp);
        return resp;
    });
}

/** Draw single card, evaluate; REAL uses live plan+settle, DEMO uses synthetic plan (no settle) */
export async function drawSvc(
    sess: ProviderSession, input: { card_id: string }, idem?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "draw", idem); if (hit) return hit; }
    return withLock(sess.sid, input.card_id, async () => {
        const c = await loadCard(sess.sid, input.card_id);
        if (!c) throw AppError.notFound("CARD_NOT_FOUND_3");
        if (c.state !== "BET_PLACED" && c.state !== "DRAWN" && c.state !== "SETTLED") throw AppError.badRequest("NO_BETS_TO_DRAW");
        const stake = +(c.stake ?? 0);
        if (!(stake > 0)) throw AppError.badRequest("NO_STAKE");

        const cfg = await loadGameCfg();

        // Plan: REAL from live RTP; DEMO synthetic
        const plan = (mode === "real")
            ? await spPlan(GAME_CODE, stake, cfg, toYYMMDD())
            : demoPlan(stake, cfg);

        // Produce deterministic draw that aims near target but never above hardCap
        let draw25: number[], pickIdx = 0, results: any[] = [], plannedPayout = 0;

        if (!c.draw25) {
            const picked = pickDrawWithRtp(c.server_seed, c.client_seed, c.grid, stake, plan.target, plan.hardCap, plan.softCap, 6);
            draw25 = picked.draw25; pickIdx = picked.pickIdx; plannedPayout = picked.payout; results = picked.results;
            c.draw25 = draw25; c.draw_pick_index = pickIdx; c.state = "DRAWN";
        } else {
            draw25 = c.draw25;
            const called = new Set<number>(draw25);
            const ev = evaluateCard(c.grid, stake, called);
            plannedPayout = Math.min(ev.total, plan.hardCap);
            results = ev.results;
        }

        const win = Math.min(
            plannedPayout,
            cfg.per_bet_cap,
            cfg.per_ticket_cap,
            cfg.per_user_daily_cap
        );

        // REAL: RTP settle + credit. DEMO: credit only.
        if (mode === "real") {
            const yymmdd = toYYMMDD();
            const dayKey = rk.day(GAME_CODE, yymmdd);
            await rtpSettleReal(dayKey, stake, win);
        }

        if (c.state !== "SETTLED") {
            const txn = `${c.server_seed_hash}-W`;
            await credit(sess, win, {
                txn, Source: "Bingo", GameName: "Bingo75", RoundId: c.server_seed_hash,
                Draw: c.draw25, Results: results, Stake: stake, Mode: mode,
                RtpTarget: plan.target, HardCap: plan.hardCap
            }, mode);
            c.state = "SETTLED";
        }

        c.results = results; await saveCard(c);

        const resp = {
            card_id: c.card_id, state: c.state, grid: c.grid,
            stake: c.stake, draw25: c.draw25, results: c.results, total_payout: win,
            fairness: {
                server_seed_hash: c.server_seed_hash,
                server_seed: c.state === "SETTLED" ? c.server_seed : undefined,
                client_seed: c.client_seed,
                pick_index: c.draw_pick_index ?? 0,
                method: "Pick K deterministic shuffles via HMAC; choose RTP-aware best"
            },
            plan,
            mode
        };
        if (idem) await setIdem(mode, sess.sid, "draw", idem, resp);
        return resp;
    });
}

export async function statusSvc(sess: ProviderSession, input: { card_id: string }) {
    const c = await loadCard(sess.sid, input.card_id);
    if (!c) throw AppError.notFound("CARD_NOT_FOUND_4");
    return {
        card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid,
        stake: c.stake, results: c.results, draw25: (c.state === "SETTLED" || c.state === "DRAWN") ? c.draw25 : undefined,
        fairness: {
            server_seed_hash: c.server_seed_hash,
            server_seed: c.state === "SETTLED" ? c.server_seed : undefined,
            client_seed: c.client_seed,
            pick_index: c.draw_pick_index ?? (c.state === "SETTLED" ? 0 : undefined)
        }
    };
}

/** ====== Batch (up to 4 cards, one shared result) ====== */
export async function placeBetsBatchSvc(
    sess: ProviderSession, input: { items: Array<{ card_id: string; revision: number; grid?: Grid75; stake: number }> }, idem?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "place_batch", idem); if (hit) return hit; }

    const unique = new Set(input.items.map(i => i.card_id));
    if (unique.size !== input.items.length) throw AppError.badRequest("DUP_CARD_IDS");
    if (input.items.length > 4) throw AppError.badRequest("MAX_4_CARDS");

    const releases: Array<() => Promise<any>> = [];
    try {
        const cards: CardState[] = [];
        for (const it of input.items) {
            const lk = `bingo:lock:${sess.sid}:${it.card_id}`;
            const ok = await (rawRedis as any).set(lk, "1", "EX", 3, "NX");
            if (ok !== "OK") throw AppError.conflict("CARD_BUSY");
            releases.push(() => rawRedis.del(lk));

            const c = await loadCard(sess.sid, it.card_id);
            if (!c) throw AppError.notFound("CARD_NOT_FOUND_BATCH");
            if (c.state !== "DRAFT") throw AppError.badRequest("ALREADY_PLACED_OR_RESOLVED");
            if (it.revision !== c.revision) throw AppError.badRequest("REVISION_STALE");
            if (!(it.stake > 0)) throw AppError.badRequest("INVALID_STAKE");
            if (it.grid) { validateGrid75(it.grid); c.grid = it.grid; }

            c.stake = +it.stake.toFixed(2);
            cards.push(c);
        }

        const totalStake = +cards.reduce((s, c) => s + (c.stake ?? 0), 0).toFixed(2);
        const batch_id = randomUUID();

        const group_server_seed = crypto.randomBytes(32).toString("hex");
        const group_server_seed_hash = sha256(group_server_seed);
        const client_seed = (sess as any).clientExternalKey ?? (sess as any).userName ?? "client";

        if (mode === "real") {
            const op = await findByPortalName(sess.portalName);
            const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            const placeTxn = `${group_server_seed_hash}-BATCH-${Date.now()}`;
            await deposit(opCtx, {
                TransactionId: placeTxn,
                TransactionType: "PlaceBet",
                Amount: totalStake,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Bingo", GameName: "Bingo75",
                    BatchId: batch_id,
                    GroupSeedHash: group_server_seed_hash,
                    Items: cards.map(c => ({ CardId: c.card_id, Revision: c.revision, Stake: c.stake }))
                }
            });
        } else {
            // demo debit from local balance
            const k = `demo:bal:${sess.sid}`; const v = await redis.get(k);
            const bal = v ? Number(v) : DEMO_START;
            if (bal < totalStake) throw AppError.badRequest("Insufficient FUN balance");
            await redis.set(k, String(+(bal - totalStake).toFixed(2)), 2 * 60 * 60);
        }

        // Save cards and optionally mark RTP active (REAL only)
        if (mode === "real") {
            const yymmdd = toYYMMDD();
            const dayKey = rk.day(GAME_CODE, yymmdd);
            await redis.hsetnx(dayKey, "rtp_target", 0.90);
            for (const c of cards) {
                c.state = "BET_PLACED";
                c.batch_id = batch_id;
                c.group_server_seed_hash = group_server_seed_hash;
                await saveCard(c);
                await redis.spEnter(dayKey, c.stake!);
            }
        } else {
            for (const c of cards) {
                c.state = "BET_PLACED";
                c.batch_id = batch_id;
                c.group_server_seed_hash = group_server_seed_hash;
                await saveCard(c);
            }
        }

        const batch: BatchState = {
            batch_id,
            sid: sess.sid,
            currency: sess.currency,
            group_server_seed,
            group_server_seed_hash,
            client_seed,
            card_ids: cards.map(c => c.card_id),
            created_at: Date.now()
        };
        await saveBatch(batch);

        const resp = {
            batch_id,
            server_seed_hash: group_server_seed_hash,
            total_stake: totalStake,
            items: cards.map(c => ({ card_id: c.card_id, state: c.state, revision: c.revision, grid: c.grid, stake: c.stake })),
            mode
        };

        if (idem) await setIdem(mode, sess.sid, "place_batch", idem, resp);
        return resp;
    } finally {
        for (const r of releases) { try { await r(); } catch { } }
    }
}

export async function drawBatchSvc(
    sess: ProviderSession, input: { batch_id: string }, idem?: string
) {
    const mode: "real" | "demo" = sess.mode === "demo" ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "draw_batch", idem); if (hit) return hit; }

    const batch = await loadBatch(sess.sid, input.batch_id);
    if (!batch) throw AppError.notFound("BATCH_NOT_FOUND");

    const cards: CardState[] = [];
    for (const card_id of batch.card_ids) {
        const c = await loadCard(sess.sid, card_id);
        if (!c) throw AppError.notFound("CARD_NOT_FOUND_BATCH_DRAW");
        if (c.state !== "BET_PLACED" && c.state !== "DRAWN" && c.state !== "SETTLED") throw AppError.badRequest("NO_BETS_TO_DRAW");
        if (!c.stake || !(c.stake > 0)) throw AppError.badRequest("NO_STAKE");
        cards.push(c);
    }

    if (!batch.draw25) {
        const nums = Array.from({ length: 75 }, (_, i) => i + 1);
        for (let k = nums.length - 1; k > 0; k--) {
            const j = Math.floor(r01(batch.group_server_seed, batch.client_seed, k, "draw") * (k + 1));
            const t = nums[k]; nums[k] = nums[j]; nums[j] = t;
        }
        batch.draw25 = nums.slice(0, 25).sort((a, b) => a - b);
        await saveBatch(batch);
    }

    const cfg = await loadGameCfg();
    const called = new Set<number>(batch.draw25);
    const yymmdd = toYYMMDD();
    const dayKey = rk.day(GAME_CODE, yymmdd);

    const perCard = [];
    let totalPayout = 0;

    for (const c of cards) {
        const stake = c.stake!;
        const plan = (mode === "real")
            ? await spPlan(GAME_CODE, stake, cfg, yymmdd)
            : demoPlan(stake, cfg);

        const ev = (function evaluate(grid: Grid75, stake: number, called: Set<number>) {
            const results = (Object.keys(PATTERN_ODDS) as Pattern[]).map(pattern => {
                const hit = checkPattern(grid, called, pattern);
                const odd = PATTERN_ODDS[pattern];
                const payout_contrib = hit ? +(stake * odd).toFixed(2) : 0;
                return { pattern, hit, odd, payout_contrib };
            });
            const total = +results.reduce((s, r) => s + r.payout_contrib, 0).toFixed(2);
            return { results, total };
        })(c.grid, stake, called);

        const win = Math.min(
            Math.min(ev.total, plan.hardCap),
            cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap
        );

        if (mode === "real") {
            await redis.spSettle(dayKey, stake, win);
        }

        c.results = ev.results;
        c.draw25 = batch.draw25;
        c.state = "SETTLED";
        await saveCard(c);

        perCard.push({ c, payout: win });
        totalPayout = +(totalPayout + win).toFixed(2);
    }

    // credit once
    if (mode === "demo") {
        const k = `demo:bal:${sess.sid}`; const v = await redis.get(k);
        const bal = v ? Number(v) : DEMO_START;
        await redis.set(k, String(+(bal + totalPayout).toFixed(2)), 2 * 60 * 60);
    } else if (totalPayout > 0) {
        const op = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        const winTxn = `${batch.group_server_seed_hash}-W`;
        await withdraw(opCtx, {
            TransactionId: winTxn,
            TransactionType: "WinAmount",
            Amount: totalPayout,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Bingo", GameName: "Bingo75",
                BatchId: batch.batch_id,
                GroupSeedHash: batch.group_server_seed_hash,
                Draw: batch.draw25,
                Items: perCard.map(({ c, payout }) => ({
                    CardId: c.card_id, Stake: c.stake, Results: c.results, Payout: payout
                }))
            }
        });
    }

    batch.settled = true; await saveBatch(batch);

    const resp = {
        batch_id: batch.batch_id,
        draw25: batch.draw25,
        total_payout: totalPayout,
        items: perCard.map(({ c, payout }) => ({
            card_id: c.card_id, stake: c.stake, results: c.results, payout, grid: c.grid
        })),
    };

    if (idem) await setIdem(mode, sess.sid, "draw_batch", idem, resp);
    return resp;
}
