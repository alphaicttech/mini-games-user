// /var/www/typesafe/alpha-mini/src/modules/games/bingo/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody, validateQuery } from "../../../middleware/validate";
import {
    newCardSvc, regenCardSvc, placeBetsSvc, drawSvc, statusSvc,
    placeBetsBatchSvc, drawBatchSvc
} from "./service";

/** ====== Schemas ====== */
const GridCell = z.union([z.number().int().min(1).max(75), z.null()]);
const Grid75 = z.array(z.array(GridCell)).refine(a => a.length === 5 && a.every(r => r.length === 5), "grid must be 5x5");

const NewBody = z.object({ client_seed: z.string().min(1).optional() });
export const newCardValidate = validateBody(NewBody);

const RegenBody = z.object({ card_id: z.string().uuid() });
export const regenCardValidate = validateBody(RegenBody);

const PlaceBody = z.object({
    card_id: z.string().uuid(),
    revision: z.number().int().min(1),
    grid: Grid75.optional(),
    stake: z.number().positive()
});
export const placeValidate = validateBody(PlaceBody);

const DrawBody = z.object({ card_id: z.string().uuid() });
export const drawValidate = validateBody(DrawBody);

const StatusQuery = z.object({ card_id: z.string().uuid() });
export const statusValidate = validateQuery(StatusQuery);

/** Batch */
const PlaceBatchBody = z.object({
    items: z.array(z.object({
        card_id: z.string().uuid(),
        revision: z.number().int().min(1),
        grid: Grid75.optional(),
        stake: z.number().positive()
    })).min(1).max(4)
});
export const placeBatchValidate = validateBody(PlaceBatchBody);

const DrawBatchBody = z.object({ batch_id: z.string().uuid() });
export const drawBatchValidate = validateBody(DrawBatchBody);

/** ====== Handlers ====== */
export const newCard = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = NewBody.parse(req.body);
    const data = await newCardSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const regenCard = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = RegenBody.parse(req.body);
    const data = await regenCardSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const placeBets = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = PlaceBody.parse(req.body);
    const data = await placeBetsSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const draw = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = DrawBody.parse(req.body);
    const data = await drawSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const status = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const query = StatusQuery.parse(req.query);
    const data = await statusSvc(sess, query);
    res.json({ ok: true, ...data });
});

/** ====== Batch ====== */
export const placeBetsBatch = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = PlaceBatchBody.parse(req.body);
    const data = await placeBetsBatchSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

export const drawBatch = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as any;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = DrawBatchBody.parse(req.body);
    const data = await drawBatchSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});
