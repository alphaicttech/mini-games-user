"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startChickenRound = startChickenRound;
exports.stepForward = stepForward;
exports.cashoutRound = cashoutRound;
exports.getChickenOdds = getChickenOdds;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
// ---------- config ----------
const GAME_CODE = "chicken-road";
const TRACK_STEPS = 30; // length of the road
const IDEM_TTL = 24 * 60 * 60; // idempotency cache TTL
const ROUND_TTL = 2 * 60 * 60; // active round TTL
const HOUSE_EDGE = 0.02; // 2% edge
const LIMITS = { min: 0.1, max: 10000 };
const PICK_CANDIDATES = 6; // number of server-seed candidates to evaluate vs RTP
const PRESETS = {
    easy: { steps: TRACK_STEPS, bombs: 3 },
    normal: { steps: TRACK_STEPS, bombs: 5 },
    medium: { steps: TRACK_STEPS, bombs: 8 },
    hard: { steps: TRACK_STEPS, bombs: 12 },
};
// ---------- keys ----------
const reqKey = (mode, sid, key) => `idem:${mode}:chicken:req:${sid}:${key}`;
const roundKey = (sid, rid) => `round:chicken:${sid}:${rid}`;
const lockKey = (sid, rid) => `lock:chicken:${sid}:${rid}`;
// ---------- helpers ----------
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
// Fairness: pick bomb step indices deterministically
function chooseBombSteps(total, bombs, serverSeed, clientSeed) {
    const scored = [];
    for (let i = 1; i <= total; i++) {
        const h = sha256(`${serverSeed}|${clientSeed}|${i}`);
        scored.push({ step: i, score: parseInt(h.slice(0, 8), 16) });
    }
    scored.sort((a, b) => a.score - b.score);
    return scored.slice(0, bombs).map(x => x.step); // 1..total
}
// Multiplier after k safe steps with T total and M bombs (stake-included)
function multiplierFor(T, M, k, edge = HOUSE_EDGE) {
    if (k <= 0)
        return 1;
    if (k > T - M)
        k = T - M;
    let num = 1, den = 1;
    for (let i = 0; i < k; i++) {
        num *= (T - i);
        den *= (T - M - i);
    }
    return +(num / den * (1 - edge)).toFixed(4);
}
// demo ledger
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const key = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(key);
        if (v)
            return Number(v);
        const start = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(key, String(start), 2 * 60 * 60);
        return start;
    });
}
function setDemoBalance(sess, amt) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60);
    });
}
// idempotency (mode-scoped)
function getIdemByKey(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(reqKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdemByKey(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
// lock
function withRoundLock(sid, rid, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = lockKey(sid, rid);
        const ok = yield redis_1.rawRedis.set(key, "1", "EX", 3, "NX");
        if (ok !== "OK")
            throw errors_1.AppError.badRequest("ROUND_BUSY");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(key);
        }
    });
}
function saveRound(st) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(roundKey(st.sid, st.roundId), JSON.stringify(st), ROUND_TTL);
    });
}
function loadRound(sid, rid) {
    return __awaiter(this, void 0, void 0, function* () {
        const v = yield redis_1.redis.get(roundKey(sid, rid));
        return v ? JSON.parse(v) : null;
    });
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function demoPlan(totalStake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
// Pick a server seed (K candidates) so first bomb occurs near the target step and never allows payout > rtpCap
function pickServerSeedForRtp(steps, bombs, stake, clientSeed, plan, rtpCap, K = PICK_CANDIDATES) {
    // k_target: highest k with stake*mult(k) <= target
    const multAt = (k) => multiplierFor(steps, bombs, k, HOUSE_EDGE);
    let kTarget = 0, kCap = 0;
    for (let k = 1; k <= steps - bombs; k++) {
        if (stake * multAt(k) <= plan.target)
            kTarget = k;
        if (stake * multAt(k) <= rtpCap)
            kCap = k;
    }
    const desiredFirstBomb = kTarget + 1; // we’d like bust right after the target step
    const maxAllowedFirst = kCap + 1; // to ensure you can’t exceed rtpCap by stepping forever
    let best = null;
    for (let i = 0; i < K; i++) {
        const seed = crypto_1.default.randomBytes(32).toString("hex");
        const bombsArr = chooseBombSteps(steps, bombs, seed, clientSeed);
        const firstBomb = Math.min(...bombsArr);
        // Hard constraint: we prefer firstBomb <= maxAllowedFirst (so max attainable payout ≤ rtpCap)
        const hardPenalty = firstBomb > maxAllowedFirst ? (firstBomb - maxAllowedFirst) * 1000 : 0;
        const proximity = Math.abs(firstBomb - desiredFirstBomb);
        const softPenalty = firstBomb > desiredFirstBomb ? (firstBomb - desiredFirstBomb) * 2 : 0;
        const score = hardPenalty + softPenalty + proximity;
        if (!best || score < best.score)
            best = { seed, bombSteps: bombsArr, firstBomb, score };
    }
    // Fallback: if somehow all candidates exceed, we still choose the lowest-score one;
    // construction ensures we never *need* to mutate bombs later.
    return best;
}
// ========== START ==========
function startChickenRound(sess, req, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        if (req.amount < LIMITS.min)
            throw errors_1.AppError.badRequest(`Min bet is ${LIMITS.min}`);
        if (req.amount > LIMITS.max)
            throw errors_1.AppError.badRequest(`Max bet is ${LIMITS.max}`);
        const mode = (sess.mode === "demo") ? "demo" : "real";
        const hit = yield getIdemByKey(mode, sess.sid, idemKey);
        if (hit)
            return hit;
        const preset = PRESETS[req.difficulty];
        const clientSeed = (_c = (_b = (_a = req.clientSeed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        // ---- Debit first
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < req.amount)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - req.amount).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const operatorSessionId = (_d = sess.opSessionId) !== null && _d !== void 0 ? _d : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            const placeTxn = (0, crypto_1.randomUUID)();
            const serverSeedProbe = crypto_1.default.randomBytes(32).toString("hex"); // just to compute hash for the ticket metadata
            const serverSeedHashProbe = sha256(serverSeedProbe);
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: placeTxn,
                TransactionType: "PlaceBet",
                Amount: req.amount,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "ChickenRoad",
                    GameName: "ChickenRoad",
                    RoundId: placeTxn,
                    GameNumber: Date.now().toString(),
                    ServerSeedHash: serverSeedHashProbe, // informative; real chosen seed below (K-candidate)
                    ClientSeed: clientSeed
                }
            });
        }
        // ---- RTP / planning
        const cfg = yield loadGameCfg();
        let rtpDayKey;
        let plan = { hardCap: 0, softCap: 0, target: 0 };
        if (mode === "real") {
            const yymmdd = (0, date_1.toYYMMDD)();
            rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_1.redis.hsetnx(rtpDayKey, "rtp_target", 0.90);
            // Enter active counters (one player stake)
            yield redis_1.redis.spEnter(rtpDayKey, req.amount);
            // Plan from live state
            plan = yield (0, governor_1.spPlan)(GAME_CODE, req.amount, cfg, yymmdd);
        }
        else {
            plan = demoPlan(req.amount, cfg);
        }
        const rtpCap = Math.min(plan.hardCap, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
        // ---- Choose serverSeed/bomb layout among K candidates to obey rtpCap & aim at target
        const pick = pickServerSeedForRtp(preset.steps, preset.bombs, req.amount, clientSeed, plan, rtpCap, PICK_CANDIDATES);
        const serverSeed = pick.seed;
        const serverSeedHash = sha256(serverSeed);
        const bombSteps = pick.bombSteps;
        const roundId = (0, crypto_1.randomUUID)();
        const state = {
            sid: sess.sid,
            roundId,
            stake: req.amount,
            currency: sess.currency,
            mode,
            difficulty: req.difficulty,
            steps: preset.steps,
            bombs: preset.bombs,
            position: 0,
            serverSeed, serverSeedHash, clientSeed,
            bombSteps,
            status: "active",
            createdAt: Date.now(),
            // bind RTP
            rtpDayKey,
            rtpCap,
            planTarget: plan.target,
            planHardCap: plan.hardCap,
        };
        yield saveRound(state);
        const nextMult = multiplierFor(preset.steps, preset.bombs, 1, HOUSE_EDGE);
        const resp = {
            game: "ChickenRoad",
            mode,
            round_id: roundId,
            stake: req.amount,
            currency: sess.currency,
            position: 0,
            track: { steps: preset.steps, bombs: preset.bombs },
            next_cashout_multiplier: nextMult,
            server_seed_hash: serverSeedHash,
            plan
        };
        if (idemKey)
            yield setIdemByKey(mode, sess.sid, idemKey, resp);
        return resp;
    });
}
// ========== STEP ==========
function stepForward(sess, req, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        const hit = yield getIdemByKey(mode, sess.sid, idemKey);
        if (hit)
            return hit;
        return yield withRoundLock(sess.sid, req.roundId, () => __awaiter(this, void 0, void 0, function* () {
            const st = yield loadRound(sess.sid, req.roundId);
            if (!st)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (st.status !== "active")
                throw errors_1.AppError.badRequest("ROUND_CLOSED");
            const nextStep = st.position + 1; // steps are 1..T
            if (nextStep > st.steps)
                throw errors_1.AppError.badRequest("END_OF_ROAD");
            const isBomb = st.bombSteps.includes(nextStep);
            if (isBomb) {
                // REAL: settle with win=0
                if (mode === "real" && st.rtpDayKey) {
                    yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, 0);
                }
                st.status = "bust";
                yield saveRound(st);
                const resp = {
                    game: "ChickenRoad",
                    mode,
                    round_id: st.roundId,
                    position: st.position, // last safe
                    outcome: "bust",
                    hit_step: nextStep,
                    // reveal proof so player can verify fairness
                    server_seed: st.serverSeed,
                    server_seed_hash: st.serverSeedHash,
                    client_seed: st.clientSeed,
                    bomb_steps: st.bombSteps
                };
                if (idemKey)
                    yield setIdemByKey(mode, sess.sid, idemKey, resp);
                return resp;
            }
            // safe: advance
            st.position = nextStep;
            yield saveRound(st);
            const k = st.position;
            const cashMult = multiplierFor(st.steps, st.bombs, k, HOUSE_EDGE);
            const nextMult = multiplierFor(st.steps, st.bombs, k + 1, HOUSE_EDGE);
            // show potential payout but clamp to rtpCap for real
            const rawPotential = +(st.stake * cashMult).toFixed(2);
            const potential = (mode === "real" && st.rtpCap != null)
                ? Math.min(rawPotential, st.rtpCap)
                : rawPotential;
            const resp = {
                game: "ChickenRoad",
                mode,
                round_id: st.roundId,
                position: k,
                outcome: "safe",
                cashout_multiplier: cashMult,
                potential_payout: potential,
                next_cashout_multiplier: nextMult
            };
            if (idemKey)
                yield setIdemByKey(mode, sess.sid, idemKey, resp);
            return resp;
        }));
    });
}
// ========== CASHOUT ==========
function cashoutRound(sess, req, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        const hit = yield getIdemByKey(mode, sess.sid, idemKey);
        if (hit)
            return hit;
        return yield withRoundLock(sess.sid, req.roundId, () => __awaiter(this, void 0, void 0, function* () {
            var _a;
            const st = yield loadRound(sess.sid, req.roundId);
            if (!st)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (st.status !== "active") {
                if (st.status === "bust")
                    throw errors_1.AppError.badRequest("ROUND_BUST");
                if (st.status === "cashed")
                    throw errors_1.AppError.badRequest("ROUND_ALREADY_CASHED");
            }
            if (st.position < 1)
                throw errors_1.AppError.badRequest("NOTHING_TO_CASHOUT");
            const k = st.position;
            const mult = multiplierFor(st.steps, st.bombs, k, HOUSE_EDGE);
            let payout = +(st.stake * mult).toFixed(2);
            // Clamp to configured caps (and to planned rtpCap in REAL)
            const cfg = yield loadGameCfg();
            payout = Math.min(payout, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap, ...(mode === "real" && st.rtpCap != null ? [st.rtpCap] : []));
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                yield setDemoBalance(sess, +(bal + payout).toFixed(2));
            }
            else {
                // RTP settle (payin += stake, payout += payout, counters--)
                if (!st.rtpDayKey) {
                    const yymmdd = (0, date_1.toYYMMDD)();
                    st.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd); // fallback
                }
                yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, payout);
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const operatorSessionId = (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId;
                const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                const winTxn = `${st.roundId}-W`;
                yield (0, client_1.withdraw)(opCtx, {
                    TransactionId: winTxn,
                    TransactionType: "WinAmount",
                    Amount: payout,
                    CurrencyCode: st.currency,
                    TransactionInfo: {
                        Source: "ChickenRoad",
                        GameName: "ChickenRoad",
                        RoundId: st.roundId,
                        GameNumber: Date.now().toString(),
                        ServerSeed: st.serverSeed,
                        ServerSeedHash: st.serverSeedHash,
                        ClientSeed: st.clientSeed,
                        Position: st.position,
                        Steps: st.steps,
                        Bombs: st.bombs
                    }
                });
            }
            st.status = "cashed";
            yield saveRound(st);
            const resp = {
                game: "ChickenRoad",
                mode,
                round_id: st.roundId,
                result: "cashed",
                position: st.position,
                multiplier: mult,
                payout,
                currency: st.currency,
                // reveal proof now
                server_seed: st.serverSeed,
                server_seed_hash: st.serverSeedHash,
                client_seed: st.clientSeed,
                bomb_steps: st.bombSteps,
                plan: (st.planTarget != null && st.planHardCap != null) ? { target: st.planTarget, hardCap: st.planHardCap } : undefined
            };
            if (idemKey)
                yield setIdemByKey(mode, sess.sid, idemKey, resp);
            return resp;
        }));
    });
}
/** Build odds array 1..(steps-bombs) using the exact same math as in-game cashout.
 * Stake-included multipliers; e.g., 2.00 = even-money profit.
 */
function getChickenOdds(mode, stepsOverride) {
    const preset = PRESETS[mode];
    const T = stepsOverride !== null && stepsOverride !== void 0 ? stepsOverride : preset.steps;
    const M = preset.bombs;
    const maxK = Math.max(0, T - M); // you can't get past T-M safe steps
    const odds = [];
    for (let k = 1; k <= maxK; k++) {
        odds.push(+multiplierFor(T, M, k, HOUSE_EDGE).toFixed(2));
    }
    return {
        game: "ChickenRoad",
        mode,
        steps: T,
        bombs: M,
        house_edge: HOUSE_EDGE,
        odds
    };
}
