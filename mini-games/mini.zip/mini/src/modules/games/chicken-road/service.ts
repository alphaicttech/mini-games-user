import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

// ---------- config ----------
const GAME_CODE = "chicken-road";
const TRACK_STEPS = 30;                 // length of the road
const IDEM_TTL = 24 * 60 * 60;          // idempotency cache TTL
const ROUND_TTL = 2 * 60 * 60;          // active round TTL
const HOUSE_EDGE = 0.02;                // 2% edge
const LIMITS = { min: 0.1, max: 10000 };
const PICK_CANDIDATES = 6;              // number of server-seed candidates to evaluate vs RTP

const PRESETS = {
    easy: { steps: TRACK_STEPS, bombs: 3 },
    normal: { steps: TRACK_STEPS, bombs: 5 },
    medium: { steps: TRACK_STEPS, bombs: 8 },
    hard: { steps: TRACK_STEPS, bombs: 12 },
} as const;

// ---------- keys ----------
const reqKey = (mode: "real" | "demo", sid: string, key: string) => `idem:${mode}:chicken:req:${sid}:${key}`;
const roundKey = (sid: string, rid: string) => `round:chicken:${sid}:${rid}`;
const lockKey = (sid: string, rid: string) => `lock:chicken:${sid}:${rid}`;

// ---------- helpers ----------
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");

// Fairness: pick bomb step indices deterministically
function chooseBombSteps(total: number, bombs: number, serverSeed: string, clientSeed: string): number[] {
    const scored: { step: number; score: number }[] = [];
    for (let i = 1; i <= total; i++) {
        const h = sha256(`${serverSeed}|${clientSeed}|${i}`);
        scored.push({ step: i, score: parseInt(h.slice(0, 8), 16) });
    }
    scored.sort((a, b) => a.score - b.score);
    return scored.slice(0, bombs).map(x => x.step); // 1..total
}

// Multiplier after k safe steps with T total and M bombs (stake-included)
function multiplierFor(T: number, M: number, k: number, edge = HOUSE_EDGE): number {
    if (k <= 0) return 1;
    if (k > T - M) k = T - M;
    let num = 1, den = 1;
    for (let i = 0; i < k; i++) { num *= (T - i); den *= (T - M - i); }
    return +(num / den * (1 - edge)).toFixed(4);
}

// demo ledger
async function getDemoBalance(sess: ProviderSession) {
    const key = `demo:bal:${sess.sid}`;
    const v = await redis.get(key);
    if (v) return Number(v);
    const start = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(key, String(start), 2 * 60 * 60);
    return start;
}
async function setDemoBalance(sess: ProviderSession, amt: number) {
    await redis.set(`demo:bal:${sess.sid}`, String(amt), 2 * 60 * 60);
}

// idempotency (mode-scoped)
async function getIdemByKey(mode: "real" | "demo", sid: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(reqKey(mode, sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdemByKey(mode: "real" | "demo", sid: string, key: string, payload: any) {
    await redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

// lock
async function withRoundLock<T>(sid: string, rid: string, fn: () => Promise<T>) {
    const key = lockKey(sid, rid);
    const ok = await (rawRedis as any).set(key, "1", "EX", 3, "NX");
    if (ok !== "OK") throw AppError.badRequest("ROUND_BUSY");
    try { return await fn(); } finally { await rawRedis.del(key); }
}

// ---------- state ----------
type StartInput = { amount: number; difficulty: keyof typeof PRESETS; clientSeed?: string };
type StepInput = { roundId: string };
type CashInput = { roundId: string };

type RoundState = {
    sid: string;
    roundId: string;
    stake: number;
    currency: string;
    mode: "demo" | "real";
    difficulty: keyof typeof PRESETS;
    steps: number;
    bombs: number;
    position: number;        // how many steps safely advanced (0..steps-1)
    serverSeed: string;
    serverSeedHash: string;
    clientSeed: string;
    bombSteps: number[];     // 1..steps (kept server-side; revealed on bust/cash)
    status: "active" | "bust" | "cashed";
    createdAt: number;

    // RTP binding (REAL)
    rtpDayKey?: string;      // redis key for day counters (fixed at start)
    rtpCap?: number;         // absolute max payout allowed for this round (money)
    planTarget?: number;
    planHardCap?: number;
};

async function saveRound(st: RoundState) {
    await redis.set(roundKey(st.sid, st.roundId), JSON.stringify(st), ROUND_TTL);
}
async function loadRound(sid: string, rid: string): Promise<RoundState | null> {
    const v = await redis.get(roundKey(sid, rid));
    return v ? JSON.parse(v) : null;
}

// ---- cfg / RTP helpers ----
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

// Pick a server seed (K candidates) so first bomb occurs near the target step and never allows payout > rtpCap
function pickServerSeedForRtp(
    steps: number, bombs: number, stake: number,
    clientSeed: string,
    plan: { target: number; hardCap: number; softCap: number },
    rtpCap: number,
    K = PICK_CANDIDATES
) {
    // k_target: highest k with stake*mult(k) <= target
    const multAt = (k: number) => multiplierFor(steps, bombs, k, HOUSE_EDGE);
    let kTarget = 0, kCap = 0;
    for (let k = 1; k <= steps - bombs; k++) {
        if (stake * multAt(k) <= plan.target) kTarget = k;
        if (stake * multAt(k) <= rtpCap) kCap = k;
    }
    const desiredFirstBomb = kTarget + 1;     // we’d like bust right after the target step
    const maxAllowedFirst = kCap + 1;        // to ensure you can’t exceed rtpCap by stepping forever

    let best: { seed: string; bombSteps: number[]; firstBomb: number; score: number } | null = null;

    for (let i = 0; i < K; i++) {
        const seed = crypto.randomBytes(32).toString("hex");
        const bombsArr = chooseBombSteps(steps, bombs, seed, clientSeed);
        const firstBomb = Math.min(...bombsArr);

        // Hard constraint: we prefer firstBomb <= maxAllowedFirst (so max attainable payout ≤ rtpCap)
        const hardPenalty = firstBomb > maxAllowedFirst ? (firstBomb - maxAllowedFirst) * 1000 : 0;
        const proximity = Math.abs(firstBomb - desiredFirstBomb);
        const softPenalty = firstBomb > desiredFirstBomb ? (firstBomb - desiredFirstBomb) * 2 : 0;

        const score = hardPenalty + softPenalty + proximity;
        if (!best || score < best.score) best = { seed, bombSteps: bombsArr, firstBomb, score };
    }

    // Fallback: if somehow all candidates exceed, we still choose the lowest-score one;
    // construction ensures we never *need* to mutate bombs later.
    return best!;
}

// ========== START ==========
export async function startChickenRound(
    sess: ProviderSession,
    req: StartInput,
    idemKey?: string
) {
    if (req.amount < LIMITS.min) throw AppError.badRequest(`Min bet is ${LIMITS.min}`);
    if (req.amount > LIMITS.max) throw AppError.badRequest(`Max bet is ${LIMITS.max}`);

    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    const hit = await getIdemByKey(mode, sess.sid, idemKey);
    if (hit) return hit;

    const preset = PRESETS[req.difficulty];
    const clientSeed = req.clientSeed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    // ---- Debit first
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < req.amount) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - req.amount).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const operatorSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        const placeTxn = randomUUID();
        const serverSeedProbe = crypto.randomBytes(32).toString("hex"); // just to compute hash for the ticket metadata
        const serverSeedHashProbe = sha256(serverSeedProbe);
        await deposit(opCtx, {
            TransactionId: placeTxn,
            TransactionType: "PlaceBet",
            Amount: req.amount,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "ChickenRoad",
                GameName: "ChickenRoad",
                RoundId: placeTxn,
                GameNumber: Date.now().toString(),
                ServerSeedHash: serverSeedHashProbe, // informative; real chosen seed below (K-candidate)
                ClientSeed: clientSeed
            }
        });
    }

    // ---- RTP / planning
    const cfg = await loadGameCfg();
    let rtpDayKey: string | undefined;
    let plan = { hardCap: 0, softCap: 0, target: 0 };
    if (mode === "real") {
        const yymmdd = toYYMMDD();
        rtpDayKey = rk.day(GAME_CODE, yymmdd);
        await redis.hsetnx(rtpDayKey, "rtp_target", 0.90);
        // Enter active counters (one player stake)
        await redis.spEnter(rtpDayKey, req.amount);
        // Plan from live state
        plan = await spPlan(GAME_CODE, req.amount, cfg, yymmdd);
    } else {
        plan = demoPlan(req.amount, cfg);
    }
    const rtpCap = Math.min(plan.hardCap, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);

    // ---- Choose serverSeed/bomb layout among K candidates to obey rtpCap & aim at target
    const pick = pickServerSeedForRtp(preset.steps, preset.bombs, req.amount, clientSeed, plan, rtpCap, PICK_CANDIDATES);
    const serverSeed = pick.seed;
    const serverSeedHash = sha256(serverSeed);
    const bombSteps = pick.bombSteps;

    const roundId = randomUUID();
    const state: RoundState = {
        sid: sess.sid,
        roundId,
        stake: req.amount,
        currency: sess.currency,
        mode,
        difficulty: req.difficulty,
        steps: preset.steps,
        bombs: preset.bombs,
        position: 0,
        serverSeed, serverSeedHash, clientSeed,
        bombSteps,
        status: "active",
        createdAt: Date.now(),
        // bind RTP
        rtpDayKey,
        rtpCap,
        planTarget: plan.target,
        planHardCap: plan.hardCap,
    };
    await saveRound(state);

    const nextMult = multiplierFor(preset.steps, preset.bombs, 1, HOUSE_EDGE);

    const resp = {
        game: "ChickenRoad",
        mode,
        round_id: roundId,
        stake: req.amount,
        currency: sess.currency,
        position: 0,
        track: { steps: preset.steps, bombs: preset.bombs },
        next_cashout_multiplier: nextMult,
        server_seed_hash: serverSeedHash,
        plan
    };
    if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
    return resp;
}

// ========== STEP ==========
export async function stepForward(
    sess: ProviderSession,
    req: StepInput,
    idemKey?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    const hit = await getIdemByKey(mode, sess.sid, idemKey);
    if (hit) return hit;

    return await withRoundLock(sess.sid, req.roundId, async () => {
        const st = await loadRound(sess.sid, req.roundId);
        if (!st) throw AppError.notFound("ROUND_NOT_FOUND");
        if (st.status !== "active") throw AppError.badRequest("ROUND_CLOSED");

        const nextStep = st.position + 1;                 // steps are 1..T
        if (nextStep > st.steps) throw AppError.badRequest("END_OF_ROAD");

        const isBomb = st.bombSteps.includes(nextStep);
        if (isBomb) {
            // REAL: settle with win=0
            if (mode === "real" && st.rtpDayKey) {
                await redis.spSettle(st.rtpDayKey, st.stake, 0);
            }

            st.status = "bust";
            await saveRound(st);

            const resp = {
                game: "ChickenRoad",
                mode,
                round_id: st.roundId,
                position: st.position,     // last safe
                outcome: "bust" as const,
                hit_step: nextStep,
                // reveal proof so player can verify fairness
                server_seed: st.serverSeed,
                server_seed_hash: st.serverSeedHash,
                client_seed: st.clientSeed,
                bomb_steps: st.bombSteps
            };
            if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
            return resp;
        }

        // safe: advance
        st.position = nextStep;
        await saveRound(st);

        const k = st.position;
        const cashMult = multiplierFor(st.steps, st.bombs, k, HOUSE_EDGE);
        const nextMult = multiplierFor(st.steps, st.bombs, k + 1, HOUSE_EDGE);

        // show potential payout but clamp to rtpCap for real
        const rawPotential = +(st.stake * cashMult).toFixed(2);
        const potential = (mode === "real" && st.rtpCap != null)
            ? Math.min(rawPotential, st.rtpCap)
            : rawPotential;

        const resp = {
            game: "ChickenRoad",
            mode,
            round_id: st.roundId,
            position: k,
            outcome: "safe" as const,
            cashout_multiplier: cashMult,
            potential_payout: potential,
            next_cashout_multiplier: nextMult
        };
        if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
        return resp;
    });
}

// ========== CASHOUT ==========
export async function cashoutRound(
    sess: ProviderSession,
    req: CashInput,
    idemKey?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    const hit = await getIdemByKey(mode, sess.sid, idemKey);
    if (hit) return hit;

    return await withRoundLock(sess.sid, req.roundId, async () => {
        const st = await loadRound(sess.sid, req.roundId);
        if (!st) throw AppError.notFound("ROUND_NOT_FOUND");
        if (st.status !== "active") {
            if (st.status === "bust") throw AppError.badRequest("ROUND_BUST");
            if (st.status === "cashed") throw AppError.badRequest("ROUND_ALREADY_CASHED");
        }
        if (st.position < 1) throw AppError.badRequest("NOTHING_TO_CASHOUT");

        const k = st.position;
        const mult = multiplierFor(st.steps, st.bombs, k, HOUSE_EDGE);
        let payout = +(st.stake * mult).toFixed(2);

        // Clamp to configured caps (and to planned rtpCap in REAL)
        const cfg = await loadGameCfg();
        payout = Math.min(
            payout,
            cfg.per_bet_cap,
            cfg.per_ticket_cap,
            cfg.per_user_daily_cap,
            ...(mode === "real" && st.rtpCap != null ? [st.rtpCap] : [])
        );

        if (mode === "demo") {
            const bal = await getDemoBalance(sess);
            await setDemoBalance(sess, +(bal + payout).toFixed(2));
        } else {
            // RTP settle (payin += stake, payout += payout, counters--)
            if (!st.rtpDayKey) {
                const yymmdd = toYYMMDD();
                st.rtpDayKey = rk.day(GAME_CODE, yymmdd); // fallback
            }
            await redis.spSettle(st.rtpDayKey!, st.stake, payout);

            const operator = await findByPortalName(sess.portalName);
            const operatorSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
            const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            const winTxn = `${st.roundId}-W`;
            await withdraw(opCtx, {
                TransactionId: winTxn,
                TransactionType: "WinAmount",
                Amount: payout,
                CurrencyCode: st.currency,
                TransactionInfo: {
                    Source: "ChickenRoad",
                    GameName: "ChickenRoad",
                    RoundId: st.roundId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: st.serverSeed,
                    ServerSeedHash: st.serverSeedHash,
                    ClientSeed: st.clientSeed,
                    Position: st.position,
                    Steps: st.steps,
                    Bombs: st.bombs
                }
            });
        }

        st.status = "cashed";
        await saveRound(st);

        const resp = {
            game: "ChickenRoad",
            mode,
            round_id: st.roundId,
            result: "cashed",
            position: st.position,
            multiplier: mult,
            payout,
            currency: st.currency,
            // reveal proof now
            server_seed: st.serverSeed,
            server_seed_hash: st.serverSeedHash,
            client_seed: st.clientSeed,
            bomb_steps: st.bombSteps,
            plan: (st.planTarget != null && st.planHardCap != null) ? { target: st.planTarget, hardCap: st.planHardCap } : undefined
        };
        if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
        return resp;
    });
}

export type Mode = keyof typeof PRESETS; // "easy" | "normal" | "medium" | "hard"

/** Build odds array 1..(steps-bombs) using the exact same math as in-game cashout.
 * Stake-included multipliers; e.g., 2.00 = even-money profit.
 */
export function getChickenOdds(mode: Mode, stepsOverride?: number) {
    const preset = PRESETS[mode];
    const T = stepsOverride ?? preset.steps;
    const M = preset.bombs;

    const maxK = Math.max(0, T - M); // you can't get past T-M safe steps
    const odds: number[] = [];
    for (let k = 1; k <= maxK; k++) {
        odds.push(+multiplierFor(T, M, k, HOUSE_EDGE).toFixed(2));
    }
    return {
        game: "ChickenRoad",
        mode,
        steps: T,
        bombs: M,
        house_edge: HOUSE_EDGE,
        odds
    };
}
