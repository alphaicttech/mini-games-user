"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.chickenOdds = exports.chickenOddsValidate = exports.cashout = exports.cashoutValidate = exports.step = exports.stepValidate = exports.start = exports.startValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const StartBody = zod_1.z.object({
    amount: zod_1.z.number().positive(),
    difficulty: zod_1.z.enum(["easy", "normal", "medium", "hard"]),
    client_seed: zod_1.z.string().min(1).optional()
});
exports.startValidate = (0, validate_1.validateBody)(StartBody);
exports.start = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { amount, difficulty, client_seed } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const result = yield (0, service_1.startChickenRound)(sess, { amount, difficulty, clientSeed: client_seed }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
const StepBody = zod_1.z.object({
    round_id: zod_1.z.string().uuid()
});
exports.stepValidate = (0, validate_1.validateBody)(StepBody);
exports.step = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { round_id } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const result = yield (0, service_1.stepForward)(sess, { roundId: round_id }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
const CashoutBody = zod_1.z.object({ round_id: zod_1.z.string().uuid() });
exports.cashoutValidate = (0, validate_1.validateBody)(CashoutBody);
exports.cashout = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { round_id } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const result = yield (0, service_1.cashoutRound)(sess, { roundId: round_id }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
const Query = zod_1.z.object({
    mode: zod_1.z.enum(["easy", "medium", "normal", "hard"]).optional(),
    steps: zod_1.z.coerce.number().int().min(1).max(100).optional() // default 20
});
exports.chickenOddsValidate = (0, validate_1.validateQuery)(Query);
// type Mode = "easy" | "medium" | "hard" | "hardcore";
// export const chickenOdds = asyncHandler(async (req: Request, res: Response) => {
//     const { mode, steps } = Query.parse(req.query);
//     const data = getChickenOdds(mode as Mode, steps ?? 30);
//     const easy = getChickenOdds("easy", 30);
//     const medium = getChickenOdds("medium", 30);
//     const hard = getChickenOdds("hard", 30);
//     const hardcore = getChickenOdds("hardcore", 30);
//     if (!mode) {
//         return res.json({ ok: true, easy, medium, hard, hardcore });
//     }
//     return res.json({ ok: true, ...data });
// });
// controller
const OddsQuery = zod_1.z.object({
    mode: zod_1.z.enum(["easy", "medium", "normal", "hard"]),
    steps: zod_1.z.coerce.number().int().min(1).max(200).optional()
});
exports.chickenOdds = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { mode, steps } = OddsQuery.parse(req.query);
    const easy = (0, service_1.getChickenOdds)("easy", 30);
    const normal = (0, service_1.getChickenOdds)("normal", 30);
    const medium = (0, service_1.getChickenOdds)("medium", 30);
    const hard = (0, service_1.getChickenOdds)("hard", 30);
    if (!mode) {
        res.json({ ok: true, easy, normal, medium, hard });
    }
    const data = (0, service_1.getChickenOdds)(mode, steps);
    return res.json(Object.assign({ ok: true }, data));
    //res.json({ ok: true, ...data, easy, normal, medium, hard });
}));
