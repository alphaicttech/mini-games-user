// /var/www/typesafe/alpha-mini/src/modules/games/chicken-road/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody, validateQuery } from "../../../middleware/validate";
import { startChickenRound, stepForward, cashoutRound, getChickenOdds, Mode } from "./service";

const StartBody = z.object({
    amount: z.number().positive(),
    difficulty: z.enum(["easy", "normal", "medium", "hard"]),
    client_seed: z.string().min(1).optional()
});
export const startValidate = validateBody(StartBody);

export const start = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { amount, difficulty, client_seed } = req.body as z.infer<typeof StartBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await startChickenRound(sess, { amount, difficulty, clientSeed: client_seed }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});

const StepBody = z.object({
    round_id: z.string().uuid()
});
export const stepValidate = validateBody(StepBody);

export const step = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { round_id } = req.body as z.infer<typeof StepBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await stepForward(sess, { roundId: round_id }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});

const CashoutBody = z.object({ round_id: z.string().uuid() });
export const cashoutValidate = validateBody(CashoutBody);

export const cashout = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { round_id } = req.body as z.infer<typeof CashoutBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await cashoutRound(sess, { roundId: round_id }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});


const Query = z.object({
    mode: z.enum(["easy", "medium", "normal", "hard"]).optional(),
    steps: z.coerce.number().int().min(1).max(100).optional()  // default 20
});

export const chickenOddsValidate = validateQuery(Query);


// type Mode = "easy" | "medium" | "hard" | "hardcore";

// export const chickenOdds = asyncHandler(async (req: Request, res: Response) => {
//     const { mode, steps } = Query.parse(req.query);
//     const data = getChickenOdds(mode as Mode, steps ?? 30);

//     const easy = getChickenOdds("easy", 30);
//     const medium = getChickenOdds("medium", 30);
//     const hard = getChickenOdds("hard", 30);
//     const hardcore = getChickenOdds("hardcore", 30);

//     if (!mode) {
//         return res.json({ ok: true, easy, medium, hard, hardcore });
//     }

//     return res.json({ ok: true, ...data });
// });

// controller
const OddsQuery = z.object({
    mode: z.enum(["easy", "medium", "normal", "hard"]),
    steps: z.coerce.number().int().min(1).max(200).optional()
});
export const chickenOdds = asyncHandler(async (req: Request, res: Response) => {
    const { mode, steps } = OddsQuery.parse(req.query);
    const easy = getChickenOdds("easy", 30);
    const normal = getChickenOdds("normal", 30);
    const medium = getChickenOdds("medium", 30);
    const hard = getChickenOdds("hard", 30);

    if (!mode) {
        res.json({ ok: true, easy, normal, medium, hard });
    }

    const data = getChickenOdds(mode as Mode, steps);
    return res.json({ ok: true, ...data });
    //res.json({ ok: true, ...data, easy, normal, medium, hard });
});