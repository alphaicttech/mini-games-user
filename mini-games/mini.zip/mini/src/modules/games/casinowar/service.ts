import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP integration (accounting only) ====
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { redis as redisClient } from "../../../config/redis";

/** ------------ Config & Types ------------ */
const IDEM_TTL = 24 * 60 * 60;

type Cfg = {
    decks: number;
    ace_high: boolean;
    burn_before_war: number;
    war_payout: number;               // stake-included return on WAR wager
    original_on_war: "push" | "pay";  // push=1.0x original; pay=2.0x original
    min_stake: number;
    max_stake: number;
};

type Card = { r: number; s: number };    // rank 0..12, suit 0..3
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];

type RoundState = {
    round_id: string;
    sid: string;
    portalName?: string;
    currency: string;

    server_seed: string;
    server_seed_hash: string;
    client_seed: string;

    cfg: Cfg;
    shoe: Card[];
    shoe_idx: number;

    stake: number;
    txn_placebet: string;
    initial: { player: Card; dealer: Card; outcome: "PLAYER" | "DEALER" | "TIE" };
    choice?: "SURRENDER" | "WAR";

    war?: {
        burn: Card[];
        player: Card;
        dealer: Card;
        outcome: "PLAYER" | "DEALER" | "TIE";
        txn_war_bet?: string;
    };

    settled: boolean;
    created_at: number;

    // RTP (REAL mode)
    mode: "real" | "demo";
    rtpDayKey?: string;
    rtpEntered?: number;  // total stake entered (base + war)
};

const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const hmacHex = (k: string, m: string) => crypto.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8: string) => parseInt(h8, 16) >>> 0;
const r01 = (server: string, client: string, i: number, tag: string) =>
    u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;

function buildShoe(decks: number): Card[] {
    const one: Card[] = [];
    for (let s = 0; s < 4; s++) for (let r = 0; r < 13; r++) one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => ({ ...c })));
}
function shuffle(arr: Card[], server: string, client: string) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k]; a[k] = a[j]; a[j] = t;
    }
    return a;
}
function rankVal(r: number, ace_high: boolean) {
    if (ace_high) return r === 0 ? 14 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
    return r === 0 ? 1 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
}
const fmt = (c: Card) => ({ rank: RANKS[c.r], suit: SUITS[c.s] });

/** ------------ Redis storage / locks / idem ------------ */
const rKey = (sid: string, id: string) => `war:round:${sid}:${id}`;
async function saveRound(r: RoundState) { await redis.set(rKey(r.sid, r.round_id), JSON.stringify(r), 24 * 60 * 60); }
async function loadRound(sid: string, id: string) { const v = await redis.get(rKey(sid, id)); return v ? JSON.parse(v) as RoundState : null; }
async function withLock<T>(sid: string, id: string, fn: () => Promise<T>) {
    const lk = `war:lock:${sid}:${id}`;
    const ok = await (rawRedis as any).set(lk, "1", "EX", 3, "NX");
    if (ok !== "OK") throw AppError.conflict("Round is busy, retry");
    try { return await fn(); } finally { await rawRedis.del(lk); }
}
// mode-scoped idempotency
function idemKey(mode: "real" | "demo", sid: string, action: string, key: string) { return `idem:${mode}:war:${action}:${sid}:${key}`; }
async function getIdem(mode: "real" | "demo", sid: string, action: string, key?: string) { if (!key) return null; const v = await redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) : null; }
async function setIdem(mode: "real" | "demo", sid: string, action: string, key: string, payload: any) { await redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); }

/** ------------ Demo wallet ------------ */
async function getDemoBalance(sess: ProviderSession) {
    const k = `demo:bal:${sess.sid}`; const v = await redis.get(k);
    if (v) return Number(v);
    const base = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(k, String(base), 2 * 60 * 60);
    return base;
}
async function setDemoBalance(sess: ProviderSession, amount: number) { await redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60); }

/** ------------ Public services ------------ */
export async function dealSvc(
    sess: ProviderSession,
    input: { stake: number; client_seed?: string; cfg: Partial<Cfg> },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "deal", idem); if (hit) return hit; }

    const stake = Number(input.stake);
    const cfg: Cfg = {
        decks: input.cfg?.decks ?? 6,
        ace_high: input.cfg?.ace_high ?? true,
        burn_before_war: input.cfg?.burn_before_war ?? 1,
        war_payout: input.cfg?.war_payout ?? 2.0,
        original_on_war: input.cfg?.original_on_war ?? "push",
        min_stake: input.cfg?.min_stake ?? 0.1,
        max_stake: input.cfg?.max_stake ?? 10000,
    };

    if (!(stake > 0)) throw AppError.badRequest("Invalid stake");
    if (stake < cfg.min_stake) throw AppError.badRequest(`Min stake is ${cfg.min_stake}`);
    if (stake > cfg.max_stake) throw AppError.badRequest(`Max stake is ${cfg.max_stake}`);

    const client_seed = input.client_seed ?? sess.clientExternalKey ?? sess.userName ?? "client";
    const server_seed = crypto.randomBytes(32).toString("hex");
    const server_seed_hash = sha256(server_seed);

    // Shoe & initial deal
    const shoe = shuffle(buildShoe(cfg.decks), server_seed, client_seed);
    let idx = 0; const draw = () => shoe[idx++];
    const p = draw(); const d = draw();

    const pv = rankVal(p.r, cfg.ace_high), dv = rankVal(d.r, cfg.ace_high);
    const outcome: "PLAYER" | "DEALER" | "TIE" = pv > dv ? "PLAYER" : (dv > pv ? "DEALER" : "TIE");

    // Debit initial stake
    const txnId = randomUUID();
    if (mode === "demo") {
        const bal = await getDemoBalance(sess); if (bal < stake) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - stake).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, {
            TransactionId: txnId, TransactionType: "PlaceBet", Amount: stake, CurrencyCode: sess.currency,
            TransactionInfo: { Source: "CasinoWar", GameName: "CasinoWar", RoundId: txnId, GameNumber: Date.now().toString(), ServerSeedHash: server_seed_hash, ClientSeed: client_seed, Config: cfg }
        });
    }

    const round: RoundState = {
        round_id: randomUUID(),
        sid: sess.sid,
        portalName: sess.portalName,
        currency: sess.currency,
        server_seed, server_seed_hash, client_seed,
        cfg, shoe, shoe_idx: idx,
        stake, txn_placebet: txnId,
        initial: { player: p, dealer: d, outcome },
        settled: outcome !== "TIE",
        created_at: Date.now(),
        mode,
        rtpEntered: 0
    };

    // RTP enter base stake (REAL)
    if (mode === "real") {
        const yymmdd = toYYMMDD();
        round.rtpDayKey = rk.day("casinowar", yymmdd);           // use your game code key here (e.g., 'casinowar')
        await redisClient.hsetnx(round.rtpDayKey, "rtp_target", 0.90);
        await redisClient.spEnter(round.rtpDayKey, stake);
        round.rtpEntered = (round.rtpEntered ?? 0) + stake;
    }

    await saveRound(round);

    // If already settled (PLAYER/DEALER), settle immediately
    let payload: any = statusPayload(round, round.settled);
    if (round.settled) {
        // PLAYER → 2.0x return; DEALER → 0.0x
        const mult = round.initial.outcome === "PLAYER" ? 2.0 : 0.0;
        const payout = +(round.stake * mult).toFixed(2);
        payload = await finalizeAndCredit(round, sess, payout, {
            mode: "BASE",
            base: { return_multiplier: mult, payout },
            war: null
        });
    }

    if (idem) await setIdem(mode, sess.sid, "deal", idem, payload);
    return payload;
}

export async function choiceSvc(
    sess: ProviderSession,
    input: { round_id: string; choice: "SURRENDER" | "WAR" },
    idem?: string
) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    if (idem) { const hit = await getIdem(mode, sess.sid, "choice", idem); if (hit) return hit; }

    return withLock(sess.sid, input.round_id, async () => {
        const r = await loadRound(sess.sid, input.round_id);
        if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
        if (r.initial.outcome !== "TIE") throw AppError.badRequest("CHOICE_ONLY_ON_TIE");
        if (r.settled) return statusPayload(r, true);
        if (r.choice) throw AppError.conflict("CHOICE_ALREADY_MADE");

        r.choice = input.choice;

        if (input.choice === "SURRENDER") {
            const payout = +(r.stake * 0.5).toFixed(2); // stake-included
            const resp = await finalizeAndCredit(r, sess, payout, {
                mode: "SURRENDER",
                base: { return_multiplier: 0.5, payout },
                war: null
            });
            if (idem) await setIdem(mode, sess.sid, "choice", idem, resp);
            return resp;
        }

        // WAR path: debit additional stake equal to base
        const warTxn = `${r.server_seed_hash}-WAR`;
        if (mode === "demo") {
            const bal = await getDemoBalance(sess); if (bal < r.stake) throw AppError.badRequest("Insufficient FUN balance for WAR");
            await setDemoBalance(sess, +(bal - r.stake).toFixed(2));
        } else {
            const operator = await findByPortalName(sess.portalName);
            const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            await deposit(opCtx, {
                TransactionId: warTxn, TransactionType: "PlaceBet", Amount: r.stake, CurrencyCode: r.currency,
                TransactionInfo: { Source: "CasinoWar", GameName: "CasinoWar", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:war` }
            });
            // RTP enter extra stake
            if (r.rtpDayKey) { await redisClient.spEnter(r.rtpDayKey, r.stake); r.rtpEntered = (r.rtpEntered ?? 0) + r.stake; }
        }

        // Burn then draw war cards
        const burn: Card[] = [];
        for (let i = 0; i < r.cfg.burn_before_war; i++) burn.push(r.shoe[r.shoe_idx++]);
        const pw = r.shoe[r.shoe_idx++], dw = r.shoe[r.shoe_idx++];
        const pv = rankVal(pw.r, r.cfg.ace_high), dv = rankVal(dw.r, r.cfg.ace_high);
        const wOutcome: "PLAYER" | "DEALER" | "TIE" = pv > dv ? "PLAYER" : (dv > pv ? "DEALER" : "TIE");

        r.war = { burn, player: pw, dealer: dw, outcome: wOutcome, txn_war_bet: warTxn };

        // Compute payouts (stake-included)
        let baseMult = 0.0, warMult = 0.0;
        if (wOutcome === "DEALER") {
            baseMult = 0.0; warMult = 0.0;
        } else if (wOutcome === "PLAYER" || wOutcome === "TIE") {
            baseMult = (r.cfg.original_on_war === "push") ? 1.0 : 2.0;
            warMult = r.cfg.war_payout;
        }
        const basePayout = +(r.stake * baseMult).toFixed(2);
        const warPayout = +(r.stake * warMult).toFixed(2);
        const totalPayout = +(basePayout + warPayout).toFixed(2);

        const resp = await finalizeAndCredit(r, sess, totalPayout, {
            mode: "WAR",
            base: { return_multiplier: baseMult, payout: basePayout },
            war: { return_multiplier: warMult, payout: warPayout, burn_count: r.cfg.burn_before_war }
        });

        if (idem) await setIdem(mode, sess.sid, "choice", idem, resp);
        return resp;
    });
}

export async function statusSvc(sess: ProviderSession, input: { round_id: string }) {
    const r = await loadRound(sess.sid, input.round_id);
    if (!r) throw AppError.notFound("ROUND_NOT_FOUND");
    return statusPayload(r, r.settled);
}

/** ------------ Settlement helpers (RTP + credit) ------------ */
async function finalizeAndCredit(
    r: RoundState,
    sess: ProviderSession,
    payoutTotal: number,
    meta: {
        mode: "BASE" | "SURRENDER" | "WAR",
        base: { return_multiplier: number; payout: number },
        war: { return_multiplier: number; payout: number; burn_count?: number } | null
    }
) {
    // RTP settle accounting (REAL): settle everything entered for this round
    if (r.mode === "real" && r.rtpDayKey && (r.rtpEntered ?? 0) > 0) {
        await redisClient.spSettle(r.rtpDayKey, r.rtpEntered!, payoutTotal);
        r.rtpEntered = 0; // consumed
    }

    // Operator credit (or demo balance)
    if (sess.mode === "demo") {
        const bal = await getDemoBalance(sess);
        await setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
    } else if (payoutTotal > 0) {
        const operator = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, {
            TransactionId: `${r.server_seed_hash}-W`,
            TransactionType: "WinAmount",
            Amount: payoutTotal,
            CurrencyCode: r.currency,
            TransactionInfo: {
                Source: "CasinoWar",
                GameName: "CasinoWar",
                RoundId: r.server_seed_hash,
                GameNumber: `${Date.now()}`,
                ServerSeed: r.server_seed,
                ServerSeedHash: r.server_seed_hash,
                ClientSeed: r.client_seed,
                Initial: { player: fmt(r.initial.player), dealer: fmt(r.initial.dealer), outcome: r.initial.outcome },
                Choice: r.choice ?? null,
                War: r.war ? {
                    burn: (r.war.burn || []).map(fmt),
                    player: fmt(r.war.player),
                    dealer: fmt(r.war.dealer),
                    outcome: r.war.outcome
                } : null,
                Returns: meta
            }
        });
    }

    r.settled = true;
    await saveRound(r);
    return statusPayload(r, true, meta);
}

/** ------------ Response builder ------------ */
function statusPayload(
    r: RoundState,
    settled: boolean,
    returns?: { mode: "BASE" | "SURRENDER" | "WAR", base: { return_multiplier: number; payout: number }, war: { return_multiplier: number; payout: number; burn_count?: number } | null }
) {
    return {
        game: "CasinoWar",
        mode: r.mode,
        round_id: r.round_id,
        currency: r.currency,
        settled,
        cfg: {
            decks: r.cfg.decks,
            ace_high: r.cfg.ace_high,
            burn_before_war: r.cfg.burn_before_war,
            war_payout: r.cfg.war_payout,
            original_on_war: r.cfg.original_on_war
        },
        stake: r.stake,
        initial: {
            player: fmt(r.initial.player),
            dealer: fmt(r.initial.dealer),
            outcome: r.initial.outcome
        },
        choice: r.choice ?? null,
        war: r.war ? {
            burn_count: r.cfg.burn_before_war,
            player: fmt(r.war.player),
            dealer: fmt(r.war.dealer),
            outcome: r.war.outcome
        } : null,
        actions: {
            can_choose: (!settled && r.initial.outcome === "TIE" && !r.choice),
            can_surrender: (!settled && r.initial.outcome === "TIE" && !r.choice),
            can_war: (!settled && r.initial.outcome === "TIE" && !r.choice)
        },
        returns: returns ?? undefined,
        fairness: {
            server_seed_hash: r.server_seed_hash,
            server_seed: settled ? r.server_seed : undefined,
            client_seed: r.client_seed,
            method: "Fisher–Yates shoe via HMAC-SHA256(server_seed, `${client_seed}:i:shoe`); war burns then draws"
        }
    };
}
