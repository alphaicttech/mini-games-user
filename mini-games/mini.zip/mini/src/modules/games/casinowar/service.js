"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dealSvc = dealSvc;
exports.choiceSvc = choiceSvc;
exports.statusSvc = statusSvc;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP integration (accounting only) ====
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const redis_2 = require("../../../config/redis");
/** ------------ Config & Types ------------ */
const IDEM_TTL = 24 * 60 * 60;
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["S", "H", "D", "C"];
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
const hmacHex = (k, m) => crypto_1.default.createHmac("sha256", k).update(m).digest("hex");
const u32 = (h8) => parseInt(h8, 16) >>> 0;
const r01 = (server, client, i, tag) => u32(hmacHex(server, `${client}:${i}:${tag}`).slice(0, 8)) / 4294967296;
function buildShoe(decks) {
    const one = [];
    for (let s = 0; s < 4; s++)
        for (let r = 0; r < 13; r++)
            one.push({ r, s });
    return Array.from({ length: decks }).flatMap(() => one.map(c => (Object.assign({}, c))));
}
function shuffle(arr, server, client) {
    const a = arr.slice();
    for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(r01(server, client, k, "shoe") * (k + 1));
        const t = a[k];
        a[k] = a[j];
        a[j] = t;
    }
    return a;
}
function rankVal(r, ace_high) {
    if (ace_high)
        return r === 0 ? 14 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
    return r === 0 ? 1 : (r >= 1 && r <= 9 ? r + 1 : 10 + (r - 9));
}
const fmt = (c) => ({ rank: RANKS[c.r], suit: SUITS[c.s] });
/** ------------ Redis storage / locks / idem ------------ */
const rKey = (sid, id) => `war:round:${sid}:${id}`;
function saveRound(r) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(rKey(r.sid, r.round_id), JSON.stringify(r), 24 * 60 * 60); });
}
function loadRound(sid, id) {
    return __awaiter(this, void 0, void 0, function* () { const v = yield redis_1.redis.get(rKey(sid, id)); return v ? JSON.parse(v) : null; });
}
function withLock(sid, id, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const lk = `war:lock:${sid}:${id}`;
        const ok = yield redis_1.rawRedis.set(lk, "1", "EX", 3, "NX");
        if (ok !== "OK")
            throw errors_1.AppError.conflict("Round is busy, retry");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(lk);
        }
    });
}
// mode-scoped idempotency
function idemKey(mode, sid, action, key) { return `idem:${mode}:war:${action}:${sid}:${key}`; }
function getIdem(mode, sid, action, key) {
    return __awaiter(this, void 0, void 0, function* () { if (!key)
        return null; const v = yield redis_1.redis.get(idemKey(mode, sid, action, key)); return v ? JSON.parse(v) : null; });
}
function setIdem(mode, sid, action, key, payload) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(idemKey(mode, sid, action, key), JSON.stringify(payload), IDEM_TTL); });
}
/** ------------ Demo wallet ------------ */
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const k = `demo:bal:${sess.sid}`;
        const v = yield redis_1.redis.get(k);
        if (v)
            return Number(v);
        const base = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(k, String(base), 2 * 60 * 60);
        return base;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(`demo:bal:${sess.sid}`, String(amount), 2 * 60 * 60); });
}
/** ------------ Public services ------------ */
function dealSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u;
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "deal", idem);
            if (hit)
                return hit;
        }
        const stake = Number(input.stake);
        const cfg = {
            decks: (_b = (_a = input.cfg) === null || _a === void 0 ? void 0 : _a.decks) !== null && _b !== void 0 ? _b : 6,
            ace_high: (_d = (_c = input.cfg) === null || _c === void 0 ? void 0 : _c.ace_high) !== null && _d !== void 0 ? _d : true,
            burn_before_war: (_f = (_e = input.cfg) === null || _e === void 0 ? void 0 : _e.burn_before_war) !== null && _f !== void 0 ? _f : 1,
            war_payout: (_h = (_g = input.cfg) === null || _g === void 0 ? void 0 : _g.war_payout) !== null && _h !== void 0 ? _h : 2.0,
            original_on_war: (_k = (_j = input.cfg) === null || _j === void 0 ? void 0 : _j.original_on_war) !== null && _k !== void 0 ? _k : "push",
            min_stake: (_m = (_l = input.cfg) === null || _l === void 0 ? void 0 : _l.min_stake) !== null && _m !== void 0 ? _m : 0.1,
            max_stake: (_p = (_o = input.cfg) === null || _o === void 0 ? void 0 : _o.max_stake) !== null && _p !== void 0 ? _p : 10000,
        };
        if (!(stake > 0))
            throw errors_1.AppError.badRequest("Invalid stake");
        if (stake < cfg.min_stake)
            throw errors_1.AppError.badRequest(`Min stake is ${cfg.min_stake}`);
        if (stake > cfg.max_stake)
            throw errors_1.AppError.badRequest(`Max stake is ${cfg.max_stake}`);
        const client_seed = (_s = (_r = (_q = input.client_seed) !== null && _q !== void 0 ? _q : sess.clientExternalKey) !== null && _r !== void 0 ? _r : sess.userName) !== null && _s !== void 0 ? _s : "client";
        const server_seed = crypto_1.default.randomBytes(32).toString("hex");
        const server_seed_hash = sha256(server_seed);
        // Shoe & initial deal
        const shoe = shuffle(buildShoe(cfg.decks), server_seed, client_seed);
        let idx = 0;
        const draw = () => shoe[idx++];
        const p = draw();
        const d = draw();
        const pv = rankVal(p.r, cfg.ace_high), dv = rankVal(d.r, cfg.ace_high);
        const outcome = pv > dv ? "PLAYER" : (dv > pv ? "DEALER" : "TIE");
        // Debit initial stake
        const txnId = (0, crypto_1.randomUUID)();
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < stake)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - stake).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_t = sess.opSessionId) !== null && _t !== void 0 ? _t : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId, TransactionType: "PlaceBet", Amount: stake, CurrencyCode: sess.currency,
                TransactionInfo: { Source: "CasinoWar", GameName: "CasinoWar", RoundId: txnId, GameNumber: Date.now().toString(), ServerSeedHash: server_seed_hash, ClientSeed: client_seed, Config: cfg }
            });
        }
        const round = {
            round_id: (0, crypto_1.randomUUID)(),
            sid: sess.sid,
            portalName: sess.portalName,
            currency: sess.currency,
            server_seed, server_seed_hash, client_seed,
            cfg, shoe, shoe_idx: idx,
            stake, txn_placebet: txnId,
            initial: { player: p, dealer: d, outcome },
            settled: outcome !== "TIE",
            created_at: Date.now(),
            mode,
            rtpEntered: 0
        };
        // RTP enter base stake (REAL)
        if (mode === "real") {
            const yymmdd = (0, date_1.toYYMMDD)();
            round.rtpDayKey = redis_keys_1.rk.day("casinowar", yymmdd); // use your game code key here (e.g., 'casinowar')
            yield redis_2.redis.hsetnx(round.rtpDayKey, "rtp_target", 0.90);
            yield redis_2.redis.spEnter(round.rtpDayKey, stake);
            round.rtpEntered = ((_u = round.rtpEntered) !== null && _u !== void 0 ? _u : 0) + stake;
        }
        yield saveRound(round);
        // If already settled (PLAYER/DEALER), settle immediately
        let payload = statusPayload(round, round.settled);
        if (round.settled) {
            // PLAYER → 2.0x return; DEALER → 0.0x
            const mult = round.initial.outcome === "PLAYER" ? 2.0 : 0.0;
            const payout = +(round.stake * mult).toFixed(2);
            payload = yield finalizeAndCredit(round, sess, payout, {
                mode: "BASE",
                base: { return_multiplier: mult, payout },
                war: null
            });
        }
        if (idem)
            yield setIdem(mode, sess.sid, "deal", idem, payload);
        return payload;
    });
}
function choiceSvc(sess, input, idem) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        if (idem) {
            const hit = yield getIdem(mode, sess.sid, "choice", idem);
            if (hit)
                return hit;
        }
        return withLock(sess.sid, input.round_id, () => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const r = yield loadRound(sess.sid, input.round_id);
            if (!r)
                throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
            if (r.initial.outcome !== "TIE")
                throw errors_1.AppError.badRequest("CHOICE_ONLY_ON_TIE");
            if (r.settled)
                return statusPayload(r, true);
            if (r.choice)
                throw errors_1.AppError.conflict("CHOICE_ALREADY_MADE");
            r.choice = input.choice;
            if (input.choice === "SURRENDER") {
                const payout = +(r.stake * 0.5).toFixed(2); // stake-included
                const resp = yield finalizeAndCredit(r, sess, payout, {
                    mode: "SURRENDER",
                    base: { return_multiplier: 0.5, payout },
                    war: null
                });
                if (idem)
                    yield setIdem(mode, sess.sid, "choice", idem, resp);
                return resp;
            }
            // WAR path: debit additional stake equal to base
            const warTxn = `${r.server_seed_hash}-WAR`;
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                if (bal < r.stake)
                    throw errors_1.AppError.badRequest("Insufficient FUN balance for WAR");
                yield setDemoBalance(sess, +(bal - r.stake).toFixed(2));
            }
            else {
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                yield (0, client_1.deposit)(opCtx, {
                    TransactionId: warTxn, TransactionType: "PlaceBet", Amount: r.stake, CurrencyCode: r.currency,
                    TransactionInfo: { Source: "CasinoWar", GameName: "CasinoWar", RoundId: r.server_seed_hash, GameNumber: `${Date.now()}:war` }
                });
                // RTP enter extra stake
                if (r.rtpDayKey) {
                    yield redis_2.redis.spEnter(r.rtpDayKey, r.stake);
                    r.rtpEntered = ((_b = r.rtpEntered) !== null && _b !== void 0 ? _b : 0) + r.stake;
                }
            }
            // Burn then draw war cards
            const burn = [];
            for (let i = 0; i < r.cfg.burn_before_war; i++)
                burn.push(r.shoe[r.shoe_idx++]);
            const pw = r.shoe[r.shoe_idx++], dw = r.shoe[r.shoe_idx++];
            const pv = rankVal(pw.r, r.cfg.ace_high), dv = rankVal(dw.r, r.cfg.ace_high);
            const wOutcome = pv > dv ? "PLAYER" : (dv > pv ? "DEALER" : "TIE");
            r.war = { burn, player: pw, dealer: dw, outcome: wOutcome, txn_war_bet: warTxn };
            // Compute payouts (stake-included)
            let baseMult = 0.0, warMult = 0.0;
            if (wOutcome === "DEALER") {
                baseMult = 0.0;
                warMult = 0.0;
            }
            else if (wOutcome === "PLAYER" || wOutcome === "TIE") {
                baseMult = (r.cfg.original_on_war === "push") ? 1.0 : 2.0;
                warMult = r.cfg.war_payout;
            }
            const basePayout = +(r.stake * baseMult).toFixed(2);
            const warPayout = +(r.stake * warMult).toFixed(2);
            const totalPayout = +(basePayout + warPayout).toFixed(2);
            const resp = yield finalizeAndCredit(r, sess, totalPayout, {
                mode: "WAR",
                base: { return_multiplier: baseMult, payout: basePayout },
                war: { return_multiplier: warMult, payout: warPayout, burn_count: r.cfg.burn_before_war }
            });
            if (idem)
                yield setIdem(mode, sess.sid, "choice", idem, resp);
            return resp;
        }));
    });
}
function statusSvc(sess, input) {
    return __awaiter(this, void 0, void 0, function* () {
        const r = yield loadRound(sess.sid, input.round_id);
        if (!r)
            throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
        return statusPayload(r, r.settled);
    });
}
/** ------------ Settlement helpers (RTP + credit) ------------ */
function finalizeAndCredit(r, sess, payoutTotal, meta) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        // RTP settle accounting (REAL): settle everything entered for this round
        if (r.mode === "real" && r.rtpDayKey && ((_a = r.rtpEntered) !== null && _a !== void 0 ? _a : 0) > 0) {
            yield redis_2.redis.spSettle(r.rtpDayKey, r.rtpEntered, payoutTotal);
            r.rtpEntered = 0; // consumed
        }
        // Operator credit (or demo balance)
        if (sess.mode === "demo") {
            const bal = yield getDemoBalance(sess);
            yield setDemoBalance(sess, +(bal + payoutTotal).toFixed(2));
        }
        else if (payoutTotal > 0) {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, {
                TransactionId: `${r.server_seed_hash}-W`,
                TransactionType: "WinAmount",
                Amount: payoutTotal,
                CurrencyCode: r.currency,
                TransactionInfo: {
                    Source: "CasinoWar",
                    GameName: "CasinoWar",
                    RoundId: r.server_seed_hash,
                    GameNumber: `${Date.now()}`,
                    ServerSeed: r.server_seed,
                    ServerSeedHash: r.server_seed_hash,
                    ClientSeed: r.client_seed,
                    Initial: { player: fmt(r.initial.player), dealer: fmt(r.initial.dealer), outcome: r.initial.outcome },
                    Choice: (_c = r.choice) !== null && _c !== void 0 ? _c : null,
                    War: r.war ? {
                        burn: (r.war.burn || []).map(fmt),
                        player: fmt(r.war.player),
                        dealer: fmt(r.war.dealer),
                        outcome: r.war.outcome
                    } : null,
                    Returns: meta
                }
            });
        }
        r.settled = true;
        yield saveRound(r);
        return statusPayload(r, true, meta);
    });
}
/** ------------ Response builder ------------ */
function statusPayload(r, settled, returns) {
    var _a;
    return {
        game: "CasinoWar",
        mode: r.mode,
        round_id: r.round_id,
        currency: r.currency,
        settled,
        cfg: {
            decks: r.cfg.decks,
            ace_high: r.cfg.ace_high,
            burn_before_war: r.cfg.burn_before_war,
            war_payout: r.cfg.war_payout,
            original_on_war: r.cfg.original_on_war
        },
        stake: r.stake,
        initial: {
            player: fmt(r.initial.player),
            dealer: fmt(r.initial.dealer),
            outcome: r.initial.outcome
        },
        choice: (_a = r.choice) !== null && _a !== void 0 ? _a : null,
        war: r.war ? {
            burn_count: r.cfg.burn_before_war,
            player: fmt(r.war.player),
            dealer: fmt(r.war.dealer),
            outcome: r.war.outcome
        } : null,
        actions: {
            can_choose: (!settled && r.initial.outcome === "TIE" && !r.choice),
            can_surrender: (!settled && r.initial.outcome === "TIE" && !r.choice),
            can_war: (!settled && r.initial.outcome === "TIE" && !r.choice)
        },
        returns: returns !== null && returns !== void 0 ? returns : undefined,
        fairness: {
            server_seed_hash: r.server_seed_hash,
            server_seed: settled ? r.server_seed : undefined,
            client_seed: r.client_seed,
            method: "Fisher–Yates shoe via HMAC-SHA256(server_seed, `${client_seed}:i:shoe`); war burns then draws"
        }
    };
}
