// /var/www/typesafe/alpha-mini/src/modules/games/casinowar/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody, validateQuery } from "../../../middleware/validate";
import { dealSvc, choiceSvc, statusSvc } from "./service";

/** ---- Input validation ---- */
const DealBody = z.object({
    stake: z.number().positive(),
    client_seed: z.string().min(1).optional(),
    cfg: z.object({
        decks: z.number().int().min(1).max(8).default(6),
        ace_high: z.boolean().default(true),
        burn_before_war: z.number().int().min(0).max(10).default(1),
        war_payout: z.number().min(1).max(5).default(2.0),     // stake-included return on war wager (2.0 = 1:1)
        original_on_war: z.enum(["push", "pay"]).default("push"), // push=1.0x return of original stake; pay=2.0x
        min_stake: z.number().positive().default(0.1),
        max_stake: z.number().positive().default(10000),
    }).default({} as any)
});
export const dealValidate = validateBody(DealBody);

export const deal = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof DealBody>;
    const data = await dealSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

/** ---- Input validation ---- */
const ChoiceBody = z.object({
    round_id: z.string().uuid(),
    choice: z.enum(["SURRENDER", "WAR"])
});
export const choiceValidate = validateBody(ChoiceBody);

export const choice = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const idem = req.header("Idempotency-Key") || undefined;
    const body = req.body as z.infer<typeof ChoiceBody>;
    const data = await choiceSvc(sess, body, idem);
    if (idem) res.setHeader("Idempotency-Key", idem);
    res.json({ ok: true, ...data });
});

/** ---- Input validation ---- */
const StatusQuery = z.object({ round_id: z.string().uuid() });
export const statusValidate = validateQuery(StatusQuery);

export const status = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const data = await statusSvc(sess, req.query as any);
    res.json({ ok: true, ...data });
});
