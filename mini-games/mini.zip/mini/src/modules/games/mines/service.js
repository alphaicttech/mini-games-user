"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startMinesRound = startMinesRound;
exports.revealCell = revealCell;
exports.cashoutRound = cashoutRound;
const crypto_1 = __importStar(require("crypto"));
const redis_1 = require("../../../config/redis");
const errors_1 = require("../../../errors");
const operator_1 = require("../../../stores/operator");
const client_1 = require("../../../operator/client");
// ==== RTP + Config ====
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../../lib/redis-keys");
const date_1 = require("../../../lib/date");
const governor_1 = require("../../rtp/governor");
// ----- config -----
const GAME_CODE = "mines";
const GRID = 5; // 5x5
const IDEM_TTL = 24 * 60 * 60; // 24h for idempotency caches
const ROUND_TTL = 2 * 60 * 60; // 2h round TTL
const HOUSE_EDGE = 0.02; // 2%
const LIMITS = { min: 0.1, max: 10000 }; // adjust per-portal if needed
const PRESETS = {
    easy: { size: GRID, mines: 3 },
    normal: { size: GRID, mines: 5 },
    medium: { size: GRID, mines: 8 },
    hard: { size: GRID, mines: 10 },
};
// ----- redis keys (mode-scoped for idempotency) -----
const reqKey = (mode, sid, key) => `idem:${mode}:mines:req:${sid}:${key}`;
const roundKey = (sid, rid) => `round:mines:${sid}:${rid}`;
const lockKey = (sid, rid) => `lock:mines:${sid}:${rid}`;
// ----- fairness helpers -----
const sha256 = (s) => crypto_1.default.createHash("sha256").update(s).digest("hex");
/** Deterministic board: score each index by H(server_seed|client_seed|index), pick lowest N as bombs */
function chooseBombs(total, mines, serverSeed, clientSeed) {
    const scored = [];
    for (let i = 0; i < total; i++) {
        const h = sha256(`${serverSeed}|${clientSeed}|${i}`);
        const s = parseInt(h.slice(0, 8), 16); // 32-bit score
        scored.push({ i, s });
    }
    scored.sort((a, b) => a.s - b.s);
    return scored.slice(0, mines).map(x => x.i);
}
/** Cashout multiplier after k safe picks with n total cells, m mines, minus edge */
function multiplierFor(n, m, k, edge = HOUSE_EDGE) {
    if (k <= 0)
        return 1;
    if (k > n - m)
        k = n - m;
    // fair multiplier = C(n, k) / C(n - m, k) ; compute via product to avoid overflow
    let num = 1, den = 1;
    for (let i = 0; i < k; i++) {
        num *= (n - i);
        den *= (n - m - i);
    }
    const fair = num / den;
    return +(fair * (1 - edge)).toFixed(4);
}
// ----- demo ledger -----
function getDemoBalance(sess) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const key = `demo:bal:${sess.sid}`;
        const cached = yield redis_1.redis.get(key);
        if (cached)
            return Number(cached);
        const start = Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
        yield redis_1.redis.set(key, String(start), 2 * 60 * 60);
        return start;
    });
}
function setDemoBalance(sess, amount) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = `demo:bal:${sess.sid}`;
        yield redis_1.redis.set(key, String(amount), 2 * 60 * 60);
    });
}
// ----- idempotency (mode-scoped) -----
function getIdemByKey(mode, sid, key) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!key)
            return null;
        const v = yield redis_1.redis.get(reqKey(mode, sid, key));
        return v ? JSON.parse(v) : null;
    });
}
function setIdemByKey(mode, sid, key, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
    });
}
// ----- locking -----
function withRoundLock(sid, rid, fn) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = lockKey(sid, rid);
        const ok = yield redis_1.rawRedis.set(key, "1", "EX", 3, "NX");
        if (ok !== "OK")
            throw errors_1.AppError.badRequest("ROUND_BUSY");
        try {
            return yield fn();
        }
        finally {
            yield redis_1.rawRedis.del(key);
        }
    });
}
/** Persist/Load round */
function saveRound(st) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.set(roundKey(st.sid, st.roundId), JSON.stringify(st), ROUND_TTL);
    });
}
function loadRound(sid, rid) {
    return __awaiter(this, void 0, void 0, function* () {
        const v = yield redis_1.redis.get(roundKey(sid, rid));
        return v ? JSON.parse(v) : null;
    });
}
function loadGameCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha: Number(cfg.alpha),
            kappa: Number(cfg.kappa),
            beta: Number(cfg.beta),
            per_bet_cap: Number(cfg.per_bet_cap),
            per_ticket_cap: Number(cfg.per_ticket_cap),
            per_user_daily_cap: Number(cfg.per_user_daily_cap),
        };
    });
}
function demoPlan(totalStake, cfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}
// ====== START ======
function startMinesRound(sess, req, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        if (req.amount < LIMITS.min)
            throw errors_1.AppError.badRequest(`Min bet is ${LIMITS.min}`);
        if (req.amount > LIMITS.max)
            throw errors_1.AppError.badRequest(`Max bet is ${LIMITS.max}`);
        const mode = (sess.mode === "demo") ? "demo" : "real";
        const hit = yield getIdemByKey(mode, sess.sid, idemKey);
        if (hit)
            return hit;
        const preset = PRESETS[req.difficulty];
        const total = preset.size * preset.size;
        const clientSeed = (_c = (_b = (_a = req.clientSeed) !== null && _a !== void 0 ? _a : sess.clientExternalKey) !== null && _b !== void 0 ? _b : sess.userName) !== null && _c !== void 0 ? _c : "client";
        // --- debit first
        if (mode === "demo") {
            const bal = yield getDemoBalance(sess);
            if (bal < req.amount)
                throw errors_1.AppError.badRequest("Insufficient FUN balance");
            yield setDemoBalance(sess, +(bal - req.amount).toFixed(2));
        }
        else {
            const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const operatorSessionId = (_d = sess.opSessionId) !== null && _d !== void 0 ? _d : sess.sessionId;
            const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            const txnId = (0, crypto_1.randomUUID)();
            const probeSeed = crypto_1.default.randomBytes(32).toString("hex"); // just for metadata hash
            const probeHash = sha256(probeSeed);
            yield (0, client_1.deposit)(opCtx, {
                TransactionId: txnId,
                TransactionType: "PlaceBet",
                Amount: req.amount,
                CurrencyCode: sess.currency,
                TransactionInfo: {
                    Source: "Mines",
                    GameName: "BombMines",
                    RoundId: txnId,
                    GameNumber: Date.now().toString(),
                    ServerSeedHash: probeHash,
                    ClientSeed: clientSeed
                }
            });
        }
        // --- RTP / planning
        const cfg = yield loadGameCfg();
        let rtpDayKey;
        let plan = { hardCap: 0, softCap: 0, target: 0 };
        if (mode === "real") {
            const yymmdd = (0, date_1.toYYMMDD)();
            rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
            yield redis_1.redis.hsetnx(rtpDayKey, "rtp_target", 0.90);
            yield redis_1.redis.spEnter(rtpDayKey, req.amount); // active_users++, active_stake+=stake
            plan = yield (0, governor_1.spPlan)(GAME_CODE, req.amount, cfg, yymmdd); // {hardCap, softCap, target}
        }
        else {
            plan = demoPlan(req.amount, cfg);
        }
        const rtpCap = Math.min(plan.hardCap, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
        // --- choose fair server seed & bombs (no post-hoc manipulation)
        const serverSeed = crypto_1.default.randomBytes(32).toString("hex");
        const serverSeedHash = sha256(serverSeed);
        const bombs = chooseBombs(total, preset.mines, serverSeed, clientSeed);
        const roundId = (0, crypto_1.randomUUID)();
        const state = {
            sid: sess.sid,
            roundId,
            stake: req.amount,
            currency: sess.currency,
            mode,
            difficulty: req.difficulty,
            size: preset.size,
            total,
            mines: preset.mines,
            serverSeed, serverSeedHash, clientSeed,
            bombs,
            revealed: [],
            status: "active",
            createdAt: Date.now(),
            // RTP binding
            rtpDayKey,
            rtpCap,
            planTarget: plan.target,
            planHardCap: plan.hardCap,
        };
        yield saveRound(state);
        const nextMult = multiplierFor(total, preset.mines, 1, HOUSE_EDGE);
        const resp = {
            game: "BombMines",
            mode,
            round_id: roundId,
            stake: req.amount,
            currency: sess.currency,
            grid: { size: preset.size, total, mines: preset.mines },
            revealed_count: 0,
            next_cashout_multiplier: nextMult,
            server_seed_hash: serverSeedHash, // reveal only hash at start
            plan
        };
        if (idemKey)
            yield setIdemByKey(mode, sess.sid, idemKey, resp);
        return resp;
    });
}
// ====== REVEAL ======
function revealCell(sess, req, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        const hit = yield getIdemByKey(mode, sess.sid, idemKey);
        if (hit)
            return hit;
        const state = yield loadRound(sess.sid, req.roundId);
        if (!state)
            throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
        if (state.status !== "active")
            throw errors_1.AppError.badRequest("ROUND_CLOSED");
        if (req.index < 0 || req.index >= state.total)
            throw errors_1.AppError.badRequest("CELL_OUT_OF_RANGE");
        if (state.revealed.includes(req.index))
            throw errors_1.AppError.badRequest("CELL_ALREADY_REVEALED");
        // lock round to avoid concurrent double reveals
        return yield withRoundLock(sess.sid, req.roundId, () => __awaiter(this, void 0, void 0, function* () {
            const st = yield loadRound(sess.sid, req.roundId);
            if (!st || st.status !== "active")
                throw errors_1.AppError.badRequest("ROUND_CLOSED");
            if (st.revealed.includes(req.index))
                throw errors_1.AppError.badRequest("CELL_ALREADY_REVEALED");
            const isBomb = st.bombs.includes(req.index);
            if (isBomb) {
                // REAL: settle RTP with win=0
                if (mode === "real" && st.rtpDayKey) {
                    yield redis_1.redis.spSettle(st.rtpDayKey, st.stake, 0);
                }
                st.status = "bust";
                yield saveRound(st);
                const resp = {
                    game: "BombMines",
                    mode,
                    round_id: st.roundId,
                    index: req.index,
                    outcome: "bomb",
                    revealed_count: st.revealed.length,
                    // reveal server seed now for verification
                    server_seed: st.serverSeed,
                    server_seed_hash: st.serverSeedHash,
                    client_seed: st.clientSeed,
                    bombs: st.bombs
                };
                if (idemKey)
                    yield setIdemByKey(mode, sess.sid, idemKey, resp);
                return resp;
            }
            st.revealed.push(req.index);
            yield saveRound(st);
            const k = st.revealed.length;
            const nextMult = multiplierFor(st.total, st.mines, k + 1, HOUSE_EDGE);
            const cashMult = multiplierFor(st.total, st.mines, k, HOUSE_EDGE);
            const rawPotential = +(st.stake * cashMult).toFixed(2);
            // show potential payout but clamp to rtpCap in REAL
            const potential = (mode === "real" && st.rtpCap != null) ? Math.min(rawPotential, st.rtpCap) : rawPotential;
            const resp = {
                game: "BombMines",
                mode,
                round_id: st.roundId,
                index: req.index,
                outcome: "safe",
                revealed_count: k,
                cashout_multiplier: cashMult,
                potential_payout: potential,
                next_cashout_multiplier: nextMult
            };
            if (idemKey)
                yield setIdemByKey(mode, sess.sid, idemKey, resp);
            return resp;
        }));
    });
}
// ====== CASHOUT ======
function cashoutRound(sess, req, idemKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const mode = (sess.mode === "demo") ? "demo" : "real";
        const hit = yield getIdemByKey(mode, sess.sid, idemKey);
        if (hit)
            return hit;
        const st = yield loadRound(sess.sid, req.roundId);
        if (!st)
            throw errors_1.AppError.notFound("ROUND_NOT_FOUND");
        if (st.status !== "active") {
            if (st.status === "bust")
                throw errors_1.AppError.badRequest("ROUND_BUST");
            if (st.status === "cashed")
                throw errors_1.AppError.badRequest("ROUND_ALREADY_CASHED");
        }
        if (st.revealed.length < 1)
            throw errors_1.AppError.badRequest("NOTHING_TO_CASHOUT");
        // lock round
        return yield withRoundLock(sess.sid, req.roundId, () => __awaiter(this, void 0, void 0, function* () {
            var _a;
            const cur = yield loadRound(sess.sid, req.roundId);
            if (!cur || cur.status !== "active")
                throw errors_1.AppError.badRequest("ROUND_CLOSED");
            const k = cur.revealed.length;
            const mult = multiplierFor(cur.total, cur.mines, k, HOUSE_EDGE);
            let payout = +(cur.stake * mult).toFixed(2);
            // Clamp to configured caps (and to planned rtpCap in REAL)
            const cfg = yield loadGameCfg();
            payout = Math.min(payout, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap, ...(mode === "real" && cur.rtpCap != null ? [cur.rtpCap] : []));
            if (mode === "demo") {
                const bal = yield getDemoBalance(sess);
                yield setDemoBalance(sess, +(bal + payout).toFixed(2));
            }
            else {
                // RTP settle (payin += stake, payout += payout, counters--)
                if (!cur.rtpDayKey) {
                    const yymmdd = (0, date_1.toYYMMDD)();
                    cur.rtpDayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd); // fallback in case key missing
                }
                yield redis_1.redis.spSettle(cur.rtpDayKey, cur.stake, payout);
                const operator = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
                const operatorSessionId = (_a = sess.opSessionId) !== null && _a !== void 0 ? _a : sess.sessionId;
                const opCtx = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
                const winTxn = `${cur.roundId}-W`;
                yield (0, client_1.withdraw)(opCtx, {
                    TransactionId: winTxn,
                    TransactionType: "WinAmount",
                    Amount: payout,
                    CurrencyCode: cur.currency,
                    TransactionInfo: {
                        Source: "Mines",
                        GameName: "BombMines",
                        RoundId: cur.roundId,
                        GameNumber: Date.now().toString(),
                        ServerSeed: cur.serverSeed,
                        ServerSeedHash: cur.serverSeedHash,
                        ClientSeed: cur.clientSeed,
                        Revealed: cur.revealed,
                        Mines: cur.mines
                    }
                });
            }
            cur.status = "cashed";
            yield saveRound(cur);
            const resp = {
                game: "BombMines",
                mode,
                round_id: cur.roundId,
                result: "cashed",
                revealed_count: k,
                multiplier: mult,
                payout,
                currency: cur.currency,
                // reveal seeds and bombs for verification
                server_seed: cur.serverSeed,
                server_seed_hash: cur.serverSeedHash,
                client_seed: cur.clientSeed,
                bombs: cur.bombs,
                plan: (cur.planTarget != null && cur.planHardCap != null)
                    ? { target: cur.planTarget, hardCap: cur.planHardCap }
                    : undefined
            };
            if (idemKey)
                yield setIdemByKey(mode, sess.sid, idemKey, resp);
            return resp;
        }));
    });
}
