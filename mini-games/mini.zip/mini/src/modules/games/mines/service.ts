import crypto, { randomUUID } from "crypto";
import { ProviderSession } from "../../../types/operator";
import { redis, rawRedis } from "../../../config/redis";
import { AppError } from "../../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../../stores/operator";
import { deposit, withdraw } from "../../../operator/client";

// ==== RTP + Config ====
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../../lib/redis-keys";
import { toYYMMDD } from "../../../lib/date";
import { spPlan } from "../../rtp/governor";

// ----- config -----
const GAME_CODE = "mines";
const GRID = 5;                           // 5x5
const IDEM_TTL = 24 * 60 * 60;            // 24h for idempotency caches
const ROUND_TTL = 2 * 60 * 60;            // 2h round TTL
const HOUSE_EDGE = 0.02;                  // 2%
const LIMITS = { min: 0.1, max: 10000 };  // adjust per-portal if needed

const PRESETS = {
    easy: { size: GRID, mines: 3 },
    normal: { size: GRID, mines: 5 },
    medium: { size: GRID, mines: 8 },
    hard: { size: GRID, mines: 10 },
} as const;

// ----- redis keys (mode-scoped for idempotency) -----
const reqKey = (mode: "real" | "demo", sid: string, key: string) => `idem:${mode}:mines:req:${sid}:${key}`;
const roundKey = (sid: string, rid: string) => `round:mines:${sid}:${rid}`;
const lockKey = (sid: string, rid: string) => `lock:mines:${sid}:${rid}`;

// ----- fairness helpers -----
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");

/** Deterministic board: score each index by H(server_seed|client_seed|index), pick lowest N as bombs */
function chooseBombs(total: number, mines: number, serverSeed: string, clientSeed: string): number[] {
    const scored: { i: number; s: number }[] = [];
    for (let i = 0; i < total; i++) {
        const h = sha256(`${serverSeed}|${clientSeed}|${i}`);
        const s = parseInt(h.slice(0, 8), 16); // 32-bit score
        scored.push({ i, s });
    }
    scored.sort((a, b) => a.s - b.s);
    return scored.slice(0, mines).map(x => x.i);
}

/** Cashout multiplier after k safe picks with n total cells, m mines, minus edge */
function multiplierFor(n: number, m: number, k: number, edge = HOUSE_EDGE): number {
    if (k <= 0) return 1;
    if (k > n - m) k = n - m;
    // fair multiplier = C(n, k) / C(n - m, k) ; compute via product to avoid overflow
    let num = 1, den = 1;
    for (let i = 0; i < k; i++) { num *= (n - i); den *= (n - m - i); }
    const fair = num / den;
    return +(fair * (1 - edge)).toFixed(4);
}

// ----- demo ledger -----
async function getDemoBalance(sess: ProviderSession) {
    const key = `demo:bal:${sess.sid}`;
    const cached = await redis.get(key);
    if (cached) return Number(cached);
    const start = Number(process.env.DEMO_START_BALANCE ?? 1000);
    await redis.set(key, String(start), 2 * 60 * 60);
    return start;
}
async function setDemoBalance(sess: ProviderSession, amount: number) {
    const key = `demo:bal:${sess.sid}`;
    await redis.set(key, String(amount), 2 * 60 * 60);
}

// ----- idempotency (mode-scoped) -----
async function getIdemByKey(mode: "real" | "demo", sid: string, key?: string) {
    if (!key) return null;
    const v = await redis.get(reqKey(mode, sid, key));
    return v ? JSON.parse(v) : null;
}
async function setIdemByKey(mode: "real" | "demo", sid: string, key: string, payload: any) {
    await redis.set(reqKey(mode, sid, key), JSON.stringify(payload), IDEM_TTL);
}

// ----- locking -----
async function withRoundLock<T>(sid: string, rid: string, fn: () => Promise<T>) {
    const key = lockKey(sid, rid);
    const ok = await (rawRedis as any).set(key, "1", "EX", 3, "NX");
    if (ok !== "OK") throw AppError.badRequest("ROUND_BUSY");
    try { return await fn(); } finally { await rawRedis.del(key); }
}

// ----- types -----
type StartInput = { amount: number; difficulty: keyof typeof PRESETS; clientSeed?: string };
type RevealInput = { roundId: string; index: number };
type CashoutInput = { roundId: string };

type RoundState = {
    sid: string;
    roundId: string;
    stake: number;
    currency: string;
    mode: "demo" | "real";
    difficulty: keyof typeof PRESETS;
    size: number;            // 5
    total: number;           // 25
    mines: number;           // e.g., 5
    serverSeed: string;
    serverSeedHash: string;
    clientSeed: string;
    bombs: number[];         // kept server-side until finish
    revealed: number[];      // safe indices picked
    status: "active" | "bust" | "cashed";
    createdAt: number;

    // RTP (REAL)
    rtpDayKey?: string;
    rtpCap?: number;
    planTarget?: number;
    planHardCap?: number;
};

/** Persist/Load round */
async function saveRound(st: RoundState) {
    await redis.set(roundKey(st.sid, st.roundId), JSON.stringify(st), ROUND_TTL);
}
async function loadRound(sid: string, rid: string): Promise<RoundState | null> {
    const v = await redis.get(roundKey(sid, rid));
    return v ? JSON.parse(v) : null;
}

// ---- cfg / RTP helpers ----
type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
async function loadGameCfg(): Promise<GameCfg> {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha: Number(cfg.alpha),
        kappa: Number(cfg.kappa),
        beta: Number(cfg.beta),
        per_bet_cap: Number(cfg.per_bet_cap),
        per_ticket_cap: Number(cfg.per_ticket_cap),
        per_user_daily_cap: Number(cfg.per_user_daily_cap),
    };
}
function demoPlan(totalStake: number, cfg: GameCfg) {
    const hardCap = Math.min(cfg.per_ticket_cap, cfg.per_bet_cap, cfg.per_user_daily_cap);
    const softCap = Math.floor(hardCap * 0.6);
    const r = Math.random();
    const target = Math.floor(softCap * (0.3 + 0.7 * r));
    return { hardCap, softCap, target };
}

// ====== START ======
export async function startMinesRound(sess: ProviderSession, req: StartInput, idemKey?: string) {
    if (req.amount < LIMITS.min) throw AppError.badRequest(`Min bet is ${LIMITS.min}`);
    if (req.amount > LIMITS.max) throw AppError.badRequest(`Max bet is ${LIMITS.max}`);

    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    const hit = await getIdemByKey(mode, sess.sid, idemKey);
    if (hit) return hit;

    const preset = PRESETS[req.difficulty];
    const total = preset.size * preset.size;
    const clientSeed = req.clientSeed ?? sess.clientExternalKey ?? sess.userName ?? "client";

    // --- debit first
    if (mode === "demo") {
        const bal = await getDemoBalance(sess);
        if (bal < req.amount) throw AppError.badRequest("Insufficient FUN balance");
        await setDemoBalance(sess, +(bal - req.amount).toFixed(2));
    } else {
        const operator = await findByPortalName(sess.portalName);
        const operatorSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
        const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        const txnId = randomUUID();
        const probeSeed = crypto.randomBytes(32).toString("hex"); // just for metadata hash
        const probeHash = sha256(probeSeed);
        await deposit(opCtx, {
            TransactionId: txnId,
            TransactionType: "PlaceBet",
            Amount: req.amount,
            CurrencyCode: sess.currency,
            TransactionInfo: {
                Source: "Mines",
                GameName: "BombMines",
                RoundId: txnId,
                GameNumber: Date.now().toString(),
                ServerSeedHash: probeHash,
                ClientSeed: clientSeed
            }
        });
    }

    // --- RTP / planning
    const cfg = await loadGameCfg();
    let rtpDayKey: string | undefined;
    let plan = { hardCap: 0, softCap: 0, target: 0 };
    if (mode === "real") {
        const yymmdd = toYYMMDD();
        rtpDayKey = rk.day(GAME_CODE, yymmdd);
        await redis.hsetnx(rtpDayKey, "rtp_target", 0.90);
        await redis.spEnter(rtpDayKey, req.amount);                 // active_users++, active_stake+=stake
        plan = await spPlan(GAME_CODE, req.amount, cfg, yymmdd);    // {hardCap, softCap, target}
    } else {
        plan = demoPlan(req.amount, cfg);
    }
    const rtpCap = Math.min(plan.hardCap, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);

    // --- choose fair server seed & bombs (no post-hoc manipulation)
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = sha256(serverSeed);
    const bombs = chooseBombs(total, preset.mines, serverSeed, clientSeed);

    const roundId = randomUUID();
    const state: RoundState = {
        sid: sess.sid,
        roundId,
        stake: req.amount,
        currency: sess.currency,
        mode,
        difficulty: req.difficulty,
        size: preset.size,
        total,
        mines: preset.mines,
        serverSeed, serverSeedHash, clientSeed,
        bombs,
        revealed: [],
        status: "active",
        createdAt: Date.now(),
        // RTP binding
        rtpDayKey,
        rtpCap,
        planTarget: plan.target,
        planHardCap: plan.hardCap,
    };
    await saveRound(state);

    const nextMult = multiplierFor(total, preset.mines, 1, HOUSE_EDGE);

    const resp = {
        game: "BombMines",
        mode,
        round_id: roundId,
        stake: req.amount,
        currency: sess.currency,
        grid: { size: preset.size, total, mines: preset.mines },
        revealed_count: 0,
        next_cashout_multiplier: nextMult,
        server_seed_hash: serverSeedHash,   // reveal only hash at start
        plan
    };

    if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
    return resp;
}

// ====== REVEAL ======
export async function revealCell(sess: ProviderSession, req: RevealInput, idemKey?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    const hit = await getIdemByKey(mode, sess.sid, idemKey);
    if (hit) return hit;

    const state = await loadRound(sess.sid, req.roundId);
    if (!state) throw AppError.notFound("ROUND_NOT_FOUND");
    if (state.status !== "active") throw AppError.badRequest("ROUND_CLOSED");

    if (req.index < 0 || req.index >= state.total) throw AppError.badRequest("CELL_OUT_OF_RANGE");
    if (state.revealed.includes(req.index)) throw AppError.badRequest("CELL_ALREADY_REVEALED");

    // lock round to avoid concurrent double reveals
    return await withRoundLock(sess.sid, req.roundId, async () => {
        const st = await loadRound(sess.sid, req.roundId);
        if (!st || st.status !== "active") throw AppError.badRequest("ROUND_CLOSED");
        if (st.revealed.includes(req.index)) throw AppError.badRequest("CELL_ALREADY_REVEALED");

        const isBomb = st.bombs.includes(req.index);
        if (isBomb) {
            // REAL: settle RTP with win=0
            if (mode === "real" && st.rtpDayKey) {
                await redis.spSettle(st.rtpDayKey, st.stake, 0);
            }

            st.status = "bust";
            await saveRound(st);
            const resp = {
                game: "BombMines",
                mode,
                round_id: st.roundId,
                index: req.index,
                outcome: "bomb" as const,
                revealed_count: st.revealed.length,
                // reveal server seed now for verification
                server_seed: st.serverSeed,
                server_seed_hash: st.serverSeedHash,
                client_seed: st.clientSeed,
                bombs: st.bombs
            };
            if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
            return resp;
        }

        st.revealed.push(req.index);
        await saveRound(st);

        const k = st.revealed.length;
        const nextMult = multiplierFor(st.total, st.mines, k + 1, HOUSE_EDGE);
        const cashMult = multiplierFor(st.total, st.mines, k, HOUSE_EDGE);
        const rawPotential = +(st.stake * cashMult).toFixed(2);

        // show potential payout but clamp to rtpCap in REAL
        const potential = (mode === "real" && st.rtpCap != null) ? Math.min(rawPotential, st.rtpCap) : rawPotential;

        const resp = {
            game: "BombMines",
            mode,
            round_id: st.roundId,
            index: req.index,
            outcome: "safe" as const,
            revealed_count: k,
            cashout_multiplier: cashMult,
            potential_payout: potential,
            next_cashout_multiplier: nextMult
        };
        if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
        return resp;
    });
}

// ====== CASHOUT ======
export async function cashoutRound(sess: ProviderSession, req: CashoutInput, idemKey?: string) {
    const mode: "real" | "demo" = (sess.mode === "demo") ? "demo" : "real";
    const hit = await getIdemByKey(mode, sess.sid, idemKey);
    if (hit) return hit;

    const st = await loadRound(sess.sid, req.roundId);
    if (!st) throw AppError.notFound("ROUND_NOT_FOUND");
    if (st.status !== "active") {
        if (st.status === "bust") throw AppError.badRequest("ROUND_BUST");
        if (st.status === "cashed") throw AppError.badRequest("ROUND_ALREADY_CASHED");
    }
    if (st.revealed.length < 1) throw AppError.badRequest("NOTHING_TO_CASHOUT");

    // lock round
    return await withRoundLock(sess.sid, req.roundId, async () => {
        const cur = await loadRound(sess.sid, req.roundId);
        if (!cur || cur.status !== "active") throw AppError.badRequest("ROUND_CLOSED");

        const k = cur.revealed.length;
        const mult = multiplierFor(cur.total, cur.mines, k, HOUSE_EDGE);
        let payout = +(cur.stake * mult).toFixed(2);

        // Clamp to configured caps (and to planned rtpCap in REAL)
        const cfg = await loadGameCfg();
        payout = Math.min(
            payout,
            cfg.per_bet_cap,
            cfg.per_ticket_cap,
            cfg.per_user_daily_cap,
            ...(mode === "real" && cur.rtpCap != null ? [cur.rtpCap] : [])
        );

        if (mode === "demo") {
            const bal = await getDemoBalance(sess);
            await setDemoBalance(sess, +(bal + payout).toFixed(2));
        } else {
            // RTP settle (payin += stake, payout += payout, counters--)
            if (!cur.rtpDayKey) {
                const yymmdd = toYYMMDD();
                cur.rtpDayKey = rk.day(GAME_CODE, yymmdd); // fallback in case key missing
            }
            await redis.spSettle(cur.rtpDayKey!, cur.stake, payout);

            const operator = await findByPortalName(sess.portalName);
            const operatorSessionId = (sess as any).opSessionId ?? (sess as any).sessionId;
            const opCtx: any = { baseUrl: operator.baseUrl, secret: operator.secret, session: { id: operatorSessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            const winTxn = `${cur.roundId}-W`;
            await withdraw(opCtx, {
                TransactionId: winTxn,
                TransactionType: "WinAmount",
                Amount: payout,
                CurrencyCode: cur.currency,
                TransactionInfo: {
                    Source: "Mines",
                    GameName: "BombMines",
                    RoundId: cur.roundId,
                    GameNumber: Date.now().toString(),
                    ServerSeed: cur.serverSeed,
                    ServerSeedHash: cur.serverSeedHash,
                    ClientSeed: cur.clientSeed,
                    Revealed: cur.revealed,
                    Mines: cur.mines
                }
            });
        }

        cur.status = "cashed";
        await saveRound(cur);

        const resp = {
            game: "BombMines",
            mode,
            round_id: cur.roundId,
            result: "cashed",
            revealed_count: k,
            multiplier: mult,
            payout,
            currency: cur.currency,
            // reveal seeds and bombs for verification
            server_seed: cur.serverSeed,
            server_seed_hash: cur.serverSeedHash,
            client_seed: cur.clientSeed,
            bombs: cur.bombs,
            plan: (cur.planTarget != null && cur.planHardCap != null)
                ? { target: cur.planTarget, hardCap: cur.planHardCap }
                : undefined
        };
        if (idemKey) await setIdemByKey(mode, sess.sid, idemKey, resp);
        return resp;
    });
}
