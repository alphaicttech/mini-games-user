// /var/www/typesafe/alpha-mini/src/modules/games/mines/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { asyncHandler } from "../../../middleware/async-handler";
import { validateBody } from "../../../middleware/validate";
import { startMinesRound, revealCell, cashoutRound } from "./service";

const StartBody = z.object({
    amount: z.number().positive(),
    difficulty: z.enum(["easy", "normal", "medium", "hard"]),
    client_seed: z.string().min(1).optional()
});
export const startValidate = validateBody(StartBody);

export const start = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { amount, difficulty, client_seed } = req.body as z.infer<typeof StartBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await startMinesRound(sess, { amount, difficulty, clientSeed: client_seed }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});

const RevealBody = z.object({
    round_id: z.string().uuid(),
    index: z.number().int().min(0).max(24)  // 5x5
});
export const revealValidate = validateBody(RevealBody);

export const reveal = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { round_id, index } = req.body as z.infer<typeof RevealBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await revealCell(sess, { roundId: round_id, index }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});

const CashoutBody = z.object({
    round_id: z.string().uuid()
});
export const cashoutValidate = validateBody(CashoutBody);

export const cashout = asyncHandler(async (req: Request, res: Response) => {
    const sess = (req as any).providerSession as import("../../../types/operator").ProviderSession;
    const { round_id } = req.body as z.infer<typeof CashoutBody>;
    const idemKey = req.header("Idempotency-Key") || undefined;

    const result = await cashoutRound(sess, { roundId: round_id }, idemKey);
    if (idemKey) res.setHeader("Idempotency-Key", idemKey);
    res.json({ ok: true, ...result });
});
