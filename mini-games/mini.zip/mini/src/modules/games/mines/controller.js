"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashout = exports.cashoutValidate = exports.reveal = exports.revealValidate = exports.start = exports.startValidate = void 0;
const zod_1 = require("zod");
const async_handler_1 = require("../../../middleware/async-handler");
const validate_1 = require("../../../middleware/validate");
const service_1 = require("./service");
const StartBody = zod_1.z.object({
    amount: zod_1.z.number().positive(),
    difficulty: zod_1.z.enum(["easy", "normal", "medium", "hard"]),
    client_seed: zod_1.z.string().min(1).optional()
});
exports.startValidate = (0, validate_1.validateBody)(StartBody);
exports.start = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { amount, difficulty, client_seed } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const result = yield (0, service_1.startMinesRound)(sess, { amount, difficulty, clientSeed: client_seed }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
const RevealBody = zod_1.z.object({
    round_id: zod_1.z.string().uuid(),
    index: zod_1.z.number().int().min(0).max(24) // 5x5
});
exports.revealValidate = (0, validate_1.validateBody)(RevealBody);
exports.reveal = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { round_id, index } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const result = yield (0, service_1.revealCell)(sess, { roundId: round_id, index }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
const CashoutBody = zod_1.z.object({
    round_id: zod_1.z.string().uuid()
});
exports.cashoutValidate = (0, validate_1.validateBody)(CashoutBody);
exports.cashout = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sess = req.providerSession;
    const { round_id } = req.body;
    const idemKey = req.header("Idempotency-Key") || undefined;
    const result = yield (0, service_1.cashoutRound)(sess, { roundId: round_id }, idemKey);
    if (idemKey)
        res.setHeader("Idempotency-Key", idemKey);
    res.json(Object.assign({ ok: true }, result));
}));
