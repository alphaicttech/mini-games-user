"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.jetxRouter = void 0;
const express_1 = require("express");
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const jetx_1 = require("../../rtp/jetx");
const date_1 = require("../../../lib/date");
exports.jetxRouter = (0, express_1.Router)();
exports.jetxRouter.post("/round/start", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { lobby } = req.body;
    const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, "jetx")).limit(1))[0];
    const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
    const x = yield (0, jetx_1.jetxRoundStart)("jetx", {
        rtp_target: Number(cfg.rtp_target),
        alpha_round: Number(cfg.alpha_round),
        gamma_round: Number(cfg.gamma_round),
        cashout_intensity: Number(cfg.cashout_intensity),
        global_odd_cap: Number(cfg.global_odd_cap),
        per_bet_cap: Number(cfg.per_bet_cap),
        max_round_budget: undefined, // optional
    }, lobby, `${Date.now()}`, (0, date_1.toYYMMDD)());
    res.json(Object.assign({ success: true }, x));
}));
exports.jetxRouter.post("/cashout", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { roundId, stake, odd } = req.body;
    const r = yield (0, jetx_1.jetxCashout)("jetx", roundId, Number(stake), Number(odd));
    // if (r.shouldCrash) engine.forceCrash() on your side and broadcast
    res.json(Object.assign({ success: true }, r));
}));
