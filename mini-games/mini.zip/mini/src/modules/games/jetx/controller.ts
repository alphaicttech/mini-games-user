import { Request, Response, Router } from "express";
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { jetxRoundStart, jetxCashout } from "../../rtp/jetx";
import { toYYMMDD } from "../../../lib/date";

export const jetxRouter = Router();

jetxRouter.post("/round/start", async (req: Request, res: Response) => {
    const { lobby } = req.body as { lobby: { sMax: number; S: number } };
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, "jetx")).limit(1))[0];
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];

    const x = await jetxRoundStart("jetx", {
        rtp_target: Number(cfg.rtp_target),
        alpha_round: Number(cfg.alpha_round),
        gamma_round: Number(cfg.gamma_round),
        cashout_intensity: Number(cfg.cashout_intensity),
        global_odd_cap: Number(cfg.global_odd_cap),
        per_bet_cap: Number(cfg.per_bet_cap),
        max_round_budget: undefined, // optional
    }, lobby, `${Date.now()}`, toYYMMDD());

    res.json({ success: true, ...x });
});

jetxRouter.post("/cashout", async (req: Request, res: Response) => {
    const { roundId, stake, odd } = req.body as { roundId: string; stake: number; odd: number };
    const r = await jetxCashout("jetx", roundId, Number(stake), Number(odd));
    // if (r.shouldCrash) engine.forceCrash() on your side and broadcast
    res.json({ success: true, ...r });
});
