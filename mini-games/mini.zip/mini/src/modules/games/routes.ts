import { Router } from "express";
import { makeSpBetHandler } from "./common/sp.controller";
import { jetxRouter } from "./jetx/controller";

// very naive target matcher for now — we’ll replace per game
async function naiveComputeWin({ target, stake }: any) {
    // never exceed a simple multiple; you’ll replace per game logic
    return Math.min(target, stake * 100);
}

export const gamesRouter = Router();

gamesRouter.post("/keno/bet", makeSpBetHandler("keno", naiveComputeWin));
gamesRouter.post("/bingo/bet", makeSpBetHandler("bingo", naiveComputeWin));
gamesRouter.post("/spin/bet", makeSpBetHandler("spin", naiveComputeWin));
gamesRouter.post("/chicken-road/bet", makeSpBetHandler("chicken-road", naiveComputeWin));
gamesRouter.post("/bomb/bet", makeSpBetHandler("bomb", naiveComputeWin));
gamesRouter.post("/777slot/bet", makeSpBetHandler("777slot", naiveComputeWin));
gamesRouter.post("/plinko/bet", makeSpBetHandler("plinko", naiveComputeWin));

gamesRouter.use("/jetx", jetxRouter);
