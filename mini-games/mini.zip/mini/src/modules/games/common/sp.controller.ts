import { Request, Response } from "express";
import { db } from "../../../config/drizzle";
import { game as gameTable, gameConfig } from "../../../db/game";
import { eq } from "drizzle-orm";
import { rtpEnterAndPlan, rtpSettle } from "../../rtp/sp.helper";
import logger from "../../../config/logger";

type ComputeWinFn = (args: {
    target: number; hardCap: number; softCap: number;
    stake: number; userId: string | number; body: any;
}) => Promise<number>;

/** Factory returns an Express handler bound to a specific gameCode and a win function */
export function makeSpBetHandler(gameCode: string, computeWin: ComputeWinFn) {
    return async function spBetHandler(req: Request, res: Response) {
        try {
            const { stake, userId } = req.body;
            if (!Number(stake) || Number(stake) <= 0) return res.status(400).json({ success: false, message: "Invalid stake" });

            // load config from DB (cache in Redis if you want later)
            const g = (await db.select().from(gameTable).where(eq(gameTable.code, gameCode)).limit(1))[0];
            if (!g || !g.is_active) return res.status(403).json({ success: false, message: "Game inactive" });
            const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
            if (!cfg) return res.status(500).json({ success: false, message: "Config missing" });

            // enter & plan
            const { dayKey, plan } = await rtpEnterAndPlan(gameCode, Number(stake), {
                rtp_target: Number(cfg.rtp_target),
                alpha: Number(cfg.alpha),
                kappa: Number(cfg.kappa),
                beta: Number(cfg.beta),
                per_bet_cap: Number(cfg.per_bet_cap),
                per_ticket_cap: Number(cfg.per_ticket_cap),
                per_user_daily_cap: Number(cfg.per_user_daily_cap),
            });

            // your game logic computes outcome close to target
            const win = await computeWin({
                target: plan.target,
                hardCap: plan.hardCap,
                softCap: plan.softCap,
                stake: Number(stake),
                userId,
                body: req.body
            });

            await rtpSettle(dayKey, Number(stake), Number(win));

            // optional pub/sub for analytics
            // await redis.publish('alpha:events', JSON.stringify({ kind:'user_bet', game:gameCode, stake:Number(stake), win:Number(win) }));

            res.json({ success: true, plan, win });
        } catch (err: any) {
            // IMPORTANT: if computeWin throws BEFORE settle, we must revert the "enter" counters.
            // Easiest pragmatic fix: settle with win=0 and stake=0 only decrements actives:
            // Create a lightweight lua if you prefer; for now, just log and 500.
            logger.error({ err }, "sp bet failed");
            return res.status(500).json({ success: false, message: "Bet failed" });
        }
    };
}
