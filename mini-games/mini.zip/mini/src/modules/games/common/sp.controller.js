"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeSpBetHandler = makeSpBetHandler;
const drizzle_1 = require("../../../config/drizzle");
const game_1 = require("../../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const sp_helper_1 = require("../../rtp/sp.helper");
const logger_1 = __importDefault(require("../../../config/logger"));
/** Factory returns an Express handler bound to a specific gameCode and a win function */
function makeSpBetHandler(gameCode, computeWin) {
    return function spBetHandler(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { stake, userId } = req.body;
                if (!Number(stake) || Number(stake) <= 0)
                    return res.status(400).json({ success: false, message: "Invalid stake" });
                // load config from DB (cache in Redis if you want later)
                const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, gameCode)).limit(1))[0];
                if (!g || !g.is_active)
                    return res.status(403).json({ success: false, message: "Game inactive" });
                const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
                if (!cfg)
                    return res.status(500).json({ success: false, message: "Config missing" });
                // enter & plan
                const { dayKey, plan } = yield (0, sp_helper_1.rtpEnterAndPlan)(gameCode, Number(stake), {
                    rtp_target: Number(cfg.rtp_target),
                    alpha: Number(cfg.alpha),
                    kappa: Number(cfg.kappa),
                    beta: Number(cfg.beta),
                    per_bet_cap: Number(cfg.per_bet_cap),
                    per_ticket_cap: Number(cfg.per_ticket_cap),
                    per_user_daily_cap: Number(cfg.per_user_daily_cap),
                });
                // your game logic computes outcome close to target
                const win = yield computeWin({
                    target: plan.target,
                    hardCap: plan.hardCap,
                    softCap: plan.softCap,
                    stake: Number(stake),
                    userId,
                    body: req.body
                });
                yield (0, sp_helper_1.rtpSettle)(dayKey, Number(stake), Number(win));
                // optional pub/sub for analytics
                // await redis.publish('alpha:events', JSON.stringify({ kind:'user_bet', game:gameCode, stake:Number(stake), win:Number(win) }));
                res.json({ success: true, plan, win });
            }
            catch (err) {
                // IMPORTANT: if computeWin throws BEFORE settle, we must revert the "enter" counters.
                // Easiest pragmatic fix: settle with win=0 and stake=0 only decrements actives:
                // Create a lightweight lua if you prefer; for now, just log and 500.
                logger_1.default.error({ err }, "sp bet failed");
                return res.status(500).json({ success: false, message: "Bet failed" });
            }
        });
    };
}
