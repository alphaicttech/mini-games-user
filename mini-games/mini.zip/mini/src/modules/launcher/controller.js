"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.launcher = exports.launcherValidate = void 0;
const zod_1 = require("zod");
const validate_1 = require("../../middleware/validate");
const async_handler_1 = require("../../middleware/async-handler");
const Q = zod_1.z.object({
    Token: zod_1.z.string().min(1),
    PortalName: zod_1.z.string().min(1),
    GameCategory: zod_1.z.string().min(1),
    GameName: zod_1.z.string().min(1),
    Lang: zod_1.z.string().default("en").optional(),
    ReturnUrl: zod_1.z.string().url().optional(),
    StopUrl: zod_1.z.string().url().optional(),
});
exports.launcherValidate = (0, validate_1.validateQuery)(Q);
exports.launcher = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { Token, GameCategory, GameName, ReturnUrl, Lang, PortalName, StopUrl } = req.query;
    const mode = (Token === "DEMO" || PortalName === "demo") ? "demo" : "real";
    // (Optional) verify PortalName exists in DB; if not, throw:
    // throw AppError.notFound(`Unknown PortalName: ${PortalName}`);
    res.json({
        ok: true,
        mode,
        token: Token,
        portal_name: PortalName,
        game: { category: GameCategory, name: GameName },
        lang: Lang || "en",
        return_url: ReturnUrl || null,
        stop_url: StopUrl || null,
        next: { method: "POST", path: "/api/session/activate" },
        ttl_seconds: 900
    });
}));
