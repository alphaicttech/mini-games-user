// /var/www/typesafe/alpha-mini/src/modules/launcher/controller.ts
import { Request, Response } from "express";
import { z } from "zod";
import { validateQuery } from "../../middleware/validate";
import { asyncHandler } from "../../middleware/async-handler";
import { AppError } from "../../errors";

const Q = z.object({
    Token: z.string().min(1),
    PortalName: z.string().min(1),
    GameCategory: z.string().min(1),
    GameName: z.string().min(1),
    Lang: z.string().default("en").optional(),
    ReturnUrl: z.string().url().optional(),
    StopUrl: z.string().url().optional(),
});

export const launcherValidate = validateQuery(Q);

export const launcher = asyncHandler(async (req: Request, res: Response) => {
    const { Token, GameCategory, GameName, ReturnUrl, Lang, PortalName, StopUrl } = req.query as any;

    const mode = (Token === "DEMO" || PortalName === "demo") ? "demo" : "real";
    // (Optional) verify PortalName exists in DB; if not, throw:
    // throw AppError.notFound(`Unknown PortalName: ${PortalName}`);

    res.json({
        ok: true,
        mode,
        token: Token,
        portal_name: PortalName,
        game: { category: GameCategory, name: GameName },
        lang: Lang || "en",
        return_url: ReturnUrl || null,
        stop_url: StopUrl || null,
        next: { method: "POST", path: "/api/session/activate" },
        ttl_seconds: 900
    });
});
