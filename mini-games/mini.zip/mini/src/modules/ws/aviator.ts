import { Server, Socket } from "socket.io";
import crypto from "crypto";
import { nanoid } from "nanoid";
import { redis, rawRedis } from "../../config/redis";
import { AppError } from "../../errors";
import { findOperatorByPortalName as findByPortalName } from "../../stores/operator";
import { deposit, rollback, withdraw } from "./../../operator/client";

// === RTP integration (JetX model) ===
import { db } from "../../config/drizzle";
import { game as gameTable, gameConfig } from "../../db/game";
import { eq } from "drizzle-orm";
import { rk } from "../../lib/redis-keys";
import { toYYMMDD } from "../../lib/date";
import { jetxRoundStart, jetxCashout } from "../../modules/rtp/jetx";

// ====== Config ======
const NAMESPACE = "/aviator";
const ROOM = "aviator-global";
const GAME_CODE = "jetx"; // RTP game code for aviator

const COUNTDOWN_MS = Number(process.env.AVIATOR_COUNTDOWN_MS ?? 8000);
const GAP_MS = Number(process.env.AVIATOR_GAP_MS ?? 1200);
const TICK_MS = Number(process.env.AVIATOR_TICK_MS ?? 200);
const R = Number(process.env.AVIATOR_GROWTH_R ?? 0.09); // exp growth rate

const EXP_P = Number(process.env.AVIATOR_EXP_P ?? 1.2);          // shape ( >1 = slower start )
const TIME_SCALE = Number(process.env.AVIATOR_TIME_SCALE ?? 1.5);  // global speed

const ALLOW_LATE_BET_MS = Number(process.env.AVIATOR_LATE_BET_MS ?? 300);
const INCLUDE_BALANCE = process.env.AVIATOR_INCLUDE_BALANCE === "true";
const MAX_BETS_PER_USER = Number(process.env.AVIATOR_MAX_BETS_PER_USER ?? 2);
const CANCEL_GRACE_MS = Number(process.env.AVIATOR_CANCEL_GRACE_MS ?? 0); // 0 = only countdown

const HISTORY_SIZE = 50;

// Redis keys
const K_CURR = "aviator:round:current";                // JSON
const K_BETS = (rid: string) => `aviator:bets:${rid}`; // HSET bet_id -> JSON
const K_AUTO = (rid: string) => `aviator:auto:${rid}`; // ZSET (score=auto multiplier) -> bet_id
const K_HIST = "aviator:history";                      // LPUSH JSON (bounded)
const K_IDEM_BET = (sid: string, key: string) => `idem:aviator:bet:${sid}:${key}`;
const K_IDEM_CASH = (sid: string, key: string) => `idem:aviator:cash:${sid}:${key}`;
const K_LIVECOUNT = (rid: string, sid: string) => `aviator:livecount:${rid}:${sid}`; // per-round, per-user live bets counter
const K_IDEM_CANCEL = (sid: string, key: string) => `idem:aviator:cancel:${sid}:${key}`;
const SESSION_KEY = (sid: string) => `session:${sid}`; // rely on Redis keyPrefix

// RTP round key helpers (store budget/caps)
const K_RTP_ROUND = (yymmdd: string, rid: string) => rk.round(GAME_CODE, yymmdd, rid);

// ====== Chat config & keys ======
const CHAT_HISTORY_SIZE = 30;
const K_CHAT = "aviator:chat";
const K_CHAT_RATE = (sid: string) => `aviator:chat:rate:${sid}`;

function maskSid(sid: string) { return sid.length > 4 ? `***${sid.slice(-4)}` : `***${sid}`; }
async function pushChat(item: any) { await redis.lpush(K_CHAT, JSON.stringify(item)); await rawRedis.ltrim(K_CHAT, 0, CHAT_HISTORY_SIZE - 1); }
async function loadChat(limit = CHAT_HISTORY_SIZE) { const arr = await redis.lrange(K_CHAT, 0, limit - 1); return arr.map(s => JSON.parse(s)); }

// ====== fairness / math ======
function crashFromSeeds(server_seed: string, round_id: string) {
    const h = crypto.createHmac("sha256", server_seed).update(round_id).digest("hex");
    const u = (parseInt(h.slice(0, 8), 16) >>> 0) / 0xffffffff;
    return Math.min(1000, 1 / (1 - Math.max(u, 1e-12)));
}
// function mAt(t_ms: number) { return Math.floor(100 * Math.exp(R * (t_ms / 1000))) / 100; }
// function tFor(mult: number) { return Math.log(Math.max(1e-12, mult)) / R * 1000; }
// t_ms -> multiplier
function mAt(t_ms: number) {
    const tSec = (t_ms / 1000) / TIME_SCALE;          // scale overall time
    const shaped = Math.pow(tSec, EXP_P);             // slow early, faster later
    const mult = Math.exp(R * shaped);
    return Math.floor(mult * 100) / 100;              // 2-decimals
}

// multiplier -> t_ms (inverse of above!)
function tFor(mult: number) {
    const y = Math.log(Math.max(1e-12, mult)) / R;    // y = tSec^EXP_P
    const tSec = Math.pow(Math.max(y, 0), 1 / EXP_P); // tSec = y^(1/EXP_P)
    return tSec * TIME_SCALE * 1000;
}


// ====== session lookup (TODO: wire to your provider session store) ======
async function getProviderSession(sid: string): Promise<import("../../types/operator").ProviderSession> {
    const raw = await redis.get(`session:${sid}`);
    if (!raw) throw AppError.unauthorized("INVALID_SID");
    return JSON.parse(raw);
}

// ====== misc helpers ======
function now() { return Date.now(); }
function ok(socket: Socket, type: string, data: any) { socket.emit(type, { type, data }); }
function broadcast(io: Server, type: string, data: any) { io.of(NAMESPACE).to(ROOM).emit(type, { type, data }); }

// ====== engine state ======
type Round = {
    round_id: string;
    phase: "countdown" | "flight" | "crashed";
    countdown_ends_at: number;
    flight_started_at?: number;
    crash_multiplier: number;
    crash_at_ts: number;
    server_seed: string;
    server_seed_hash: string;
    next_server_seed_hash: string; // commitment for next round

    // RTP runtime cache (REAL)
    yymmdd?: string;
    max_odd_cap?: number; // clamp multiplier
};

let engineRunning = false;
let tickTimer: NodeJS.Timeout | null = null;

// ====== wallet helpers ======
async function debitBet(sess: any, amount: number, txn: string) {
    if (sess.mode === "demo") {
        const key = `demo:bal:${sess.sid}`; const v = await redis.get(key);
        const bal = v ? Number(v) : Number(process.env.DEMO_START_BALANCE ?? 1000);
        if (bal < amount) throw AppError.badRequest("INSUFFICIENT_FUN");
        await redis.set(key, String(+(bal - amount).toFixed(2)), 2 * 60 * 60);
        return +(bal - amount).toFixed(2);
    } else {
        const op = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await deposit(opCtx, { TransactionId: txn, TransactionType: "PlaceBet", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: { Source: "Aviator", GameName: "Aviator", RoundId: txn, GameNumber: `${Date.now()}` } });
        return undefined;
    }
}
async function creditCashout(sess: any, amount: number, txn: string) {
    if (amount <= 0) return undefined;
    if (sess.mode === "demo") {
        const key = `demo:bal:${sess.sid}`; const v = await redis.get(key);
        const bal = v ? Number(v) : Number(process.env.DEMO_START_BALANCE ?? 1000);
        const newBal = +(bal + amount).toFixed(2);
        await redis.set(key, String(newBal), 2 * 60 * 60);
        return newBal;
    } else {
        const op = await findByPortalName(sess.portalName);
        const opCtx: any = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (sess as any).opSessionId ?? (sess as any).sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
        await withdraw(opCtx, { TransactionId: txn, TransactionType: "WinAmount", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: { Source: "Aviator", GameName: "Aviator", RoundId: txn, GameNumber: `${Date.now()}` } });
        return undefined;
    }
}

// ====== players count ======
function emitPlayersCount(io: Server) {
    const room = io.of(NAMESPACE).adapter.rooms.get(ROOM);
    const count = room?.size ?? 0;
    io.of(NAMESPACE).to(ROOM).emit("players_count", { type: "players_count", data: { room: ROOM, count } });
}

// ====== history helpers ======
async function pushHistory(item: any) { await redis.lpush(K_HIST, JSON.stringify(item)); await rawRedis.ltrim(K_HIST, 0, HISTORY_SIZE - 1); }
async function loadHistory(limit = HISTORY_SIZE) { const arr = await redis.lrange(K_HIST, 0, limit - 1); return arr.map(s => JSON.parse(s)); }

// ====== engine storage ======
async function writeCurrentRound(r: Round) { await redis.set(K_CURR, JSON.stringify(r)); }
async function readCurrentRound(): Promise<Round | null> { const raw = await redis.get(K_CURR); return raw ? JSON.parse(raw) : null; }

// ====== RTP cfg loader (REAL mode) ======
async function loadJetxCfg() {
    const g = (await db.select().from(gameTable).where(eq(gameTable.code, GAME_CODE)).limit(1))[0];
    if (!g || !g.is_active) throw AppError.badRequest("GAME_INACTIVE");
    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    if (!cfg) throw AppError.badRequest("GAME_CFG_MISSING");
    return {
        rtp_target: Number(cfg.rtp_target),
        alpha_round: Number((cfg as any).alpha_round),
        gamma_round: Number((cfg as any).gamma_round),
        cashout_intensity: Number((cfg as any).cashout_intensity),
        global_odd_cap: Number((cfg as any).global_odd_cap),
        per_bet_cap: Number(cfg.per_bet_cap),
        max_round_budget: undefined as number | undefined,
    };
}

// ====== engine ======
async function startNewRound(io: Server, prevSeed?: string) {
    const server_seed = crypto.randomBytes(32).toString("hex");
    const server_seed_hash = crypto.createHash("sha256").update(server_seed).digest("hex");
    const next_server_seed = crypto.randomBytes(32).toString("hex");
    const next_server_seed_hash = crypto.createHash("sha256").update(next_server_seed).digest("hex");

    const round_id = nanoid();
    const crash_multiplier = crashFromSeeds(server_seed, round_id);
    const countdown_ends_at = now() + COUNTDOWN_MS;
    const crash_at_ts = countdown_ends_at + tFor(crash_multiplier);

    const r: Round = { round_id, phase: "countdown", countdown_ends_at, crash_multiplier, crash_at_ts, server_seed, server_seed_hash, next_server_seed_hash };
    await writeCurrentRound(r);

    broadcast(io, "state", { round_id, phase: "countdown", countdown_ends_at, server_seed_hash, next_server_seed_hash });

    setTimeout(async () => {
        // move to flight
        const flight_started_at = now();
        r.phase = "flight";
        r.flight_started_at = flight_started_at;

        // ==== RTP: compute round budget/caps (REAL mode) ====
        try {
            const yymmdd = toYYMMDD();
            r.yymmdd = yymmdd;

            // scan bets for REAL mode totals
            const bets = await redis.hgetall(K_BETS(r.round_id));
            let S = 0, sMax = 0;
            for (const raw of Object.values(bets)) {
                const b = JSON.parse(raw);
                if (b.status === "live" && b.mode === "real") {
                    const amt = Number(b.amount) || 0;
                    S += amt;
                    if (amt > sMax) sMax = amt;
                }
            }

            if (S > 0) {
                const cfg = await loadJetxCfg();
                const { B_round, cap_per_bet, max_odd_cap } = await jetxRoundStart(GAME_CODE, cfg, { sMax, S }, r.round_id, yymmdd);
                // add round payin now (per design)
                const dayKey = rk.day(GAME_CODE, yymmdd);
                await redis.hsetnx(dayKey, "rtp_target", (cfg as any).rtp_target ?? 0.90);
                await redis.hincrbyfloat(dayKey, "payin", S);

                // cache for tick clamp
                r.max_odd_cap = max_odd_cap;
            } else {
                r.max_odd_cap = undefined;
            }
        } catch (e) {
            // if anything fails, continue without RTP clamps (demo-like)
            r.max_odd_cap = undefined;
        }

        await writeCurrentRound(r);
        broadcast(io, "state", { round_id, phase: "flight", flight_started_at, crash_at_ts, crash_multiplier });

        // start ticking
        if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
        tickTimer = setInterval(async () => {
            const t = now() - (r.flight_started_at as number);
            const m = mAt(t);

            // Clamp by max_odd_cap if present (REAL budget-driven cap)
            if (r.max_odd_cap && m >= r.max_odd_cap) {
                // force immediate crash at cap
                if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
                await crashRound(io, r);
                return;
            }

            broadcast(io, "tick", { round_id, t_ms: t, multiplier: m });

            // auto-cashouts
            const hits = await (rawRedis as any).zrangebyscore(K_AUTO(r.round_id), "-inf", m.toString(), "LIMIT", "0", "200");
            for (const bet_id of hits) await performCashout(io, r, bet_id, "auto");

            if (m >= r.crash_multiplier) {
                if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
                await crashRound(io, r);
            }
        }, TICK_MS);
    }, COUNTDOWN_MS + 5);
}

async function crashRound(io: Server, r: Round) {
    r.phase = "crashed";
    await writeCurrentRound(r);

    // Settle remaining live bets as lost (no RTP payout changes; payin was added at flight start)
    const bets = await redis.hgetall(K_BETS(r.round_id));
    for (const [bet_id, raw] of Object.entries(bets)) {
        const b = JSON.parse(raw);
        if (b.status === "live") {
            b.status = "lost";
            await rawRedis.decr(K_LIVECOUNT(r.round_id, b.sid));
            await redis.hset(K_BETS(r.round_id), bet_id, JSON.stringify(b));
        }
    }

    broadcast(io, "crash", { round_id: r.round_id, at_multiplier: r.crash_multiplier, server_seed: r.server_seed, server_seed_hash: r.server_seed_hash });
    await pushHistory({ round_id: r.round_id, at: r.crash_multiplier, server_seed_hash: r.server_seed_hash, revealed_seed: r.server_seed });

    setTimeout(() => startNewRound(io, r.server_seed), GAP_MS);
}

// ====== perform cashout (with idempotency & single-execution) ======
async function performCashout(io: Server, r: Round, bet_id: string, reason: "user" | "auto") {
    const key = K_BETS(r.round_id);
    const raw = await redis.hget(key, bet_id);
    if (!raw) return;
    const b = JSON.parse(raw);
    if (b.status !== "live") return; // idempotent

    // compute current multiplier
    const mult = r.phase === "flight" && r.flight_started_at ? mAt(now() - r.flight_started_at) : 0;
    if (r.phase !== "flight" || mult >= r.crash_multiplier) return;

    // mark status first to avoid races
    b.status = "cashed";
    await rawRedis.decr(K_LIVECOUNT(r.round_id, b.sid));

    let payout = 0;
    let cashMult = +(Math.floor(mult * 100) / 100).toFixed(2);

    const sess = await getProviderSession(b.sid);

    if (b.mode === "real" && r.yymmdd) {
        // Use JetX governor to apply per-bet cap and update day payout; may trigger shouldCrash
        const res = await jetxCashout(GAME_CODE, r.round_id, Number(b.amount), cashMult, r.yymmdd);
        payout = +res.win.toFixed(2);
        // Adjust displayed multiplier to reflect any cap effects (payout/amount)
        cashMult = +(payout / Number(b.amount)).toFixed(2);

        // if budget nearly exhausted or odd cap reached → crash ASAP
        if (res.shouldCrash) {
            // Force immediate crash at current cap/mult
            if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
            await crashRound(io, r);
        }
    } else {
        // demo: plain payout, no RTP clamp
        payout = +(Number(b.amount) * cashMult).toFixed(2);
    }

    b.cashout_multiplier = cashMult;
    b.cashout_ms = now();
    b.payout = payout;
    await redis.hset(key, bet_id, JSON.stringify(b));

    // credit wallet
    const newBal = await creditCashout(sess, payout, `${r.round_id}-CASH-${bet_id}`);

    // notify the room
    io.of(NAMESPACE).to(ROOM).emit("cashout_event", {
        type: "cashout_event",
        data: {
            round_id: r.round_id,
            bet_id,
            sid: maskSid(b.sid),
            cashout_multiplier: cashMult,
            payout
        }
    });
    return newBal;
}

// ====== Recovery on boot ======
export async function recoverAndRun(io: Server) {
    if (engineRunning) return;
    engineRunning = true;

    const r = await readCurrentRound();
    if (!r) { await startNewRound(io); return; }

    const n = now();
    if (r.phase === "countdown") {
        const delay = Math.max(0, r.countdown_ends_at - n);
        broadcast(io, "state", { round_id: r.round_id, phase: "countdown", countdown_ends_at: r.countdown_ends_at, server_seed_hash: r.server_seed_hash, next_server_seed_hash: r.next_server_seed_hash });
        setTimeout(async () => {
            r.phase = "flight";
            r.flight_started_at = now();
            await writeCurrentRound(r);
            broadcast(io, "state", { round_id: r.round_id, phase: "flight", flight_started_at: r.flight_started_at, crash_at_ts: r.crash_at_ts, crash_multiplier: r.crash_multiplier });
            if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
            tickTimer = setInterval(async () => {
                const t = now() - (r.flight_started_at as number);
                const m2 = mAt(t);
                // clamp by cached max_odd_cap if any
                if (r.max_odd_cap && m2 >= r.max_odd_cap) { if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } await crashRound(io, r); return; }
                broadcast(io, "tick", { round_id: r.round_id, t_ms: t, multiplier: m2 });
                const hits = await (rawRedis as any).zrangebyscore(K_AUTO(r.round_id), "-inf", m2.toString(), "LIMIT", "0", "200");
                for (const bet_id of hits) await performCashout(io, r, bet_id, "auto");
                if (m2 >= r.crash_multiplier) { if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } await crashRound(io, r); }
            }, TICK_MS);
        }, delay + 10);
        return;
    }

    if (r.phase === "flight") {
        const m = mAt(n - (r.flight_started_at as number));
        if (m >= r.crash_multiplier) { await crashRound(io, r); return; }
        broadcast(io, "state", { round_id: r.round_id, phase: "flight", flight_started_at: r.flight_started_at, crash_at_ts: r.crash_at_ts, crash_multiplier: r.crash_multiplier });
        if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
        tickTimer = setInterval(async () => {
            const t = now() - (r.flight_started_at as number);
            const m2 = mAt(t);
            if (r.max_odd_cap && m2 >= r.max_odd_cap) { if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } await crashRound(io, r); return; }
            broadcast(io, "tick", { round_id: r.round_id, t_ms: t, multiplier: m2 });
            const hits = await (rawRedis as any).zrangebyscore(K_AUTO(r.round_id), "-inf", m2.toString(), "LIMIT", "0", "200");
            for (const bet_id of hits) await performCashout(io, r, bet_id, "auto");
            if (m2 >= r.crash_multiplier) { if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } await crashRound(io, r); }
        }, TICK_MS);
        return;
    }

    await crashRound(io, r);
}

// ====== wiring entry ======
export function mountAviator(io: Server) {
    const nsp = io.of(NAMESPACE);

    nsp.use(async (socket: Socket, next: (err?: any) => void) => {
        try {
            const sid =
                (socket.handshake.auth && socket.handshake.auth.sid) ||
                (socket.handshake.headers["x-provider-sid"] as string) ||
                (socket.handshake.query?.sid as string);

            if (!sid) return next(AppError.unauthorized("UNAUTHORIZED"));
            const sess = await getProviderSession(String(sid));
            (socket as any).sid = String(sid);
            (socket as any).providerSession = sess;
            next();
        } catch (e) { next(e as any); }
    });

    nsp.on("connection", async (socket) => {
        const sid = (socket as any).sid as string;
        const sess = (socket as any).providerSession as any;
        socket.join(ROOM);

        ok(socket, "history", await loadHistory(100));
        emitPlayersCount(io);

        socket.on("disconnect", () => {
            broadcast(io, "player_left", { sid });
            emitPlayersCount(io);
        });

        // BET (supports auto_cashout). Store mode for RTP split.
        socket.on("bet", async (msg: any) => {
            let reservedTicket = false;
            try {
                const { amount, auto_cashout, idempotency_key } = msg?.data || msg || {};
                if (!(amount > 0)) throw AppError.badRequest("BAD_AMOUNT");

                if (idempotency_key) {
                    const prev = await redis.get(K_IDEM_BET(sid, idempotency_key));
                    if (prev) { ok(socket, "bet_accepted", JSON.parse(prev)); return; }
                }

                const r = await readCurrentRound();
                if (!r) throw AppError.internal("NO_ROUND");
                const acceptWindow = r.phase === "countdown" ||
                    (r.phase === "flight" && r.flight_started_at && now() - r.flight_started_at < ALLOW_LATE_BET_MS);
                if (!acceptWindow) throw AppError.badRequest("ROUND_CLOSED");

                const cntKey = K_LIVECOUNT(r.round_id, sid);
                const c = await rawRedis.incr(cntKey);
                reservedTicket = true;
                if (c === 1) await rawRedis.expire(cntKey, 10 * 60);
                if (c > MAX_BETS_PER_USER) throw AppError.badRequest("MAX_BETS_REACHED");

                const betTxn = `${r.round_id}-BET-${nanoid()}`;
                const newBal = await debitBet(sess, amount, betTxn);

                const bet_id = nanoid();
                const bet = {
                    sid,
                    amount,
                    auto: (auto_cashout ?? null),
                    placed_at_ms: now(),
                    status: "live",
                    txn_id: betTxn,
                    mode: (sess.mode === "demo" ? "demo" : "real") as "demo" | "real"
                };
                await redis.hset(K_BETS(r.round_id), bet_id, JSON.stringify(bet));
                if (auto_cashout && typeof auto_cashout === "number" && auto_cashout > 1) {
                    await rawRedis.zadd(K_AUTO(r.round_id), Number(auto_cashout), bet_id);
                }

                const payload = { bet_id, amount, auto_cashout: auto_cashout ?? null, balance: newBal ?? null };
                if (idempotency_key) await redis.set(K_IDEM_BET(sid, idempotency_key), JSON.stringify(payload), 24 * 60 * 60);

                ok(socket, "bet_accepted", payload);
                broadcast(io, "user_bet", { round_id: r.round_id, bet_id, sid: maskSid(sid), amount, auto_cashout: auto_cashout ?? null, ts: Date.now() });
            } catch (e: any) {
                ok(socket, "error", { code: e.code ?? "BAD_REQUEST", message: e.message ?? String(e) });
                if (reservedTicket) {
                    const r = await readCurrentRound();
                    if (r) await rawRedis.decr(K_LIVECOUNT(r.round_id, sid));
                }
            }
        });

        // MANUAL CASHOUT
        socket.on("cashout", async (msg: any) => {
            try {
                const { bet_id, idempotency_key } = msg?.data || msg || {};
                if (!bet_id) throw AppError.badRequest("MISSING_BET_ID");

                if (idempotency_key) {
                    const prev = await redis.get(K_IDEM_CASH(sid, idempotency_key));
                    if (prev) { ok(socket, "cashout_ok", JSON.parse(prev)); return; }
                }

                const r = await readCurrentRound();
                if (!r || r.phase !== "flight") throw AppError.badRequest("ROUND_CLOSED");

                const raw = await redis.hget(K_BETS(r.round_id), bet_id);
                if (!raw) throw AppError.notFound("BET_NOT_FOUND");
                const b = JSON.parse(raw);
                if (b.sid !== sid) throw AppError.unauthorized("NOT_OWNER");
                if (b.status !== "live") throw AppError.badRequest("ALREADY_RESOLVED");

                // current multiplier
                const mult = mAt(now() - (r.flight_started_at as number));
                if (mult >= r.crash_multiplier) throw AppError.badRequest("TOO_LATE");

                // Settle (RTP-aware for real mode)
                // Mark status & release ticket inside performCashout()
                const newBal = await performCashout(io, r, bet_id, "user");

                const updated = await redis.hget(K_BETS(r.round_id), bet_id);
                const ub = JSON.parse(updated!);

                const payload = { bet_id, cashout_multiplier: ub.cashout_multiplier, payout: ub.payout, balance: newBal ?? null };
                if (idempotency_key) await redis.set(K_IDEM_CASH(sid, idempotency_key), JSON.stringify(payload), 24 * 60 * 60);

                ok(socket, "cashout_ok", payload);
                broadcast(io, "user_cashout", {
                    round_id: r.round_id, bet_id, sid: maskSid(b.sid),
                    cashout_multiplier: ub.cashout_multiplier, payout: ub.payout, reason: "user", ts: Date.now()
                });
            } catch (e: any) {
                ok(socket, "error", { code: e.code ?? "BAD_REQUEST", message: e.message ?? String(e) });
            }
        });

        ok(socket, "chat_history", await loadChat(100));

        socket.on("chat_typing", () => {
            broadcast(io, "chat_typing", { sid: maskSid((socket as any).sid), ts: Date.now() });
        });

        socket.on("chat_send", async (msg: any) => {
            try {
                const sid = (socket as any).sid as string;
                const { text } = msg?.data || msg || {};
                const raw = String(text ?? "").trim();
                if (!raw) throw AppError.badRequest("EMPTY_MESSAGE");
                if (raw.length > 300) throw AppError.badRequest("MESSAGE_TOO_LONG");
                const clean = raw.replace(/[^\x09\x0A\x0D\x20-\x7E\u1200-\u137F\u1380-\u1399\u2D80-\u2DDF]/g, "");

                const hit = await rawRedis.incr(K_CHAT_RATE(sid));
                if (hit === 1) await rawRedis.expire(K_CHAT_RATE(sid), 5);
                if (hit > 5) throw AppError.badRequest("RATE_LIMIT");

                const item = { sid: maskSid(sid), text: clean, ts: Date.now() };
                await pushChat(item);
                broadcast(io, "chat_message", item);
                ok(socket, "chat_ok", { ts: item.ts });
            } catch (e: any) {
                ok(socket, "error", { code: e.code ?? "BAD_REQUEST", message: e.message ?? String(e) });
            }
        });

        ok(socket, "players_count", { room: ROOM, count: (nsp.adapter.rooms.get(ROOM)?.size ?? 0) });
    });

    // boot recovery + engine loop
    recoverAndRun(io);
}
