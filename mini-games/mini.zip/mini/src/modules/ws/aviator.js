"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a, _b, _c, _d, _e, _f, _g, _h, _j;
Object.defineProperty(exports, "__esModule", { value: true });
exports.recoverAndRun = recoverAndRun;
exports.mountAviator = mountAviator;
const crypto_1 = __importDefault(require("crypto"));
const nanoid_1 = require("nanoid");
const redis_1 = require("../../config/redis");
const errors_1 = require("../../errors");
const operator_1 = require("../../stores/operator");
const client_1 = require("./../../operator/client");
// === RTP integration (JetX model) ===
const drizzle_1 = require("../../config/drizzle");
const game_1 = require("../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_keys_1 = require("../../lib/redis-keys");
const date_1 = require("../../lib/date");
const jetx_1 = require("../../modules/rtp/jetx");
// ====== Config ======
const NAMESPACE = "/aviator";
const ROOM = "aviator-global";
const GAME_CODE = "jetx"; // RTP game code for aviator
const COUNTDOWN_MS = Number((_a = process.env.AVIATOR_COUNTDOWN_MS) !== null && _a !== void 0 ? _a : 8000);
const GAP_MS = Number((_b = process.env.AVIATOR_GAP_MS) !== null && _b !== void 0 ? _b : 1200);
const TICK_MS = Number((_c = process.env.AVIATOR_TICK_MS) !== null && _c !== void 0 ? _c : 200);
const R = Number((_d = process.env.AVIATOR_GROWTH_R) !== null && _d !== void 0 ? _d : 0.09); // exp growth rate
const EXP_P = Number((_e = process.env.AVIATOR_EXP_P) !== null && _e !== void 0 ? _e : 1.2); // shape ( >1 = slower start )
const TIME_SCALE = Number((_f = process.env.AVIATOR_TIME_SCALE) !== null && _f !== void 0 ? _f : 1.5); // global speed
const ALLOW_LATE_BET_MS = Number((_g = process.env.AVIATOR_LATE_BET_MS) !== null && _g !== void 0 ? _g : 300);
const INCLUDE_BALANCE = process.env.AVIATOR_INCLUDE_BALANCE === "true";
const MAX_BETS_PER_USER = Number((_h = process.env.AVIATOR_MAX_BETS_PER_USER) !== null && _h !== void 0 ? _h : 2);
const CANCEL_GRACE_MS = Number((_j = process.env.AVIATOR_CANCEL_GRACE_MS) !== null && _j !== void 0 ? _j : 0); // 0 = only countdown
const HISTORY_SIZE = 50;
// Redis keys
const K_CURR = "aviator:round:current"; // JSON
const K_BETS = (rid) => `aviator:bets:${rid}`; // HSET bet_id -> JSON
const K_AUTO = (rid) => `aviator:auto:${rid}`; // ZSET (score=auto multiplier) -> bet_id
const K_HIST = "aviator:history"; // LPUSH JSON (bounded)
const K_IDEM_BET = (sid, key) => `idem:aviator:bet:${sid}:${key}`;
const K_IDEM_CASH = (sid, key) => `idem:aviator:cash:${sid}:${key}`;
const K_LIVECOUNT = (rid, sid) => `aviator:livecount:${rid}:${sid}`; // per-round, per-user live bets counter
const K_IDEM_CANCEL = (sid, key) => `idem:aviator:cancel:${sid}:${key}`;
const SESSION_KEY = (sid) => `session:${sid}`; // rely on Redis keyPrefix
// RTP round key helpers (store budget/caps)
const K_RTP_ROUND = (yymmdd, rid) => redis_keys_1.rk.round(GAME_CODE, yymmdd, rid);
// ====== Chat config & keys ======
const CHAT_HISTORY_SIZE = 30;
const K_CHAT = "aviator:chat";
const K_CHAT_RATE = (sid) => `aviator:chat:rate:${sid}`;
function maskSid(sid) { return sid.length > 4 ? `***${sid.slice(-4)}` : `***${sid}`; }
function pushChat(item) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.lpush(K_CHAT, JSON.stringify(item)); yield redis_1.rawRedis.ltrim(K_CHAT, 0, CHAT_HISTORY_SIZE - 1); });
}
function loadChat() {
    return __awaiter(this, arguments, void 0, function* (limit = CHAT_HISTORY_SIZE) { const arr = yield redis_1.redis.lrange(K_CHAT, 0, limit - 1); return arr.map(s => JSON.parse(s)); });
}
// ====== fairness / math ======
function crashFromSeeds(server_seed, round_id) {
    const h = crypto_1.default.createHmac("sha256", server_seed).update(round_id).digest("hex");
    const u = (parseInt(h.slice(0, 8), 16) >>> 0) / 0xffffffff;
    return Math.min(1000, 1 / (1 - Math.max(u, 1e-12)));
}
// function mAt(t_ms: number) { return Math.floor(100 * Math.exp(R * (t_ms / 1000))) / 100; }
// function tFor(mult: number) { return Math.log(Math.max(1e-12, mult)) / R * 1000; }
// t_ms -> multiplier
function mAt(t_ms) {
    const tSec = (t_ms / 1000) / TIME_SCALE; // scale overall time
    const shaped = Math.pow(tSec, EXP_P); // slow early, faster later
    const mult = Math.exp(R * shaped);
    return Math.floor(mult * 100) / 100; // 2-decimals
}
// multiplier -> t_ms (inverse of above!)
function tFor(mult) {
    const y = Math.log(Math.max(1e-12, mult)) / R; // y = tSec^EXP_P
    const tSec = Math.pow(Math.max(y, 0), 1 / EXP_P); // tSec = y^(1/EXP_P)
    return tSec * TIME_SCALE * 1000;
}
// ====== session lookup (TODO: wire to your provider session store) ======
function getProviderSession(sid) {
    return __awaiter(this, void 0, void 0, function* () {
        const raw = yield redis_1.redis.get(`session:${sid}`);
        if (!raw)
            throw errors_1.AppError.unauthorized("INVALID_SID");
        return JSON.parse(raw);
    });
}
// ====== misc helpers ======
function now() { return Date.now(); }
function ok(socket, type, data) { socket.emit(type, { type, data }); }
function broadcast(io, type, data) { io.of(NAMESPACE).to(ROOM).emit(type, { type, data }); }
let engineRunning = false;
let tickTimer = null;
// ====== wallet helpers ======
function debitBet(sess, amount, txn) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        if (sess.mode === "demo") {
            const key = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(key);
            const bal = v ? Number(v) : Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
            if (bal < amount)
                throw errors_1.AppError.badRequest("INSUFFICIENT_FUN");
            yield redis_1.redis.set(key, String(+(bal - amount).toFixed(2)), 2 * 60 * 60);
            return +(bal - amount).toFixed(2);
        }
        else {
            const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.deposit)(opCtx, { TransactionId: txn, TransactionType: "PlaceBet", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: { Source: "Aviator", GameName: "Aviator", RoundId: txn, GameNumber: `${Date.now()}` } });
            return undefined;
        }
    });
}
function creditCashout(sess, amount, txn) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        if (amount <= 0)
            return undefined;
        if (sess.mode === "demo") {
            const key = `demo:bal:${sess.sid}`;
            const v = yield redis_1.redis.get(key);
            const bal = v ? Number(v) : Number((_a = process.env.DEMO_START_BALANCE) !== null && _a !== void 0 ? _a : 1000);
            const newBal = +(bal + amount).toFixed(2);
            yield redis_1.redis.set(key, String(newBal), 2 * 60 * 60);
            return newBal;
        }
        else {
            const op = yield (0, operator_1.findOperatorByPortalName)(sess.portalName);
            const opCtx = { baseUrl: op.baseUrl, secret: op.secret, session: { id: (_b = sess.opSessionId) !== null && _b !== void 0 ? _b : sess.sessionId, userName: sess.userName, clientExternalKey: sess.clientExternalKey } };
            yield (0, client_1.withdraw)(opCtx, { TransactionId: txn, TransactionType: "WinAmount", Amount: amount, CurrencyCode: sess.currency, TransactionInfo: { Source: "Aviator", GameName: "Aviator", RoundId: txn, GameNumber: `${Date.now()}` } });
            return undefined;
        }
    });
}
// ====== players count ======
function emitPlayersCount(io) {
    var _a;
    const room = io.of(NAMESPACE).adapter.rooms.get(ROOM);
    const count = (_a = room === null || room === void 0 ? void 0 : room.size) !== null && _a !== void 0 ? _a : 0;
    io.of(NAMESPACE).to(ROOM).emit("players_count", { type: "players_count", data: { room: ROOM, count } });
}
// ====== history helpers ======
function pushHistory(item) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.lpush(K_HIST, JSON.stringify(item)); yield redis_1.rawRedis.ltrim(K_HIST, 0, HISTORY_SIZE - 1); });
}
function loadHistory() {
    return __awaiter(this, arguments, void 0, function* (limit = HISTORY_SIZE) { const arr = yield redis_1.redis.lrange(K_HIST, 0, limit - 1); return arr.map(s => JSON.parse(s)); });
}
// ====== engine storage ======
function writeCurrentRound(r) {
    return __awaiter(this, void 0, void 0, function* () { yield redis_1.redis.set(K_CURR, JSON.stringify(r)); });
}
function readCurrentRound() {
    return __awaiter(this, void 0, void 0, function* () { const raw = yield redis_1.redis.get(K_CURR); return raw ? JSON.parse(raw) : null; });
}
// ====== RTP cfg loader (REAL mode) ======
function loadJetxCfg() {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, GAME_CODE)).limit(1))[0];
        if (!g || !g.is_active)
            throw errors_1.AppError.badRequest("GAME_INACTIVE");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        if (!cfg)
            throw errors_1.AppError.badRequest("GAME_CFG_MISSING");
        return {
            rtp_target: Number(cfg.rtp_target),
            alpha_round: Number(cfg.alpha_round),
            gamma_round: Number(cfg.gamma_round),
            cashout_intensity: Number(cfg.cashout_intensity),
            global_odd_cap: Number(cfg.global_odd_cap),
            per_bet_cap: Number(cfg.per_bet_cap),
            max_round_budget: undefined,
        };
    });
}
// ====== engine ======
function startNewRound(io, prevSeed) {
    return __awaiter(this, void 0, void 0, function* () {
        const server_seed = crypto_1.default.randomBytes(32).toString("hex");
        const server_seed_hash = crypto_1.default.createHash("sha256").update(server_seed).digest("hex");
        const next_server_seed = crypto_1.default.randomBytes(32).toString("hex");
        const next_server_seed_hash = crypto_1.default.createHash("sha256").update(next_server_seed).digest("hex");
        const round_id = (0, nanoid_1.nanoid)();
        const crash_multiplier = crashFromSeeds(server_seed, round_id);
        const countdown_ends_at = now() + COUNTDOWN_MS;
        const crash_at_ts = countdown_ends_at + tFor(crash_multiplier);
        const r = { round_id, phase: "countdown", countdown_ends_at, crash_multiplier, crash_at_ts, server_seed, server_seed_hash, next_server_seed_hash };
        yield writeCurrentRound(r);
        broadcast(io, "state", { round_id, phase: "countdown", countdown_ends_at, server_seed_hash, next_server_seed_hash });
        setTimeout(() => __awaiter(this, void 0, void 0, function* () {
            var _a;
            // move to flight
            const flight_started_at = now();
            r.phase = "flight";
            r.flight_started_at = flight_started_at;
            // ==== RTP: compute round budget/caps (REAL mode) ====
            try {
                const yymmdd = (0, date_1.toYYMMDD)();
                r.yymmdd = yymmdd;
                // scan bets for REAL mode totals
                const bets = yield redis_1.redis.hgetall(K_BETS(r.round_id));
                let S = 0, sMax = 0;
                for (const raw of Object.values(bets)) {
                    const b = JSON.parse(raw);
                    if (b.status === "live" && b.mode === "real") {
                        const amt = Number(b.amount) || 0;
                        S += amt;
                        if (amt > sMax)
                            sMax = amt;
                    }
                }
                if (S > 0) {
                    const cfg = yield loadJetxCfg();
                    const { B_round, cap_per_bet, max_odd_cap } = yield (0, jetx_1.jetxRoundStart)(GAME_CODE, cfg, { sMax, S }, r.round_id, yymmdd);
                    // add round payin now (per design)
                    const dayKey = redis_keys_1.rk.day(GAME_CODE, yymmdd);
                    yield redis_1.redis.hsetnx(dayKey, "rtp_target", (_a = cfg.rtp_target) !== null && _a !== void 0 ? _a : 0.90);
                    yield redis_1.redis.hincrbyfloat(dayKey, "payin", S);
                    // cache for tick clamp
                    r.max_odd_cap = max_odd_cap;
                }
                else {
                    r.max_odd_cap = undefined;
                }
            }
            catch (e) {
                // if anything fails, continue without RTP clamps (demo-like)
                r.max_odd_cap = undefined;
            }
            yield writeCurrentRound(r);
            broadcast(io, "state", { round_id, phase: "flight", flight_started_at, crash_at_ts, crash_multiplier });
            // start ticking
            if (tickTimer) {
                clearInterval(tickTimer);
                tickTimer = null;
            }
            tickTimer = setInterval(() => __awaiter(this, void 0, void 0, function* () {
                const t = now() - r.flight_started_at;
                const m = mAt(t);
                // Clamp by max_odd_cap if present (REAL budget-driven cap)
                if (r.max_odd_cap && m >= r.max_odd_cap) {
                    // force immediate crash at cap
                    if (tickTimer) {
                        clearInterval(tickTimer);
                        tickTimer = null;
                    }
                    yield crashRound(io, r);
                    return;
                }
                broadcast(io, "tick", { round_id, t_ms: t, multiplier: m });
                // auto-cashouts
                const hits = yield redis_1.rawRedis.zrangebyscore(K_AUTO(r.round_id), "-inf", m.toString(), "LIMIT", "0", "200");
                for (const bet_id of hits)
                    yield performCashout(io, r, bet_id, "auto");
                if (m >= r.crash_multiplier) {
                    if (tickTimer) {
                        clearInterval(tickTimer);
                        tickTimer = null;
                    }
                    yield crashRound(io, r);
                }
            }), TICK_MS);
        }), COUNTDOWN_MS + 5);
    });
}
function crashRound(io, r) {
    return __awaiter(this, void 0, void 0, function* () {
        r.phase = "crashed";
        yield writeCurrentRound(r);
        // Settle remaining live bets as lost (no RTP payout changes; payin was added at flight start)
        const bets = yield redis_1.redis.hgetall(K_BETS(r.round_id));
        for (const [bet_id, raw] of Object.entries(bets)) {
            const b = JSON.parse(raw);
            if (b.status === "live") {
                b.status = "lost";
                yield redis_1.rawRedis.decr(K_LIVECOUNT(r.round_id, b.sid));
                yield redis_1.redis.hset(K_BETS(r.round_id), bet_id, JSON.stringify(b));
            }
        }
        broadcast(io, "crash", { round_id: r.round_id, at_multiplier: r.crash_multiplier, server_seed: r.server_seed, server_seed_hash: r.server_seed_hash });
        yield pushHistory({ round_id: r.round_id, at: r.crash_multiplier, server_seed_hash: r.server_seed_hash, revealed_seed: r.server_seed });
        setTimeout(() => startNewRound(io, r.server_seed), GAP_MS);
    });
}
// ====== perform cashout (with idempotency & single-execution) ======
function performCashout(io, r, bet_id, reason) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = K_BETS(r.round_id);
        const raw = yield redis_1.redis.hget(key, bet_id);
        if (!raw)
            return;
        const b = JSON.parse(raw);
        if (b.status !== "live")
            return; // idempotent
        // compute current multiplier
        const mult = r.phase === "flight" && r.flight_started_at ? mAt(now() - r.flight_started_at) : 0;
        if (r.phase !== "flight" || mult >= r.crash_multiplier)
            return;
        // mark status first to avoid races
        b.status = "cashed";
        yield redis_1.rawRedis.decr(K_LIVECOUNT(r.round_id, b.sid));
        let payout = 0;
        let cashMult = +(Math.floor(mult * 100) / 100).toFixed(2);
        const sess = yield getProviderSession(b.sid);
        if (b.mode === "real" && r.yymmdd) {
            // Use JetX governor to apply per-bet cap and update day payout; may trigger shouldCrash
            const res = yield (0, jetx_1.jetxCashout)(GAME_CODE, r.round_id, Number(b.amount), cashMult, r.yymmdd);
            payout = +res.win.toFixed(2);
            // Adjust displayed multiplier to reflect any cap effects (payout/amount)
            cashMult = +(payout / Number(b.amount)).toFixed(2);
            // if budget nearly exhausted or odd cap reached → crash ASAP
            if (res.shouldCrash) {
                // Force immediate crash at current cap/mult
                if (tickTimer) {
                    clearInterval(tickTimer);
                    tickTimer = null;
                }
                yield crashRound(io, r);
            }
        }
        else {
            // demo: plain payout, no RTP clamp
            payout = +(Number(b.amount) * cashMult).toFixed(2);
        }
        b.cashout_multiplier = cashMult;
        b.cashout_ms = now();
        b.payout = payout;
        yield redis_1.redis.hset(key, bet_id, JSON.stringify(b));
        // credit wallet
        const newBal = yield creditCashout(sess, payout, `${r.round_id}-CASH-${bet_id}`);
        // notify the room
        io.of(NAMESPACE).to(ROOM).emit("cashout_event", {
            type: "cashout_event",
            data: {
                round_id: r.round_id,
                bet_id,
                sid: maskSid(b.sid),
                cashout_multiplier: cashMult,
                payout
            }
        });
        return newBal;
    });
}
// ====== Recovery on boot ======
function recoverAndRun(io) {
    return __awaiter(this, void 0, void 0, function* () {
        if (engineRunning)
            return;
        engineRunning = true;
        const r = yield readCurrentRound();
        if (!r) {
            yield startNewRound(io);
            return;
        }
        const n = now();
        if (r.phase === "countdown") {
            const delay = Math.max(0, r.countdown_ends_at - n);
            broadcast(io, "state", { round_id: r.round_id, phase: "countdown", countdown_ends_at: r.countdown_ends_at, server_seed_hash: r.server_seed_hash, next_server_seed_hash: r.next_server_seed_hash });
            setTimeout(() => __awaiter(this, void 0, void 0, function* () {
                r.phase = "flight";
                r.flight_started_at = now();
                yield writeCurrentRound(r);
                broadcast(io, "state", { round_id: r.round_id, phase: "flight", flight_started_at: r.flight_started_at, crash_at_ts: r.crash_at_ts, crash_multiplier: r.crash_multiplier });
                if (tickTimer) {
                    clearInterval(tickTimer);
                    tickTimer = null;
                }
                tickTimer = setInterval(() => __awaiter(this, void 0, void 0, function* () {
                    const t = now() - r.flight_started_at;
                    const m2 = mAt(t);
                    // clamp by cached max_odd_cap if any
                    if (r.max_odd_cap && m2 >= r.max_odd_cap) {
                        if (tickTimer) {
                            clearInterval(tickTimer);
                            tickTimer = null;
                        }
                        yield crashRound(io, r);
                        return;
                    }
                    broadcast(io, "tick", { round_id: r.round_id, t_ms: t, multiplier: m2 });
                    const hits = yield redis_1.rawRedis.zrangebyscore(K_AUTO(r.round_id), "-inf", m2.toString(), "LIMIT", "0", "200");
                    for (const bet_id of hits)
                        yield performCashout(io, r, bet_id, "auto");
                    if (m2 >= r.crash_multiplier) {
                        if (tickTimer) {
                            clearInterval(tickTimer);
                            tickTimer = null;
                        }
                        yield crashRound(io, r);
                    }
                }), TICK_MS);
            }), delay + 10);
            return;
        }
        if (r.phase === "flight") {
            const m = mAt(n - r.flight_started_at);
            if (m >= r.crash_multiplier) {
                yield crashRound(io, r);
                return;
            }
            broadcast(io, "state", { round_id: r.round_id, phase: "flight", flight_started_at: r.flight_started_at, crash_at_ts: r.crash_at_ts, crash_multiplier: r.crash_multiplier });
            if (tickTimer) {
                clearInterval(tickTimer);
                tickTimer = null;
            }
            tickTimer = setInterval(() => __awaiter(this, void 0, void 0, function* () {
                const t = now() - r.flight_started_at;
                const m2 = mAt(t);
                if (r.max_odd_cap && m2 >= r.max_odd_cap) {
                    if (tickTimer) {
                        clearInterval(tickTimer);
                        tickTimer = null;
                    }
                    yield crashRound(io, r);
                    return;
                }
                broadcast(io, "tick", { round_id: r.round_id, t_ms: t, multiplier: m2 });
                const hits = yield redis_1.rawRedis.zrangebyscore(K_AUTO(r.round_id), "-inf", m2.toString(), "LIMIT", "0", "200");
                for (const bet_id of hits)
                    yield performCashout(io, r, bet_id, "auto");
                if (m2 >= r.crash_multiplier) {
                    if (tickTimer) {
                        clearInterval(tickTimer);
                        tickTimer = null;
                    }
                    yield crashRound(io, r);
                }
            }), TICK_MS);
            return;
        }
        yield crashRound(io, r);
    });
}
// ====== wiring entry ======
function mountAviator(io) {
    const nsp = io.of(NAMESPACE);
    nsp.use((socket, next) => __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            const sid = (socket.handshake.auth && socket.handshake.auth.sid) ||
                socket.handshake.headers["x-provider-sid"] ||
                ((_a = socket.handshake.query) === null || _a === void 0 ? void 0 : _a.sid);
            if (!sid)
                return next(errors_1.AppError.unauthorized("UNAUTHORIZED"));
            const sess = yield getProviderSession(String(sid));
            socket.sid = String(sid);
            socket.providerSession = sess;
            next();
        }
        catch (e) {
            next(e);
        }
    }));
    nsp.on("connection", (socket) => __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const sid = socket.sid;
        const sess = socket.providerSession;
        socket.join(ROOM);
        ok(socket, "history", yield loadHistory(100));
        emitPlayersCount(io);
        socket.on("disconnect", () => {
            broadcast(io, "player_left", { sid });
            emitPlayersCount(io);
        });
        // BET (supports auto_cashout). Store mode for RTP split.
        socket.on("bet", (msg) => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            let reservedTicket = false;
            try {
                const { amount, auto_cashout, idempotency_key } = (msg === null || msg === void 0 ? void 0 : msg.data) || msg || {};
                if (!(amount > 0))
                    throw errors_1.AppError.badRequest("BAD_AMOUNT");
                if (idempotency_key) {
                    const prev = yield redis_1.redis.get(K_IDEM_BET(sid, idempotency_key));
                    if (prev) {
                        ok(socket, "bet_accepted", JSON.parse(prev));
                        return;
                    }
                }
                const r = yield readCurrentRound();
                if (!r)
                    throw errors_1.AppError.internal("NO_ROUND");
                const acceptWindow = r.phase === "countdown" ||
                    (r.phase === "flight" && r.flight_started_at && now() - r.flight_started_at < ALLOW_LATE_BET_MS);
                if (!acceptWindow)
                    throw errors_1.AppError.badRequest("ROUND_CLOSED");
                const cntKey = K_LIVECOUNT(r.round_id, sid);
                const c = yield redis_1.rawRedis.incr(cntKey);
                reservedTicket = true;
                if (c === 1)
                    yield redis_1.rawRedis.expire(cntKey, 10 * 60);
                if (c > MAX_BETS_PER_USER)
                    throw errors_1.AppError.badRequest("MAX_BETS_REACHED");
                const betTxn = `${r.round_id}-BET-${(0, nanoid_1.nanoid)()}`;
                const newBal = yield debitBet(sess, amount, betTxn);
                const bet_id = (0, nanoid_1.nanoid)();
                const bet = {
                    sid,
                    amount,
                    auto: (auto_cashout !== null && auto_cashout !== void 0 ? auto_cashout : null),
                    placed_at_ms: now(),
                    status: "live",
                    txn_id: betTxn,
                    mode: (sess.mode === "demo" ? "demo" : "real")
                };
                yield redis_1.redis.hset(K_BETS(r.round_id), bet_id, JSON.stringify(bet));
                if (auto_cashout && typeof auto_cashout === "number" && auto_cashout > 1) {
                    yield redis_1.rawRedis.zadd(K_AUTO(r.round_id), Number(auto_cashout), bet_id);
                }
                const payload = { bet_id, amount, auto_cashout: auto_cashout !== null && auto_cashout !== void 0 ? auto_cashout : null, balance: newBal !== null && newBal !== void 0 ? newBal : null };
                if (idempotency_key)
                    yield redis_1.redis.set(K_IDEM_BET(sid, idempotency_key), JSON.stringify(payload), 24 * 60 * 60);
                ok(socket, "bet_accepted", payload);
                broadcast(io, "user_bet", { round_id: r.round_id, bet_id, sid: maskSid(sid), amount, auto_cashout: auto_cashout !== null && auto_cashout !== void 0 ? auto_cashout : null, ts: Date.now() });
            }
            catch (e) {
                ok(socket, "error", { code: (_a = e.code) !== null && _a !== void 0 ? _a : "BAD_REQUEST", message: (_b = e.message) !== null && _b !== void 0 ? _b : String(e) });
                if (reservedTicket) {
                    const r = yield readCurrentRound();
                    if (r)
                        yield redis_1.rawRedis.decr(K_LIVECOUNT(r.round_id, sid));
                }
            }
        }));
        // MANUAL CASHOUT
        socket.on("cashout", (msg) => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            try {
                const { bet_id, idempotency_key } = (msg === null || msg === void 0 ? void 0 : msg.data) || msg || {};
                if (!bet_id)
                    throw errors_1.AppError.badRequest("MISSING_BET_ID");
                if (idempotency_key) {
                    const prev = yield redis_1.redis.get(K_IDEM_CASH(sid, idempotency_key));
                    if (prev) {
                        ok(socket, "cashout_ok", JSON.parse(prev));
                        return;
                    }
                }
                const r = yield readCurrentRound();
                if (!r || r.phase !== "flight")
                    throw errors_1.AppError.badRequest("ROUND_CLOSED");
                const raw = yield redis_1.redis.hget(K_BETS(r.round_id), bet_id);
                if (!raw)
                    throw errors_1.AppError.notFound("BET_NOT_FOUND");
                const b = JSON.parse(raw);
                if (b.sid !== sid)
                    throw errors_1.AppError.unauthorized("NOT_OWNER");
                if (b.status !== "live")
                    throw errors_1.AppError.badRequest("ALREADY_RESOLVED");
                // current multiplier
                const mult = mAt(now() - r.flight_started_at);
                if (mult >= r.crash_multiplier)
                    throw errors_1.AppError.badRequest("TOO_LATE");
                // Settle (RTP-aware for real mode)
                // Mark status & release ticket inside performCashout()
                const newBal = yield performCashout(io, r, bet_id, "user");
                const updated = yield redis_1.redis.hget(K_BETS(r.round_id), bet_id);
                const ub = JSON.parse(updated);
                const payload = { bet_id, cashout_multiplier: ub.cashout_multiplier, payout: ub.payout, balance: newBal !== null && newBal !== void 0 ? newBal : null };
                if (idempotency_key)
                    yield redis_1.redis.set(K_IDEM_CASH(sid, idempotency_key), JSON.stringify(payload), 24 * 60 * 60);
                ok(socket, "cashout_ok", payload);
                broadcast(io, "user_cashout", {
                    round_id: r.round_id, bet_id, sid: maskSid(b.sid),
                    cashout_multiplier: ub.cashout_multiplier, payout: ub.payout, reason: "user", ts: Date.now()
                });
            }
            catch (e) {
                ok(socket, "error", { code: (_a = e.code) !== null && _a !== void 0 ? _a : "BAD_REQUEST", message: (_b = e.message) !== null && _b !== void 0 ? _b : String(e) });
            }
        }));
        ok(socket, "chat_history", yield loadChat(100));
        socket.on("chat_typing", () => {
            broadcast(io, "chat_typing", { sid: maskSid(socket.sid), ts: Date.now() });
        });
        socket.on("chat_send", (msg) => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            try {
                const sid = socket.sid;
                const { text } = (msg === null || msg === void 0 ? void 0 : msg.data) || msg || {};
                const raw = String(text !== null && text !== void 0 ? text : "").trim();
                if (!raw)
                    throw errors_1.AppError.badRequest("EMPTY_MESSAGE");
                if (raw.length > 300)
                    throw errors_1.AppError.badRequest("MESSAGE_TOO_LONG");
                const clean = raw.replace(/[^\x09\x0A\x0D\x20-\x7E\u1200-\u137F\u1380-\u1399\u2D80-\u2DDF]/g, "");
                const hit = yield redis_1.rawRedis.incr(K_CHAT_RATE(sid));
                if (hit === 1)
                    yield redis_1.rawRedis.expire(K_CHAT_RATE(sid), 5);
                if (hit > 5)
                    throw errors_1.AppError.badRequest("RATE_LIMIT");
                const item = { sid: maskSid(sid), text: clean, ts: Date.now() };
                yield pushChat(item);
                broadcast(io, "chat_message", item);
                ok(socket, "chat_ok", { ts: item.ts });
            }
            catch (e) {
                ok(socket, "error", { code: (_a = e.code) !== null && _a !== void 0 ? _a : "BAD_REQUEST", message: (_b = e.message) !== null && _b !== void 0 ? _b : String(e) });
            }
        }));
        ok(socket, "players_count", { room: ROOM, count: ((_b = (_a = nsp.adapter.rooms.get(ROOM)) === null || _a === void 0 ? void 0 : _a.size) !== null && _b !== void 0 ? _b : 0) });
    }));
    // boot recovery + engine loop
    recoverAndRun(io);
}
