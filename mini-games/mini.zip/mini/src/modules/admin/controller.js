"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.me = exports.adminRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const async_handler_1 = require("../../middleware/async-handler");
const admin_auth_1 = require("../../middleware/admin-auth");
const svc = __importStar(require("./service"));
// Router
exports.adminRouter = (0, express_1.Router)();
/* -------------------- Auth -------------------- */
const LoginBody = zod_1.z.object({ username: zod_1.z.string().min(2), password: zod_1.z.string().min(6) });
exports.adminRouter.post("/auth/login", (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { username, password } = LoginBody.parse(req.body);
        const out = yield svc.adminLogin(username, password);
        // out is { sid, user }; it does NOT contain `ok`
        res.json(Object.assign({ ok: true }, out));
    }
    catch (error) {
        res.status(401).json({ ok: false, message: error.message });
    }
})));
exports.adminRouter.get("/auth/me", admin_auth_1.adminAuth, (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const sid = (req.get("x-admin-sid") || "");
        const me = yield svc.adminMe(sid);
        res.json({ ok: true, me });
    }
    catch (error) {
        res.status(401).json({ ok: false, message: error.message });
    }
})));
exports.me = (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    // adminAuth must run before this route
    if (!req.admin) {
        return res.status(401).json({ ok: false, code: "UNAUTHORIZED" });
    }
    // If you still want to hydrate from Redis:
    if (req.admin.kind === "user" && req.admin.sid) {
        const me = yield svc.adminMe(req.admin.sid);
        return res.json({ ok: true, me });
    }
    // For token-based principal, return the principal itself
    return res.json({ ok: true, me: req.admin });
}));
exports.adminRouter.post("/auth/logout", admin_auth_1.adminAuth, (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const sid = (req.get("x-admin-sid") || "");
        yield svc.adminLogout(sid);
        res.json({ ok: true });
    }
    catch (error) {
        res.status(401).json({ ok: false, message: error.message });
    }
})));
/* -------------------- Tokens -------------------- */
const IssueTokenBody = zod_1.z.object({
    label: zod_1.z.string().min(2),
    scopes: zod_1.z.array(zod_1.z.string()).min(1),
    expiresInSeconds: zod_1.z.number().optional(),
    operatorId: zod_1.z.number().optional(),
});
exports.adminRouter.post("/tokens", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("admin:token:issue"), (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        if (((_a = req.admin) === null || _a === void 0 ? void 0 : _a.kind) !== "user") {
            return res.status(403).json({ ok: false, message: "Only user sessions can issue tokens" });
        }
        const body = IssueTokenBody.parse(req.body);
        const created = yield svc.issueToken(Object.assign(Object.assign({}, body), { createdBy: req.admin.userId }));
        // created = { id, token }
        res.json(Object.assign({ ok: true }, created));
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
exports.adminRouter.delete("/tokens/:id", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("admin:token:revoke"), (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const id = Number(req.params.id);
        const actorId = ((_a = req.admin) === null || _a === void 0 ? void 0 : _a.kind) === "user" ? req.admin.userId : 0;
        yield svc.revokeToken(id, actorId);
        res.json({ ok: true });
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
/* -------------------- Games -------------------- */
exports.adminRouter.get("/games", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("games:read"), (0, async_handler_1.asyncHandler)((_req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield svc.listGames();
        res.json({ ok: true, data });
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
const UpdateGameBody = svc.UpdateGameBody;
exports.adminRouter.patch("/games/:id", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("games:write"), (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const id = Number(req.params.id);
        const payload = UpdateGameBody.parse(req.body);
        const updated = yield svc.updateGame(id, payload, req.admin);
        res.json({ ok: true, data: updated });
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
exports.adminRouter.put("/games/:id/config", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("games:write"), (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const id = Number(req.params.id);
        // FIX: use the exported UpsertGameConfigBody from service
        const payload = svc.UpsertGameConfigBody.parse(req.body);
        const cfg = yield svc.upsertGameConfig(id, payload, req.admin);
        res.json({ ok: true, data: cfg });
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
/* -------------------- RTP -------------------- */
const ListRtpQuery = zod_1.z.object({
    game: zod_1.z.string().optional(),
    from: zod_1.z.string().optional(),
    to: zod_1.z.string().optional(),
});
exports.adminRouter.get("/rtp/day", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("rtp:read"), (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const q = ListRtpQuery.parse(req.query);
        const data = yield svc.listRtpDay({ gameCode: q.game, from: q.from, to: q.to });
        res.json({ ok: true, data });
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
exports.adminRouter.post("/rtp/adjust", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("rtp:adjust"), (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const body = svc.RtpAdjustBody.parse(req.body);
        const out = yield svc.adjustRtp(req.admin, body);
        // FIX: service already returns { ok: true }, don't duplicate `ok`
        res.json(out);
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
/* -------------------- Operators / Cash Flow -------------------- */
exports.adminRouter.get("/operators", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("ops:read"), (0, async_handler_1.asyncHandler)((_req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield svc.listOperators();
        res.json({ ok: true, data });
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
exports.adminRouter.get("/operators/:id/balance", admin_auth_1.adminAuth, (0, admin_auth_1.requireScope)("ops:read"), (0, async_handler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const id = Number(req.params.id);
        const balance = yield svc.getOperatorBalance(id);
        res.json({ ok: true, balance });
    }
    catch (error) {
        res.status(403).json({ ok: false, message: error.message });
    }
})));
const ListTokensQuery = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).default(1),
    limit: zod_1.z.coerce.number().int().min(1).max(200).default(50),
    q: zod_1.z.string().optional(),
    status: zod_1.z.enum(["all", "active", "inactive"]).default("all"),
    operator_id: zod_1.z.coerce.number().int().optional(),
});
exports.adminRouter.get("/tokens", admin_auth_1.adminAuth, 
// adjust scope to your policy; earlier we used "admin:token:issue"/"admin:token:revoke"
// For listing, either reuse 'admin:token:issue' or define a 'admin:token:read'
(0, admin_auth_1.requireScope)("admin:token:issue"), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const q = ListTokensQuery.parse(req.query);
        const data = yield svc.listTokens({
            page: q.page,
            limit: q.limit,
            q: q.q,
            status: q.status,
            operatorId: q.operator_id,
        });
        res.json(Object.assign({ ok: true }, data));
    }
    catch (e) {
        next(e);
    }
}));
// Example: “me” route
//adminRouter.get("/auth/mee", adminAuth, me);
exports.default = exports.adminRouter;
