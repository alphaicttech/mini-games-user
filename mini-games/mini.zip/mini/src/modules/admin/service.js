"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateGameConfigBody = exports.RtpAdjustBody = exports.UpsertGameConfigBody = exports.UpdateGameBody = void 0;
exports.adminLogin = adminLogin;
exports.adminLogout = adminLogout;
exports.adminMe = adminMe;
exports.listAdminSessions = listAdminSessions;
exports.listTokens = listTokens;
exports.issueToken = issueToken;
exports.revokeToken = revokeToken;
exports.hasScope = hasScope;
exports.listGames = listGames;
exports.updateGame = updateGame;
exports.upsertGameConfig = upsertGameConfig;
exports.listRtpDay = listRtpDay;
exports.adjustRtp = adjustRtp;
exports.listOperators = listOperators;
exports.getOperatorBalance = getOperatorBalance;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const drizzle_1 = require("../../config/drizzle");
const redis_1 = require("../../config/redis");
const admin_1 = require("../../db/admin");
const game_1 = require("../../db/game");
const rtp_1 = require("../../db/rtp");
const operator_1 = require("../../db/operator");
const drizzle_orm_1 = require("drizzle-orm");
const crypto_1 = __importDefault(require("crypto"));
const zod_1 = require("zod");
const client_1 = require("../../operator/client");
// ---------- Auth ----------
function adminLogin(username, password) {
    return __awaiter(this, void 0, void 0, function* () {
        const rows = yield drizzle_1.db.select().from(admin_1.adminUsers).where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(admin_1.adminUsers.username, username), (0, drizzle_orm_1.eq)(admin_1.adminUsers.isActive, true))).limit(1);
        const user = rows[0];
        if (!user)
            throw new Error("INVALID_CREDENTIALS");
        const ok = yield bcryptjs_1.default.compare(password, user.passwordHash);
        if (!ok)
            throw new Error("INVALID_CREDENTIALS");
        const sid = crypto_1.default.randomUUID();
        const session = {
            userId: user.id,
            username: user.username,
            role: user.role,
            scopes: roleToScopes(user.role),
            createdAt: Date.now(),
        };
        yield redis_1.redis.setJSON(`admin:sess:${sid}`, session, 3600); // 1h
        yield drizzle_1.db.insert(admin_1.adminAudit).values({
            actorType: "USER",
            actorId: user.id,
            actorName: user.username,
            action: "LOGIN",
            resource: "auth",
            meta: {},
        });
        return { sid, user: { id: user.id, username: user.username, role: user.role } };
    });
}
function adminLogout(sid) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.del(`admin:sess:${sid}`);
    });
}
function adminMe(sid) {
    return __awaiter(this, void 0, void 0, function* () {
        const s = yield redis_1.redis.getJSON(`admin:sess:${sid}`);
        if (!s)
            throw new Error("NO_SESSION");
        return s;
    });
}
function listAdminSessions(userId) {
    return __awaiter(this, void 0, void 0, function* () {
        // naive approach: scan keys (optimize later)
        const raw = yield redis_1.redis.getRaw().keys("alpha-mini-games:admin:sess:*");
        const sessions = [];
        for (const k of raw) {
            const s = yield redis_1.redis.getJSON(k.replace("alpha-mini-games:", ""));
            if (!userId || (s === null || s === void 0 ? void 0 : s.userId) === userId) {
                sessions.push(Object.assign({ key: k }, s));
            }
        }
        return sessions;
    });
}
/**
 * Returns paginated list of admin tokens with optional filters.
 * NOTE: adjust field names if your admin_tokens schema differs.
 */
function listTokens() {
    return __awaiter(this, arguments, void 0, function* (params = {}) {
        var _a, _b;
        const page = Math.max(1, (_a = params.page) !== null && _a !== void 0 ? _a : 1);
        const limit = Math.min(Math.max(1, (_b = params.limit) !== null && _b !== void 0 ? _b : 50), 500);
        const offset = (page - 1) * limit;
        const filters = [];
        if (params.q && params.q.trim().length > 0) {
            // case-insensitive label filter; use ILIKE if available in your drizzle version:
            // import { ilike } from 'drizzle-orm/pg-core'; and replace `like` with `ilike`
            filters.push((0, drizzle_orm_1.like)(admin_1.adminTokens.label, `%${params.q}%`));
        }
        if (params.status === "active") {
            filters.push((0, drizzle_orm_1.eq)(admin_1.adminTokens.isActive, true));
        }
        else if (params.status === "inactive") {
            filters.push((0, drizzle_orm_1.eq)(admin_1.adminTokens.isActive, false));
        }
        if (params.operatorId != null) {
            filters.push((0, drizzle_orm_1.eq)(admin_1.adminTokens.operatorId, params.operatorId));
        }
        const where = filters.length ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const items = yield drizzle_1.db
            .select({
            id: admin_1.adminTokens.id,
            label: admin_1.adminTokens.label,
            scopes: admin_1.adminTokens.scopes,
            operatorId: admin_1.adminTokens.operatorId,
            isActive: admin_1.adminTokens.isActive,
            createdAt: admin_1.adminTokens.createdAt,
            expiresAt: admin_1.adminTokens.expiresAt,
        })
            .from(admin_1.adminTokens)
            .where(where)
            .orderBy((0, drizzle_orm_1.desc)(admin_1.adminTokens.id))
            .limit(limit)
            .offset(offset);
        return {
            page,
            limit,
            items,
        };
    });
}
// ---------- Tokens ----------
function issueToken(params) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const tokenPlain = crypto_1.default.randomUUID().replace(/-/g, "") + crypto_1.default.randomBytes(8).toString("hex");
        const tokenHash = crypto_1.default.createHash("sha256").digest("hex").toString(); // OOPS fix: use update(tokenPlain)
        // Fix: correct hashing
        const tokenHash2 = crypto_1.default.createHash("sha256").update(tokenPlain).digest("hex");
        const expiresAt = new Date(Date.now() + ((_a = params.expiresInSeconds) !== null && _a !== void 0 ? _a : 3600 * 24 * 365) * 1000);
        const [row] = yield drizzle_1.db.insert(admin_1.adminTokens).values({
            label: params.label,
            tokenHash: tokenHash2,
            scopes: params.scopes,
            isActive: true,
            operatorId: params.operatorId,
            createdBy: params.createdBy,
            expiresAt,
        }).returning();
        yield drizzle_1.db.insert(admin_1.adminAudit).values({
            actorType: "USER",
            actorId: params.createdBy,
            actorName: `user:${params.createdBy}`,
            action: "TOKEN_CREATE",
            resource: `token:${row.id}`,
            meta: { scopes: params.scopes, operatorId: params.operatorId },
        });
        return { id: row.id, token: tokenPlain };
    });
}
function revokeToken(id, actorId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield drizzle_1.db.update(admin_1.adminTokens).set({ isActive: false }).where((0, drizzle_orm_1.eq)(admin_1.adminTokens.id, id));
        yield drizzle_1.db.insert(admin_1.adminAudit).values({
            actorType: "USER", actorId, actorName: `user:${actorId}`, action: "TOKEN_REVOKE", resource: `token:${id}`,
        });
    });
}
function roleToScopes(role) {
    if (role === "SUPER_ADMIN")
        return ["*"];
    if (role === "OPS")
        return ["games:read", "games:write", "rtp:read", "cash:read"];
    if (role === "RISK")
        return ["rtp:read", "rtp:adjust"];
    return ["read"];
}
function hasScope(p, needed) {
    var _a, _b, _c;
    if (!p)
        return false;
    if (p.kind === "user") {
        if (p.role === "SUPER_ADMIN")
            return true;
        if ((_a = p.scopes) === null || _a === void 0 ? void 0 : _a.includes("*"))
            return true;
        return (_b = p.scopes) === null || _b === void 0 ? void 0 : _b.includes(needed);
    }
    if (p.kind === "token") {
        return (_c = p.scopes) === null || _c === void 0 ? void 0 : _c.includes(needed);
    }
    return false;
}
// ---------- Game Management ----------
function listGames() {
    return __awaiter(this, void 0, void 0, function* () {
        const rows = yield drizzle_1.db.select().from(game_1.game).orderBy(game_1.game.code);
        const cfgs = yield drizzle_1.db.select().from(game_1.gameConfig);
        const byId = {};
        for (const c of cfgs)
            byId[c.game_id] = c;
        return rows.map(g => (Object.assign(Object.assign({}, g), { config: byId[g.id] || null })));
    });
}
exports.UpdateGameBody = zod_1.z.object({
    name: zod_1.z.string().min(2).optional(),
    is_active: zod_1.z.boolean().optional()
});
function updateGame(id, payload, actor) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const existing = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.id, id)).limit(1))[0];
        if (!existing)
            throw new Error("NOT_FOUND");
        yield drizzle_1.db.update(game_1.game).set({
            name: (_a = payload.name) !== null && _a !== void 0 ? _a : existing.name,
            is_active: (_b = payload.is_active) !== null && _b !== void 0 ? _b : existing.is_active,
        }).where((0, drizzle_orm_1.eq)(game_1.game.id, id));
        yield drizzle_1.db.insert(admin_1.adminAudit).values({
            actorType: actor.kind === "user" ? "USER" : "TOKEN",
            actorId: actor.kind === "user" ? actor.userId : actor.tokenId,
            actorName: actor.kind === "user" ? actor.username : `token:${actor.tokenId}`,
            action: "GAME_UPDATE",
            resource: `game:${existing.code}`,
            before: existing,
            after: Object.assign(Object.assign({}, existing), payload),
        });
        const [fresh] = yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.id, id)).limit(1);
        return fresh;
    });
}
exports.UpsertGameConfigBody = zod_1.z.object({
    rtp_target: zod_1.z.coerce.number().min(0.01).max(0.9999),
    alpha: zod_1.z.coerce.number().min(0).max(1),
    kappa: zod_1.z.coerce.number().min(0),
    beta: zod_1.z.coerce.number().min(0),
    per_bet_cap: zod_1.z.coerce.number().min(0),
    per_ticket_cap: zod_1.z.coerce.number().min(0),
    per_user_daily_cap: zod_1.z.coerce.number().min(0),
    alpha_round: zod_1.z.coerce.number().min(0),
    gamma_round: zod_1.z.coerce.number().min(0),
    cashout_intensity: zod_1.z.coerce.number().min(0),
    global_odd_cap: zod_1.z.coerce.number().min(0),
});
function upsertGameConfig(gameId, body, actor) {
    return __awaiter(this, void 0, void 0, function* () {
        const existing = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, gameId)).limit(1))[0];
        if (!existing) {
            const [row] = yield drizzle_1.db.insert(game_1.gameConfig).values(Object.assign({ game_id: gameId }, body)).returning();
            yield drizzle_1.db.insert(admin_1.adminAudit).values({
                actorType: actor.kind === "user" ? "USER" : "TOKEN",
                actorId: actor.kind === "user" ? actor.userId : actor.tokenId,
                actorName: actor.kind === "user" ? actor.username : `token:${actor.tokenId}`,
                action: "GAME_CONFIG_CREATE",
                resource: `game_config:${gameId}`,
                after: row,
            });
            return row;
        }
        else {
            yield drizzle_1.db.update(game_1.gameConfig).set(body).where((0, drizzle_orm_1.eq)(game_1.gameConfig.id, existing.id));
            const [fresh] = yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.id, existing.id)).limit(1);
            yield drizzle_1.db.insert(admin_1.adminAudit).values({
                actorType: actor.kind === "user" ? "USER" : "TOKEN",
                actorId: actor.kind === "user" ? actor.userId : actor.tokenId,
                actorName: actor.kind === "user" ? actor.username : `token:${actor.tokenId}`,
                action: "GAME_CONFIG_UPDATE",
                resource: `game_config:${gameId}`,
                before: existing,
                after: fresh,
            });
            return fresh;
        }
    });
}
// ---------- RTP Data ----------
function listRtpDay(params) {
    return __awaiter(this, void 0, void 0, function* () {
        const where = [];
        if (params.gameCode) {
            const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, params.gameCode)).limit(1))[0];
            if (!g)
                throw new Error("GAME_NOT_FOUND");
            where.push((0, drizzle_orm_1.eq)(rtp_1.rtpDay.game_id, g.id));
        }
        if (params.from)
            where.push((0, drizzle_orm_1.gte)(rtp_1.rtpDay.date_yymmdd, params.from));
        if (params.to)
            where.push((0, drizzle_orm_1.lte)(rtp_1.rtpDay.date_yymmdd, params.to));
        const rows = yield drizzle_1.db.select().from(rtp_1.rtpDay).where(where.length ? (0, drizzle_orm_1.and)(...where) : undefined).orderBy((0, drizzle_orm_1.desc)(rtp_1.rtpDay.date_yymmdd));
        return rows;
    });
}
exports.RtpAdjustBody = zod_1.z.object({
    game_code: zod_1.z.string().min(2),
    yymmdd: zod_1.z.string().length(6),
    delta_payin: zod_1.z.coerce.number().default(0),
    delta_payout: zod_1.z.coerce.number().default(0),
    delta_carry: zod_1.z.coerce.number().default(0),
    reason: zod_1.z.string().min(3)
});
function adjustRtp(principal, body) {
    return __awaiter(this, void 0, void 0, function* () {
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, body.game_code)).limit(1))[0];
        if (!g)
            throw new Error("GAME_NOT_FOUND");
        const [day] = yield drizzle_1.db.select().from(rtp_1.rtpDay)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(rtp_1.rtpDay.game_id, g.id), (0, drizzle_orm_1.eq)(rtp_1.rtpDay.date_yymmdd, body.yymmdd))).limit(1);
        if (!day)
            throw new Error("RTP_DAY_NOT_FOUND");
        // write adjustment record
        yield drizzle_1.db.insert(admin_1.adminAudit).values({
            actorType: principal.kind === "user" ? "USER" : "TOKEN",
            actorId: principal.kind === "user" ? principal.userId : principal.tokenId,
            actorName: principal.kind === "user" ? principal.username : `token:${principal.tokenId}`,
            action: "RTP_ADJUST",
            resource: `rtp_day:${g.code}:${body.yymmdd}`,
            before: { payin: day.payin, payout: day.payout, carry_out: day.carry_out },
            after: {
                payin: String((Number(day.payin) + body.delta_payin).toFixed(2)),
                payout: String((Number(day.payout) + body.delta_payout).toFixed(2)),
                carry_out: String((Number(day.carry_out) + body.delta_carry).toFixed(2))
            },
            meta: body,
        });
        // apply DB changes (if you want to adjust snapshots)
        yield drizzle_1.db.update(rtp_1.rtpDay).set({
            payin: String((Number(day.payin) + body.delta_payin).toFixed(2)),
            payout: String((Number(day.payout) + body.delta_payout).toFixed(2)),
            carry_out: String((Number(day.carry_out) + body.delta_carry).toFixed(2)),
        }).where((0, drizzle_orm_1.eq)(rtp_1.rtpDay.id, day.id));
        return { ok: true };
    });
}
// ---------- Operators / Cash Flow ----------
function listOperators() {
    return __awaiter(this, void 0, void 0, function* () {
        const rows = yield drizzle_1.db.select().from(operator_1.operators).orderBy((0, drizzle_orm_1.asc)(operator_1.operators.name));
        return rows;
    });
}
function getOperatorBalance(operatorId) {
    return __awaiter(this, void 0, void 0, function* () {
        const row = yield drizzle_1.db.select().from(operator_1.operators).where((0, drizzle_orm_1.eq)(operator_1.operators.id, operatorId)).limit(1);
        if (!row[0])
            throw new Error("NOT_FOUND");
        const opCtx = {
            baseUrl: row[0].baseUrl,
            secret: row[0].secret,
            session: { id: "", userName: "admin", clientExternalKey: "admin" } // adapt to your provider needs
        };
        const res = yield (0, client_1.getBalance)(opCtx);
        return res;
    });
}
exports.UpdateGameConfigBody = zod_1.z.object({
    rtp_target: zod_1.z.coerce.number().min(0.01).max(0.9999),
    alpha: zod_1.z.coerce.number().min(0).max(1),
    kappa: zod_1.z.coerce.number().min(0),
    beta: zod_1.z.coerce.number().min(0),
    per_bet_cap: zod_1.z.coerce.number().min(0),
    per_ticket_cap: zod_1.z.coerce.number().min(0),
    per_user_daily_cap: zod_1.z.coerce.number().min(0),
    // jetx knobs kept for compatibility; set or ignore per game
    alpha_round: zod_1.z.coerce.number().min(0).optional(),
    gamma_round: zod_1.z.coerce.number().min(0).optional(),
    cashout_intensity: zod_1.z.coerce.number().min(0).optional(),
    global_odd_cap: zod_1.z.coerce.number().min(0).optional(),
});
