import bcrypt from "bcryptjs";
import { db } from "../../config/drizzle";
import { redis } from "../../config/redis";
import { adminTokens, adminUsers, adminAudit } from "../../db/admin";
import { game, gameConfig } from "../../db/game";
import { rtpDay as rtp_day, rtpMonth as rtp_month } from "../../db/rtp";
import { operators } from "../../db/operator";
import { eq, and, desc, asc, gte, lte, like } from "drizzle-orm";
import crypto from "crypto";
import { z } from "zod";
import { toYYMMDD } from "../../lib/date";
import { rk } from "../../lib/redis-keys";
import { findOperatorById } from "../../stores/operator"; // implement if needed
import { getBalance as opGetBalance } from "../../operator/client";

// ---------- Auth ----------
export async function adminLogin(username: string, password: string) {
    const rows = await db.select().from(adminUsers).where(and(eq(adminUsers.username, username), eq(adminUsers.isActive, true))).limit(1);
    const user = rows[0];
    if (!user) throw new Error("INVALID_CREDENTIALS");
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) throw new Error("INVALID_CREDENTIALS");

    const sid = crypto.randomUUID();
    const session = {
        userId: user.id,
        username: user.username,
        role: user.role,
        scopes: roleToScopes(user.role),
        createdAt: Date.now(),
    };
    await redis.setJSON(`admin:sess:${sid}`, session, 3600); // 1h
    await db.insert(adminAudit).values({
        actorType: "USER",
        actorId: user.id,
        actorName: user.username,
        action: "LOGIN",
        resource: "auth",
        meta: {},
    });

    return { sid, user: { id: user.id, username: user.username, role: user.role } };
}

export async function adminLogout(sid: string) {
    await redis.del(`admin:sess:${sid}`);
}

export async function adminMe(sid: string) {
    const s = await redis.getJSON<any>(`admin:sess:${sid}`);
    if (!s) throw new Error("NO_SESSION");
    return s;
}

export async function listAdminSessions(userId?: number) {
    // naive approach: scan keys (optimize later)
    const raw = await redis.getRaw().keys("alpha-mini-games:admin:sess:*");
    const sessions: any[] = [];
    for (const k of raw) {
        const s = await redis.getJSON<any>(k.replace("alpha-mini-games:", ""));
        if (!userId || s?.userId === userId) {
            sessions.push({ key: k, ...s });
        }
    }
    return sessions;
}
// export async function adminMe(sid: string) {
//     if (!sid) {
//         throw new Error("NO_SESSION");
//     }
//     // ✅ Use redis.getJSON, not db.getJSON
//     const session = await redis.getJSON<any>(`admin:sess:${sid}`);
//     if (!session) {
//         throw new Error("NO_SESSION");
//     }
//     return session;
// }


type ListTokensParams = {
    page?: number;
    limit?: number;
    q?: string;
    status?: "all" | "active" | "inactive";
    operatorId?: number;
};

/**
 * Returns paginated list of admin tokens with optional filters.
 * NOTE: adjust field names if your admin_tokens schema differs.
 */
export async function listTokens(params: ListTokensParams = {}) {
    const page = Math.max(1, params.page ?? 1);
    const limit = Math.min(Math.max(1, params.limit ?? 50), 500);
    const offset = (page - 1) * limit;

    const filters: any[] = [];

    if (params.q && params.q.trim().length > 0) {
        // case-insensitive label filter; use ILIKE if available in your drizzle version:
        // import { ilike } from 'drizzle-orm/pg-core'; and replace `like` with `ilike`
        filters.push(like(adminTokens.label, `%${params.q}%`));
    }
    if (params.status === "active") {
        filters.push(eq(adminTokens.isActive, true));
    } else if (params.status === "inactive") {
        filters.push(eq(adminTokens.isActive, false));
    }
    if (params.operatorId != null) {
        filters.push(eq(adminTokens.operatorId, params.operatorId));
    }

    const where = filters.length ? and(...filters) : undefined;

    const items = await db
        .select({
            id: adminTokens.id,
            label: adminTokens.label,
            scopes: adminTokens.scopes,
            operatorId: adminTokens.operatorId,
            isActive: adminTokens.isActive,
            createdAt: adminTokens.createdAt,
            expiresAt: adminTokens.expiresAt,
        })
        .from(adminTokens)
        .where(where)
        .orderBy(desc(adminTokens.id))
        .limit(limit)
        .offset(offset);

    return {
        page,
        limit,
        items,
    };
}
// ---------- Tokens ----------
export async function issueToken(params: {
    label: string; scopes: string[]; expiresInSeconds?: number; createdBy: number; operatorId?: number;
}) {
    const tokenPlain = crypto.randomUUID().replace(/-/g, "") + crypto.randomBytes(8).toString("hex");
    const tokenHash = crypto.createHash("sha256").digest("hex").toString(); // OOPS fix: use update(tokenPlain)
    // Fix: correct hashing
    const tokenHash2 = crypto.createHash("sha256").update(tokenPlain).digest("hex");
    const expiresAt = new Date(Date.now() + (params.expiresInSeconds ?? 3600 * 24 * 365) * 1000);

    const [row] = await db.insert(adminTokens).values({
        label: params.label,
        tokenHash: tokenHash2,
        scopes: params.scopes,
        isActive: true,
        operatorId: params.operatorId,
        createdBy: params.createdBy,
        expiresAt,
    }).returning();

    await db.insert(adminAudit).values({
        actorType: "USER",
        actorId: params.createdBy,
        actorName: `user:${params.createdBy}`,
        action: "TOKEN_CREATE",
        resource: `token:${row.id}`,
        meta: { scopes: params.scopes, operatorId: params.operatorId },
    });

    return { id: row.id, token: tokenPlain };
}

export async function revokeToken(id: number, actorId: number) {
    await db.update(adminTokens).set({ isActive: false }).where(eq(adminTokens.id, id));
    await db.insert(adminAudit).values({
        actorType: "USER", actorId, actorName: `user:${actorId}`, action: "TOKEN_REVOKE", resource: `token:${id}`,
    });
}

function roleToScopes(role: string): string[] {
    if (role === "SUPER_ADMIN") return ["*"];
    if (role === "OPS") return ["games:read", "games:write", "rtp:read", "cash:read"];
    if (role === "RISK") return ["rtp:read", "rtp:adjust"];
    return ["read"];
}

export function hasScope(p: any, needed: string) {
    if (!p) return false;
    if (p.kind === "user") {
        if (p.role === "SUPER_ADMIN") return true;
        if (p.scopes?.includes("*")) return true;
        return p.scopes?.includes(needed);
    }
    if (p.kind === "token") {
        return p.scopes?.includes(needed);
    }
    return false;
}

// ---------- Game Management ----------
export async function listGames() {
    const rows = await db.select().from(game).orderBy(game.code);
    const cfgs = await db.select().from(gameConfig);
    const byId: Record<number, any> = {};
    for (const c of cfgs) byId[c.game_id as number] = c;
    return rows.map(g => ({ ...g, config: byId[g.id] || null }));
}

export const UpdateGameBody = z.object({
    name: z.string().min(2).optional(),
    is_active: z.boolean().optional()
});
export async function updateGame(id: number, payload: z.infer<typeof UpdateGameBody>, actor: any) {
    const existing = (await db.select().from(game).where(eq(game.id, id)).limit(1))[0];
    if (!existing) throw new Error("NOT_FOUND");

    await db.update(game).set({
        name: payload.name ?? existing.name,
        is_active: payload.is_active ?? existing.is_active,
    }).where(eq(game.id, id));

    await db.insert(adminAudit).values({
        actorType: actor.kind === "user" ? "USER" : "TOKEN",
        actorId: actor.kind === "user" ? (actor.userId as number) : (actor.tokenId as number),
        actorName: actor.kind === "user" ? actor.username : `token:${actor.tokenId}`,
        action: "GAME_UPDATE",
        resource: `game:${existing.code}`,
        before: existing,
        after: { ...existing, ...payload },
    });

    const [fresh] = await db.select().from(game).where(eq(game.id, id)).limit(1);
    return fresh;
}

export const UpsertGameConfigBody = z.object({
    rtp_target: z.coerce.number().min(0.01).max(0.9999),
    alpha: z.coerce.number().min(0).max(1),
    kappa: z.coerce.number().min(0),
    beta: z.coerce.number().min(0),
    per_bet_cap: z.coerce.number().min(0),
    per_ticket_cap: z.coerce.number().min(0),
    per_user_daily_cap: z.coerce.number().min(0),
    alpha_round: z.coerce.number().min(0),
    gamma_round: z.coerce.number().min(0),
    cashout_intensity: z.coerce.number().min(0),
    global_odd_cap: z.coerce.number().min(0),
});

export async function upsertGameConfig(gameId: number, body: z.infer<typeof UpsertGameConfigBody>, actor: any) {
    const existing = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, gameId)).limit(1))[0];
    if (!existing) {
        const [row] = await db.insert(gameConfig).values({ game_id: gameId, ...body }).returning();
        await db.insert(adminAudit).values({
            actorType: actor.kind === "user" ? "USER" : "TOKEN",
            actorId: actor.kind === "user" ? (actor.userId as number) : (actor.tokenId as number),
            actorName: actor.kind === "user" ? actor.username : `token:${actor.tokenId}`,
            action: "GAME_CONFIG_CREATE",
            resource: `game_config:${gameId}`,
            after: row,
        });
        return row;
    } else {
        await db.update(gameConfig).set(body).where(eq(gameConfig.id, existing.id));
        const [fresh] = await db.select().from(gameConfig).where(eq(gameConfig.id, existing.id)).limit(1);
        await db.insert(adminAudit).values({
            actorType: actor.kind === "user" ? "USER" : "TOKEN",
            actorId: actor.kind === "user" ? (actor.userId as number) : (actor.tokenId as number),
            actorName: actor.kind === "user" ? actor.username : `token:${actor.tokenId}`,
            action: "GAME_CONFIG_UPDATE",
            resource: `game_config:${gameId}`,
            before: existing,
            after: fresh,
        });
        return fresh;
    }
}

// ---------- RTP Data ----------
export async function listRtpDay(params: { gameCode?: string; from?: string; to?: string; }) {
    const where: any[] = [];
    if (params.gameCode) {
        const g = (await db.select().from(game).where(eq(game.code, params.gameCode)).limit(1))[0];
        if (!g) throw new Error("GAME_NOT_FOUND");
        where.push(eq(rtp_day.game_id, g.id));
    }
    if (params.from) where.push(gte(rtp_day.date_yymmdd, params.from));
    if (params.to) where.push(lte(rtp_day.date_yymmdd, params.to));

    const rows = await db.select().from(rtp_day).where(where.length ? and(...where) : undefined).orderBy(desc(rtp_day.date_yymmdd));
    return rows;
}

export const RtpAdjustBody = z.object({
    game_code: z.string().min(2),
    yymmdd: z.string().length(6),
    delta_payin: z.coerce.number().default(0),
    delta_payout: z.coerce.number().default(0),
    delta_carry: z.coerce.number().default(0),
    reason: z.string().min(3)
});

export async function adjustRtp(principal: any, body: z.infer<typeof RtpAdjustBody>) {
    const g = (await db.select().from(game).where(eq(game.code, body.game_code)).limit(1))[0];
    if (!g) throw new Error("GAME_NOT_FOUND");
    const [day] = await db.select().from(rtp_day)
        .where(and(eq(rtp_day.game_id, g.id), eq(rtp_day.date_yymmdd, body.yymmdd))).limit(1);

    if (!day) throw new Error("RTP_DAY_NOT_FOUND");

    // write adjustment record
    await db.insert(adminAudit).values({
        actorType: principal.kind === "user" ? "USER" : "TOKEN",
        actorId: principal.kind === "user" ? (principal.userId as number) : (principal.tokenId as number),
        actorName: principal.kind === "user" ? principal.username : `token:${principal.tokenId}`,
        action: "RTP_ADJUST",
        resource: `rtp_day:${g.code}:${body.yymmdd}`,
        before: { payin: day.payin, payout: day.payout, carry_out: day.carry_out },
        after: {
            payin: String((Number(day.payin) + body.delta_payin).toFixed(2)),
            payout: String((Number(day.payout) + body.delta_payout).toFixed(2)),
            carry_out: String((Number(day.carry_out) + body.delta_carry).toFixed(2))
        },
        meta: body,
    });

    // apply DB changes (if you want to adjust snapshots)
    await db.update(rtp_day).set({
        payin: String((Number(day.payin) + body.delta_payin).toFixed(2)),
        payout: String((Number(day.payout) + body.delta_payout).toFixed(2)),
        carry_out: String((Number(day.carry_out) + body.delta_carry).toFixed(2)),
    }).where(eq(rtp_day.id, day.id));

    return { ok: true };
}

// ---------- Operators / Cash Flow ----------
export async function listOperators() {
    const rows = await db.select().from(operators).orderBy(asc(operators.name));
    return rows;
}

export async function getOperatorBalance(operatorId: number) {
    const row = await db.select().from(operators).where(eq(operators.id, operatorId)).limit(1);
    if (!row[0]) throw new Error("NOT_FOUND");
    const opCtx: any = {
        baseUrl: row[0].baseUrl,
        secret: row[0].secret,
        session: { id: "", userName: "admin", clientExternalKey: "admin" } // adapt to your provider needs
    };
    const res = await opGetBalance(opCtx);
    return res;
}

export const UpdateGameConfigBody = z.object({
    rtp_target: z.coerce.number().min(0.01).max(0.9999),
    alpha: z.coerce.number().min(0).max(1),
    kappa: z.coerce.number().min(0),
    beta: z.coerce.number().min(0),
    per_bet_cap: z.coerce.number().min(0),
    per_ticket_cap: z.coerce.number().min(0),
    per_user_daily_cap: z.coerce.number().min(0),
    // jetx knobs kept for compatibility; set or ignore per game
    alpha_round: z.coerce.number().min(0).optional(),
    gamma_round: z.coerce.number().min(0).optional(),
    cashout_intensity: z.coerce.number().min(0).optional(),
    global_odd_cap: z.coerce.number().min(0).optional(),
});