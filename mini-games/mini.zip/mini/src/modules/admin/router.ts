// // /var/www/typesafe/alpha-mini/src/modules/admin/router.ts
// import { Router } from "express";
// import { adminAuth, requireScope } from "../../middleware/admin-auth";
// import * as c from "./controller";

// /**
//  * Admin API Router
//  * 
//  * Authentication:
//  *   - User sessions:      pass `X-Admin-Sid: <sid>` header
//  *   - API tokens (other admin): pass `X-Admin-Token: <token>` header
//  * 
//  * Scopes:
//  *   - games:read, games:write
//  *   - rt:read, rtp:adjust
//  *   - ops:read
//  *   - admin:token:issue, admin:token:revoke
//  */

// const router = Router();

// /* ----------------------------------------
//  *  Auth & Session Management
//  * -------------------------------------- */

// // Log in (returns { sid, user })
// router.post("/auth/login", c.login);

// // Current session info
// router.get("/auth/me", adminAuth, c.me);

// // Destroy current session
// router.post("/auth/logout", adminAuth, c.logout);

// /* ----------------------------------------
//  *  Admin Token Management (for external admin integration)
//  * -------------------------------------- */

// // Issue a new admin token (requires user session + scope)
// router.post(
//     "/tokens",
//     adminAuth,
//     requireScope("admin:token:issue"),
//     // controller returns { ok, token, id }
//     ...([] as any[]).concat(c.issueToken as any)
// );

// // Revoke a token by id
// router.delete(
//     "/tokens/:id",
//     adminAuth,
//     requireScope("admin:token:revoke"),
//     ...([] as any[]).concat(c.revokeToken as any)
// );

// /* ----------------------------------------
//  *  Game Management
//  * -------------------------------------- */

// // List games with config
// router.get(
//     "/games",
//     adminAuth,
//     requireScope("games:read"),
//     c.getGames
// );

// // Update game (name / is_active)
// router.patch(
//     "/games/:id",
//     adminAuth,
//     requireScope("games:write"),
//     c.updateGame
// );

// // Upsert game-level RTP/caps config
// router.put(
//     "/games/:id/config",
//     adminAuth,
//     requireScope("games:write"),
//     c.upsertGameConfig
// );

// /* ----------------------------------------
//  *  RTP Data & Adjustments
//  * -------------------------------------- */

// // List day-level RTP snapshots (filter by game & date window)
// router.get(
//     "/rtp/day",
//     adminAuth,
//     requireScope("rtp:read"),
//     c.listRtpDay
// );

// // Optional: list month-level RTP if you expose it in controller
// // router.get("/rtp/month", adminAuth, requireScope("rtp:read"), c.listRtpMonth);

// // Manual RTP adjustment with audit trail
// router.post(
//     "/rtp/adjust",
//     adminAuth,
//     requireScope("rtp:adjust"),
//     c.adjustRtp
// );

// /* ----------------------------------------
//  *  Operators & Cash Flow
//  * -------------------------------------- */

// // List operators (name, portalName, baseUrl, isActive, currencies, etc.)
// router.get(
//     "/operators",
//     adminAuth,
//     requireScope("ops:read"),
//     c.listOperators
// );

// // Get operator wallet balance (passthrough to provider)
// router.get(
//     "/operators/:id/balance",
//     adminAuth,
//     requireScope("ops:read"),
//     c.getOperatorBal
// );

// // Optional: cashflow / transactions (if you expose this in controller)
// // router.get("/cash/tx", adminAuth, requireScope("cash:read"), c.listCashflow);

// export default router;
