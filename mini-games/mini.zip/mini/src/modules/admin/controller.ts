import { Request, Response, Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../../middleware/async-handler";
import { adminAuth, requireScope } from "../../middleware/admin-auth";
import * as svc from "./service";

// Router
export const adminRouter = Router();

/* -------------------- Auth -------------------- */
const LoginBody = z.object({ username: z.string().min(2), password: z.string().min(6) });

adminRouter.post("/auth/login", asyncHandler(async (req: Request, res: Response) => {
    try {
        const { username, password } = LoginBody.parse(req.body);
        const out = await svc.adminLogin(username, password);
        // out is { sid, user }; it does NOT contain `ok`
        res.json({ ok: true, ...out });
    } catch (error) {
        res.status(401).json({ ok: false, message: (error as Error).message });
    }
}));

adminRouter.get("/auth/me", adminAuth, asyncHandler(async (req: Request, res: Response) => {
    try {
        const sid = (req.get("x-admin-sid") || "") as string;
        const me = await svc.adminMe(sid);
        res.json({ ok: true, me });
    } catch (error) {
        res.status(401).json({ ok: false, message: (error as Error).message });
    }
}));

export const me = asyncHandler(async (req: Request, res: Response) => {
    // adminAuth must run before this route
    if (!req.admin) {
        return res.status(401).json({ ok: false, code: "UNAUTHORIZED" });
    }
    // If you still want to hydrate from Redis:
    if (req.admin.kind === "user" && req.admin.sid) {
        const me = await svc.adminMe(req.admin.sid);
        return res.json({ ok: true, me });
    }
    // For token-based principal, return the principal itself
    return res.json({ ok: true, me: req.admin });
});
adminRouter.post("/auth/logout", adminAuth, asyncHandler(async (req: Request, res: Response) => {
    try {
        const sid = (req.get("x-admin-sid") || "") as string;
        await svc.adminLogout(sid);
        res.json({ ok: true });
    } catch (error) {
        res.status(401).json({ ok: false, message: (error as Error).message });
    }
}));

/* -------------------- Tokens -------------------- */
const IssueTokenBody = z.object({
    label: z.string().min(2),
    scopes: z.array(z.string()).min(1),
    expiresInSeconds: z.number().optional(),
    operatorId: z.number().optional(),
});

adminRouter.post(
    "/tokens",
    adminAuth,
    requireScope("admin:token:issue"),
    asyncHandler(async (req: Request, res: Response) => {
        try {
            if (req.admin?.kind !== "user") {
                return res.status(403).json({ ok: false, message: "Only user sessions can issue tokens" });
            }
            const body = IssueTokenBody.parse(req.body);
            const created = await svc.issueToken({ ...body, createdBy: req.admin.userId! });
            // created = { id, token }
            res.json({ ok: true, ...created });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

adminRouter.delete(
    "/tokens/:id",
    adminAuth,
    requireScope("admin:token:revoke"),
    asyncHandler(async (req: Request, res: Response) => {
        try {
            const id = Number(req.params.id);
            const actorId = req.admin?.kind === "user" ? (req.admin.userId as number) : 0;
            await svc.revokeToken(id, actorId);
            res.json({ ok: true });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

/* -------------------- Games -------------------- */
adminRouter.get(
    "/games",
    adminAuth,
    requireScope("games:read"),
    asyncHandler(async (_req: Request, res: Response) => {
        try {
            const data = await svc.listGames();
            res.json({ ok: true, data });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

const UpdateGameBody = svc.UpdateGameBody;

adminRouter.patch(
    "/games/:id",
    adminAuth,
    requireScope("games:write"),
    asyncHandler(async (req: Request, res: Response) => {
        try {
            const id = Number(req.params.id);
            const payload = UpdateGameBody.parse(req.body);
            const updated = await svc.updateGame(id, payload, req.admin);
            res.json({ ok: true, data: updated });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

adminRouter.put(
    "/games/:id/config",
    adminAuth,
    requireScope("games:write"),
    asyncHandler(async (req: Request, res: Response) => {
        try {
            const id = Number(req.params.id);
            // FIX: use the exported UpsertGameConfigBody from service
            const payload = svc.UpsertGameConfigBody.parse(req.body);
            const cfg = await svc.upsertGameConfig(id, payload, req.admin);
            res.json({ ok: true, data: cfg });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

/* -------------------- RTP -------------------- */
const ListRtpQuery = z.object({
    game: z.string().optional(),
    from: z.string().optional(),
    to: z.string().optional(),
});

adminRouter.get(
    "/rtp/day",
    adminAuth,
    requireScope("rtp:read"),
    asyncHandler(async (req: Request, res: Response) => {
        try {
            const q = ListRtpQuery.parse(req.query);
            const data = await svc.listRtpDay({ gameCode: q.game, from: q.from, to: q.to });
            res.json({ ok: true, data });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

adminRouter.post(
    "/rtp/adjust",
    adminAuth,
    requireScope("rtp:adjust"),
    asyncHandler(async (req: Request, res: Response) => {
        try {
            const body = svc.RtpAdjustBody.parse(req.body);
            const out = await svc.adjustRtp(req.admin, body);
            // FIX: service already returns { ok: true }, don't duplicate `ok`
            res.json(out);
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

/* -------------------- Operators / Cash Flow -------------------- */
adminRouter.get(
    "/operators",
    adminAuth,
    requireScope("ops:read"),
    asyncHandler(async (_req: Request, res: Response) => {
        try {
            const data = await svc.listOperators();
            res.json({ ok: true, data });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);

adminRouter.get(
    "/operators/:id/balance",
    adminAuth,
    requireScope("ops:read"),
    asyncHandler(async (req: Request, res: Response) => {
        try {
            const id = Number(req.params.id);
            const balance = await svc.getOperatorBalance(id);
            res.json({ ok: true, balance });
        } catch (error) {
            res.status(403).json({ ok: false, message: (error as Error).message });
        }
    })
);
const ListTokensQuery = z.object({
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(200).default(50),
    q: z.string().optional(),
    status: z.enum(["all", "active", "inactive"]).default("all"),
    operator_id: z.coerce.number().int().optional(),
});

adminRouter.get(
    "/tokens",
    adminAuth,
    // adjust scope to your policy; earlier we used "admin:token:issue"/"admin:token:revoke"
    // For listing, either reuse 'admin:token:issue' or define a 'admin:token:read'
    requireScope("admin:token:issue"),
    async (req, res, next) => {
        try {
            const q = ListTokensQuery.parse(req.query);
            const data = await svc.listTokens({
                page: q.page,
                limit: q.limit,
                q: q.q,
                status: q.status,
                operatorId: q.operator_id,
            });
            res.json({ ok: true, ...data });
        } catch (e) {
            next(e);
        }
    }
);


// Example: “me” route
//adminRouter.get("/auth/mee", adminAuth, me);

export default adminRouter;
