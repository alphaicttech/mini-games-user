import { Router } from "express";
import { postLedger } from "./controller";
export const ledgerRouter = Router();
ledgerRouter.post("/", postLedger);
