import { db } from "../../config/drizzle";
import { walletTxn } from "../../db/rtp";
import { sql, eq } from "drizzle-orm";

export type LedgerType = "DEPOSIT" | "WITHDRAW" | "ROLLBACK";

function normAmount(x: number | string): string {
    // Drizzle numeric prefers string to avoid JS float quirks
    const n = typeof x === "string" ? Number(x) : x;
    if (!isFinite(n)) throw new Error("Invalid amount");
    return n.toFixed(2);
}

export async function saveLedger(params: {
    external_id?: string | null;
    type: LedgerType;
    amount: number | string;
    currency?: string;
    meta?: Record<string, any>;
}) {
    const { external_id = null, type, amount, currency = "ETB", meta } = params;

    const values = {
        external_id,
        type,
        amount: normAmount(amount),
        currency,
        meta: meta ? JSON.stringify(meta).slice(0, 2048) : null,
    };

    // If you created the unique index on external_id, this guarantees idempotency:
    const rows = await db
        .insert(walletTxn)
        .values(values as any)
        .onConflictDoNothing({ target: walletTxn.external_id })
        .returning({ id: walletTxn.id });

    // If onConflictDoNothing swallowed a duplicate, fetch the existing id so callers still get an ID.
    if (rows.length) return rows[0];
    if (external_id) {
        const existing = await db.query.walletTxn.findFirst({
            where: eq(walletTxn.external_id, external_id),
            columns: { id: true },
        });
        if (existing) return existing;
    }
    // No external_id or couldn’t fetch; return a neutral object
    return { id: 0 };
}
