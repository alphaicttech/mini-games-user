import { Request, Response } from "express";
import { saveLedger } from "./service";
import logger from "../../config/logger";

export async function postLedger(req: Request, res: Response) {
    try {
        const { type, amount, external_id, currency, meta } = req.body;

        if (!["DEPOSIT", "WITHDRAW", "ROLLBACK"].includes(type)) {
            return res.status(400).json({ success: false, message: "Invalid type" });
        }
        if (!amount || !isFinite(Number(amount))) {
            return res.status(400).json({ success: false, message: "Invalid amount" });
        }

        const row = await saveLedger({
            type,
            amount,
            external_id,
            currency,
            meta,
        });

        res.json({ success: true, id: row.id });
    } catch (err: any) {
        logger.error({ err }, "ledger insert failed");
        res.status(500).json({ success: false, message: "Ledger insert failed" });
    }
}
