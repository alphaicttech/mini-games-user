"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveLedger = saveLedger;
const drizzle_1 = require("../../config/drizzle");
const rtp_1 = require("../../db/rtp");
const drizzle_orm_1 = require("drizzle-orm");
function normAmount(x) {
    // Drizzle numeric prefers string to avoid JS float quirks
    const n = typeof x === "string" ? Number(x) : x;
    if (!isFinite(n))
        throw new Error("Invalid amount");
    return n.toFixed(2);
}
function saveLedger(params) {
    return __awaiter(this, void 0, void 0, function* () {
        const { external_id = null, type, amount, currency = "ETB", meta } = params;
        const values = {
            external_id,
            type,
            amount: normAmount(amount),
            currency,
            meta: meta ? JSON.stringify(meta).slice(0, 2048) : null,
        };
        // If you created the unique index on external_id, this guarantees idempotency:
        const rows = yield drizzle_1.db
            .insert(rtp_1.walletTxn)
            .values(values)
            .onConflictDoNothing({ target: rtp_1.walletTxn.external_id })
            .returning({ id: rtp_1.walletTxn.id });
        // If onConflictDoNothing swallowed a duplicate, fetch the existing id so callers still get an ID.
        if (rows.length)
            return rows[0];
        if (external_id) {
            const existing = yield drizzle_1.db.query.walletTxn.findFirst({
                where: (0, drizzle_orm_1.eq)(rtp_1.walletTxn.external_id, external_id),
                columns: { id: true },
            });
            if (existing)
                return existing;
        }
        // No external_id or couldn’t fetch; return a neutral object
        return { id: 0 };
    });
}
