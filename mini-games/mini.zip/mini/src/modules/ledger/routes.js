"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ledgerRouter = void 0;
const express_1 = require("express");
const controller_1 = require("./controller");
exports.ledgerRouter = (0, express_1.Router)();
exports.ledgerRouter.post("/", controller_1.postLedger);
