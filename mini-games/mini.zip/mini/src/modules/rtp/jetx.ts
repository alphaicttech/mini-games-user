import { redis } from "../../config/redis";
import { rk } from "../../lib/redis-keys";
import { toYYMMDD } from "../../lib/date";

export type JetxCfg = {
    rtp_target: number; alpha_round: number; gamma_round: number;
    cashout_intensity: number; global_odd_cap: number;
    per_bet_cap: number; max_round_budget?: number;
};

export async function jetxRoundStart(gameCode: string, cfg: JetxCfg, lobby: { sMax: number; S: number; }, roundId: string, yymmdd = toYYMMDD()) {
    const dayKey = rk.day(gameCode, yymmdd);
    const h = await redis.hgetall(dayKey);
    const payin = Number(h.payin ?? 0), payout = Number(h.payout ?? 0), carry_in = Number(h.carry_in ?? 0);
    const T = Number(h.rtp_target ?? cfg.rtp_target);
    const B_today = carry_in + (payin * T) - payout;

    const B_round = Math.min(B_today * cfg.alpha_round, cfg.max_round_budget ?? Number.MAX_SAFE_INTEGER);
    const cap_per_bet = Math.min(B_round * 0.6, cfg.per_bet_cap);

    const C1 = Math.floor(cap_per_bet / Math.max(1, lobby.sMax));
    const C2 = Math.floor(B_round / Math.max(1, lobby.S * cfg.cashout_intensity));
    const C_cap = Math.max(101, Math.min(C1, C2, Math.floor(cfg.global_odd_cap * 100))) / 100; // two decimals

    const roundKey = rk.round(gameCode, yymmdd, roundId);
    await redis.hmset(roundKey, {
        budget: B_round,
        max_odd_cap: C_cap,
        cap_per_bet,
        realized_payout: 0
    });
    await redis.hincrby(dayKey, 'rounds', 1);
    return { B_round, cap_per_bet, max_odd_cap: C_cap };
}

export async function jetxCashout(gameCode: string, roundId: string, stake: number, odd: number, yymmdd = toYYMMDD()) {
    const roundKey = rk.round(gameCode, yymmdd, roundId);
    const dayKey = rk.day(gameCode, yymmdd);
    const rkAll = await redis.hgetall(roundKey);
    const cap = Number(rkAll.cap_per_bet ?? 0);
    const budget = Number(rkAll.budget ?? 0);
    const gamma = 0.90; // you can pass via cfg if you want
    const maxOddCap = Number(rkAll.max_odd_cap ?? 1.01);

    const win = Math.min(stake * Math.min(odd, maxOddCap), cap);

    await redis
        .multi()
        .hincrbyfloat(roundKey, "realized_payout", win)
        .hincrbyfloat(dayKey, "payout", win)
        .exec();

    const realized = Number(await redis.hget(roundKey, "realized_payout"));
    const shouldCrash = realized >= budget * gamma || odd >= maxOddCap;
    return { win, shouldCrash, maxOddCap };
}
