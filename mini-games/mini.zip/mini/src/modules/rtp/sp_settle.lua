-- KEYS[1] = dayKey, ARGV[1] = stake, ARGV[2] = win
redis.call('HINCRBYFLOAT', KEYS[1], 'payin', ARGV[1])
redis.call('HINCRBYFLOAT', KEYS[1], 'payout', ARGV[2])
redis.call('HINCRBYFLOAT', KEYS[1], 'active_users', -1)
redis.call('HINCRBYFLOAT', KEYS[1], 'active_stake', -ARGV[1])
return 'OK'
