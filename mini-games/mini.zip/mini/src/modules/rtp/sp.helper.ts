import { rk } from "../../lib/redis-keys";
import { toYYMMDD } from "../../lib/date";
import { redis } from "../../config/redis";
import type { GameCfg } from "./types";
import { spPlan } from "./governor";

/**
 * Atomic(ish) per-bet sequence for single-player:
 *  1) enter (active counters++)
 *  2) compute caps/target
 *  3) your game picks outcome -> win
 *  4) settle (payin+=stake, payout+=win, counters--)
 */
export async function rtpEnterAndPlan(gameCode: string, stake: number, cfg: GameCfg) {
    const yymmdd = toYYMMDD();
    const dayKey = rk.day(gameCode, yymmdd);

    await redis.spEnter(dayKey, stake);              // atomic in Redis (Lua)
    const plan = await spPlan(gameCode, stake, cfg); // hardCap, softCap, target
    return { yymmdd, dayKey, plan };
}

export async function rtpSettle(dayKey: string, stake: number, win: number) {
    await redis.spSettle(dayKey, stake, win);        // atomic counters write
}
