import { Router } from "express";
import { snapshotRtpDay } from "./snapshot";
import { openDay, closeDay } from "./rotate";
import { spEnter, spPlan, spSettle } from "./governor";
import { toYYMMDD } from "../../lib/date";

export const rtpRouter = Router();

// Admin/dev tools
rtpRouter.post("/open/:game", async (req, res) => {
    await openDay(req.params.game);
    res.json({ ok: true });
});
rtpRouter.post("/close/:game", async (req, res) => {
    await closeDay(req.params.game);
    res.json({ ok: true });
});
rtpRouter.post("/snapshot/:game", async (req, res) => {
    const { gameId, yymmdd = toYYMMDD() } = req.body;
    await snapshotRtpDay(Number(gameId), req.params.game, yymmdd);
    res.json({ ok: true });
});

// Example single-player test endpoint
rtpRouter.post("/sp/:game/bet", async (req, res) => {
    const { stake } = req.body as { stake: number };
    const cfg = req.body.cfg; // or load from DB/cache
    const gameCode = req.params.game;

    await spEnter(gameCode, stake);
    const plan = await spPlan(gameCode, stake, cfg);
    // TODO: your game logic computes a "win" close to plan.target
    const simulatedWin = Math.min(plan.target, stake * 100); // placeholder
    await spSettle(gameCode, stake, simulatedWin);

    res.json({ plan, win: simulatedWin });
});
