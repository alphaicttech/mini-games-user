"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rtpEnterAndPlan = rtpEnterAndPlan;
exports.rtpSettle = rtpSettle;
const redis_keys_1 = require("../../lib/redis-keys");
const date_1 = require("../../lib/date");
const redis_1 = require("../../config/redis");
const governor_1 = require("./governor");
/**
 * Atomic(ish) per-bet sequence for single-player:
 *  1) enter (active counters++)
 *  2) compute caps/target
 *  3) your game picks outcome -> win
 *  4) settle (payin+=stake, payout+=win, counters--)
 */
function rtpEnterAndPlan(gameCode, stake, cfg) {
    return __awaiter(this, void 0, void 0, function* () {
        const yymmdd = (0, date_1.toYYMMDD)();
        const dayKey = redis_keys_1.rk.day(gameCode, yymmdd);
        yield redis_1.redis.spEnter(dayKey, stake); // atomic in Redis (Lua)
        const plan = yield (0, governor_1.spPlan)(gameCode, stake, cfg); // hardCap, softCap, target
        return { yymmdd, dayKey, plan };
    });
}
function rtpSettle(dayKey, stake, win) {
    return __awaiter(this, void 0, void 0, function* () {
        yield redis_1.redis.spSettle(dayKey, stake, win); // atomic counters write
    });
}
