-- KEYS[1] = dayKey, ARGV[1] = stake
redis.call('HINCRBYFLOAT', KEYS[1], 'active_users', 1)
redis.call('HINCRBYFLOAT', KEYS[1], 'active_stake', ARGV[1])
return 'OK'
