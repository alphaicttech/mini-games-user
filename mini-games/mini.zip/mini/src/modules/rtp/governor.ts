import { redis } from "../../config/redis";
import { rk } from "../../lib/redis-keys";
import { toYYMMDD } from "../../lib/date";
import { lua } from "../../lib/redis-lua";
import type { GameCfg, RtpState } from "./types";

/** Read current day state */
async function readDay(gameCode: string, yymmdd = toYYMMDD()): Promise<RtpState> {
    const key = rk.day(gameCode, yymmdd);
    const h = await redis.hgetall(key);
    const num = (v?: string) => Number(v ?? 0);
    return {
        payin: num(h.payin), payout: num(h.payout), carry_in: num(h.carry_in),
        rtp_target: Number(h.rtp_target ?? 0.90),
        active_users: num(h.active_users), active_stake: num(h.active_stake),
    };
}

function computeCap(state: RtpState, stake: number, cfg: GameCfg) {
    const B_today = state.carry_in + (state.payin * cfg.rtp_target) - state.payout;
    const N = Math.max(1, state.active_users + 1);
    const S = Math.max(0, state.active_stake) + stake;
    const share = N * (stake / Math.max(S, stake));
    const D = cfg.kappa + share;
    const hardCap = Math.max(0, Math.floor((B_today * cfg.alpha) / D));
    const softCap = Math.floor(hardCap * cfg.beta);
    return { B_today, hardCap, softCap };
}

export async function spEnter(gameCode: string, stake: number, yymmdd = toYYMMDD()) {
    const key = rk.day(gameCode, yymmdd);
    await (redis as any).sp_enter(key, stake.toString());
}

export function drawTarget(softCap: number, cfg: GameCfg) {
    const r = Math.random(); // replace with better PRNG if needed
    let target = Math.floor(softCap * (0.15 + 0.85 * r));
    target = Math.min(target, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
    return Math.max(0, target);
}

export async function spSettle(gameCode: string, stake: number, win: number, yymmdd = toYYMMDD()) {
    const key = rk.day(gameCode, yymmdd);
    await (redis as any).sp_settle(key, stake.toString(), win.toString());
}

export async function spPlan(gameCode: string, stake: number, cfg: GameCfg, yymmdd = toYYMMDD()) {
    const state = await readDay(gameCode, yymmdd);
    const { hardCap, softCap } = computeCap(state, stake, cfg);
    const target = drawTarget(softCap, cfg);
    return { hardCap, softCap, target };
}
