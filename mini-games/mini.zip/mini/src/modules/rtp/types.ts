export type RtpState = {
    payin: number; payout: number; carry_in: number; rtp_target: number;
    active_users: number; active_stake: number;
};
export type GameCfg = {
    rtp_target: number; alpha: number; kappa: number; beta: number;
    per_bet_cap: number; per_ticket_cap: number; per_user_daily_cap: number;
};
