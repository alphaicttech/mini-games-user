"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.spEnter = spEnter;
exports.drawTarget = drawTarget;
exports.spSettle = spSettle;
exports.spPlan = spPlan;
const redis_1 = require("../../config/redis");
const redis_keys_1 = require("../../lib/redis-keys");
const date_1 = require("../../lib/date");
/** Read current day state */
function readDay(gameCode_1) {
    return __awaiter(this, arguments, void 0, function* (gameCode, yymmdd = (0, date_1.toYYMMDD)()) {
        var _a;
        const key = redis_keys_1.rk.day(gameCode, yymmdd);
        const h = yield redis_1.redis.hgetall(key);
        const num = (v) => Number(v !== null && v !== void 0 ? v : 0);
        return {
            payin: num(h.payin), payout: num(h.payout), carry_in: num(h.carry_in),
            rtp_target: Number((_a = h.rtp_target) !== null && _a !== void 0 ? _a : 0.90),
            active_users: num(h.active_users), active_stake: num(h.active_stake),
        };
    });
}
function computeCap(state, stake, cfg) {
    const B_today = state.carry_in + (state.payin * cfg.rtp_target) - state.payout;
    const N = Math.max(1, state.active_users + 1);
    const S = Math.max(0, state.active_stake) + stake;
    const share = N * (stake / Math.max(S, stake));
    const D = cfg.kappa + share;
    const hardCap = Math.max(0, Math.floor((B_today * cfg.alpha) / D));
    const softCap = Math.floor(hardCap * cfg.beta);
    return { B_today, hardCap, softCap };
}
function spEnter(gameCode_1, stake_1) {
    return __awaiter(this, arguments, void 0, function* (gameCode, stake, yymmdd = (0, date_1.toYYMMDD)()) {
        const key = redis_keys_1.rk.day(gameCode, yymmdd);
        yield redis_1.redis.sp_enter(key, stake.toString());
    });
}
function drawTarget(softCap, cfg) {
    const r = Math.random(); // replace with better PRNG if needed
    let target = Math.floor(softCap * (0.15 + 0.85 * r));
    target = Math.min(target, cfg.per_bet_cap, cfg.per_ticket_cap, cfg.per_user_daily_cap);
    return Math.max(0, target);
}
function spSettle(gameCode_1, stake_1, win_1) {
    return __awaiter(this, arguments, void 0, function* (gameCode, stake, win, yymmdd = (0, date_1.toYYMMDD)()) {
        const key = redis_keys_1.rk.day(gameCode, yymmdd);
        yield redis_1.redis.sp_settle(key, stake.toString(), win.toString());
    });
}
function spPlan(gameCode_1, stake_1, cfg_1) {
    return __awaiter(this, arguments, void 0, function* (gameCode, stake, cfg, yymmdd = (0, date_1.toYYMMDD)()) {
        const state = yield readDay(gameCode, yymmdd);
        const { hardCap, softCap } = computeCap(state, stake, cfg);
        const target = drawTarget(softCap, cfg);
        return { hardCap, softCap, target };
    });
}
