"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.jetxRoundStart = jetxRoundStart;
exports.jetxCashout = jetxCashout;
const redis_1 = require("../../config/redis");
const redis_keys_1 = require("../../lib/redis-keys");
const date_1 = require("../../lib/date");
function jetxRoundStart(gameCode_1, cfg_1, lobby_1, roundId_1) {
    return __awaiter(this, arguments, void 0, function* (gameCode, cfg, lobby, roundId, yymmdd = (0, date_1.toYYMMDD)()) {
        var _a, _b, _c, _d, _e;
        const dayKey = redis_keys_1.rk.day(gameCode, yymmdd);
        const h = yield redis_1.redis.hgetall(dayKey);
        const payin = Number((_a = h.payin) !== null && _a !== void 0 ? _a : 0), payout = Number((_b = h.payout) !== null && _b !== void 0 ? _b : 0), carry_in = Number((_c = h.carry_in) !== null && _c !== void 0 ? _c : 0);
        const T = Number((_d = h.rtp_target) !== null && _d !== void 0 ? _d : cfg.rtp_target);
        const B_today = carry_in + (payin * T) - payout;
        const B_round = Math.min(B_today * cfg.alpha_round, (_e = cfg.max_round_budget) !== null && _e !== void 0 ? _e : Number.MAX_SAFE_INTEGER);
        const cap_per_bet = Math.min(B_round * 0.6, cfg.per_bet_cap);
        const C1 = Math.floor(cap_per_bet / Math.max(1, lobby.sMax));
        const C2 = Math.floor(B_round / Math.max(1, lobby.S * cfg.cashout_intensity));
        const C_cap = Math.max(101, Math.min(C1, C2, Math.floor(cfg.global_odd_cap * 100))) / 100; // two decimals
        const roundKey = redis_keys_1.rk.round(gameCode, yymmdd, roundId);
        yield redis_1.redis.hmset(roundKey, {
            budget: B_round,
            max_odd_cap: C_cap,
            cap_per_bet,
            realized_payout: 0
        });
        yield redis_1.redis.hincrby(dayKey, 'rounds', 1);
        return { B_round, cap_per_bet, max_odd_cap: C_cap };
    });
}
function jetxCashout(gameCode_1, roundId_1, stake_1, odd_1) {
    return __awaiter(this, arguments, void 0, function* (gameCode, roundId, stake, odd, yymmdd = (0, date_1.toYYMMDD)()) {
        var _a, _b, _c;
        const roundKey = redis_keys_1.rk.round(gameCode, yymmdd, roundId);
        const dayKey = redis_keys_1.rk.day(gameCode, yymmdd);
        const rkAll = yield redis_1.redis.hgetall(roundKey);
        const cap = Number((_a = rkAll.cap_per_bet) !== null && _a !== void 0 ? _a : 0);
        const budget = Number((_b = rkAll.budget) !== null && _b !== void 0 ? _b : 0);
        const gamma = 0.90; // you can pass via cfg if you want
        const maxOddCap = Number((_c = rkAll.max_odd_cap) !== null && _c !== void 0 ? _c : 1.01);
        const win = Math.min(stake * Math.min(odd, maxOddCap), cap);
        yield redis_1.redis
            .multi()
            .hincrbyfloat(roundKey, "realized_payout", win)
            .hincrbyfloat(dayKey, "payout", win)
            .exec();
        const realized = Number(yield redis_1.redis.hget(roundKey, "realized_payout"));
        const shouldCrash = realized >= budget * gamma || odd >= maxOddCap;
        return { win, shouldCrash, maxOddCap };
    });
}
