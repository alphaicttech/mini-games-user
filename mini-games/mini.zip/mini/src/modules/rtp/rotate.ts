import { db } from "../../config/drizzle";
import { rtpDay, rtpMonth } from "../../db/rtp";
import { game, gameConfig } from "../../db/game";
import { eq } from "drizzle-orm";
import { redis } from "../../config/redis";
import { toYYMMDD, monthYY } from "../../lib/date";
import { rk } from "../../lib/redis-keys";

export async function openDay(gameCode: string) {
    const g = (await db.select().from(game).where(eq(game.code, gameCode)).limit(1))[0];
    if (!g) throw new Error("game not found");

    const cfg = (await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1))[0];
    const today = toYYMMDD();

    // get yesterday carry_out
    const yest = (await db.select().from(rtpDay)
        .where(eq(rtpDay.game_id, g.id))
        .orderBy(rtpDay.date_yymmdd)
        .limit(1)
    ); // you can query yesterday specifically; simplified here

    const carry_in = yest?.[0]?.carry_out ?? '0';

    // upsert day
    await db.insert(rtpDay).values({
        game_id: g.id,                        // likely integer → OK
        date_yymmdd: today,                   // should be 'yymmdd' string
        rtp_target: String(cfg.rtp_target),   // numeric → string
        payin: '0',                           // numeric → string OK
        payout: '0',                          // numeric → string OK
        carry_in: String(carry_in),           // numeric → string
        carry_out: '0',                       // numeric → string
        rounds: 0                             // integer → OK
    }).onConflictDoNothing();

    // seed redis
    const key = rk.day(gameCode, today);
    await redis.hsetnx(key, "rtp_target", String(cfg.rtp_target));
    await redis.hsetnx(key, "payin", "0");
    await redis.hsetnx(key, "payout", "0");
    await redis.hsetnx(key, "carry_in", String(carry_in ?? 0));
    await redis.hsetnx(key, "active_users", "0");
    await redis.hsetnx(key, "active_stake", "0");
}

export async function closeDay(gameCode: string) {
    const g = (await db.select().from(game).where(eq(game.code, gameCode)).limit(1))[0];
    if (!g) throw new Error("game not found");

    const today = toYYMMDD();
    const mYY = monthYY();
    const key = rk.day(gameCode, today);
    const h = await redis.hgetall(key);

    const payin = Number(h.payin ?? 0);
    const payout = Number(h.payout ?? 0);
    const carry_in = Number(h.carry_in ?? 0);
    const T = Number(h.rtp_target ?? 0.90);
    const carry_out = carry_in + (payin * T) - payout;

    // finalize day
    await db
        .insert(rtpDay)
        .values({
            game_id: g.id, date_yymmdd: today, rtp_target: T,
            payin, payout, carry_in, carry_out, last_snapshot_at: new Date()
        } as any)
        .onConflictDoUpdate({
            target: [rtpDay.game_id, rtpDay.date_yymmdd],
            set: { payin, payout, carry_in, carry_out, rtp_target: T, last_snapshot_at: new Date() } as any
        });

    // roll into month
    await db
        .insert(rtpMonth)
        .values({
            game_id: g.id, month_yy: mYY, rtp_target: T,
            payin, payout, carry_in, carry_out
        } as any)
        .onConflictDoUpdate({
            target: [rtpMonth.game_id, rtpMonth.month_yy],
            set: {
                // simple “latest overwrite” or do incremental sums as you prefer:
                payin, payout, carry_in, carry_out, rtp_target: T
            } as any
        });

    // mark closed or delete redis day key if you prefer fresh start
    await redis.hset(key, "closed", "1");
}
