"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rtpRouter = void 0;
const express_1 = require("express");
const snapshot_1 = require("./snapshot");
const rotate_1 = require("./rotate");
const governor_1 = require("./governor");
const date_1 = require("../../lib/date");
exports.rtpRouter = (0, express_1.Router)();
// Admin/dev tools
exports.rtpRouter.post("/open/:game", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    yield (0, rotate_1.openDay)(req.params.game);
    res.json({ ok: true });
}));
exports.rtpRouter.post("/close/:game", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    yield (0, rotate_1.closeDay)(req.params.game);
    res.json({ ok: true });
}));
exports.rtpRouter.post("/snapshot/:game", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { gameId, yymmdd = (0, date_1.toYYMMDD)() } = req.body;
    yield (0, snapshot_1.snapshotRtpDay)(Number(gameId), req.params.game, yymmdd);
    res.json({ ok: true });
}));
// Example single-player test endpoint
exports.rtpRouter.post("/sp/:game/bet", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { stake } = req.body;
    const cfg = req.body.cfg; // or load from DB/cache
    const gameCode = req.params.game;
    yield (0, governor_1.spEnter)(gameCode, stake);
    const plan = yield (0, governor_1.spPlan)(gameCode, stake, cfg);
    // TODO: your game logic computes a "win" close to plan.target
    const simulatedWin = Math.min(plan.target, stake * 100); // placeholder
    yield (0, governor_1.spSettle)(gameCode, stake, simulatedWin);
    res.json({ plan, win: simulatedWin });
}));
