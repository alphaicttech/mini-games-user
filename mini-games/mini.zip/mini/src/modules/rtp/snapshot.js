"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.snapshotRtpDay = snapshotRtpDay;
const drizzle_1 = require("../../config/drizzle"); // your drizzle instance
const rtp_1 = require("../../db/rtp");
const redis_1 = require("../../config/redis");
const redis_keys_1 = require("../../lib/redis-keys");
function snapshotRtpDay(gameId, gameCode, yymmdd) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const key = redis_keys_1.rk.day(gameCode, yymmdd);
        const h = yield redis_1.redis.hgetall(key);
        const patch = {
            rtp_target: (_a = h.rtp_target) !== null && _a !== void 0 ? _a : '0.90',
            payin: (_b = h.payin) !== null && _b !== void 0 ? _b : '0',
            payout: (_c = h.payout) !== null && _c !== void 0 ? _c : '0',
            carry_in: (_d = h.carry_in) !== null && _d !== void 0 ? _d : '0',
            last_snapshot_at: new Date(),
        };
        yield drizzle_1.db
            .insert(rtp_1.rtpDay)
            .values(Object.assign({ game_id: gameId, date_yymmdd: yymmdd }, patch))
            .onConflictDoUpdate({
            target: [rtp_1.rtpDay.game_id, rtp_1.rtpDay.date_yymmdd],
            set: patch,
        });
    });
}
