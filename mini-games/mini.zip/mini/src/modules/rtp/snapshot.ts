import { db } from "../../config/drizzle"; // your drizzle instance
import { rtpDay } from "../../db/rtp";
import { eq } from "drizzle-orm";
import { redis } from "../../config/redis";
import { rk } from "../../lib/redis-keys";

export async function snapshotRtpDay(gameId: number, gameCode: string, yymmdd: string) {
    const key = rk.day(gameCode, yymmdd);
    const h = await redis.hgetall(key);
    const patch = {
        rtp_target: h.rtp_target ?? '0.90',
        payin: h.payin ?? '0',
        payout: h.payout ?? '0',
        carry_in: h.carry_in ?? '0',
        last_snapshot_at: new Date(),
    };
    await db
        .insert(rtpDay)
        .values({ game_id: gameId, date_yymmdd: yymmdd, ...patch })
        .onConflictDoUpdate({
            target: [rtpDay.game_id, rtpDay.date_yymmdd],
            set: patch as any,
        });
}
