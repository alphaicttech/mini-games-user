"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.openDay = openDay;
exports.closeDay = closeDay;
const drizzle_1 = require("../../config/drizzle");
const rtp_1 = require("../../db/rtp");
const game_1 = require("../../db/game");
const drizzle_orm_1 = require("drizzle-orm");
const redis_1 = require("../../config/redis");
const date_1 = require("../../lib/date");
const redis_keys_1 = require("../../lib/redis-keys");
function openDay(gameCode) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, gameCode)).limit(1))[0];
        if (!g)
            throw new Error("game not found");
        const cfg = (yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1))[0];
        const today = (0, date_1.toYYMMDD)();
        // get yesterday carry_out
        const yest = (yield drizzle_1.db.select().from(rtp_1.rtpDay)
            .where((0, drizzle_orm_1.eq)(rtp_1.rtpDay.game_id, g.id))
            .orderBy(rtp_1.rtpDay.date_yymmdd)
            .limit(1)); // you can query yesterday specifically; simplified here
        const carry_in = (_b = (_a = yest === null || yest === void 0 ? void 0 : yest[0]) === null || _a === void 0 ? void 0 : _a.carry_out) !== null && _b !== void 0 ? _b : '0';
        // upsert day
        yield drizzle_1.db.insert(rtp_1.rtpDay).values({
            game_id: g.id, // likely integer → OK
            date_yymmdd: today, // should be 'yymmdd' string
            rtp_target: String(cfg.rtp_target), // numeric → string
            payin: '0', // numeric → string OK
            payout: '0', // numeric → string OK
            carry_in: String(carry_in), // numeric → string
            carry_out: '0', // numeric → string
            rounds: 0 // integer → OK
        }).onConflictDoNothing();
        // seed redis
        const key = redis_keys_1.rk.day(gameCode, today);
        yield redis_1.redis.hsetnx(key, "rtp_target", String(cfg.rtp_target));
        yield redis_1.redis.hsetnx(key, "payin", "0");
        yield redis_1.redis.hsetnx(key, "payout", "0");
        yield redis_1.redis.hsetnx(key, "carry_in", String(carry_in !== null && carry_in !== void 0 ? carry_in : 0));
        yield redis_1.redis.hsetnx(key, "active_users", "0");
        yield redis_1.redis.hsetnx(key, "active_stake", "0");
    });
}
function closeDay(gameCode) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const g = (yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, gameCode)).limit(1))[0];
        if (!g)
            throw new Error("game not found");
        const today = (0, date_1.toYYMMDD)();
        const mYY = (0, date_1.monthYY)();
        const key = redis_keys_1.rk.day(gameCode, today);
        const h = yield redis_1.redis.hgetall(key);
        const payin = Number((_a = h.payin) !== null && _a !== void 0 ? _a : 0);
        const payout = Number((_b = h.payout) !== null && _b !== void 0 ? _b : 0);
        const carry_in = Number((_c = h.carry_in) !== null && _c !== void 0 ? _c : 0);
        const T = Number((_d = h.rtp_target) !== null && _d !== void 0 ? _d : 0.90);
        const carry_out = carry_in + (payin * T) - payout;
        // finalize day
        yield drizzle_1.db
            .insert(rtp_1.rtpDay)
            .values({
            game_id: g.id, date_yymmdd: today, rtp_target: T,
            payin, payout, carry_in, carry_out, last_snapshot_at: new Date()
        })
            .onConflictDoUpdate({
            target: [rtp_1.rtpDay.game_id, rtp_1.rtpDay.date_yymmdd],
            set: { payin, payout, carry_in, carry_out, rtp_target: T, last_snapshot_at: new Date() }
        });
        // roll into month
        yield drizzle_1.db
            .insert(rtp_1.rtpMonth)
            .values({
            game_id: g.id, month_yy: mYY, rtp_target: T,
            payin, payout, carry_in, carry_out
        })
            .onConflictDoUpdate({
            target: [rtp_1.rtpMonth.game_id, rtp_1.rtpMonth.month_yy],
            set: {
                // simple “latest overwrite” or do incremental sums as you prefer:
                payin, payout, carry_in, carry_out, rtp_target: T
            }
        });
        // mark closed or delete redis day key if you prefer fresh start
        yield redis_1.redis.hset(key, "closed", "1");
    });
}
