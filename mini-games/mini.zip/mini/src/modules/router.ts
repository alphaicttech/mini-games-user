// /var/www/typesafe/alpha-mini/src/modules/router.ts

import express from "express";
import { launcher, launcherValidate } from "./launcher/controller";
import * as session from "./session/controller";
import * as coin from "./games/coin-toss/controller";
import { providerAuth } from "../middleware/provider-auth";
import * as mines from "./games/mines/controller";
import * as chicken from "./games/chicken-road/controller";
import * as slot from "./games/777-slot/controller";
import * as roulette from "./games/spin/controller";
import * as balloon from "./games/balloons/controller";
import * as avia from "./games/avia-masters/controller";
import * as plinko from "./games/plinko/controller";
import * as penality from "./games/penality/controller";
import * as keno from "./games/keno/controller";
import * as baccarat from "./games/baccarat/controller";
import * as blackjack from "./games/blackjack/controller";
import * as dragontiger from "./games/dragontiger/controller";
import * as casinowar from "./games/casinowar/controller";
import * as reddog from "./games/reddog/controller";
import * as rouletteMini from "./games/roulette_mini/controller";
import * as bingo from "./games/bingo/controller";
import * as greyhound from "./games/grayhound/controller";
import * as admin from "./admin/controller";

const router = express.Router();

// launcher (for testing)
router.get(["/GameLauncher/Loader.aspx", "/GameLauncher/Loader", "/launcher"], launcherValidate, launcher);

// session
router.post("/sessions/activate", session.activateValidate, session.activate);

// get balance
router.get("/sessions/verify", providerAuth, session.verify);

// get demo balance
router.get("/sessions/balance", providerAuth, session.balance);

// 1. coin toss
router.post("/games/coin/bet", providerAuth, coin.betValidate, coin.bet);

// 2. mines
router.post("/games/mines/start", providerAuth, mines.startValidate, mines.start);
router.post("/games/mines/reveal", providerAuth, mines.revealValidate, mines.reveal);
router.post("/games/mines/cashout", providerAuth, mines.cashoutValidate, mines.cashout);

// 3. chicken road
router.post("/games/chicken/start", providerAuth, chicken.startValidate, chicken.start);
router.post("/games/chicken/step", providerAuth, chicken.stepValidate, chicken.step);
router.post("/games/chicken/cashout", providerAuth, chicken.cashoutValidate, chicken.cashout);
router.get("/games/chicken/odds", providerAuth, chicken.chickenOddsValidate, chicken.chickenOdds);


// 4. slot
router.post("/games/slot777/spin", providerAuth, slot.spinValidate, slot.spin);

// 5. avia masters
router.post("/games/avia/spin", providerAuth, avia.spinValidate, avia.spin);

// 6. balloons
router.post("/games/balloon/start", providerAuth, balloon.startValidate, balloon.start);
router.post("/games/balloon/inflate", providerAuth, balloon.inflateValidate, balloon.inflate);
router.post("/games/balloon/cashout", providerAuth, balloon.cashoutValidate, balloon.cashout);

// 7. roulette
router.post("/games/roulette/spin", providerAuth, roulette.spinValidate, roulette.spin);

// 8. keno
router.post("/games/keno/draw", providerAuth, keno.drawValidate, keno.draw);

// 9. plinko
router.post("/games/plinko/drop", providerAuth, plinko.dropValidate, plinko.drop);
router.get("/games/plinko/odds", plinko.odds);

// 10. penalty ladder
router.post("/games/penalty-ladder/start", providerAuth, penality.startValidate, penality.startSeries);
router.post("/games/penalty-ladder/kick", providerAuth, penality.kickValidate, penality.kick);
router.post("/games/penalty-ladder/cashout", providerAuth, penality.cashoutValidate, penality.cashout);
router.get("/games/penalty-ladder/status", providerAuth, penality.statusValidate, penality.status);

// 11. baccarat
router.post("/games/baccarat/deal", providerAuth, baccarat.dealValidate, baccarat.deal);

// 12. blackjack
router.post("/games/blackjack/start", providerAuth, blackjack.startValidate, blackjack.startRound);
router.post("/games/blackjack/hit", providerAuth, blackjack.hitValidate, blackjack.hit);
router.post("/games/blackjack/stand", providerAuth, blackjack.standValidate, blackjack.stand);
router.post("/games/blackjack/double", providerAuth, blackjack.doubleValidate, blackjack.doubleDown);
router.post("/games/blackjack/split", providerAuth, blackjack.splitValidate, blackjack.splitHand);
router.post("/games/blackjack/finish", providerAuth, blackjack.finishValidate, blackjack.finishRound);
router.get("/games/blackjack/status", providerAuth, blackjack.statusValidate, blackjack.statusRound);
router.post("/games/blackjack/insurance", providerAuth, blackjack.insuranceValidate, blackjack.insuranceAction);
router.post("/games/blackjack/surrender", providerAuth, blackjack.surrenderValidate, blackjack.surrenderAction);


// 13. dragontiger
router.post("/games/dragontiger/deal", providerAuth, dragontiger.dealValidate, dragontiger.deal);

// 14. casinowar
router.post("/games/casinowar/deal", providerAuth, casinowar.dealValidate, casinowar.deal);
router.post("/games/casinowar/choice", providerAuth, casinowar.choiceValidate, casinowar.choice);
router.get("/games/casinowar/status", providerAuth, casinowar.statusValidate, casinowar.status);


// 15. reddog
router.post("/games/reddog/deal", providerAuth, reddog.dealValidate, reddog.deal);
router.post("/games/reddog/raise", providerAuth, reddog.raiseValidate, reddog.raiseAction);
router.get("/games/reddog/status", providerAuth, reddog.statusValidate, reddog.status);


// 16. roulette mini    
router.post("/games/roulette-mini/spin", providerAuth, rouletteMini.spinValidate, rouletteMini.spin);

// 17. greyhound
router.post("/games/greyhound/race/new", providerAuth, greyhound.newRaceValidate, greyhound.newRace);
router.post("/games/greyhound/regenerate", providerAuth, greyhound.regenValidate, greyhound.regenerate);
router.post("/games/greyhound/bets/place", providerAuth, greyhound.placeValidate, greyhound.placeBets);
router.post("/games/greyhound/race/start", providerAuth, greyhound.startValidate, greyhound.startRace);
router.post("/games/greyhound/race/settle", providerAuth, greyhound.settleValidate, greyhound.settleRace);
router.post("/games/greyhound/race/stream/:result_id", providerAuth, greyhound.streamValidate, greyhound.streamResultVideo);
router.get("/games/greyhound/race/status", providerAuth, greyhound.statusValidate, greyhound.raceStatus);

// 18. bingo
// router.post("/games/bingo/card/new", providerAuth, bingo.newCardValidate, bingo.newCard);
// router.post("/games/bingo/card/regenerate", providerAuth, bingo.regenCardValidate, bingo.regenCard);
// router.post("/games/bingo/bets/place", providerAuth, bingo.placeValidate, bingo.placeBets);
// router.post("/games/bingo/draw", providerAuth, bingo.drawValidate, bingo.draw);
// router.get("/games/bingo/status", providerAuth, bingo.statusValidate, bingo.status);

// // router.ts
// router.post("/games/bingo/batch/place", providerAuth, bingo.placeBatchValidate, bingo.placeBetsBatch);
// router.post("/games/bingo/batch/draw", providerAuth, bingo.drawBatchValidate, bingo.drawBatch);

// single-card flow
router.post("/games/bingo/card/new", providerAuth, bingo.newCardValidate, bingo.newCard);
router.post("/games/bingo/card/regenerate", providerAuth, bingo.regenCardValidate, bingo.regenCard);
router.post("/games/bingo/bets/place", providerAuth, bingo.placeValidate, bingo.placeBets);
router.post("/games/bingo/draw", providerAuth, bingo.drawValidate, bingo.draw);
router.get("/games/bingo/status", providerAuth, bingo.statusValidate, bingo.status);

// batch flow (up to 4 cards with one shared result)
router.post("/games/bingo/batch/place", providerAuth, bingo.placeBatchValidate, bingo.placeBetsBatch);
router.post("/games/bingo/batch/draw", providerAuth, bingo.drawBatchValidate, bingo.drawBatch);

router.use("/admin", admin.adminRouter);




// app.post("/v1/games/greyhound/race/new",        providerAuth, newRaceValidate,  newRace);
// app.post("/v1/games/greyhound/race/regenerate", providerAuth, regenValidate,    regenerate);
// app.post("/v1/games/greyhound/bets/place",      providerAuth, placeValidate,    placeBets);
// app.post("/v1/games/greyhound/race/start",      providerAuth, startValidate,    startRace);
// app.post("/v1/games/greyhound/race/settle",     providerAuth, settleValidate,   settleRace);
// app.get ("/v1/games/greyhound/race/status",     providerAuth, statusValidate,   raceStatus);

// // NEW: public-ish stream endpoint (you can keep providerAuth if you want)
// app.get ("/v1/games/greyhound/race/stream/:result_id", streamValidate, streamResultVideo);



export default router;