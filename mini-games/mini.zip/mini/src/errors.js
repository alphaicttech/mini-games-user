"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperatorError = exports.AppError = void 0;
class AppError extends Error {
    constructor({ code, message, status = 400, details }) {
        super(message);
        this.code = code;
        this.status = status;
        this.details = details;
    }
    static badRequest(msg, details) {
        return new AppError({ code: "BAD_REQUEST", message: msg, status: 400, details });
    }
    static unauthorized(msg, details) {
        return new AppError({ code: "UNAUTHORIZED", message: msg, status: 401, details });
    }
    static notFound(msg, details) {
        return new AppError({ code: "NOT_FOUND", message: msg, status: 404, details });
    }
    static conflict(msg, details) {
        return new AppError({ code: "CONFLICT", message: msg, status: 409, details });
    }
    static rateLimited(msg, details) {
        return new AppError({ code: "RATE_LIMITED", message: msg, status: 429, details });
    }
    static upstream(msg, details) {
        return new AppError({ code: "UPSTREAM_ERROR", message: msg, status: 502, details });
    }
    static internal(msg = "Internal server error", details) {
        return new AppError({ code: "INTERNAL_ERROR", message: msg, status: 500, details });
    }
}
exports.AppError = AppError;
class OperatorError extends AppError {
    constructor(code, message, httpStatus, details) {
        super({ code, message, status: httpStatus !== null && httpStatus !== void 0 ? httpStatus : 502, details });
        this.httpStatus = httpStatus;
    }
}
exports.OperatorError = OperatorError;
