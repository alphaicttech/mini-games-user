"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// /var/www/typesafe/alpha-mini/src/server.ts
const app_1 = require("./app");
const env_1 = require("./config/env");
const http_1 = __importDefault(require("http"));
const socket_io_1 = require("socket.io");
const aviator_1 = require("./modules/ws/aviator");
const node_cron_1 = __importDefault(require("node-cron"));
const env_2 = require("./config/env");
const rtp_checkpoint_1 = require("./jobs/rtp.checkpoint");
const rtp_midnight_close_1 = require("./jobs/rtp.midnight-close");
const routes_1 = require("./modules/rtp/routes");
const server = http_1.default.createServer(app_1.app);
const io = new socket_io_1.Server(server, { cors: { origin: "*" } }); // path to the server
app_1.app.use("/rtp", routes_1.rtpRouter);
// Jobs
node_cron_1.default.schedule(env_2.RTP.CHECKPOINT_CRON, rtp_checkpoint_1.runRtpCheckpoint, { timezone: env_2.RTP.TIMEZONE });
node_cron_1.default.schedule(env_2.RTP.MIDNIGHT_CRON, rtp_midnight_close_1.runMidnightCloseOpen, { timezone: env_2.RTP.TIMEZONE });
(0, aviator_1.mountAviator)(io); // <— start multiplayer engine + WS namespace
server.listen(env_1.env.PORT, () => {
    console.log(`mini-games aggregator listening on :${env_1.env.PORT}`);
});
// import { app } from "./app";
// import { env } from "./config/env";
// app.listen(env.PORT, () => {
//     console.log(`mini-games aggregator listening on :${env.PORT}`);
// });
