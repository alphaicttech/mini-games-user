import { db } from "../config/drizzle";
import { game } from "../db/game";
import { closeDay, openDay } from "../modules/rtp/rotate";

export async function runMidnightCloseOpen() {
    const rows = await db.select().from(game);
    for (const g of rows) {
        await closeDay(g.code);
        await openDay(g.code);
    }
}
