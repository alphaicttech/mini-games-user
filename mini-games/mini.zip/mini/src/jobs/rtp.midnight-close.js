"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runMidnightCloseOpen = runMidnightCloseOpen;
const drizzle_1 = require("../config/drizzle");
const game_1 = require("../db/game");
const rotate_1 = require("../modules/rtp/rotate");
function runMidnightCloseOpen() {
    return __awaiter(this, void 0, void 0, function* () {
        const rows = yield drizzle_1.db.select().from(game_1.game);
        for (const g of rows) {
            yield (0, rotate_1.closeDay)(g.code);
            yield (0, rotate_1.openDay)(g.code);
        }
    });
}
