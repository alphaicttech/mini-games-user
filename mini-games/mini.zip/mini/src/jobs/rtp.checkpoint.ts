import { snapshotRtpDay } from "../modules/rtp/snapshot";
import { db } from "../config/drizzle";
import { game } from "../db/game";
import { toYYMMDD } from "../lib/date";

export async function runRtpCheckpoint() {
    const today = toYYMMDD();
    const rows = await db.select().from(game);
    for (const g of rows) {
        await snapshotRtpDay(g.id, g.code, today);
    }
}
