export function toYYMMDD(d = new Date()) {
    const yy = String(d.getFullYear()).slice(-2);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yy}${mm}${dd}`;
}
export function toYY(d = new Date()) {
    return String(d.getFullYear()).slice(-2);
}
export function monthYY(d = new Date()) {
    const yy = toYY(d);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    return `${yy}${mm}`;
}
