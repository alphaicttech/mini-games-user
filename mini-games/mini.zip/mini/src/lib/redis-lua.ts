// /var/www/typesafe/alpha-mini/src/lib/redis-lua.ts
import { redis } from '../config/redis';

export const lua = {
    sp_enter: (dayKey: string, stake: number) => redis.spEnter(dayKey, stake),
    sp_settle: (dayKey: string, stake: number, win: number) => redis.spSettle(dayKey, stake, win),
};
