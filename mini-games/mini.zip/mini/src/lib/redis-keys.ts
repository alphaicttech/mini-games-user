export const rk = {
    day: (gameCode: string, yymmdd: string) => `rtp:${gameCode}:${yymmdd}`,
    round: (gameCode: string, yymmdd: string, rid: string | number) => `rtp:${gameCode}:${yymmdd}:round:${rid}`,
};
