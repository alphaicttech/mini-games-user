"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.activateSession = activateSession;
exports.getBalance = getBalance;
exports.deposit = deposit;
exports.withdraw = withdraw;
exports.rollback = rollback;
// /var/www/typesafe/alpha-mini/src/operator/client.ts
const crypto_1 = __importDefault(require("crypto"));
const axios_1 = __importStar(require("axios"));
const errors_1 = require("../errors");
const md5 = (s) => crypto_1.default.createHash("md5").update(s).digest("hex");
const sign = (secret, method, rawBody) => md5(`${secret}|${method}|${rawBody}`);
const AXIOS = axios_1.default.create({
    timeout: 7000, // configurable
    maxBodyLength: 1e6,
    validateStatus: () => true, // we’ll handle manually
});
function normalizeAxiosError(e, fallbackCode) {
    var _a, _b, _c, _d, _e, _f, _g;
    if (e instanceof axios_1.AxiosError) {
        const status = (_a = e.response) === null || _a === void 0 ? void 0 : _a.status;
        const code = ((_c = (_b = e.response) === null || _b === void 0 ? void 0 : _b.headers) === null || _c === void 0 ? void 0 : _c["x-errorcode"]) || fallbackCode;
        const msg = ((_e = (_d = e.response) === null || _d === void 0 ? void 0 : _d.headers) === null || _e === void 0 ? void 0 : _e["x-errormessage"]) || e.message || "Upstream error";
        throw new errors_1.OperatorError(code, msg, status, { url: (_f = e.config) === null || _f === void 0 ? void 0 : _f.url });
    }
    throw new errors_1.OperatorError(fallbackCode, (_g = e === null || e === void 0 ? void 0 : e.message) !== null && _g !== void 0 ? _g : "Upstream error");
}
function httpPost(op, path, raw) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const sig = sign(op.secret, "POST", raw);
            const headers = { "Content-Type": "application/json", "X-Signature": sig };
            if (op.session) {
                headers["X-SessionId"] = op.session.sessionId;
                headers["X-UserName"] = op.session.userName;
                headers["X-ClientExternalKey"] = op.session.clientExternalKey;
            }
            const res = yield AXIOS.post(`${op.baseUrl}${path}`, raw, { headers });
            if (res.status !== 200) {
                const code = res.headers["x-errorcode"] || "UPSTREAM_ERROR";
                const msg = res.headers["x-errormessage"] || "Upstream rejected";
                throw new errors_1.OperatorError(code, msg, res.status, { path });
            }
            return res.data;
        }
        catch (e) {
            normalizeAxiosError(e, "UPSTREAM_ERROR");
        }
    });
}
function httpGet(op, path) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const sig = sign(op.secret, "GET", "");
            const headers = {
                "Content-Type": "application/json",
                "X-Signature": sig,
                "X-SessionId": op.session.sessionId,
                "X-UserName": op.session.userName,
                "X-ClientExternalKey": op.session.clientExternalKey,
            };
            const res = yield AXIOS.get(`${op.baseUrl}${path}`, { headers });
            if (res.status !== 200) {
                const code = res.headers["x-errorcode"] || "UPSTREAM_ERROR";
                const msg = res.headers["x-errormessage"] || "Upstream rejected";
                throw new errors_1.OperatorError(code, msg, res.status, { path });
            }
            return res.data;
        }
        catch (e) {
            normalizeAxiosError(e, "UPSTREAM_ERROR");
        }
    });
}
function activateSession(op, token) {
    return __awaiter(this, void 0, void 0, function* () {
        const data = yield httpPost(op, "/ActivateSession", JSON.stringify({ Token: token }));
        const session = {
            sessionId: String(data.SessionId),
            userName: String(data.UserName),
            clientExternalKey: String(data.ClientExternalKey),
            currencyCode: String(data.CurrencyCode)
        };
        op.session = session;
        return session;
    });
}
function getBalance(op) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const data = yield httpGet(op, "/GetBalance");
        return { amount: Number((_a = data.Amount) !== null && _a !== void 0 ? _a : 0), currencyCode: String((_b = data.CurrencyCode) !== null && _b !== void 0 ? _b : op.session.currencyCode) };
    });
}
function deposit(op, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield httpPost(op, "/Deposit", JSON.stringify(payload));
    });
}
function withdraw(op, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield httpPost(op, "/Withdraw", JSON.stringify(payload));
    });
}
function rollback(op, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield httpPost(op, "/RollbackTransaction", JSON.stringify(payload));
    });
}
