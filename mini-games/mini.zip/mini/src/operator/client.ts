// /var/www/typesafe/alpha-mini/src/operator/client.ts
import crypto from "crypto";
import axios, { AxiosError } from "axios";
import { OperatorCtx, OperatorSession } from "../types/operator";
import { OperatorError } from "../errors";

const md5 = (s: string) => crypto.createHash("md5").update(s).digest("hex");
const sign = (secret: string, method: "GET" | "POST", rawBody: string) =>
    md5(`${secret}|${method}|${rawBody}`);

const AXIOS = axios.create({
    timeout: 7000,              // configurable
    maxBodyLength: 1e6,
    validateStatus: () => true, // we’ll handle manually
});

function normalizeAxiosError(e: any, fallbackCode: string) {
    if (e instanceof AxiosError) {
        const status = e.response?.status;
        const code = (e.response?.headers?.["x-errorcode"] as string) || fallbackCode;
        const msg = (e.response?.headers?.["x-errormessage"] as string) || e.message || "Upstream error";
        throw new OperatorError(code, msg, status, { url: e.config?.url });
    }
    throw new OperatorError(fallbackCode, e?.message ?? "Upstream error");
}

async function httpPost(op: OperatorCtx, path: string, raw: string) {
    try {
        const sig = sign(op.secret, "POST", raw);
        const headers: Record<string, string> = { "Content-Type": "application/json", "X-Signature": sig };
        if (op.session) {
            headers["X-SessionId"] = op.session.sessionId;
            headers["X-UserName"] = op.session.userName;
            headers["X-ClientExternalKey"] = op.session.clientExternalKey;
        }
        const res = await AXIOS.post(`${op.baseUrl}${path}`, raw, { headers });
        if (res.status !== 200) {
            const code = (res.headers["x-errorcode"] as string) || "UPSTREAM_ERROR";
            const msg = (res.headers["x-errormessage"] as string) || "Upstream rejected";
            throw new OperatorError(code, msg, res.status, { path });
        }
        return res.data;
    } catch (e) {
        normalizeAxiosError(e, "UPSTREAM_ERROR");
    }
}

async function httpGet(op: OperatorCtx, path: string) {
    try {
        const sig = sign(op.secret, "GET", "");
        const headers: Record<string, string> = {
            "Content-Type": "application/json",
            "X-Signature": sig,
            "X-SessionId": op.session!.sessionId,
            "X-UserName": op.session!.userName,
            "X-ClientExternalKey": op.session!.clientExternalKey,
        };
        const res = await AXIOS.get(`${op.baseUrl}${path}`, { headers });
        if (res.status !== 200) {
            const code = (res.headers["x-errorcode"] as string) || "UPSTREAM_ERROR";
            const msg = (res.headers["x-errormessage"] as string) || "Upstream rejected";
            throw new OperatorError(code, msg, res.status, { path });
        }
        return res.data;
    } catch (e) {
        normalizeAxiosError(e, "UPSTREAM_ERROR");
    }
}

export async function activateSession(op: OperatorCtx, token: string): Promise<OperatorSession> {
    const data = await httpPost(op, "/ActivateSession", JSON.stringify({ Token: token }));
    const session: OperatorSession = {
        sessionId: String(data.SessionId),
        userName: String(data.UserName),
        clientExternalKey: String(data.ClientExternalKey),
        currencyCode: String(data.CurrencyCode)
    };
    op.session = session;
    return session;
}

export async function getBalance(op: OperatorCtx) {
    const data = await httpGet(op, "/GetBalance");
    return { amount: Number(data.Amount ?? 0), currencyCode: String(data.CurrencyCode ?? op.session!.currencyCode) };
}

export async function deposit(op: OperatorCtx, payload: any) {
    return await httpPost(op, "/Deposit", JSON.stringify(payload));
}
export async function withdraw(op: OperatorCtx, payload: any) {
    return await httpPost(op, "/Withdraw", JSON.stringify(payload));
}
export async function rollback(op: OperatorCtx, payload: any) {
    return await httpPost(op, "/RollbackTransaction", JSON.stringify(payload));
}


