// /var/www/typesafe/alpha-mini/src/app.ts
import express from "express";
import cors from "cors";
import router from "./modules/router";
import { notFoundHandler, errorHandler } from "./middleware/async-handler";

const app = express();
app.use(cors({ origin: "*" }));
app.use(express.json());

app.use("/v1", router);

// health
app.get("/health", (_req, res) => res.json({ ok: true }));


// 404 + error handlers (MUST be after routes)
app.use(notFoundHandler);
app.use(errorHandler);

export { app };


// curl -X POST "https://admin.alphatech.et/4000/v1/sessions/activate" \
//   -H "Content-Type: application/json" \
//   -d '{"token":"DEMO","portal_name":"demo","game_category":"Crash","game_name":"JetX","lang":"en"}'
