// // /var/www/typesafe/alpha-mini/src/rtp/rtp.util.ts
// import type { InferModel } from "drizzle-orm";
// import { and, eq } from "drizzle-orm";
// import { rtpDaily, games, gameVariants } from "../db/schema";
// import { drizzle } from "drizzle-orm/node-postgres";

// /** Format today as YYYYMMDD (local or UTC per policy) */
// export function yyyymmdd(d = new Date()): string {
//     const y = d.getFullYear();
//     const m = String(d.getMonth() + 1).padStart(2, "0");
//     const day = String(d.getDate()).padStart(2, "0");
//     return `${y}${m}${day}`;
// }

// /** Upsert the daily RTP row (create if missing). */
// export async function ensureRtpDaily(db: ReturnType<typeof drizzle>, p: {
//     operatorId: number; regionId?: number | null; gameId: number; variantId?: number | null;
//     ymd?: string; targetRtpBp: number; carryInCents?: bigint;
// }) {
//     const ymd = p.ymd ?? yyyymmdd();
//     const row = await db.query.rtpDaily.findFirst({
//         where: (t, { and, eq, isNull }) =>
//             and(
//                 eq(t.operatorId, p.operatorId),
//                 p.regionId ? eq(t.regionId, p.regionId) : isNull(t.regionId),
//                 eq(t.gameId, p.gameId),
//                 p.variantId ? eq(t.variantId, p.variantId) : isNull(t.variantId),
//                 eq(t.yyyymmdd, ymd)
//             )
//     });
//     if (row) return row;

//     const insert = await db.insert(rtpDaily).values({
//         operatorId: p.operatorId,
//         regionId: p.regionId ?? null,
//         gameId: p.gameId,
//         variantId: p.variantId ?? null,
//         yyyymmdd: ymd,
//         targetRtpBp: p.targetRtpBp,
//         carryInCents: BigInt(p.carryInCents ?? 0n),
//     }).returning();
//     return insert[0];
// }

// /** Compute daily target budget = floor((payin + carry_in) * target / 10000). */
// export function computeTargetBudgetCents(row: InferModel<typeof rtpDaily, "select">) {
//     const base = row.payinCents + row.carryInCents;
//     return (base * BigInt(row.targetRtpBp)) / 10000n;
// }

// /** Available = target_budget - payout - reserved (never below 0). */
// export function computeAvailableCents(row: InferModel<typeof rtpDaily, "select">) {
//     const target = computeTargetBudgetCents(row);
//     const used = row.payoutCents + row.reservedCents;
//     const diff = target - used;
//     return diff > 0n ? diff : 0n;
// }

// /** Stake-weight share for single-player cap (fairer than halving). */
// export function stakeShareCapCents(params: {
//     availableCents: bigint; activeStakeCents: bigint; incomingStakeCents: bigint; maxTicketPayoutCents: bigint;
// }) {
//     const { availableCents, activeStakeCents, incomingStakeCents, maxTicketPayoutCents } = params;
//     if (availableCents <= 0n) return 0n;
//     const denom = activeStakeCents + incomingStakeCents;
//     if (denom <= 0n) return availableCents < maxTicketPayoutCents ? availableCents : maxTicketPayoutCents;
//     // weight = stake / (active + stake); cap = available * weight
//     const cap = (availableCents * incomingStakeCents) / denom;
//     return cap < maxTicketPayoutCents ? cap : maxTicketPayoutCents;
// }
