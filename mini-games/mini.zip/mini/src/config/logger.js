"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// /var/www/typesafe/alpha-mini/src/config/logger.ts
const pino_1 = __importDefault(require("pino"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const logDir = path_1.default.join(__dirname, '../../logs');
fs_1.default.mkdirSync(logDir, { recursive: true });
const infoStream = fs_1.default.createWriteStream(path_1.default.join(logDir, 'info.log'), { flags: 'a' });
const errorStream = fs_1.default.createWriteStream(path_1.default.join(logDir, 'error.log'), { flags: 'a' });
const logger = (0, pino_1.default)({
    level: 'info',
    formatters: {
        level: (label) => ({ level: label }),
    },
    timestamp: pino_1.default.stdTimeFunctions.isoTime,
}, pino_1.default.multistream([
    { stream: infoStream, level: 'info' },
    { stream: errorStream, level: 'error' },
]));
exports.default = logger;
