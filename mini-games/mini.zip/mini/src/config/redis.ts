// // /var/www/typesafe/alpha-mini/src/config/redis.ts
// import IORedis, { RedisOptions } from 'ioredis';
// import { readFileSync } from 'fs';
// import path from 'path';
// import { env } from './env';
// import logger from './logger';

// export interface RedisConfig {
//     host: string;
//     port: number;
//     password?: string;
//     db?: number;
//     keyPrefix?: string;
//     tls?: boolean;
// }

// type LuaMap = Record<string, { file: string; numberOfKeys: number }>;

// const LUA_SCRIPTS: LuaMap = {
//     sp_enter: { file: '../../modules/rtp/lua/sp_enter.lua', numberOfKeys: 1 },
//     sp_settle: { file: '../../modules/rtp/lua/sp_settle.lua', numberOfKeys: 1 },
// };

// function loadLuaFile(rel: string): string {
//     const full = path.resolve(__dirname, rel);
//     return readFileSync(full, 'utf8');
// }

// // -----------------------------
// // Enhanced RedisClient Wrapper
// // -----------------------------
// class RedisClient {
//     private client: IORedis;
//     private subscriber: IORedis;
//     private publisher: IORedis;

//     constructor(config: RedisConfig) {
//         const baseConfig: RedisOptions = {
//             host: config.host,
//             port: config.port,
//             password: config.password,
//             db: config.db ?? 0,
//             keyPrefix: config.keyPrefix ?? 'alpha-mini-games:',
//             tls: config.tls ? {} as any : undefined,
//             enableAutoPipelining: true,
//             maxRetriesPerRequest: null,
//             lazyConnect: false,
//             commandTimeout: 5000,
//             retryStrategy: (times) => Math.min(times * 200, 5000),
//             reconnectOnError: (err) => {
//                 const msg = err?.message ?? '';
//                 return msg.includes('READONLY') || msg.includes('MOVED') || msg.includes('ASK');
//             },
//         };

//         this.client = new IORedis(baseConfig);
//         this.subscriber = new IORedis(baseConfig);
//         this.publisher = new IORedis(baseConfig);

//         this.setupEventHandlers();
//         this.loadLuaScripts();
//     }

//     private setupEventHandlers() {
//         this.client.on('connect', () => logger.info('✅ Redis connected'));
//         this.client.on('ready', () => logger.info('🔌 Redis is ready'));
//         this.client.on('error', (err) => logger.error({ err }, '❌ Redis error'));
//         this.client.on('close', () => logger.warn('🚪 Redis connection closed'));
//         this.client.on('reconnecting', () => logger.info('♻️ Redis reconnecting...'));
//         this.client.on('end', () => logger.error('❌ Redis connection ended'));

//         this.subscriber.on('error', (err) => logger.error({ err }, '❌ Redis SUB error'));
//         this.publisher.on('error', (err) => logger.error({ err }, '❌ Redis PUB error'));
//     }

//     /** Load & register Lua scripts for atomic RTP ops */
//     private loadLuaScripts() {
//         try {
//             for (const [name, meta] of Object.entries(LUA_SCRIPTS)) {
//                 const lua = loadLuaFile(meta.file);
//                 // defineCommand exists on IORedis but TS types can be finicky → cast
//                 (this.client as any).defineCommand(name, { numberOfKeys: meta.numberOfKeys, lua });
//             }
//             logger.info('📜 Redis Lua scripts loaded');
//         } catch (err) {
//             logger.error({ err }, '⚠️ Failed to load Redis Lua scripts');
//         }
//     }

//     /** Raw ioredis if you need pipelines/MULTI/etc */
//     getRaw(): IORedis {
//         return this.client;
//     }

//     // -------- KV --------
//     async get(key: string) { return this.client.get(key); }
//     async set(key: string, value: string, ttl?: number): Promise<'OK'> {
//         if (ttl && ttl > 0) return this.client.setex(key, ttl, value);
//         return this.client.set(key, value);
//     }
//     async del(key: string) { return this.client.del(key); }
//     async exists(key: string) { return this.client.exists(key); }
//     async expire(key: string, ttl: number) { return this.client.expire(key, ttl); }

//     // -------- JSON helpers --------
//     async setJSON(key: string, data: any, ttl?: number) {
//         return this.set(key, JSON.stringify(data), ttl);
//     }
//     async getJSON<T = any>(key: string): Promise<T | null> {
//         const s = await this.get(key);
//         return s ? JSON.parse(s) as T : null;
//     }

//     // -------- Hash --------
//     async hget(key: string, field: string) { return this.client.hget(key, field); }

//     // Overload: hset(key, field, value) OR hset(key, obj)
//     async hset(key: string, field: string, value: string | number): Promise<number>;
//     async hset(key: string, obj: Record<string, string | number>): Promise<number>;
//     async hset(key: string, a: any, b?: any): Promise<number> {
//         if (typeof a === 'object' && b === undefined) {
//             const flat: Array<string> = [];
//             for (const [k, v] of Object.entries(a as Record<string, string | number>)) {
//                 flat.push(k, String(v));
//             }
//             return this.client.hset(key, ...flat);
//         }
//         return this.client.hset(key, String(a), String(b));
//     }

//     async hgetall(key: string) { return this.client.hgetall(key); }
//     async hdel(key: string, field: string) { return this.client.hdel(key, field); }
//     // async hsetnx(key: string, field: string, value: string | number) {
//     //     // emulate HSET field NX
//     //     return this.client.hset(key, field, String(value), 'NX');
//     // }
//     async hsetnx(key: string, field: string, value: string | number) {
//         return (this.client as any).hsetnx(key, field, String(value));
//       }
      
//     async hincrby(key: string, field: string, by: number) { return this.client.hincrby(key, field, by); }
//     async hincrbyfloat(key: string, field: string, by: number) { return this.client.hincrbyfloat(key, field, by); }
//     async hmset(key: string, obj: Record<string, string | number>): Promise<'OK'> {
//         const flat: Array<string> = [];
//         for (const [k, v] of Object.entries(obj)) flat.push(k, String(v));
//         await this.client.hset(key, ...flat);
//         return 'OK';
//     }

//     // -------- Lists --------
//     async lpush(key: string, value: string) { return this.client.lpush(key, value); }
//     async rpush(key: string, value: string) { return this.client.rpush(key, value); }
//     async lpop(key: string) { return this.client.lpop(key); }
//     async rpop(key: string) { return this.client.rpop(key); }
//     async lrange(key: string, start: number, stop: number) { return this.client.lrange(key, start, stop); }

//     // -------- Sets --------
//     async sadd(key: string, member: string) { return this.client.sadd(key, member); }
//     async srem(key: string, member: string) { return this.client.srem(key, member); }
//     async smembers(key: string) { return this.client.smembers(key); }
//     async sismember(key: string, member: string) { return this.client.sismember(key, member); }

//     // -------- Pub/Sub --------
//     async publish(channel: string, message: string) { return this.publisher.publish(channel, message); }
//     async subscribe(channel: string, callback: (message: string) => void) {
//         await this.subscriber.subscribe(channel);
//         this.subscriber.on('message', (ch, message) => { if (ch === channel) callback(message); });
//     }
//     async unsubscribe(channel: string) { return this.subscriber.unsubscribe(channel); }

//     // -------- Pipelines / MULTI --------
//     multi() { return this.client.multi(); } // don’t annotate; TS will use ioredis’ type

//     // -------- RTP Lua wrappers --------
//     async spEnter(dayKey: string, stake: number) {
//         return (this.client as any).sp_enter(dayKey, stake.toString());
//     }
//     async spSettle(dayKey: string, stake: number, win: number) {
//         return (this.client as any).sp_settle(dayKey, stake.toString(), win.toString());
//     }

//     // --- Session helpers (compat) ---
//     async setSession(sessionId: string, data: any, ttl: number = 3600): Promise<'OK'> {
//         return this.set(`session:${sessionId}`, JSON.stringify(data), ttl);
//     }

//     async getSession<T = any>(sessionId: string): Promise<T | null> {
//         const raw = await this.get(`session:${sessionId}`);
//         return raw ? JSON.parse(raw) as T : null;
//     }

//     async acquireLock(key: string, ttlSeconds = 3): Promise<boolean> {
//         const res = await this.client.set(key, '1', 'EX', ttlSeconds, 'NX');
//         return res === 'OK';
//       }
      
//       async releaseLock(key: string): Promise<void> {
//         await this.client.del(key);
//       }




//     // -------- Lifecycle --------
//     async disconnect(): Promise<void> {
//         await this.client.quit();
//         await this.subscriber.quit();
//         await this.publisher.quit();
//     }
// }

// // 🔧 Enhanced Redis client (for req.redis, sessions, games)
// export const redis = new RedisClient({
//     host: env.REDIS_HOST,
//     port: env.REDIS_PORT,
//     password: env.REDIS_PASSWORD,
//     db: 1,
//     keyPrefix: 'alpha-mini-games:',
//     tls: env.REDIS_TLS === 'true',
// });

// export { RedisClient };

// // -----------------------------
// // Raw Redis for BullMQ/low-level
// // -----------------------------
// export const rawRedis = new IORedis({
//     host: env.REDIS_HOST,
//     port: env.REDIS_PORT,
//     password: env.REDIS_PASSWORD,
//     db: env.REDIS_DB,
//     tls: env.REDIS_TLS === 'true' ? {} : undefined,
//     maxRetriesPerRequest: null,
//     enableAutoPipelining: true,
// });

import IORedis, { RedisOptions } from "ioredis";
import { readFileSync } from "fs";
import path from "path";
import { env } from "./env";
import logger from "./logger";

export interface RedisConfig {
  host: string;
  port: number;
  password?: string;
  db?: number;
  keyPrefix?: string;
  tls?: boolean;
}

type LuaMap = Record<string, { file: string; numberOfKeys: number }>;

const LUA_SCRIPTS: LuaMap = {
  sp_enter:  { file: "../modules/rtp/lua/sp_enter.lua",  numberOfKeys: 1 },
  sp_settle: { file: "../modules/rtp/lua/sp_settle.lua", numberOfKeys: 1 },
};

function loadLuaFile(relFromConfigDir: string): string {
  // __dirname is .../src/config  →  ../modules/... is correct
  const full = path.resolve(__dirname, relFromConfigDir);
  return readFileSync(full, "utf8");
}

// -----------------------------
// Enhanced RedisClient Wrapper
// -----------------------------
class RedisClient {
  private client: IORedis;
  private subscriber: IORedis;
  private publisher: IORedis;
  private luaLoaded = false;

  constructor(config: RedisConfig) {
    const baseConfig: RedisOptions = {
      host: config.host,
      port: config.port,
      password: config.password,
      db: config.db ?? 0,
      keyPrefix: config.keyPrefix ?? "alpha-mini-games:",
      tls: config.tls ? ({} as any) : undefined,
      enableAutoPipelining: true,
      maxRetriesPerRequest: null,
      lazyConnect: false,
      commandTimeout: 5000,
      retryStrategy: (times) => Math.min(times * 200, 5000),
      reconnectOnError: (err) => {
        const msg = err?.message ?? "";
        return msg.includes("READONLY") || msg.includes("MOVED") || msg.includes("ASK");
      },
    };

    this.client = new IORedis(baseConfig);
    this.subscriber = new IORedis(baseConfig);
    this.publisher = new IORedis(baseConfig);

    this.setupEventHandlers();
    this.loadLuaScripts();
  }

  private setupEventHandlers() {
    this.client.on("connect", () => logger.info("✅ Redis connected"));
    this.client.on("ready", () => logger.info("🔌 Redis is ready"));
    this.client.on("error", (err) => logger.error({ err }, "❌ Redis error"));
    this.client.on("close", () => logger.warn("🚪 Redis connection closed"));
    this.client.on("reconnecting", () => logger.info("♻️ Redis reconnecting..."));
    this.client.on("end", () => logger.error("❌ Redis connection ended"));

    this.subscriber.on("error", (err) => logger.error({ err }, "❌ Redis SUB error"));
    this.publisher.on("error", (err) => logger.error({ err }, "❌ Redis PUB error"));
  }

  /** Load & register Lua scripts for atomic RTP ops (with fallback to MULTI) */
  private loadLuaScripts() {
    try {
      for (const [name, meta] of Object.entries(LUA_SCRIPTS)) {
        const lua = loadLuaFile(meta.file);
        (this.client as any).defineCommand(name, { numberOfKeys: meta.numberOfKeys, lua });
        logger.info(`📜 Registered Lua command: ${name}`);
      }
      this.luaLoaded = true;
      logger.info("📜 Redis Lua scripts loaded");
    } catch (err) {
      this.luaLoaded = false;
      logger.error({ err }, "⚠️ Failed to load Redis Lua scripts (will use MULTI fallback)");
    }
  }

  /** Raw ioredis if you need pipelines/MULTI/etc */
  getRaw(): IORedis {
    return this.client;
  }

  // -------- KV --------
  async get(key: string) { return this.client.get(key); }

  async set(key: string, value: string, ttl?: number): Promise<"OK"> {
    if (ttl && ttl > 0) return this.client.setex(key, ttl, value);
    return this.client.set(key, value);
  }

  async del(key: string) { return this.client.del(key); }
  async exists(key: string) { return this.client.exists(key); }
  async expire(key: string, ttl: number) { return this.client.expire(key, ttl); }

  // -------- JSON helpers --------
  async setJSON(key: string, data: any, ttl?: number) {
    return this.set(key, JSON.stringify(data), ttl);
  }
  async getJSON<T = any>(key: string): Promise<T | null> {
    const s = await this.get(key);
    return s ? (JSON.parse(s) as T) : null;
  }

  // -------- Hash --------
  async hget(key: string, field: string) { return this.client.hget(key, field); }

  // Overload: hset(key, field, value) OR hset(key, obj)
  async hset(key: string, field: string, value: string | number): Promise<number>;
  async hset(key: string, obj: Record<string, string | number>): Promise<number>;
  async hset(key: string, a: any, b?: any): Promise<number> {
    if (typeof a === "object" && b === undefined) {
      const flat: Array<string> = [];
      for (const [k, v] of Object.entries(a as Record<string, string | number>)) {
        flat.push(k, String(v));
      }
      // @ts-ignore ioredis variadic
      return this.client.hset(key, ...flat);
    }
    return this.client.hset(key, String(a), String(b));
  }

  async hgetall(key: string) { return this.client.hgetall(key); }
  async hdel(key: string, field: string) { return this.client.hdel(key, field); }

  async hsetnx(key: string, field: string, value: string | number) {
    // Use the proper HSETNX command in ioredis
    // @ts-ignore
    return (this.client as any).hsetnx(key, field, String(value));
  }

  async hincrby(key: string, field: string, by: number) { return this.client.hincrby(key, field, by); }
  async hincrbyfloat(key: string, field: string, by: number) { return this.client.hincrbyfloat(key, field, by); }

  async hmset(key: string, obj: Record<string, string | number>): Promise<"OK"> {
    const flat: Array<string> = [];
    for (const [k, v] of Object.entries(obj)) flat.push(k, String(v));
    // @ts-ignore
    await this.client.hset(key, ...flat);
    return "OK";
  }

  // -------- Lists --------
  async lpush(key: string, value: string) { return this.client.lpush(key, value); }
  async rpush(key: string, value: string) { return this.client.rpush(key, value); }
  async lpop(key: string) { return this.client.lpop(key); }
  async rpop(key: string) { return this.client.rpop(key); }
  async lrange(key: string, start: number, stop: number) { return this.client.lrange(key, start, stop); }

  // -------- Sets --------
  async sadd(key: string, member: string) { return this.client.sadd(key, member); }
  async srem(key: string, member: string) { return this.client.srem(key, member); }
  async smembers(key: string) { return this.client.smembers(key); }
  async sismember(key: string, member: string) { return this.client.sismember(key, member); }

  // -------- Pub/Sub --------
  async publish(channel: string, message: string) { return this.publisher.publish(channel, message); }
  async subscribe(channel: string, callback: (message: string) => void) {
    await this.subscriber.subscribe(channel);
    this.subscriber.on("message", (ch, message) => { if (ch === channel) callback(message); });
  }
  async unsubscribe(channel: string) { return this.subscriber.unsubscribe(channel); }

  // -------- Pipelines / MULTI --------
  multi() { return this.client.multi(); }

  // -------- Lock helpers (ioredis syntax) --------
  async acquireLock(key: string, ttlSeconds = 3): Promise<boolean> {
    // ioredis SET key val 'EX' 3 'NX'
    const res = await this.client.set(key, "1", "EX", ttlSeconds, "NX");
    return res === "OK";
  }
  async releaseLock(key: string): Promise<void> {
    await this.client.del(key);
  }

  // -------- RTP Lua wrappers with MULTI fallback --------
  async spEnter(dayKey: string, stake: number) {
    if (this.luaLoaded && typeof (this.client as any).sp_enter === "function") {
      return (this.client as any).sp_enter(dayKey, stake.toString());
    }
    // Fallback: active_users++, active_stake += stake, initialize payin/payout if missing
    const m = this.client.multi();
    m.hincrby(dayKey, "active_users", 1);
    // @ts-ignore
    m.hincrbyfloat(dayKey, "active_stake", Number(stake) || 0);
    // @ts-ignore
    m.hsetnx(dayKey, "payin", "0");
    // @ts-ignore
    m.hsetnx(dayKey, "payout", "0");
    return m.exec();
  }

  async spSettle(dayKey: string, stake: number, win: number) {
    if (this.luaLoaded && typeof (this.client as any).sp_settle === "function") {
      return (this.client as any).sp_settle(dayKey, stake.toString(), win.toString());
    }
    const m = this.client.multi();
    m.hincrby(dayKey, "active_users", -1);
    // @ts-ignore
    m.hincrbyfloat(dayKey, "active_stake", -(Number(stake) || 0));
    // @ts-ignore
    m.hincrbyfloat(dayKey, "payin", Number(stake) || 0);
    // @ts-ignore
    m.hincrbyfloat(dayKey, "payout", Number(win) || 0);
    return m.exec();
  }

  // --- Session helpers (compat) ---
  async setSession(sessionId: string, data: any, ttl: number = 3600): Promise<"OK"> {
    return this.set(`session:${sessionId}`, JSON.stringify(data), ttl);
  }

  async getSession<T = any>(sessionId: string): Promise<T | null> {
    const raw = await this.get(`session:${sessionId}`);
    return raw ? (JSON.parse(raw) as T) : null;
  }

  // -------- Lifecycle --------
  async disconnect(): Promise<void> {
    await this.client.quit();
    await this.subscriber.quit();
    await this.publisher.quit();
  }
}

// 🔧 Enhanced Redis client (for req.redis, sessions, games)
export const redis = new RedisClient({
  host: env.REDIS_HOST,
  port: env.REDIS_PORT,
  password: env.REDIS_PASSWORD,
  db: 1,
  keyPrefix: "alpha-mini-games:",
  tls: env.REDIS_TLS === "true",
});

export { RedisClient };

// -----------------------------
// Raw Redis for BullMQ/low-level
// -----------------------------
export const rawRedis = new IORedis({
  host: env.REDIS_HOST,
  port: env.REDIS_PORT,
  password: env.REDIS_PASSWORD,
  db: env.REDIS_DB,
  tls: env.REDIS_TLS === "true" ? {} : undefined,
  maxRetriesPerRequest: null,
  enableAutoPipelining: true,
});
