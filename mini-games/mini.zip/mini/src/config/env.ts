// /var/www/typesafe/alpha-mini/src/config/env.ts
import { z } from "zod";
import "dotenv/config";

const jsonArray = <T extends z.ZodTypeAny>(schema: T, def: z.infer<T>) =>
  z.preprocess((v) => {
    if (Array.isArray(v)) return v;
    if (typeof v === "string") {
      try { return JSON.parse(v); } catch {
        // allow comma-separated fallback
        return v.split(",").map((s) => s.trim()).filter(Boolean);
      }
    }
    return v;
  }, schema).default(def);

const schema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.coerce.number().default(5005),

  // Database
  DATABASE_URL: z.string().min(1),

  // Redis
  REDIS_HOST: z.string().default("127.0.0.1"),
  REDIS_PORT: z.coerce.number().default(6379),
  REDIS_PASSWORD: z.string().optional(),
  REDIS_DB: z.coerce.number().default(1),
  REDIS_TLS: z.enum(["true", "false"]).default("false"),

  // TTLs (seconds)
  LAUNCH_TOKEN_TTL: z.coerce.number().default(900),
  SESSION_TTL: z.coerce.number().default(7200),
  IDEMPOTENCY_TTL: z.coerce.number().default(86400),

  // Demo
  DEMO_START_BALANCE: z.coerce.number().default(1000),

  // Optional (Kept for now)
  GAT_SECRET: z.string().default("change-me-dev"),

  // Operator defaults (read from .env)
  base_url: z.string().url().default("http://localhost:4001"),
  secret: z.string().default("DEMO_SECRET"),
  name: z.string().default("Demo Operator"),
  currencies: jsonArray(z.array(z.string()), ["FUN"]),
  ip_allowlist: jsonArray(z.array(z.string()), ["127.0.0.1/32"]),
});

export const RTP = {
  CHECKPOINT_CRON: process.env.RTP_CHECKPOINT_CRON ?? "*/5 * * * *",
  MIDNIGHT_CRON: process.env.RTP_MIDNIGHT_CRON ?? "59 59 23 * * *",
  TIMEZONE: process.env.TZ ?? "Africa/Addis_Ababa",
};

export const env = schema.parse(process.env);
