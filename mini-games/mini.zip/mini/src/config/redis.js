"use strict";
// // /var/www/typesafe/alpha-mini/src/config/redis.ts
// import IORedis, { RedisOptions } from 'ioredis';
// import { readFileSync } from 'fs';
// import path from 'path';
// import { env } from './env';
// import logger from './logger';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rawRedis = exports.RedisClient = exports.redis = void 0;
// export interface RedisConfig {
//     host: string;
//     port: number;
//     password?: string;
//     db?: number;
//     keyPrefix?: string;
//     tls?: boolean;
// }
// type LuaMap = Record<string, { file: string; numberOfKeys: number }>;
// const LUA_SCRIPTS: LuaMap = {
//     sp_enter: { file: '../../modules/rtp/lua/sp_enter.lua', numberOfKeys: 1 },
//     sp_settle: { file: '../../modules/rtp/lua/sp_settle.lua', numberOfKeys: 1 },
// };
// function loadLuaFile(rel: string): string {
//     const full = path.resolve(__dirname, rel);
//     return readFileSync(full, 'utf8');
// }
// // -----------------------------
// // Enhanced RedisClient Wrapper
// // -----------------------------
// class RedisClient {
//     private client: IORedis;
//     private subscriber: IORedis;
//     private publisher: IORedis;
//     constructor(config: RedisConfig) {
//         const baseConfig: RedisOptions = {
//             host: config.host,
//             port: config.port,
//             password: config.password,
//             db: config.db ?? 0,
//             keyPrefix: config.keyPrefix ?? 'alpha-mini-games:',
//             tls: config.tls ? {} as any : undefined,
//             enableAutoPipelining: true,
//             maxRetriesPerRequest: null,
//             lazyConnect: false,
//             commandTimeout: 5000,
//             retryStrategy: (times) => Math.min(times * 200, 5000),
//             reconnectOnError: (err) => {
//                 const msg = err?.message ?? '';
//                 return msg.includes('READONLY') || msg.includes('MOVED') || msg.includes('ASK');
//             },
//         };
//         this.client = new IORedis(baseConfig);
//         this.subscriber = new IORedis(baseConfig);
//         this.publisher = new IORedis(baseConfig);
//         this.setupEventHandlers();
//         this.loadLuaScripts();
//     }
//     private setupEventHandlers() {
//         this.client.on('connect', () => logger.info('✅ Redis connected'));
//         this.client.on('ready', () => logger.info('🔌 Redis is ready'));
//         this.client.on('error', (err) => logger.error({ err }, '❌ Redis error'));
//         this.client.on('close', () => logger.warn('🚪 Redis connection closed'));
//         this.client.on('reconnecting', () => logger.info('♻️ Redis reconnecting...'));
//         this.client.on('end', () => logger.error('❌ Redis connection ended'));
//         this.subscriber.on('error', (err) => logger.error({ err }, '❌ Redis SUB error'));
//         this.publisher.on('error', (err) => logger.error({ err }, '❌ Redis PUB error'));
//     }
//     /** Load & register Lua scripts for atomic RTP ops */
//     private loadLuaScripts() {
//         try {
//             for (const [name, meta] of Object.entries(LUA_SCRIPTS)) {
//                 const lua = loadLuaFile(meta.file);
//                 // defineCommand exists on IORedis but TS types can be finicky → cast
//                 (this.client as any).defineCommand(name, { numberOfKeys: meta.numberOfKeys, lua });
//             }
//             logger.info('📜 Redis Lua scripts loaded');
//         } catch (err) {
//             logger.error({ err }, '⚠️ Failed to load Redis Lua scripts');
//         }
//     }
//     /** Raw ioredis if you need pipelines/MULTI/etc */
//     getRaw(): IORedis {
//         return this.client;
//     }
//     // -------- KV --------
//     async get(key: string) { return this.client.get(key); }
//     async set(key: string, value: string, ttl?: number): Promise<'OK'> {
//         if (ttl && ttl > 0) return this.client.setex(key, ttl, value);
//         return this.client.set(key, value);
//     }
//     async del(key: string) { return this.client.del(key); }
//     async exists(key: string) { return this.client.exists(key); }
//     async expire(key: string, ttl: number) { return this.client.expire(key, ttl); }
//     // -------- JSON helpers --------
//     async setJSON(key: string, data: any, ttl?: number) {
//         return this.set(key, JSON.stringify(data), ttl);
//     }
//     async getJSON<T = any>(key: string): Promise<T | null> {
//         const s = await this.get(key);
//         return s ? JSON.parse(s) as T : null;
//     }
//     // -------- Hash --------
//     async hget(key: string, field: string) { return this.client.hget(key, field); }
//     // Overload: hset(key, field, value) OR hset(key, obj)
//     async hset(key: string, field: string, value: string | number): Promise<number>;
//     async hset(key: string, obj: Record<string, string | number>): Promise<number>;
//     async hset(key: string, a: any, b?: any): Promise<number> {
//         if (typeof a === 'object' && b === undefined) {
//             const flat: Array<string> = [];
//             for (const [k, v] of Object.entries(a as Record<string, string | number>)) {
//                 flat.push(k, String(v));
//             }
//             return this.client.hset(key, ...flat);
//         }
//         return this.client.hset(key, String(a), String(b));
//     }
//     async hgetall(key: string) { return this.client.hgetall(key); }
//     async hdel(key: string, field: string) { return this.client.hdel(key, field); }
//     // async hsetnx(key: string, field: string, value: string | number) {
//     //     // emulate HSET field NX
//     //     return this.client.hset(key, field, String(value), 'NX');
//     // }
//     async hsetnx(key: string, field: string, value: string | number) {
//         return (this.client as any).hsetnx(key, field, String(value));
//       }
//     async hincrby(key: string, field: string, by: number) { return this.client.hincrby(key, field, by); }
//     async hincrbyfloat(key: string, field: string, by: number) { return this.client.hincrbyfloat(key, field, by); }
//     async hmset(key: string, obj: Record<string, string | number>): Promise<'OK'> {
//         const flat: Array<string> = [];
//         for (const [k, v] of Object.entries(obj)) flat.push(k, String(v));
//         await this.client.hset(key, ...flat);
//         return 'OK';
//     }
//     // -------- Lists --------
//     async lpush(key: string, value: string) { return this.client.lpush(key, value); }
//     async rpush(key: string, value: string) { return this.client.rpush(key, value); }
//     async lpop(key: string) { return this.client.lpop(key); }
//     async rpop(key: string) { return this.client.rpop(key); }
//     async lrange(key: string, start: number, stop: number) { return this.client.lrange(key, start, stop); }
//     // -------- Sets --------
//     async sadd(key: string, member: string) { return this.client.sadd(key, member); }
//     async srem(key: string, member: string) { return this.client.srem(key, member); }
//     async smembers(key: string) { return this.client.smembers(key); }
//     async sismember(key: string, member: string) { return this.client.sismember(key, member); }
//     // -------- Pub/Sub --------
//     async publish(channel: string, message: string) { return this.publisher.publish(channel, message); }
//     async subscribe(channel: string, callback: (message: string) => void) {
//         await this.subscriber.subscribe(channel);
//         this.subscriber.on('message', (ch, message) => { if (ch === channel) callback(message); });
//     }
//     async unsubscribe(channel: string) { return this.subscriber.unsubscribe(channel); }
//     // -------- Pipelines / MULTI --------
//     multi() { return this.client.multi(); } // don’t annotate; TS will use ioredis’ type
//     // -------- RTP Lua wrappers --------
//     async spEnter(dayKey: string, stake: number) {
//         return (this.client as any).sp_enter(dayKey, stake.toString());
//     }
//     async spSettle(dayKey: string, stake: number, win: number) {
//         return (this.client as any).sp_settle(dayKey, stake.toString(), win.toString());
//     }
//     // --- Session helpers (compat) ---
//     async setSession(sessionId: string, data: any, ttl: number = 3600): Promise<'OK'> {
//         return this.set(`session:${sessionId}`, JSON.stringify(data), ttl);
//     }
//     async getSession<T = any>(sessionId: string): Promise<T | null> {
//         const raw = await this.get(`session:${sessionId}`);
//         return raw ? JSON.parse(raw) as T : null;
//     }
//     async acquireLock(key: string, ttlSeconds = 3): Promise<boolean> {
//         const res = await this.client.set(key, '1', 'EX', ttlSeconds, 'NX');
//         return res === 'OK';
//       }
//       async releaseLock(key: string): Promise<void> {
//         await this.client.del(key);
//       }
//     // -------- Lifecycle --------
//     async disconnect(): Promise<void> {
//         await this.client.quit();
//         await this.subscriber.quit();
//         await this.publisher.quit();
//     }
// }
// // 🔧 Enhanced Redis client (for req.redis, sessions, games)
// export const redis = new RedisClient({
//     host: env.REDIS_HOST,
//     port: env.REDIS_PORT,
//     password: env.REDIS_PASSWORD,
//     db: 1,
//     keyPrefix: 'alpha-mini-games:',
//     tls: env.REDIS_TLS === 'true',
// });
// export { RedisClient };
// // -----------------------------
// // Raw Redis for BullMQ/low-level
// // -----------------------------
// export const rawRedis = new IORedis({
//     host: env.REDIS_HOST,
//     port: env.REDIS_PORT,
//     password: env.REDIS_PASSWORD,
//     db: env.REDIS_DB,
//     tls: env.REDIS_TLS === 'true' ? {} : undefined,
//     maxRetriesPerRequest: null,
//     enableAutoPipelining: true,
// });
const ioredis_1 = __importDefault(require("ioredis"));
const fs_1 = require("fs");
const path_1 = __importDefault(require("path"));
const env_1 = require("./env");
const logger_1 = __importDefault(require("./logger"));
const LUA_SCRIPTS = {
    sp_enter: { file: "../modules/rtp/lua/sp_enter.lua", numberOfKeys: 1 },
    sp_settle: { file: "../modules/rtp/lua/sp_settle.lua", numberOfKeys: 1 },
};
function loadLuaFile(relFromConfigDir) {
    // __dirname is .../src/config  →  ../modules/... is correct
    const full = path_1.default.resolve(__dirname, relFromConfigDir);
    return (0, fs_1.readFileSync)(full, "utf8");
}
// -----------------------------
// Enhanced RedisClient Wrapper
// -----------------------------
class RedisClient {
    constructor(config) {
        var _a, _b;
        this.luaLoaded = false;
        const baseConfig = {
            host: config.host,
            port: config.port,
            password: config.password,
            db: (_a = config.db) !== null && _a !== void 0 ? _a : 0,
            keyPrefix: (_b = config.keyPrefix) !== null && _b !== void 0 ? _b : "alpha-mini-games:",
            tls: config.tls ? {} : undefined,
            enableAutoPipelining: true,
            maxRetriesPerRequest: null,
            lazyConnect: false,
            commandTimeout: 5000,
            retryStrategy: (times) => Math.min(times * 200, 5000),
            reconnectOnError: (err) => {
                var _a;
                const msg = (_a = err === null || err === void 0 ? void 0 : err.message) !== null && _a !== void 0 ? _a : "";
                return msg.includes("READONLY") || msg.includes("MOVED") || msg.includes("ASK");
            },
        };
        this.client = new ioredis_1.default(baseConfig);
        this.subscriber = new ioredis_1.default(baseConfig);
        this.publisher = new ioredis_1.default(baseConfig);
        this.setupEventHandlers();
        this.loadLuaScripts();
    }
    setupEventHandlers() {
        this.client.on("connect", () => logger_1.default.info("✅ Redis connected"));
        this.client.on("ready", () => logger_1.default.info("🔌 Redis is ready"));
        this.client.on("error", (err) => logger_1.default.error({ err }, "❌ Redis error"));
        this.client.on("close", () => logger_1.default.warn("🚪 Redis connection closed"));
        this.client.on("reconnecting", () => logger_1.default.info("♻️ Redis reconnecting..."));
        this.client.on("end", () => logger_1.default.error("❌ Redis connection ended"));
        this.subscriber.on("error", (err) => logger_1.default.error({ err }, "❌ Redis SUB error"));
        this.publisher.on("error", (err) => logger_1.default.error({ err }, "❌ Redis PUB error"));
    }
    /** Load & register Lua scripts for atomic RTP ops (with fallback to MULTI) */
    loadLuaScripts() {
        try {
            for (const [name, meta] of Object.entries(LUA_SCRIPTS)) {
                const lua = loadLuaFile(meta.file);
                this.client.defineCommand(name, { numberOfKeys: meta.numberOfKeys, lua });
                logger_1.default.info(`📜 Registered Lua command: ${name}`);
            }
            this.luaLoaded = true;
            logger_1.default.info("📜 Redis Lua scripts loaded");
        }
        catch (err) {
            this.luaLoaded = false;
            logger_1.default.error({ err }, "⚠️ Failed to load Redis Lua scripts (will use MULTI fallback)");
        }
    }
    /** Raw ioredis if you need pipelines/MULTI/etc */
    getRaw() {
        return this.client;
    }
    // -------- KV --------
    get(key) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.get(key); });
    }
    set(key, value, ttl) {
        return __awaiter(this, void 0, void 0, function* () {
            if (ttl && ttl > 0)
                return this.client.setex(key, ttl, value);
            return this.client.set(key, value);
        });
    }
    del(key) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.del(key); });
    }
    exists(key) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.exists(key); });
    }
    expire(key, ttl) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.expire(key, ttl); });
    }
    // -------- JSON helpers --------
    setJSON(key, data, ttl) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.set(key, JSON.stringify(data), ttl);
        });
    }
    getJSON(key) {
        return __awaiter(this, void 0, void 0, function* () {
            const s = yield this.get(key);
            return s ? JSON.parse(s) : null;
        });
    }
    // -------- Hash --------
    hget(key, field) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.hget(key, field); });
    }
    hset(key, a, b) {
        return __awaiter(this, void 0, void 0, function* () {
            if (typeof a === "object" && b === undefined) {
                const flat = [];
                for (const [k, v] of Object.entries(a)) {
                    flat.push(k, String(v));
                }
                // @ts-ignore ioredis variadic
                return this.client.hset(key, ...flat);
            }
            return this.client.hset(key, String(a), String(b));
        });
    }
    hgetall(key) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.hgetall(key); });
    }
    hdel(key, field) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.hdel(key, field); });
    }
    hsetnx(key, field, value) {
        return __awaiter(this, void 0, void 0, function* () {
            // Use the proper HSETNX command in ioredis
            // @ts-ignore
            return this.client.hsetnx(key, field, String(value));
        });
    }
    hincrby(key, field, by) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.hincrby(key, field, by); });
    }
    hincrbyfloat(key, field, by) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.hincrbyfloat(key, field, by); });
    }
    hmset(key, obj) {
        return __awaiter(this, void 0, void 0, function* () {
            const flat = [];
            for (const [k, v] of Object.entries(obj))
                flat.push(k, String(v));
            // @ts-ignore
            yield this.client.hset(key, ...flat);
            return "OK";
        });
    }
    // -------- Lists --------
    lpush(key, value) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.lpush(key, value); });
    }
    rpush(key, value) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.rpush(key, value); });
    }
    lpop(key) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.lpop(key); });
    }
    rpop(key) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.rpop(key); });
    }
    lrange(key, start, stop) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.lrange(key, start, stop); });
    }
    // -------- Sets --------
    sadd(key, member) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.sadd(key, member); });
    }
    srem(key, member) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.srem(key, member); });
    }
    smembers(key) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.smembers(key); });
    }
    sismember(key, member) {
        return __awaiter(this, void 0, void 0, function* () { return this.client.sismember(key, member); });
    }
    // -------- Pub/Sub --------
    publish(channel, message) {
        return __awaiter(this, void 0, void 0, function* () { return this.publisher.publish(channel, message); });
    }
    subscribe(channel, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.subscriber.subscribe(channel);
            this.subscriber.on("message", (ch, message) => { if (ch === channel)
                callback(message); });
        });
    }
    unsubscribe(channel) {
        return __awaiter(this, void 0, void 0, function* () { return this.subscriber.unsubscribe(channel); });
    }
    // -------- Pipelines / MULTI --------
    multi() { return this.client.multi(); }
    // -------- Lock helpers (ioredis syntax) --------
    acquireLock(key_1) {
        return __awaiter(this, arguments, void 0, function* (key, ttlSeconds = 3) {
            // ioredis SET key val 'EX' 3 'NX'
            const res = yield this.client.set(key, "1", "EX", ttlSeconds, "NX");
            return res === "OK";
        });
    }
    releaseLock(key) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.client.del(key);
        });
    }
    // -------- RTP Lua wrappers with MULTI fallback --------
    spEnter(dayKey, stake) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.luaLoaded && typeof this.client.sp_enter === "function") {
                return this.client.sp_enter(dayKey, stake.toString());
            }
            // Fallback: active_users++, active_stake += stake, initialize payin/payout if missing
            const m = this.client.multi();
            m.hincrby(dayKey, "active_users", 1);
            // @ts-ignore
            m.hincrbyfloat(dayKey, "active_stake", Number(stake) || 0);
            // @ts-ignore
            m.hsetnx(dayKey, "payin", "0");
            // @ts-ignore
            m.hsetnx(dayKey, "payout", "0");
            return m.exec();
        });
    }
    spSettle(dayKey, stake, win) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.luaLoaded && typeof this.client.sp_settle === "function") {
                return this.client.sp_settle(dayKey, stake.toString(), win.toString());
            }
            const m = this.client.multi();
            m.hincrby(dayKey, "active_users", -1);
            // @ts-ignore
            m.hincrbyfloat(dayKey, "active_stake", -(Number(stake) || 0));
            // @ts-ignore
            m.hincrbyfloat(dayKey, "payin", Number(stake) || 0);
            // @ts-ignore
            m.hincrbyfloat(dayKey, "payout", Number(win) || 0);
            return m.exec();
        });
    }
    // --- Session helpers (compat) ---
    setSession(sessionId_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (sessionId, data, ttl = 3600) {
            return this.set(`session:${sessionId}`, JSON.stringify(data), ttl);
        });
    }
    getSession(sessionId) {
        return __awaiter(this, void 0, void 0, function* () {
            const raw = yield this.get(`session:${sessionId}`);
            return raw ? JSON.parse(raw) : null;
        });
    }
    // -------- Lifecycle --------
    disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.client.quit();
            yield this.subscriber.quit();
            yield this.publisher.quit();
        });
    }
}
exports.RedisClient = RedisClient;
// 🔧 Enhanced Redis client (for req.redis, sessions, games)
exports.redis = new RedisClient({
    host: env_1.env.REDIS_HOST,
    port: env_1.env.REDIS_PORT,
    password: env_1.env.REDIS_PASSWORD,
    db: 1,
    keyPrefix: "alpha-mini-games:",
    tls: env_1.env.REDIS_TLS === "true",
});
// -----------------------------
// Raw Redis for BullMQ/low-level
// -----------------------------
exports.rawRedis = new ioredis_1.default({
    host: env_1.env.REDIS_HOST,
    port: env_1.env.REDIS_PORT,
    password: env_1.env.REDIS_PASSWORD,
    db: env_1.env.REDIS_DB,
    tls: env_1.env.REDIS_TLS === "true" ? {} : undefined,
    maxRetriesPerRequest: null,
    enableAutoPipelining: true,
});
