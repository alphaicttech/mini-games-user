"use strict";
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = exports.RTP = void 0;
// /var/www/typesafe/alpha-mini/src/config/env.ts
const zod_1 = require("zod");
require("dotenv/config");
const jsonArray = (schema, def) => zod_1.z.preprocess((v) => {
    if (Array.isArray(v))
        return v;
    if (typeof v === "string") {
        try {
            return JSON.parse(v);
        }
        catch (_a) {
            // allow comma-separated fallback
            return v.split(",").map((s) => s.trim()).filter(Boolean);
        }
    }
    return v;
}, schema).default(def);
const schema = zod_1.z.object({
    NODE_ENV: zod_1.z.enum(["development", "production", "test"]).default("development"),
    PORT: zod_1.z.coerce.number().default(5005),
    // Database
    DATABASE_URL: zod_1.z.string().min(1),
    // Redis
    REDIS_HOST: zod_1.z.string().default("127.0.0.1"),
    REDIS_PORT: zod_1.z.coerce.number().default(6379),
    REDIS_PASSWORD: zod_1.z.string().optional(),
    REDIS_DB: zod_1.z.coerce.number().default(1),
    REDIS_TLS: zod_1.z.enum(["true", "false"]).default("false"),
    // TTLs (seconds)
    LAUNCH_TOKEN_TTL: zod_1.z.coerce.number().default(900),
    SESSION_TTL: zod_1.z.coerce.number().default(7200),
    IDEMPOTENCY_TTL: zod_1.z.coerce.number().default(86400),
    // Demo
    DEMO_START_BALANCE: zod_1.z.coerce.number().default(1000),
    // Optional (Kept for now)
    GAT_SECRET: zod_1.z.string().default("change-me-dev"),
    // Operator defaults (read from .env)
    base_url: zod_1.z.string().url().default("http://localhost:4001"),
    secret: zod_1.z.string().default("DEMO_SECRET"),
    name: zod_1.z.string().default("Demo Operator"),
    currencies: jsonArray(zod_1.z.array(zod_1.z.string()), ["FUN"]),
    ip_allowlist: jsonArray(zod_1.z.array(zod_1.z.string()), ["127.0.0.1/32"]),
});
exports.RTP = {
    CHECKPOINT_CRON: (_a = process.env.RTP_CHECKPOINT_CRON) !== null && _a !== void 0 ? _a : "*/5 * * * *",
    MIDNIGHT_CRON: (_b = process.env.RTP_MIDNIGHT_CRON) !== null && _b !== void 0 ? _b : "59 59 23 * * *",
    TIMEZONE: (_c = process.env.TZ) !== null && _c !== void 0 ? _c : "Africa/Addis_Ababa",
};
exports.env = schema.parse(process.env);
