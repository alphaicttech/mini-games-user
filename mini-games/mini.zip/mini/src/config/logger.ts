// /var/www/typesafe/alpha-mini/src/config/logger.ts
import pino from 'pino';
import fs from 'fs';
import path from 'path';

const logDir = path.join(__dirname, '../../logs');
fs.mkdirSync(logDir, { recursive: true });

const infoStream = fs.createWriteStream(path.join(logDir, 'info.log'), { flags: 'a' });
const errorStream = fs.createWriteStream(path.join(logDir, 'error.log'), { flags: 'a' });

const logger = pino(
    {
        level: 'info',
        formatters: {
            level: (label) => ({ level: label }),
        },
        timestamp: pino.stdTimeFunctions.isoTime,
    },
    pino.multistream([
        { stream: infoStream, level: 'info' },
        { stream: errorStream, level: 'error' },
    ])
);

export default logger;
