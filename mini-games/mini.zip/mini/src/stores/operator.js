"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.upsertOperator = upsertOperator;
exports.findOperatorByPortalName = findOperatorByPortalName;
exports.findOperatorById = findOperatorById;
// src/stores/operator.ts
const drizzle_1 = require("../config/drizzle"); // your drizzle instance
const schema_1 = require("../db/schema"); // barrel must export operators
const drizzle_orm_1 = require("drizzle-orm");
// export async function findOperatorByPortalName(portalName: string): Promise<OperatorRow> {
//     const row = await db.query.operators.findFirst({
//         where: eq(operators.portalName, portalName),
//     });
//     if (!row) throw new Error(`OPERATOR_NOT_FOUND: ${portalName}`);
//     return row;
// }
function upsertOperator(payload) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const existing = yield drizzle_1.db.query.operators.findFirst({
            where: (0, drizzle_orm_1.eq)(schema_1.operators.portalName, payload.portalName),
        });
        if (!existing) {
            yield drizzle_1.db.insert(schema_1.operators).values({
                portalName: payload.portalName,
                name: (_a = payload.name) !== null && _a !== void 0 ? _a : payload.portalName,
                baseUrl: payload.baseUrl,
                secret: payload.secret,
                currencies: (_b = payload.currencies) !== null && _b !== void 0 ? _b : [],
                ipAllowlist: (_c = payload.ipAllowlist) !== null && _c !== void 0 ? _c : [],
            });
        }
        else {
            yield drizzle_1.db.update(schema_1.operators)
                .set({
                name: (_d = payload.name) !== null && _d !== void 0 ? _d : existing.name,
                baseUrl: payload.baseUrl,
                secret: payload.secret,
                currencies: (_f = (_e = payload.currencies) !== null && _e !== void 0 ? _e : existing.currencies) !== null && _f !== void 0 ? _f : [],
                ipAllowlist: (_h = (_g = payload.ipAllowlist) !== null && _g !== void 0 ? _g : existing.ipAllowlist) !== null && _h !== void 0 ? _h : [],
            })
                .where((0, drizzle_orm_1.eq)(schema_1.operators.id, existing.id));
        }
    });
}
function findOperatorByPortalName(portalName) {
    return __awaiter(this, void 0, void 0, function* () {
        const row = yield drizzle_1.db.query.operators.findFirst({
            where: (0, drizzle_orm_1.eq)(schema_1.operators.portalName, portalName),
        });
        if (!row)
            throw new Error(`OPERATOR_NOT_FOUND: ${portalName}`);
        return row;
    });
}
function findOperatorById(id) {
    return __awaiter(this, void 0, void 0, function* () {
        const row = yield drizzle_1.db.query.operators.findFirst({
            where: (0, drizzle_orm_1.eq)(schema_1.operators.id, id),
        });
        if (!row)
            throw new Error(`OPERATOR_NOT_FOUND_BY_ID: ${id}`);
        return row;
    });
}
