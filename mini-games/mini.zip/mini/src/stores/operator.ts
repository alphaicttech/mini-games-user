// src/stores/operator.ts
import { db } from "../config/drizzle";            // your drizzle instance
import { operators } from "../db/schema";   // barrel must export operators
import { eq } from "drizzle-orm";

export type OperatorRow = typeof operators.$inferSelect;

// export async function findOperatorByPortalName(portalName: string): Promise<OperatorRow> {
//     const row = await db.query.operators.findFirst({
//         where: eq(operators.portalName, portalName),
//     });
//     if (!row) throw new Error(`OPERATOR_NOT_FOUND: ${portalName}`);
//     return row;
// }

export async function upsertOperator(payload: {
    portalName: string; name?: string; baseUrl: string; secret: string;
    currencies?: string[]; ipAllowlist?: string[];
}) {
    const existing = await db.query.operators.findFirst({
        where: eq(operators.portalName, payload.portalName),
    });

    if (!existing) {
        await db.insert(operators).values({
            portalName: payload.portalName,
            name: payload.name ?? payload.portalName,
            baseUrl: payload.baseUrl,
            secret: payload.secret,
            currencies: payload.currencies ?? [],
            ipAllowlist: payload.ipAllowlist ?? [],
        });
    } else {
        await db.update(operators)
            .set({
                name: payload.name ?? existing.name,
                baseUrl: payload.baseUrl,
                secret: payload.secret,
                currencies: payload.currencies ?? existing.currencies ?? [],
                ipAllowlist: payload.ipAllowlist ?? existing.ipAllowlist ?? [],
            })
            .where(eq(operators.id, existing.id));
    }
}


export async function findOperatorByPortalName(portalName: string): Promise<OperatorRow> {
    const row = await db.query.operators.findFirst({
        where: eq(operators.portalName, portalName),
    });
    if (!row) throw new Error(`OPERATOR_NOT_FOUND: ${portalName}`);
    return row;
}

export async function findOperatorById(id: number): Promise<OperatorRow> {
    const row = await db.query.operators.findFirst({
        where: eq(operators.id, id),
    });
    if (!row) throw new Error(`OPERATOR_NOT_FOUND_BY_ID: ${id}`);
    return row;
}
