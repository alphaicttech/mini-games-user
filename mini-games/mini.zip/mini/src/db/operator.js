"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.operators = void 0;
const pg_core_1 = require("drizzle-orm/pg-core");
exports.operators = (0, pg_core_1.pgTable)("operators", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    name: (0, pg_core_1.varchar)("name", { length: 100 }).notNull(),
    portalName: (0, pg_core_1.varchar)("portal_name", { length: 100 }).notNull(), // used in Loader.aspx?PortalName=...
    baseUrl: (0, pg_core_1.text)("base_url").notNull(), // operator wallet API base
    secret: (0, pg_core_1.text)("secret").notNull(), // signing secret (md5)
    currencies: (0, pg_core_1.jsonb)("currencies").$type().default([]),
    ipAllowlist: (0, pg_core_1.jsonb)("ip_allowlist").$type().default([]),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    uxPortal: (0, pg_core_1.uniqueIndex)("ux_operators_portal").on(t.portalName),
    ixName: (0, pg_core_1.index)("ix_operators_name").on(t.name),
}));
