import "dotenv/config";
import { db } from "../../config/drizzle";
import { adminUsers } from "../../db/admin";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

async function up() {
    const username = process.env.ADMIN_USER || "admin";
    const password = process.env.ADMIN_PASS || "123456";
    const email = process.env.ADMIN_EMAIL || "admin@example.com";

    const exists = await db.select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1);
    if (exists.length) {
        console.log("Admin user exists:", username);
        return;
    }

    const hash = await bcrypt.hash(password, 12);
    const [row] = await db.insert(adminUsers).values({
        username,
        email,
        passwordHash: hash,
        role: "SUPER_ADMIN",
        isActive: true,
    }).returning();

    console.log("✅ Created admin:", row.username, "(id:", row.id, ")");
    console.log("Use credentials:", username, "/", password);
}

up().catch(e => { console.error(e); process.exit(1); }).then(() => process.exit(0));
