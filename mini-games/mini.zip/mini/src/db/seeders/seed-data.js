"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
// /var/www/typesafe/alpha-mini/src/db/seeders/seed-initial.ts
require("dotenv/config");
const drizzle_1 = require("../../config/drizzle");
const drizzle_orm_1 = require("drizzle-orm");
const game_1 = require("../game");
const operator_1 = require("../operator");
/** Parse arrays from .env (supports JSON string or comma-separated) */
function parseArray(input, fallback) {
    if (Array.isArray(input))
        return input;
    if (typeof input === "string") {
        try {
            return JSON.parse(input);
        }
        catch (_a) {
            return input.split(",").map(s => s.trim()).filter(Boolean);
        }
    }
    return fallback;
}
function upsertOperatorDemo() {
    return __awaiter(this, void 0, void 0, function* () {
        const portalName = "demo";
        const name = process.env.name || "Demo Operator";
        const baseUrl = process.env.base_url || "http://localhost:4001";
        const secret = process.env.secret || "DEMO_SECRET";
        const currencies = parseArray(process.env.currencies, ["FUN"]);
        const ipAllowlist = parseArray(process.env.ip_allowlist, ["127.0.0.1/32"]);
        const existing = yield drizzle_1.db.query.operators.findFirst({
            where: (0, drizzle_orm_1.eq)(operator_1.operators.portalName, portalName),
        });
        if (!existing) {
            const [row] = yield drizzle_1.db.insert(operator_1.operators).values({
                portalName,
                name,
                baseUrl,
                secret,
                currencies,
                ipAllowlist,
            }).returning();
            console.log("✅ seeded operator:", row);
        }
        else {
            yield drizzle_1.db.update(operator_1.operators)
                .set({ name, baseUrl, secret, currencies, ipAllowlist })
                .where((0, drizzle_orm_1.eq)(operator_1.operators.id, existing.id));
            console.log("✅ updated operator:", portalName);
        }
    });
}
function upsertGamesAndConfig() {
    return __awaiter(this, void 0, void 0, function* () {
        const gamesData = [
            { code: "keno", name: "Keno", is_active: true },
            { code: "bingo", name: "Bingo 75", is_active: true },
            { code: "spin", name: "Spin & Wheel", is_active: true },
            { code: "roulette_mini", name: "Roulette Mini", is_active: true },
            { code: "plinko", name: "Plinko", is_active: true },
            { code: "mines", name: "Bomb Mines", is_active: true },
            { code: "chicken-road", name: "Chicken Road", is_active: true },
            { code: "balloons", name: "Balloons", is_active: true },
            { code: "baccarat", name: "Baccarat", is_active: true },
            { code: "dragontiger", name: "Dragon Tiger", is_active: true },
            { code: "reddog", name: "Red Dog", is_active: true },
            { code: "casinowar", name: "Casino War", is_active: true },
            { code: "jetx", name: "Aviator", is_active: true },
            { code: "greyhound", name: "Greyhound", is_active: true }, // REQUIRED
        ];
        // upsert games
        for (const g of gamesData) {
            const existing = yield drizzle_1.db.select().from(game_1.game).where((0, drizzle_orm_1.eq)(game_1.game.code, g.code)).limit(1);
            if (existing.length === 0) {
                const [row] = yield drizzle_1.db.insert(game_1.game).values(g).returning();
                console.log("🆕 created game:", row.code, row.id);
            }
            else {
                const row = existing[0];
                if (row.name !== g.name || row.is_active !== g.is_active) {
                    yield drizzle_1.db.update(game_1.game)
                        .set({ name: g.name, is_active: g.is_active })
                        .where((0, drizzle_orm_1.eq)(game_1.game.id, row.id));
                    console.log("🔄 updated game:", g.code);
                }
            }
        }
        // default numeric config for all games
        const defaults = {
            rtp_target: 0.90,
            alpha: 0.85,
            kappa: 1.50,
            beta: 0.60,
            per_bet_cap: 5000,
            per_ticket_cap: 10000,
            per_user_daily_cap: 20000,
            alpha_round: 0.25,
            gamma_round: 0.90,
            cashout_intensity: 0.40,
            global_odd_cap: 50,
        };
        const allGames = yield drizzle_1.db.select().from(game_1.game);
        for (const g of allGames) {
            const existingCfg = yield drizzle_1.db.select().from(game_1.gameConfig).where((0, drizzle_orm_1.eq)(game_1.gameConfig.game_id, g.id)).limit(1);
            if (existingCfg.length === 0) {
                const [cfg] = yield drizzle_1.db.insert(game_1.gameConfig).values(Object.assign({ game_id: g.id }, defaults)).returning();
                console.log("🆕 created cfg for:", g.code, "→", cfg.id);
            }
        }
    });
}
(() => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield upsertOperatorDemo();
        yield upsertGamesAndConfig();
        console.log("✅ Seed complete.");
        process.exit(0);
    }
    catch (e) {
        console.error("Seed failed:", e);
        process.exit(1);
    }
}))();
