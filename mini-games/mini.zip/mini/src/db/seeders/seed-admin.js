"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const drizzle_1 = require("../../config/drizzle");
const admin_1 = require("../../db/admin");
const drizzle_orm_1 = require("drizzle-orm");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
function up() {
    return __awaiter(this, void 0, void 0, function* () {
        const username = process.env.ADMIN_USER || "admin";
        const password = process.env.ADMIN_PASS || "123456";
        const email = process.env.ADMIN_EMAIL || "admin@example.com";
        const exists = yield drizzle_1.db.select().from(admin_1.adminUsers).where((0, drizzle_orm_1.eq)(admin_1.adminUsers.username, username)).limit(1);
        if (exists.length) {
            console.log("Admin user exists:", username);
            return;
        }
        const hash = yield bcryptjs_1.default.hash(password, 12);
        const [row] = yield drizzle_1.db.insert(admin_1.adminUsers).values({
            username,
            email,
            passwordHash: hash,
            role: "SUPER_ADMIN",
            isActive: true,
        }).returning();
        console.log("✅ Created admin:", row.username, "(id:", row.id, ")");
        console.log("Use credentials:", username, "/", password);
    });
}
up().catch(e => { console.error(e); process.exit(1); }).then(() => process.exit(0));
