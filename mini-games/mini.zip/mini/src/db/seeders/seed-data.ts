// /var/www/typesafe/alpha-mini/src/db/seeders/seed-initial.ts
import "dotenv/config";
import { db } from "../../config/drizzle";
import { eq } from "drizzle-orm";
import { game, gameConfig } from "../game";
import { operators } from "../operator";

/** Parse arrays from .env (supports JSON string or comma-separated) */
function parseArray(input: any, fallback: string[]): string[] {
  if (Array.isArray(input)) return input;
  if (typeof input === "string") {
    try { return JSON.parse(input); } catch {
      return input.split(",").map(s => s.trim()).filter(Boolean);
    }
  }
  return fallback;
}

async function upsertOperatorDemo() {
  const portalName = "demo";
  const name = process.env.name || "Demo Operator";
  const baseUrl = process.env.base_url || "http://localhost:4001";
  const secret = process.env.secret || "DEMO_SECRET";
  const currencies = parseArray(process.env.currencies, ["FUN"]);
  const ipAllowlist = parseArray(process.env.ip_allowlist, ["127.0.0.1/32"]);

  const existing = await db.query.operators.findFirst({
    where: eq(operators.portalName, portalName),
  });

  if (!existing) {
    const [row] = await db.insert(operators).values({
      portalName,
      name,
      baseUrl,
      secret,
      currencies,
      ipAllowlist,
    }).returning();
    console.log("✅ seeded operator:", row);
  } else {
    await db.update(operators)
      .set({ name, baseUrl, secret, currencies, ipAllowlist })
      .where(eq(operators.id, existing.id));
    console.log("✅ updated operator:", portalName);
  }
}

async function upsertGamesAndConfig() {
  const gamesData: Array<{ code: string; name: string; is_active: boolean }> = [
    { code: "keno",          name: "Keno",          is_active: true },
    { code: "bingo",         name: "Bingo 75",      is_active: true },
    { code: "spin",          name: "Spin & Wheel",  is_active: true },
    { code: "roulette_mini", name: "Roulette Mini", is_active: true },
    { code: "plinko",        name: "Plinko",        is_active: true },
    { code: "mines",         name: "Bomb Mines",    is_active: true },
    { code: "chicken-road",  name: "Chicken Road",  is_active: true },
    { code: "balloons",      name: "Balloons",      is_active: true },
    { code: "baccarat",      name: "Baccarat",      is_active: true },
    { code: "dragontiger",   name: "Dragon Tiger",  is_active: true },
    { code: "reddog",        name: "Red Dog",       is_active: true },
    { code: "casinowar",     name: "Casino War",    is_active: true },
    { code: "jetx",          name: "Aviator",       is_active: true },
    { code: "greyhound",     name: "Greyhound",     is_active: true }, // REQUIRED
  ];

  // upsert games
  for (const g of gamesData) {
    const existing = await db.select().from(game).where(eq(game.code, g.code)).limit(1);
    if (existing.length === 0) {
      const [row] = await db.insert(game).values(g).returning();
      console.log("🆕 created game:", row.code, row.id);
    } else {
      const row = existing[0];
      if (row.name !== g.name || row.is_active !== g.is_active) {
        await db.update(game)
          .set({ name: g.name, is_active: g.is_active })
          .where(eq(game.id, row.id));
        console.log("🔄 updated game:", g.code);
      }
    }
  }

  // default numeric config for all games
  const defaults = {
    rtp_target: 0.90,
    alpha: 0.85,
    kappa: 1.50,
    beta: 0.60,
    per_bet_cap: 5000,
    per_ticket_cap: 10000,
    per_user_daily_cap: 20000,
    alpha_round: 0.25,
    gamma_round: 0.90,
    cashout_intensity: 0.40,
    global_odd_cap: 50,
  };

  const allGames = await db.select().from(game);
  for (const g of allGames) {
    const existingCfg = await db.select().from(gameConfig).where(eq(gameConfig.game_id, g.id)).limit(1);
    if (existingCfg.length === 0) {
      const [cfg] = await db.insert(gameConfig).values({
        game_id: g.id,
        ...defaults, // numeric values now OK due to .$type<number>() in schema
      }).returning();
      console.log("🆕 created cfg for:", g.code, "→", cfg.id);
    }
  }
}

(async () => {
  try {
    await upsertOperatorDemo();
    await upsertGamesAndConfig();
    console.log("✅ Seed complete.");
    process.exit(0);
  } catch (e) {
    console.error("Seed failed:", e);
    process.exit(1);
  }
})();
