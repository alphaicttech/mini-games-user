// import { pgTable, serial, varchar, boolean, integer, numeric, uniqueIndex, pgEnum } from "drizzle-orm/pg-core";

// export const game = pgTable("game", {
//     id: serial("id").primaryKey(),
//     code: varchar("code", { length: 32 }).notNull().unique(), // 'keno','bingo','plinko','jetx',...
//     name: varchar("name", { length: 64 }).notNull(),
//     is_active: boolean("is_active").notNull().default(true),
// });

// export const gameConfig = pgTable("game_config", {
//     id: serial("id").primaryKey(),
//     game_id: integer("game_id").notNull().references(() => game.id),
//     // single-player knobs
//     rtp_target: numeric("rtp_target", { precision: 5, scale: 4 }).notNull().default('0.90'),
//     alpha: numeric("alpha", { precision: 5, scale: 4 }).notNull().default('0.85'),
//     kappa: numeric("kappa", { precision: 5, scale: 4 }).notNull().default('1.50'),
//     beta: numeric("beta", { precision: 5, scale: 4 }).notNull().default('0.60'),
//     per_bet_cap: numeric("per_bet_cap", { precision: 18, scale: 2 }).notNull().default('5000'),
//     per_ticket_cap: numeric("per_ticket_cap", { precision: 18, scale: 2 }).notNull().default('10000'),
//     per_user_daily_cap: numeric("per_user_daily_cap", { precision: 18, scale: 2 }).notNull().default('20000'),
//     // JetX knobs
//     alpha_round: numeric("alpha_round", { precision: 5, scale: 4 }).notNull().default('0.25'),
//     gamma_round: numeric("gamma_round", { precision: 5, scale: 4 }).notNull().default('0.90'),
//     cashout_intensity: numeric("cashout_intensity", { precision: 5, scale: 4 }).notNull().default('0.40'),
//     global_odd_cap: numeric("global_odd_cap", { precision: 10, scale: 2 }).notNull().default('50'),
// }, t => ({ uniq: uniqueIndex("cfg_by_game").on(t.game_id) }));

// /var/www/typesafe/alpha-mini/src/db/game.ts
import {
    pgTable,
    serial,
    integer,
    varchar,
    boolean,
    numeric,
    uniqueIndex,
  } from "drizzle-orm/pg-core";
  
  /** Base game table */
  export const game = pgTable("game", {
    id: serial("id").primaryKey(),
    code: varchar("code", { length: 32 }).notNull(),
    name: varchar("name", { length: 64 }).notNull(),
    is_active: boolean("is_active").notNull().default(true),
  }, (t) => ({
    codeUnique: uniqueIndex("game_code_unique").on(t.code),
  }));
  
  /**
   * Per-game config.
   * NOTE: numeric() columns are kept as numeric in DB but exposed as number in TS via .$type<number>().
   */
  export const gameConfig = pgTable("game_config", {
    id: serial("id").primaryKey(),
    game_id: integer("game_id").notNull(), // FK set in migration; ensure your migration includes it
    rtp_target: numeric("rtp_target", { precision: 5, scale: 4 }).notNull().default("0.90").$type<number>(),
    alpha: numeric("alpha", { precision: 5, scale: 4 }).notNull().default("0.85").$type<number>(),
    kappa: numeric("kappa", { precision: 5, scale: 4 }).notNull().default("1.50").$type<number>(),
    beta: numeric("beta", { precision: 5, scale: 4 }).notNull().default("0.60").$type<number>(),
    per_bet_cap: numeric("per_bet_cap", { precision: 20, scale: 2 }).notNull().default("5000").$type<number>(),
    per_ticket_cap: numeric("per_ticket_cap", { precision: 20, scale: 2 }).notNull().default("10000").$type<number>(),
    per_user_daily_cap: numeric("per_user_daily_cap", { precision: 20, scale: 2 }).notNull().default("20000").$type<number>(),
  
    // JetX-specific knobs (harmless on other games)
    alpha_round: numeric("alpha_round", { precision: 5, scale: 4 }).notNull().default("0.25").$type<number>(),
    gamma_round: numeric("gamma_round", { precision: 5, scale: 4 }).notNull().default("0.90").$type<number>(),
    cashout_intensity: numeric("cashout_intensity", { precision: 5, scale: 4 }).notNull().default("0.40").$type<number>(),
    global_odd_cap: numeric("global_odd_cap", { precision: 10, scale: 2 }).notNull().default("50").$type<number>(),
  }, (t) => ({
    byGame: uniqueIndex("cfg_by_game").on(t.game_id),
  }));
  