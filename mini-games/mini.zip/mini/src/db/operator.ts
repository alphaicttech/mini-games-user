import { pgTable, serial, varchar, boolean, timestamp, uniqueIndex, jsonb, text, index } from "drizzle-orm/pg-core";

export const operators = pgTable("operators", {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    portalName: varchar("portal_name", { length: 100 }).notNull(),   // used in Loader.aspx?PortalName=...
    baseUrl: text("base_url").notNull(),                              // operator wallet API base
    secret: text("secret").notNull(),                                 // signing secret (md5)
    currencies: jsonb("currencies").$type<string[]>().default([]),
    ipAllowlist: jsonb("ip_allowlist").$type<string[]>().default([]),
    createdAt: timestamp("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    uxPortal: uniqueIndex("ux_operators_portal").on(t.portalName),
    ixName: index("ix_operators_name").on(t.name),
}));