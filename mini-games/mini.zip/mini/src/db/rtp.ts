import { pgTable, serial, integer, varchar, numeric, timestamp, index, uniqueIndex, pgEnum } from "drizzle-orm/pg-core";
import { game } from "./game";
export const walletTxnType = pgEnum("wallet_txn_type", ["DEPOSIT", "WITHDRAW", "ROLLBACK"]);

export const rtpMonth = pgTable("rtp_month", {
    id: serial("id").primaryKey(),
    game_id: integer("game_id").notNull().references(() => game.id),
    month_yy: varchar("month_yy", { length: 6 }).notNull(), // '2510'
    rtp_target: numeric("rtp_target", { precision: 5, scale: 4 }).notNull(),
    payin: numeric("payin", { precision: 20, scale: 2 }).notNull().default('0'),
    payout: numeric("payout", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_in: numeric("carry_in", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_out: numeric("carry_out", { precision: 20, scale: 2 }).notNull().default('0'),
    created_at: timestamp("created_at").defaultNow(),
}, t => ({
    uniq: uniqueIndex("rtp_month_uniq").on(t.game_id, t.month_yy),
    byGame: index("rtp_month_game_idx").on(t.game_id),
}));

export const rtpDay = pgTable("rtp_day", {
    id: serial("id").primaryKey(),
    game_id: integer("game_id").notNull().references(() => game.id),
    date_yymmdd: varchar("date_yymmdd", { length: 6 }).notNull(), // '251027'
    rtp_target: numeric("rtp_target", { precision: 5, scale: 4 }).notNull(),
    payin: numeric("payin", { precision: 20, scale: 2 }).notNull().default('0'),
    payout: numeric("payout", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_in: numeric("carry_in", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_out: numeric("carry_out", { precision: 20, scale: 2 }).notNull().default('0'),
    rounds: integer("rounds").notNull().default(0),
    last_snapshot_at: timestamp("last_snapshot_at"),
    created_at: timestamp("created_at").defaultNow(),
}, t => ({
    uniq: uniqueIndex("rtp_day_uniq").on(t.game_id, t.date_yymmdd),
    byGame: index("rtp_day_game_idx").on(t.game_id),
}));

// Ledger (operator deposits/withdraws/rollbacks)

// replace walletTxn table with:
export const walletTxn = pgTable("wallet_txn", {
    id: serial("id").primaryKey(),
    external_id: varchar("external_id", { length: 64 }), // make unique if webhook sends it
    type: walletTxnType("type").notNull(),
    amount: numeric("amount", { precision: 20, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 8 }).notNull().default("ETB"),
    meta: varchar("meta", { length: 2048 }),
    created_at: timestamp("created_at").defaultNow(),
}, t => ({
    byExternal: uniqueIndex("wallet_txn_ext_uniq").on(t.external_id),
    byType: index("wallet_txn_type_idx").on(t.type),
    byCreated: index("wallet_txn_created_idx").on(t.created_at),
}));