"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rtpAdjustments = exports.adminAudit = exports.adminTokens = exports.adminUsers = exports.adminRole = void 0;
const pg_core_1 = require("drizzle-orm/pg-core");
const game_1 = require("./game"); // existing
const drizzle_orm_1 = require("drizzle-orm");
/** Admin roles */
exports.adminRole = ["SUPER_ADMIN", "OPS", "RISK", "VIEWER"];
exports.adminUsers = (0, pg_core_1.pgTable)("admin_users", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    username: (0, pg_core_1.varchar)("username", { length: 64 }).notNull(),
    email: (0, pg_core_1.varchar)("email", { length: 120 }).notNull(),
    passwordHash: (0, pg_core_1.varchar)("password_hash", { length: 255 }).notNull(),
    role: (0, pg_core_1.varchar)("role", { length: 32 }).notNull().$type().default("VIEWER"),
    isActive: (0, pg_core_1.boolean)("is_active").notNull().default(true),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow()
}, (t) => ({
    uxUsername: (0, pg_core_1.uniqueIndex)("ux_admin_username").on(t.username),
    uxEmail: (0, pg_core_1.uniqueIndex)("ux_admin_email").on(t.email),
}));
/** API Tokens for cross-admin access (from your sportsbook/virtual admin) */
exports.adminTokens = (0, pg_core_1.pgTable)("admin_tokens", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    label: (0, pg_core_1.varchar)("label", { length: 128 }).notNull(),
    tokenHash: (0, pg_core_1.varchar)("token_hash", { length: 128 }).notNull(), // store SHA-256 hex
    scopes: (0, pg_core_1.jsonb)("scopes").$type().notNull().default((0, drizzle_orm_1.sql) `'[]'::jsonb`),
    operatorId: (0, pg_core_1.integer)("operator_id"), // optional: tie to operator.id
    createdBy: (0, pg_core_1.integer)("created_by"), // admin_users.id
    isActive: (0, pg_core_1.boolean)("is_active").notNull().default(true),
    expiresAt: (0, pg_core_1.timestamp)("expires_at").default((0, drizzle_orm_1.sql) `(now() + interval '365 days')`),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow()
}, (t) => ({
    uxTokenHash: (0, pg_core_1.uniqueIndex)("ux_admin_token_hash").on(t.tokenHash),
}));
/** Admin Audit Log (append-only) */
exports.adminAudit = (0, pg_core_1.pgTable)("admin_audit", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    at: (0, pg_core_1.timestamp)("at").defaultNow(),
    actorType: (0, pg_core_1.varchar)("actor_type", { length: 16 }).notNull().default("USER"), // USER | TOKEN
    actorId: (0, pg_core_1.integer)("actor_id"),
    actorName: (0, pg_core_1.varchar)("actor_name", { length: 128 }),
    action: (0, pg_core_1.varchar)("action", { length: 128 }).notNull(), // e.g. 'GAME_UPDATE', 'RTP_ADJUST', 'TOKEN_CREATE'
    resource: (0, pg_core_1.varchar)("resource", { length: 256 }).notNull(), // e.g. 'game:greyhound' or 'rtp_day:greyhound:251027'
    before: (0, pg_core_1.jsonb)("before"),
    after: (0, pg_core_1.jsonb)("after"),
    meta: (0, pg_core_1.jsonb)("meta"),
});
/** Optional: manual RTP adjustments to DB */
exports.rtpAdjustments = (0, pg_core_1.pgTable)("rtp_adjustments", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    gameId: (0, pg_core_1.integer)("game_id").references(() => game_1.game.id).notNull(),
    yymmdd: (0, pg_core_1.varchar)("yymmdd", { length: 6 }).notNull(),
    deltaPayin: (0, pg_core_1.varchar)("delta_payin", { length: 32 }).notNull().default("0"), // numeric(20,2) in DB; store as string if schema numeric()
    deltaPayout: (0, pg_core_1.varchar)("delta_payout", { length: 32 }).notNull().default("0"),
    deltaCarry: (0, pg_core_1.varchar)("delta_carry", { length: 32 }).notNull().default("0"),
    reason: (0, pg_core_1.text)("reason").notNull(),
    actorId: (0, pg_core_1.integer)("actor_id"), // admin_users.id
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
});
