import {
    pgTable, serial, varchar, boolean, timestamp, integer, jsonb, text, uniqueIndex
} from "drizzle-orm/pg-core";
import { game } from "./game";     // existing
import { sql } from "drizzle-orm";

/** Admin roles */
export const adminRole = ["SUPER_ADMIN", "OPS", "RISK", "VIEWER"] as const;

export const adminUsers = pgTable("admin_users", {
    id: serial("id").primaryKey(),
    username: varchar("username", { length: 64 }).notNull(),
    email: varchar("email", { length: 120 }).notNull(),
    passwordHash: varchar("password_hash", { length: 255 }).notNull(),
    role: varchar("role", { length: 32 }).notNull().$type<(typeof adminRole)[number]>().default("VIEWER"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at").defaultNow()
}, (t) => ({
    uxUsername: uniqueIndex("ux_admin_username").on(t.username),
    uxEmail: uniqueIndex("ux_admin_email").on(t.email),
}));

/** API Tokens for cross-admin access (from your sportsbook/virtual admin) */
export const adminTokens = pgTable("admin_tokens", {
    id: serial("id").primaryKey(),
    label: varchar("label", { length: 128 }).notNull(),
    tokenHash: varchar("token_hash", { length: 128 }).notNull(),   // store SHA-256 hex
    scopes: jsonb("scopes").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    operatorId: integer("operator_id"), // optional: tie to operator.id
    createdBy: integer("created_by"), // admin_users.id
    isActive: boolean("is_active").notNull().default(true),
    expiresAt: timestamp("expires_at").default(sql`(now() + interval '365 days')`),
    createdAt: timestamp("created_at").defaultNow()
}, (t) => ({
    uxTokenHash: uniqueIndex("ux_admin_token_hash").on(t.tokenHash),
}));

/** Admin Audit Log (append-only) */
export const adminAudit = pgTable("admin_audit", {
    id: serial("id").primaryKey(),
    at: timestamp("at").defaultNow(),
    actorType: varchar("actor_type", { length: 16 }).notNull().default("USER"), // USER | TOKEN
    actorId: integer("actor_id"),
    actorName: varchar("actor_name", { length: 128 }),
    action: varchar("action", { length: 128 }).notNull(),     // e.g. 'GAME_UPDATE', 'RTP_ADJUST', 'TOKEN_CREATE'
    resource: varchar("resource", { length: 256 }).notNull(),   // e.g. 'game:greyhound' or 'rtp_day:greyhound:251027'
    before: jsonb("before"),
    after: jsonb("after"),
    meta: jsonb("meta"),
});

/** Optional: manual RTP adjustments to DB */
export const rtpAdjustments = pgTable("rtp_adjustments", {
    id: serial("id").primaryKey(),
    gameId: integer("game_id").references(() => game.id).notNull(),
    yymmdd: varchar("yymmdd", { length: 6 }).notNull(),
    deltaPayin: varchar("delta_payin", { length: 32 }).notNull().default("0"),  // numeric(20,2) in DB; store as string if schema numeric()
    deltaPayout: varchar("delta_payout", { length: 32 }).notNull().default("0"),
    deltaCarry: varchar("delta_carry", { length: 32 }).notNull().default("0"),
    reason: text("reason").notNull(),
    actorId: integer("actor_id"), // admin_users.id
    createdAt: timestamp("created_at").defaultNow(),
});
