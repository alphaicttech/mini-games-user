"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
// // /var/www/typesafe/alpha-mini/src/db/schema.ts
// src/db/schema/index.ts
__exportStar(require("./game"), exports);
__exportStar(require("./rtp"), exports);
__exportStar(require("./operator"), exports);
__exportStar(require("./admin"), exports);
// add other files that define tables:
// export * from "./wallet";
// export * from "./audit";
// ...
// // export const gameSessionStatus = pgEnum("GameSessionStatus", [
// //     "DRAFT", "ACTIVE", "CLOSED"
// // ]);
// // export const txnType = pgEnum("WalletTxnType", [
// //     "DEPOSIT", "WITHDRAW", "ROLLBACK"
// // ]);
// // export const txnStatus = pgEnum("WalletTxnStatus", [
// //     "ACCEPTED", "REJECTED", "REVERSED"
// // ]);
// // export const operators = pgTable("operators", {
// //     id: serial("id").primaryKey(),
// //     name: varchar("name", { length: 100 }).notNull(),
// //     portalName: varchar("portal_name", { length: 100 }).notNull(),   // used in Loader.aspx?PortalName=...
// //     baseUrl: text("base_url").notNull(),                              // operator wallet API base
// //     secret: text("secret").notNull(),                                 // signing secret (md5)
// //     currencies: jsonb("currencies").$type<string[]>().default([]),
// //     ipAllowlist: jsonb("ip_allowlist").$type<string[]>().default([]),
// //     createdAt: timestamp("created_at", { withTimezone: false }).defaultNow(),
// // }, (t) => ({
// //     uxPortal: uniqueIndex("ux_operators_portal").on(t.portalName),
// //     ixName: index("ix_operators_name").on(t.name),
// // }));
// import {
//     pgTable, serial, integer, varchar, numeric, boolean, timestamp, date,
//     index, uniqueIndex, pgEnum
// } from "drizzle-orm/pg-core";
// export const walletTxnType = pgEnum("wallet_txn_type", ["DEPOSIT", "WITHDRAW", "ROLLBACK"]);
// export const game = pgTable("game", {
//     id: serial("id").primaryKey(),
//     code: varchar("code", { length: 32 }).notNull().unique(), // 'keno','bingo','plinko','jetx',...
//     name: varchar("name", { length: 64 }).notNull(),
//     is_active: boolean("is_active").notNull().default(true),
// });
// export const gameConfig = pgTable("game_config", {
//     id: serial("id").primaryKey(),
//     game_id: integer("game_id").notNull().references(() => game.id),
//     rtp_target: numeric("rtp_target", { precision: 5, scale: 4 }).notNull().default('0.90'), // 0.9000
//     alpha: numeric("alpha", { precision: 5, scale: 4 }).notNull().default('0.85'),
//     kappa: numeric("kappa", { precision: 5, scale: 4 }).notNull().default('1.50'),
//     beta: numeric("beta", { precision: 5, scale: 4 }).notNull().default('0.60'),
//     per_bet_cap: numeric("per_bet_cap", { precision: 18, scale: 2 }).notNull().default('5000'),
//     per_ticket_cap: numeric("per_ticket_cap", { precision: 18, scale: 2 }).notNull().default('10000'),
//     per_user_daily_cap: numeric("per_user_daily_cap", { precision: 18, scale: 2 }).notNull().default('20000'),
//     // jetx-only:
//     alpha_round: numeric("alpha_round", { precision: 5, scale: 4 }).notNull().default('0.25'),
//     gamma_round: numeric("gamma_round", { precision: 5, scale: 4 }).notNull().default('0.90'),
//     cashout_intensity: numeric("cashout_intensity", { precision: 5, scale: 4 }).notNull().default('0.40'),
//     global_odd_cap: numeric("global_odd_cap", { precision: 10, scale: 2 }).notNull().default('50'),
// }, t => ({ byGame: uniqueIndex("cfg_by_game").on(t.game_id) }));
// export const rtpMonth = pgTable("rtp_month", {
//     id: serial("id").primaryKey(),
//     game_id: integer("game_id").notNull().references(() => game.id),
//     month_yy: varchar("month_yy", { length: 6 }).notNull(), // e.g. '2510'
//     rtp_target: numeric("rtp_target", { precision: 5, scale: 4 }).notNull(),
//     payin: numeric("payin", { precision: 20, scale: 2 }).notNull().default('0'),
//     payout: numeric("payout", { precision: 20, scale: 2 }).notNull().default('0'),
//     carry_in: numeric("carry_in", { precision: 20, scale: 2 }).notNull().default('0'),
//     carry_out: numeric("carry_out", { precision: 20, scale: 2 }).notNull().default('0'),
//     created_at: timestamp("created_at").defaultNow(),
// }, t => ({
//     uniq: uniqueIndex("rtp_month_uniq").on(t.game_id, t.month_yy),
//     byGame: index("rtp_month_game_idx").on(t.game_id),
// }));
// export const rtpDay = pgTable("rtp_day", {
//     id: serial("id").primaryKey(),
//     game_id: integer("game_id").notNull().references(() => game.id),
//     date_yymmdd: varchar("date_yymmdd", { length: 6 }).notNull(), // '251027'
//     rtp_target: numeric("rtp_target", { precision: 5, scale: 4 }).notNull(),
//     payin: numeric("payin", { precision: 20, scale: 2 }).notNull().default('0'),
//     payout: numeric("payout", { precision: 20, scale: 2 }).notNull().default('0'),
//     carry_in: numeric("carry_in", { precision: 20, scale: 2 }).notNull().default('0'),
//     carry_out: numeric("carry_out", { precision: 20, scale: 2 }).notNull().default('0'),
//     rounds: integer("rounds").notNull().default(0), // for jetx
//     created_at: timestamp("created_at").defaultNow(),
// }, t => ({
//     uniq: uniqueIndex("rtp_day_uniq").on(t.game_id, t.date_yymmdd),
//     byGame: index("rtp_day_game_idx").on(t.game_id),
// }));
// export const walletTxn = pgTable("wallet_txn", {
//     id: serial("id").primaryKey(),
//     external_id: varchar("external_id", { length: 64 }), // id from operator if any
//     type: walletTxnType("type").notNull(),
//     amount: numeric("amount", { precision: 20, scale: 2 }).notNull(),
//     currency: varchar("currency", { length: 8 }).notNull().default('ETB'),
//     meta: varchar("meta", { length: 2048 }),
//     created_at: timestamp("created_at").defaultNow(),
// }, t => ({
//     byType: index("wallet_type_idx").on(t.type),
// }));
