"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.walletTxn = exports.rtpDay = exports.rtpMonth = exports.walletTxnType = void 0;
const pg_core_1 = require("drizzle-orm/pg-core");
const game_1 = require("./game");
exports.walletTxnType = (0, pg_core_1.pgEnum)("wallet_txn_type", ["DEPOSIT", "WITHDRAW", "ROLLBACK"]);
exports.rtpMonth = (0, pg_core_1.pgTable)("rtp_month", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    game_id: (0, pg_core_1.integer)("game_id").notNull().references(() => game_1.game.id),
    month_yy: (0, pg_core_1.varchar)("month_yy", { length: 6 }).notNull(), // '2510'
    rtp_target: (0, pg_core_1.numeric)("rtp_target", { precision: 5, scale: 4 }).notNull(),
    payin: (0, pg_core_1.numeric)("payin", { precision: 20, scale: 2 }).notNull().default('0'),
    payout: (0, pg_core_1.numeric)("payout", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_in: (0, pg_core_1.numeric)("carry_in", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_out: (0, pg_core_1.numeric)("carry_out", { precision: 20, scale: 2 }).notNull().default('0'),
    created_at: (0, pg_core_1.timestamp)("created_at").defaultNow(),
}, t => ({
    uniq: (0, pg_core_1.uniqueIndex)("rtp_month_uniq").on(t.game_id, t.month_yy),
    byGame: (0, pg_core_1.index)("rtp_month_game_idx").on(t.game_id),
}));
exports.rtpDay = (0, pg_core_1.pgTable)("rtp_day", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    game_id: (0, pg_core_1.integer)("game_id").notNull().references(() => game_1.game.id),
    date_yymmdd: (0, pg_core_1.varchar)("date_yymmdd", { length: 6 }).notNull(), // '251027'
    rtp_target: (0, pg_core_1.numeric)("rtp_target", { precision: 5, scale: 4 }).notNull(),
    payin: (0, pg_core_1.numeric)("payin", { precision: 20, scale: 2 }).notNull().default('0'),
    payout: (0, pg_core_1.numeric)("payout", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_in: (0, pg_core_1.numeric)("carry_in", { precision: 20, scale: 2 }).notNull().default('0'),
    carry_out: (0, pg_core_1.numeric)("carry_out", { precision: 20, scale: 2 }).notNull().default('0'),
    rounds: (0, pg_core_1.integer)("rounds").notNull().default(0),
    last_snapshot_at: (0, pg_core_1.timestamp)("last_snapshot_at"),
    created_at: (0, pg_core_1.timestamp)("created_at").defaultNow(),
}, t => ({
    uniq: (0, pg_core_1.uniqueIndex)("rtp_day_uniq").on(t.game_id, t.date_yymmdd),
    byGame: (0, pg_core_1.index)("rtp_day_game_idx").on(t.game_id),
}));
// Ledger (operator deposits/withdraws/rollbacks)
// replace walletTxn table with:
exports.walletTxn = (0, pg_core_1.pgTable)("wallet_txn", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    external_id: (0, pg_core_1.varchar)("external_id", { length: 64 }), // make unique if webhook sends it
    type: (0, exports.walletTxnType)("type").notNull(),
    amount: (0, pg_core_1.numeric)("amount", { precision: 20, scale: 2 }).notNull(),
    currency: (0, pg_core_1.varchar)("currency", { length: 8 }).notNull().default("ETB"),
    meta: (0, pg_core_1.varchar)("meta", { length: 2048 }),
    created_at: (0, pg_core_1.timestamp)("created_at").defaultNow(),
}, t => ({
    byExternal: (0, pg_core_1.uniqueIndex)("wallet_txn_ext_uniq").on(t.external_id),
    byType: (0, pg_core_1.index)("wallet_txn_type_idx").on(t.type),
    byCreated: (0, pg_core_1.index)("wallet_txn_created_idx").on(t.created_at),
}));
