// /var/www/typesafe/alpha-mini/src/errors.ts
export type ErrorPayload = {
    code: string;
    message: string;
    status?: number;
    details?: Record<string, any>;
};

export class AppError extends Error {
    code: string;
    status: number;
    details?: Record<string, any>;
    constructor({ code, message, status = 400, details }: ErrorPayload) {
        super(message);
        this.code = code;
        this.status = status;
        this.details = details;
    }
    static badRequest(msg: string, details?: any) {
        return new AppError({ code: "BAD_REQUEST", message: msg, status: 400, details });
    }
    static unauthorized(msg: string, details?: any) {
        return new AppError({ code: "UNAUTHORIZED", message: msg, status: 401, details });
    }
    static notFound(msg: string, details?: any) {
        return new AppError({ code: "NOT_FOUND", message: msg, status: 404, details });
    }
    static conflict(msg: string, details?: any) {
        return new AppError({ code: "CONFLICT", message: msg, status: 409, details });
    }
    static rateLimited(msg: string, details?: any) {
        return new AppError({ code: "RATE_LIMITED", message: msg, status: 429, details });
    }
    static upstream(msg: string, details?: any) {
        return new AppError({ code: "UPSTREAM_ERROR", message: msg, status: 502, details });
    }
    static internal(msg = "Internal server error", details?: any) {
        return new AppError({ code: "INTERNAL_ERROR", message: msg, status: 500, details });
    }
}

export class OperatorError extends AppError {
    httpStatus?: number;
    constructor(code: string, message: string, httpStatus?: number, details?: any) {
        super({ code, message, status: httpStatus ?? 502, details });
        this.httpStatus = httpStatus;
    }
}
