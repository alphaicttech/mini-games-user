CREATE TABLE "admin_audit" (
	"id" serial PRIMARY KEY NOT NULL,
	"at" timestamp DEFAULT now(),
	"actor_type" varchar(16) DEFAULT 'USER' NOT NULL,
	"actor_id" integer,
	"actor_name" varchar(128),
	"action" varchar(128) NOT NULL,
	"resource" varchar(256) NOT NULL,
	"before" jsonb,
	"after" jsonb,
	"meta" jsonb
);
--> statement-breakpoint
CREATE TABLE "admin_tokens" (
	"id" serial PRIMARY KEY NOT NULL,
	"label" varchar(128) NOT NULL,
	"token_hash" varchar(128) NOT NULL,
	"scopes" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"operator_id" integer,
	"created_by" integer,
	"is_active" boolean DEFAULT true NOT NULL,
	"expires_at" timestamp DEFAULT (now() + interval '365 days'),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "admin_users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" varchar(64) NOT NULL,
	"email" varchar(120) NOT NULL,
	"password_hash" varchar(255) NOT NULL,
	"role" varchar(32) DEFAULT 'VIEWER' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "rtp_adjustments" (
	"id" serial PRIMARY KEY NOT NULL,
	"game_id" integer NOT NULL,
	"yymmdd" varchar(6) NOT NULL,
	"delta_payin" varchar(32) DEFAULT '0' NOT NULL,
	"delta_payout" varchar(32) DEFAULT '0' NOT NULL,
	"delta_carry" varchar(32) DEFAULT '0' NOT NULL,
	"reason" text NOT NULL,
	"actor_id" integer,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "rtp_adjustments" ADD CONSTRAINT "rtp_adjustments_game_id_game_id_fk" FOREIGN KEY ("game_id") REFERENCES "public"."game"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "ux_admin_token_hash" ON "admin_tokens" USING btree ("token_hash");--> statement-breakpoint
CREATE UNIQUE INDEX "ux_admin_username" ON "admin_users" USING btree ("username");--> statement-breakpoint
CREATE UNIQUE INDEX "ux_admin_email" ON "admin_users" USING btree ("email");