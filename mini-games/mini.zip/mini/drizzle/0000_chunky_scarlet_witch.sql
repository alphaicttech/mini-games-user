CREATE TYPE "public"."wallet_txn_type" AS ENUM('DEPOSIT', 'WITHDRAW', 'ROLLBACK');--> statement-breakpoint
CREATE TABLE "game" (
	"id" serial PRIMARY KEY NOT NULL,
	"code" varchar(32) NOT NULL,
	"name" varchar(64) NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	CONSTRAINT "game_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "game_config" (
	"id" serial PRIMARY KEY NOT NULL,
	"game_id" integer NOT NULL,
	"rtp_target" numeric(5, 4) DEFAULT '0.90' NOT NULL,
	"alpha" numeric(5, 4) DEFAULT '0.85' NOT NULL,
	"kappa" numeric(5, 4) DEFAULT '1.50' NOT NULL,
	"beta" numeric(5, 4) DEFAULT '0.60' NOT NULL,
	"per_bet_cap" numeric(18, 2) DEFAULT '5000' NOT NULL,
	"per_ticket_cap" numeric(18, 2) DEFAULT '10000' NOT NULL,
	"per_user_daily_cap" numeric(18, 2) DEFAULT '20000' NOT NULL,
	"alpha_round" numeric(5, 4) DEFAULT '0.25' NOT NULL,
	"gamma_round" numeric(5, 4) DEFAULT '0.90' NOT NULL,
	"cashout_intensity" numeric(5, 4) DEFAULT '0.40' NOT NULL,
	"global_odd_cap" numeric(10, 2) DEFAULT '50' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rtp_month" (
	"id" serial PRIMARY KEY NOT NULL,
	"game_id" integer NOT NULL,
	"month_yy" varchar(6) NOT NULL,
	"rtp_target" numeric(5, 4) NOT NULL,
	"payin" numeric(20, 2) DEFAULT '0' NOT NULL,
	"payout" numeric(20, 2) DEFAULT '0' NOT NULL,
	"carry_in" numeric(20, 2) DEFAULT '0' NOT NULL,
	"carry_out" numeric(20, 2) DEFAULT '0' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "rtp_day" (
	"id" serial PRIMARY KEY NOT NULL,
	"game_id" integer NOT NULL,
	"date_yymmdd" varchar(6) NOT NULL,
	"rtp_target" numeric(5, 4) NOT NULL,
	"payin" numeric(20, 2) DEFAULT '0' NOT NULL,
	"payout" numeric(20, 2) DEFAULT '0' NOT NULL,
	"carry_in" numeric(20, 2) DEFAULT '0' NOT NULL,
	"carry_out" numeric(20, 2) DEFAULT '0' NOT NULL,
	"rounds" integer DEFAULT 0 NOT NULL,
	"last_snapshot_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "wallet_txn" (
	"id" serial PRIMARY KEY NOT NULL,
	"external_id" varchar(64),
	"type" "wallet_txn_type" NOT NULL,
	"amount" numeric(20, 2) NOT NULL,
	"currency" varchar(8) DEFAULT 'ETB' NOT NULL,
	"meta" varchar(2048),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "operators" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(100) NOT NULL,
	"portal_name" varchar(100) NOT NULL,
	"base_url" text NOT NULL,
	"secret" text NOT NULL,
	"currencies" jsonb DEFAULT '[]'::jsonb,
	"ip_allowlist" jsonb DEFAULT '[]'::jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "game_config" ADD CONSTRAINT "game_config_game_id_game_id_fk" FOREIGN KEY ("game_id") REFERENCES "public"."game"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "rtp_month" ADD CONSTRAINT "rtp_month_game_id_game_id_fk" FOREIGN KEY ("game_id") REFERENCES "public"."game"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "rtp_day" ADD CONSTRAINT "rtp_day_game_id_game_id_fk" FOREIGN KEY ("game_id") REFERENCES "public"."game"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "cfg_by_game" ON "game_config" USING btree ("game_id");--> statement-breakpoint
CREATE UNIQUE INDEX "rtp_month_uniq" ON "rtp_month" USING btree ("game_id","month_yy");--> statement-breakpoint
CREATE INDEX "rtp_month_game_idx" ON "rtp_month" USING btree ("game_id");--> statement-breakpoint
CREATE UNIQUE INDEX "rtp_day_uniq" ON "rtp_day" USING btree ("game_id","date_yymmdd");--> statement-breakpoint
CREATE INDEX "rtp_day_game_idx" ON "rtp_day" USING btree ("game_id");--> statement-breakpoint
CREATE UNIQUE INDEX "wallet_txn_ext_uniq" ON "wallet_txn" USING btree ("external_id");--> statement-breakpoint
CREATE INDEX "wallet_txn_type_idx" ON "wallet_txn" USING btree ("type");--> statement-breakpoint
CREATE INDEX "wallet_txn_created_idx" ON "wallet_txn" USING btree ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "ux_operators_portal" ON "operators" USING btree ("portal_name");--> statement-breakpoint
CREATE INDEX "ix_operators_name" ON "operators" USING btree ("name");