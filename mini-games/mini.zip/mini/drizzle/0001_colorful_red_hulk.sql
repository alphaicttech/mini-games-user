ALTER TABLE "game" DROP CONSTRAINT "game_code_unique";--> statement-breakpoint
ALTER TABLE "game_config" DROP CONSTRAINT "game_config_game_id_game_id_fk";
--> statement-breakpoint
ALTER TABLE "game_config" ALTER COLUMN "per_bet_cap" SET DATA TYPE numeric(20, 2);--> statement-breakpoint
ALTER TABLE "game_config" ALTER COLUMN "per_bet_cap" SET DEFAULT '5000';--> statement-breakpoint
ALTER TABLE "game_config" ALTER COLUMN "per_ticket_cap" SET DATA TYPE numeric(20, 2);--> statement-breakpoint
ALTER TABLE "game_config" ALTER COLUMN "per_ticket_cap" SET DEFAULT '10000';--> statement-breakpoint
ALTER TABLE "game_config" ALTER COLUMN "per_user_daily_cap" SET DATA TYPE numeric(20, 2);--> statement-breakpoint
ALTER TABLE "game_config" ALTER COLUMN "per_user_daily_cap" SET DEFAULT '20000';--> statement-breakpoint
CREATE UNIQUE INDEX "game_code_unique" ON "game" USING btree ("code");