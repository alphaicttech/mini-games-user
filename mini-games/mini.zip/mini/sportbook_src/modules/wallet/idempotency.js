"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getIdempotent = getIdempotent;
exports.setIdempotent = setIdempotent;
const redis_1 = require("../../config/redis");
const env_1 = require("../../config/env");
function getIdempotent(provider, txnId, type) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = `idem:${provider}:${txnId}:${type}`;
        const val = yield redis_1.redis.get(key);
        return val ? JSON.parse(val) : null;
    });
}
function setIdempotent(provider, txnId, type, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        const key = `idem:${provider}:${txnId}:${type}`;
        yield redis_1.redis.setex(key, env_1.env.IDEMPOTENCY_TTL, JSON.stringify(payload));
    });
}
