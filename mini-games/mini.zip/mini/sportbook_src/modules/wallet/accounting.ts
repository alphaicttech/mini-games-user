// Wire these into your real wallet.
// For now, placeholders that you replace with your ledger service / Prisma / Drizzle calls.

export type DebitArgs = { userId: number; amount: string; currency: string; reason: string; meta?: any };
export type CreditArgs = { userId: number; amount: string; currency: string; reason: string; meta?: any };

export async function debit({ userId, amount }: DebitArgs): Promise<{ balanceAfter: string }> {
    // TODO: call your accounting. Must be atomic and fail on insufficient funds/limits.
    return { balanceAfter: "0.00" };
}

export async function credit({ userId, amount }: CreditArgs): Promise<{ balanceAfter: string }> {
    // TODO: call your accounting. Must be atomic.
    return { balanceAfter: amount };
}
