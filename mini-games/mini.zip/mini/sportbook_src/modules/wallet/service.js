"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.doDeposit = doDeposit;
exports.doWithdraw = doWithdraw;
exports.doRollback = doRollback;
const drizzle_1 = require("../../config/drizzle");
const schema_1 = require("../../db/schema");
const ids_1 = require("../../utils/ids");
const accounting_1 = require("./accounting");
const idempotency_1 = require("./idempotency");
function doDeposit(ctx, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        // expected fields from provider (normalize per adapter if needed)
        const providerTxnId = String((_b = (_a = payload.TransactionId) !== null && _a !== void 0 ? _a : payload.TransactionID) !== null && _b !== void 0 ? _b : payload.txnId);
        const amount = String(payload.Amount);
        const currency = String((_c = payload.CurrencyCode) !== null && _c !== void 0 ? _c : ctx.session.currency);
        const roundId = (_d = payload.RoundId) !== null && _d !== void 0 ? _d : payload.RoundID;
        const game = (_e = payload.Game) !== null && _e !== void 0 ? _e : payload.GameName;
        const gameNumber = payload.GameNumber ? Number(payload.GameNumber) : null;
        const operatorTxnId = (0, ids_1.newId)();
        const { balanceAfter } = yield (0, accounting_1.debit)({
            userId: ctx.session.userId,
            amount,
            currency,
            reason: "PlaceBet",
            meta: payload,
        });
        yield drizzle_1.db.insert(schema_1.walletTxns).values({
            provider: ctx.provider,
            providerTxnId,
            operatorTxnId,
            type: "DEPOSIT",
            amount,
            currencyCode: currency,
            userId: ctx.session.userId,
            sessionId: ctx.session.sessionId,
            roundId,
            game,
            gameNumber: gameNumber !== null && gameNumber !== void 0 ? gameNumber : undefined,
            balanceAfter,
            status: "ACCEPTED",
            meta: payload,
        });
        yield (0, idempotency_1.setIdempotent)(ctx.provider, providerTxnId, "DEPOSIT", { operatorTxnId, balance: balanceAfter });
        return { operatorTxnId, balance: balanceAfter };
    });
}
function doWithdraw(ctx, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        const providerTxnId = String((_b = (_a = payload.TransactionId) !== null && _a !== void 0 ? _a : payload.TransactionID) !== null && _b !== void 0 ? _b : payload.txnId);
        const amount = String(payload.Amount);
        const currency = String((_c = payload.CurrencyCode) !== null && _c !== void 0 ? _c : ctx.session.currency);
        const roundId = (_d = payload.RoundId) !== null && _d !== void 0 ? _d : payload.RoundID;
        const game = (_e = payload.Game) !== null && _e !== void 0 ? _e : payload.GameName;
        const gameNumber = payload.GameNumber ? Number(payload.GameNumber) : null;
        const operatorTxnId = (0, ids_1.newId)();
        const { balanceAfter } = yield (0, accounting_1.credit)({
            userId: ctx.session.userId,
            amount,
            currency,
            reason: "Win",
            meta: payload,
        });
        yield drizzle_1.db.insert(schema_1.walletTxns).values({
            provider: ctx.provider,
            providerTxnId,
            operatorTxnId,
            type: "WITHDRAW",
            amount,
            currencyCode: currency,
            userId: ctx.session.userId,
            sessionId: ctx.session.sessionId,
            roundId,
            game,
            gameNumber: gameNumber !== null && gameNumber !== void 0 ? gameNumber : undefined,
            balanceAfter,
            status: "ACCEPTED",
            meta: payload,
        });
        yield (0, idempotency_1.setIdempotent)(ctx.provider, providerTxnId, "WITHDRAW", { operatorTxnId, balance: balanceAfter });
        return { operatorTxnId, balance: balanceAfter };
    });
}
function doRollback(ctx, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const providerTxnId = String((_b = (_a = payload.TransactionId) !== null && _a !== void 0 ? _a : payload.TransactionID) !== null && _b !== void 0 ? _b : payload.txnId);
        const type = String((_c = payload.TransactionType) !== null && _c !== void 0 ? _c : payload.Type); // “DEPOSIT” or “WITHDRAW” on provider side
        const operatorTxnId = (0, ids_1.newId)();
        // You’ll reverse in your accounting layer (not shown here)
        const balanceAfter = "0.00"; // return from your ledger
        yield drizzle_1.db.insert(schema_1.walletTxns).values({
            provider: ctx.provider,
            providerTxnId,
            operatorTxnId,
            type: "ROLLBACK",
            amount: "0.00",
            currencyCode: ctx.session.currency,
            userId: ctx.session.userId,
            sessionId: ctx.session.sessionId,
            balanceAfter,
            status: "REVERSED",
            meta: payload,
        });
        yield (0, idempotency_1.setIdempotent)(ctx.provider, providerTxnId, "ROLLBACK", { operatorTxnId, balance: balanceAfter });
        return { operatorTxnId, balance: balanceAfter };
    });
}
