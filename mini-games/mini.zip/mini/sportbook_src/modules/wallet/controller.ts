import type { Request, Response } from "express";
import { redis } from "../../config/redis";
import { env } from "../../config/env";
import { db } from "../../config/drizzle";
import { eq } from "drizzle-orm";
import { gameSessions } from "../../db/schema";
import { getIdempotent } from "./idempotency";
import { doDeposit, doWithdraw, doRollback } from "./service";
import { newId } from "../../utils/ids";

// 1) ActivateSession (provider -> us)
export async function activateSession(req: Request, res: Response) {
    const provider = req.params.provider; // "smartsoft"
    // (X-Signature already checked by route-level middleware)
    const { Token } = req.body ?? {};
    if (!Token) return res.status(400).json({ success: false, message: "Token required" });

    const launchKey = `launch:token:${Token}`;
    const seedStr = await redis.get(launchKey);
    if (!seedStr) return res.status(401).json({ success: false, message: "Invalid or expired token" });

    await redis.del(launchKey);
    const seed = JSON.parse(seedStr) as {
        provider: string; userId: number; username: string; clientExternalKey: string; currency: string;
    };

    const sessionId = newId();
    const session = {
        sessionId,
        userId: seed.userId,
        username: seed.username,
        clientExternalKey: seed.clientExternalKey,
        currency: seed.currency,
    };

    const sessKey = `session:${provider}:${sessionId}`;
    await redis.setex(sessKey, env.SESSION_TTL, JSON.stringify(session));

    // update the DB draft row
    await db.update(gameSessions)
        .set({ sessionId, status: "ACTIVE" })
        .where(eq(gameSessions.token, Token));

    // response shape expected by provider
    return res.json({
        SessionId: sessionId,
        UserName: seed.username,
        ClientExternalKey: seed.clientExternalKey,
        CurrencyCode: seed.currency,
    });
}

// 2) GetBalance
export async function getBalance(req: Request, res: Response) {
    const { session } = req as any;
    // TODO: wire to your real balance service
    const mockBalance = "0.00";
    res.json({ CurrencyCode: session.currency, Amount: mockBalance });
}

// 3) Deposit (bet)
export async function deposit(req: Request, res: Response) {
    const provider = req.params.provider;
    const { session } = req as any;
    const payload = req.body;

    const providerTxnId = String(payload.TransactionId ?? payload.TransactionID ?? payload.txnId);
    if (!providerTxnId) return res.status(400).json({ success: false, message: "TransactionId missing" });

    // idempotency
    const idem = await getIdempotent(provider, providerTxnId, "DEPOSIT");
    if (idem) return res.json(idem);

    const result = await doDeposit({ provider, session }, payload);
    res.json(result);
}

// 4) Withdraw (win)
export async function withdraw(req: Request, res: Response) {
    const provider = req.params.provider;
    const { session } = req as any;
    const payload = req.body;

    const providerTxnId = String(payload.TransactionId ?? payload.TransactionID ?? payload.txnId);
    if (!providerTxnId) return res.status(400).json({ success: false, message: "TransactionId missing" });

    const idem = await getIdempotent(provider, providerTxnId, "WITHDRAW");
    if (idem) return res.json(idem);

    const result = await doWithdraw({ provider, session }, payload);
    res.json(result);
}

// 5) Rollback
export async function rollback(req: Request, res: Response) {
    const provider = req.params.provider;
    const { session } = req as any;
    const payload = req.body;

    const providerTxnId = String(payload.TransactionId ?? payload.TransactionID ?? payload.txnId);
    if (!providerTxnId) return res.status(400).json({ success: false, message: "TransactionId missing" });

    const idem = await getIdempotent(provider, providerTxnId, "ROLLBACK");
    if (idem) return res.json(idem);

    const result = await doRollback({ provider, session }, payload);
    res.json(result);
}
