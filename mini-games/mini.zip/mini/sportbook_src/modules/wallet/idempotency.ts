import { redis } from "../../config/redis";
import { env } from "../../config/env";

export async function getIdempotent(provider: string, txnId: string, type: string) {
    const key = `idem:${provider}:${txnId}:${type}`;
    const val = await redis.get(key);
    return val ? JSON.parse(val) : null;
}

export async function setIdempotent(provider: string, txnId: string, type: string, payload: any) {
    const key = `idem:${provider}:${txnId}:${type}`;
    await redis.setex(key, env.IDEMPOTENCY_TTL, JSON.stringify(payload));
}
