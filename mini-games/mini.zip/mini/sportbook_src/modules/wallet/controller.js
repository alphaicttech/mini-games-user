"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.activateSession = activateSession;
exports.getBalance = getBalance;
exports.deposit = deposit;
exports.withdraw = withdraw;
exports.rollback = rollback;
const redis_1 = require("../../config/redis");
const env_1 = require("../../config/env");
const drizzle_1 = require("../../config/drizzle");
const drizzle_orm_1 = require("drizzle-orm");
const schema_1 = require("../../db/schema");
const idempotency_1 = require("./idempotency");
const service_1 = require("./service");
const ids_1 = require("../../utils/ids");
// 1) ActivateSession (provider -> us)
function activateSession(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const provider = req.params.provider; // "smartsoft"
        // (X-Signature already checked by route-level middleware)
        const { Token } = (_a = req.body) !== null && _a !== void 0 ? _a : {};
        if (!Token)
            return res.status(400).json({ success: false, message: "Token required" });
        const launchKey = `launch:token:${Token}`;
        const seedStr = yield redis_1.redis.get(launchKey);
        if (!seedStr)
            return res.status(401).json({ success: false, message: "Invalid or expired token" });
        yield redis_1.redis.del(launchKey);
        const seed = JSON.parse(seedStr);
        const sessionId = (0, ids_1.newId)();
        const session = {
            sessionId,
            userId: seed.userId,
            username: seed.username,
            clientExternalKey: seed.clientExternalKey,
            currency: seed.currency,
        };
        const sessKey = `session:${provider}:${sessionId}`;
        yield redis_1.redis.setex(sessKey, env_1.env.SESSION_TTL, JSON.stringify(session));
        // update the DB draft row
        yield drizzle_1.db.update(schema_1.gameSessions)
            .set({ sessionId, status: "ACTIVE" })
            .where((0, drizzle_orm_1.eq)(schema_1.gameSessions.token, Token));
        // response shape expected by provider
        return res.json({
            SessionId: sessionId,
            UserName: seed.username,
            ClientExternalKey: seed.clientExternalKey,
            CurrencyCode: seed.currency,
        });
    });
}
// 2) GetBalance
function getBalance(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { session } = req;
        // TODO: wire to your real balance service
        const mockBalance = "0.00";
        res.json({ CurrencyCode: session.currency, Amount: mockBalance });
    });
}
// 3) Deposit (bet)
function deposit(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const provider = req.params.provider;
        const { session } = req;
        const payload = req.body;
        const providerTxnId = String((_b = (_a = payload.TransactionId) !== null && _a !== void 0 ? _a : payload.TransactionID) !== null && _b !== void 0 ? _b : payload.txnId);
        if (!providerTxnId)
            return res.status(400).json({ success: false, message: "TransactionId missing" });
        // idempotency
        const idem = yield (0, idempotency_1.getIdempotent)(provider, providerTxnId, "DEPOSIT");
        if (idem)
            return res.json(idem);
        const result = yield (0, service_1.doDeposit)({ provider, session }, payload);
        res.json(result);
    });
}
// 4) Withdraw (win)
function withdraw(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const provider = req.params.provider;
        const { session } = req;
        const payload = req.body;
        const providerTxnId = String((_b = (_a = payload.TransactionId) !== null && _a !== void 0 ? _a : payload.TransactionID) !== null && _b !== void 0 ? _b : payload.txnId);
        if (!providerTxnId)
            return res.status(400).json({ success: false, message: "TransactionId missing" });
        const idem = yield (0, idempotency_1.getIdempotent)(provider, providerTxnId, "WITHDRAW");
        if (idem)
            return res.json(idem);
        const result = yield (0, service_1.doWithdraw)({ provider, session }, payload);
        res.json(result);
    });
}
// 5) Rollback
function rollback(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const provider = req.params.provider;
        const { session } = req;
        const payload = req.body;
        const providerTxnId = String((_b = (_a = payload.TransactionId) !== null && _a !== void 0 ? _a : payload.TransactionID) !== null && _b !== void 0 ? _b : payload.txnId);
        if (!providerTxnId)
            return res.status(400).json({ success: false, message: "TransactionId missing" });
        const idem = yield (0, idempotency_1.getIdempotent)(provider, providerTxnId, "ROLLBACK");
        if (idem)
            return res.json(idem);
        const result = yield (0, service_1.doRollback)({ provider, session }, payload);
        res.json(result);
    });
}
