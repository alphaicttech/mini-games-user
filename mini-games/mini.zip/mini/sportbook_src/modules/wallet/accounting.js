"use strict";
// Wire these into your real wallet.
// For now, placeholders that you replace with your ledger service / Prisma / Drizzle calls.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.debit = debit;
exports.credit = credit;
function debit(_a) {
    return __awaiter(this, arguments, void 0, function* ({ userId, amount }) {
        // TODO: call your accounting. Must be atomic and fail on insufficient funds/limits.
        return { balanceAfter: "0.00" };
    });
}
function credit(_a) {
    return __awaiter(this, arguments, void 0, function* ({ userId, amount }) {
        // TODO: call your accounting. Must be atomic.
        return { balanceAfter: amount };
    });
}
