import { db } from "../../config/drizzle";
import { walletTxns } from "../../db/schema";
import { newId } from "../../utils/ids";
import { credit, debit } from "./accounting";
import { setIdempotent } from "./idempotency";

type CommonCtx = {
    provider: string;
    session: { userId: number; currency: string; username: string; clientExternalKey: string; sessionId: string };
};

export async function doDeposit(ctx: CommonCtx, payload: any) {
    // expected fields from provider (normalize per adapter if needed)
    const providerTxnId = String(payload.TransactionId ?? payload.TransactionID ?? payload.txnId);
    const amount = String(payload.Amount);
    const currency = String(payload.CurrencyCode ?? ctx.session.currency);
    const roundId = payload.RoundId ?? payload.RoundID;
    const game = payload.Game ?? payload.GameName;
    const gameNumber = payload.GameNumber ? Number(payload.GameNumber) : null;

    const operatorTxnId = newId();

    const { balanceAfter } = await debit({
        userId: ctx.session.userId,
        amount,
        currency,
        reason: "PlaceBet",
        meta: payload,
    });

    await db.insert(walletTxns).values({
        provider: ctx.provider,
        providerTxnId,
        operatorTxnId,
        type: "DEPOSIT",
        amount,
        currencyCode: currency,
        userId: ctx.session.userId,
        sessionId: ctx.session.sessionId,
        roundId,
        game,
        gameNumber: gameNumber ?? undefined,
        balanceAfter,
        status: "ACCEPTED",
        meta: payload,
    });

    await setIdempotent(ctx.provider, providerTxnId, "DEPOSIT", { operatorTxnId, balance: balanceAfter });
    return { operatorTxnId, balance: balanceAfter };
}

export async function doWithdraw(ctx: CommonCtx, payload: any) {
    const providerTxnId = String(payload.TransactionId ?? payload.TransactionID ?? payload.txnId);
    const amount = String(payload.Amount);
    const currency = String(payload.CurrencyCode ?? ctx.session.currency);
    const roundId = payload.RoundId ?? payload.RoundID;
    const game = payload.Game ?? payload.GameName;
    const gameNumber = payload.GameNumber ? Number(payload.GameNumber) : null;

    const operatorTxnId = newId();

    const { balanceAfter } = await credit({
        userId: ctx.session.userId,
        amount,
        currency,
        reason: "Win",
        meta: payload,
    });

    await db.insert(walletTxns).values({
        provider: ctx.provider,
        providerTxnId,
        operatorTxnId,
        type: "WITHDRAW",
        amount,
        currencyCode: currency,
        userId: ctx.session.userId,
        sessionId: ctx.session.sessionId,
        roundId,
        game,
        gameNumber: gameNumber ?? undefined,
        balanceAfter,
        status: "ACCEPTED",
        meta: payload,
    });

    await setIdempotent(ctx.provider, providerTxnId, "WITHDRAW", { operatorTxnId, balance: balanceAfter });
    return { operatorTxnId, balance: balanceAfter };
}

export async function doRollback(ctx: CommonCtx, payload: any) {
    const providerTxnId = String(payload.TransactionId ?? payload.TransactionID ?? payload.txnId);
    const type = String(payload.TransactionType ?? payload.Type); // “DEPOSIT” or “WITHDRAW” on provider side
    const operatorTxnId = newId();

    // You’ll reverse in your accounting layer (not shown here)
    const balanceAfter = "0.00"; // return from your ledger

    await db.insert(walletTxns).values({
        provider: ctx.provider,
        providerTxnId,
        operatorTxnId,
        type: "ROLLBACK",
        amount: "0.00",
        currencyCode: ctx.session.currency,
        userId: ctx.session.userId,
        sessionId: ctx.session.sessionId,
        balanceAfter,
        status: "REVERSED",
        meta: payload,
    });

    await setIdempotent(ctx.provider, providerTxnId, "ROLLBACK", { operatorTxnId, balance: balanceAfter });
    return { operatorTxnId, balance: balanceAfter };
}
