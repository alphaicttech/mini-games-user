import type { Request, Response } from "express";
import { z } from "zod";
import { env } from "../../config/env";
import { redis } from "../../config/redis";
import { db } from "../../config/drizzle";
import { gameSessions } from "../../db/schema";
import { getAdapter } from "../../providers";
import { newId } from "../../utils/ids";
import { eq } from "drizzle-orm";

const LaunchBody = z.object({
    provider: z.literal("smartsoft"), // extend as you add more
    user_id: z.coerce.number(),
    username: z.string().min(1),
    client_external_key: z.string().min(1),
    currency: z.string().length(3),
    gameCategory: z.string().min(1),
    gameName: z.string().min(1),
    lang: z.string().min(2),
    returnUrl: z.string().url().optional(),
    stopUrl: z.string().url().optional(),
});

export async function launchHandler(req: Request, res: Response) {
    const body = LaunchBody.parse(req.body);
    const provider = body.provider;
    const adapter = getAdapter(provider);

    const token = newId();
    const launchKey = `launch:token:${token}`;
    const returnUrl = body.returnUrl ?? env.BRAND_RETURN_BASE ?? "https://example.com/return";

    // cache token for ActivateSession
    const sessionSeed = {
        provider,
        userId: body.user_id,
        username: body.username,
        clientExternalKey: body.client_external_key,
        currency: body.currency,
    };
    await redis.setex(launchKey, env.LAUNCH_TOKEN_TTL, JSON.stringify(sessionSeed));

    // draft DB row
    await db.insert(gameSessions).values({
        provider,
        userId: body.user_id,
        username: body.username,
        clientExternalKey: body.client_external_key,
        token,
        currencyCode: body.currency,
        status: "DRAFT",
    });

    const iframe_url = adapter.launcherUrl({
        token,
        gameCategory: body.gameCategory,
        gameName: body.gameName,
        lang: body.lang,
        returnUrl,
        stopUrl: body.stopUrl,
    });

    res.json({ success: true, iframe_url, token, ttl_seconds: env.LAUNCH_TOKEN_TTL });
}
