"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.launchHandler = launchHandler;
const zod_1 = require("zod");
const env_1 = require("../../config/env");
const redis_1 = require("../../config/redis");
const drizzle_1 = require("../../config/drizzle");
const schema_1 = require("../../db/schema");
const providers_1 = require("../../providers");
const ids_1 = require("../../utils/ids");
const LaunchBody = zod_1.z.object({
    provider: zod_1.z.literal("smartsoft"), // extend as you add more
    user_id: zod_1.z.coerce.number(),
    username: zod_1.z.string().min(1),
    client_external_key: zod_1.z.string().min(1),
    currency: zod_1.z.string().length(3),
    gameCategory: zod_1.z.string().min(1),
    gameName: zod_1.z.string().min(1),
    lang: zod_1.z.string().min(2),
    returnUrl: zod_1.z.string().url().optional(),
    stopUrl: zod_1.z.string().url().optional(),
});
function launchHandler(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const body = LaunchBody.parse(req.body);
        const provider = body.provider;
        const adapter = (0, providers_1.getAdapter)(provider);
        const token = (0, ids_1.newId)();
        const launchKey = `launch:token:${token}`;
        const returnUrl = (_b = (_a = body.returnUrl) !== null && _a !== void 0 ? _a : env_1.env.BRAND_RETURN_BASE) !== null && _b !== void 0 ? _b : "https://example.com/return";
        // cache token for ActivateSession
        const sessionSeed = {
            provider,
            userId: body.user_id,
            username: body.username,
            clientExternalKey: body.client_external_key,
            currency: body.currency,
        };
        yield redis_1.redis.setex(launchKey, env_1.env.LAUNCH_TOKEN_TTL, JSON.stringify(sessionSeed));
        // draft DB row
        yield drizzle_1.db.insert(schema_1.gameSessions).values({
            provider,
            userId: body.user_id,
            username: body.username,
            clientExternalKey: body.client_external_key,
            token,
            currencyCode: body.currency,
            status: "DRAFT",
        });
        const iframe_url = adapter.launcherUrl({
            token,
            gameCategory: body.gameCategory,
            gameName: body.gameName,
            lang: body.lang,
            returnUrl,
            stopUrl: body.stopUrl,
        });
        res.json({ success: true, iframe_url, token, ttl_seconds: env_1.env.LAUNCH_TOKEN_TTL });
    });
}
