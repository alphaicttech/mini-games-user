import express from "express";
import cors from "cors";
import { captureRawBody } from "./middleware/raw-body";
import { launchHandler } from "./modules/launch/controller";
import { activateSession, getBalance, deposit, withdraw, rollback } from "./modules/wallet/controller";
import { verifySignature } from "./middleware/verify-signature";
import { requireProviderSession } from "./middleware/require-session";

export const app = express();

app.use(cors({ origin: "*" }));
app.use(express.json({ verify: captureRawBody }));

// 1) Launch (sportsbook -> aggregator)
app.post("/games/launch", launchHandler);

// 2) Provider wallet endpoints (provider -> aggregator)
// NOTE: Add more providers by changing :provider param (e.g., /smartsoft)
app.post("/:provider/wallet/ActivateSession", verifySignature("smartsoft"), activateSession);
app.get("/:provider/wallet/GetBalance", verifySignature("smartsoft"), requireProviderSession, getBalance);
app.post("/:provider/wallet/Deposit", verifySignature("smartsoft"), requireProviderSession, deposit);
app.post("/:provider/wallet/Withdraw", verifySignature("smartsoft"), requireProviderSession, withdraw);
app.post("/:provider/wallet/RollbackTransaction", verifySignature("smartsoft"), requireProviderSession, rollback);

// health
app.get("/health", (_req, res) => res.json({ ok: true }));
