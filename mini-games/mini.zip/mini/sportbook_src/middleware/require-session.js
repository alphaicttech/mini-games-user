"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireProviderSession = requireProviderSession;
const redis_1 = require("../config/redis");
function requireProviderSession(req, res, next) {
    return __awaiter(this, void 0, void 0, function* () {
        const sessionId = req.header("X-SessionId");
        const userName = req.header("X-UserName");
        const clientKey = req.header("X-ClientExternalKey");
        if (!sessionId || !userName || !clientKey) {
            return res.status(400).json({ success: false, message: "Missing session headers" });
        }
        const sessKey = `session:${req.params.provider}:${sessionId}`;
        const blob = yield redis_1.redis.get(sessKey);
        if (!blob)
            return res.status(401).json({ success: false, message: "Invalid/expired session" });
        req.session = JSON.parse(blob);
        next();
    });
}
