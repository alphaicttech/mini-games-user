"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifySignature = verifySignature;
const providers_1 = require("../providers");
function verifySignature(provider) {
    return (req, res, next) => {
        var _a;
        const signature = req.header("X-Signature") || "";
        const raw = (_a = req.rawBody) !== null && _a !== void 0 ? _a : "";
        const ok = (0, providers_1.getAdapter)(provider).verifySignature(req.method, raw, signature);
        if (!ok)
            return res.status(401).json({ success: false, message: "Bad signature" });
        next();
    };
}
