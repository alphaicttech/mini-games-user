"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.captureRawBody = captureRawBody;
exports.ensureRawBody = ensureRawBody;
function captureRawBody(req, _res, buf) {
    if (buf === null || buf === void 0 ? void 0 : buf.length)
        req.rawBody = buf.toString("utf8");
}
function ensureRawBody(_req, _res, next) {
    // placeholder to ensure type is there even if route didn't parse JSON
    next();
}
