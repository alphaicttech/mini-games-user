import type { Request, Response, NextFunction } from "express";
import { getAdapter } from "../providers";

export function verifySignature(provider: string) {
    return (req: Request, res: Response, next: NextFunction) => {
        const signature = req.header("X-Signature") || "";
        const raw = (req as any).rawBody ?? "";
        const ok = getAdapter(provider).verifySignature(req.method, raw, signature);
        if (!ok) return res.status(401).json({ success: false, message: "Bad signature" });
        next();
    };
}
