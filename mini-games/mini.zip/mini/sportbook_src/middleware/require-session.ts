import type { Request, Response, NextFunction } from "express";
import { redis } from "../config/redis";

export async function requireProviderSession(req: Request, res: Response, next: NextFunction) {
    const sessionId = req.header("X-SessionId");
    const userName = req.header("X-UserName");
    const clientKey = req.header("X-ClientExternalKey");

    if (!sessionId || !userName || !clientKey) {
        return res.status(400).json({ success: false, message: "Missing session headers" });
    }

    const sessKey = `session:${req.params.provider}:${sessionId}`;
    const blob = await redis.get(sessKey);
    if (!blob) return res.status(401).json({ success: false, message: "Invalid/expired session" });

    (req as any).session = JSON.parse(blob);
    next();
}
