import type { Request, Response, NextFunction } from "express";

declare global {
    // eslint-disable-next-line no-var
    var __captureRawBody: boolean | undefined;
}

export function captureRawBody(req: Request, _res: Response, buf: Buffer) {
    if (buf?.length) (req as any).rawBody = buf.toString("utf8");
}

export function ensureRawBody(_req: Request, _res: Response, next: NextFunction) {
    // placeholder to ensure type is there even if route didn't parse JSON
    next();
}
