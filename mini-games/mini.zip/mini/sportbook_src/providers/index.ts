import { env } from "../config/env";
import { SmartSoftAdapter } from "./smartsoft.adapter";
import { ProviderAdapter } from "./types";

const smartsoft = new SmartSoftAdapter({
    secret: env.PROVIDER_SMARTSOFT_SECRET,
    baseLauncherUrl: env.PROVIDER_SMARTSOFT_LAUNCH_URL,
    portalName: env.PROVIDER_SMARTSOFT_PORTAL_NAME,
});

const registry = new Map<string, ProviderAdapter>([
    ["smartsoft", smartsoft],
]);

export function getAdapter(provider: string): ProviderAdapter {
    const a = registry.get(provider);
    if (!a) throw new Error(`Unknown provider: ${provider}`);
    return a;
}
