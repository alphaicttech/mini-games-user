"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAdapter = getAdapter;
const env_1 = require("../config/env");
const smartsoft_adapter_1 = require("./smartsoft.adapter");
const smartsoft = new smartsoft_adapter_1.SmartSoftAdapter({
    secret: env_1.env.PROVIDER_SMARTSOFT_SECRET,
    baseLauncherUrl: env_1.env.PROVIDER_SMARTSOFT_LAUNCH_URL,
    portalName: env_1.env.PROVIDER_SMARTSOFT_PORTAL_NAME,
});
const registry = new Map([
    ["smartsoft", smartsoft],
]);
function getAdapter(provider) {
    const a = registry.get(provider);
    if (!a)
        throw new Error(`Unknown provider: ${provider}`);
    return a;
}
