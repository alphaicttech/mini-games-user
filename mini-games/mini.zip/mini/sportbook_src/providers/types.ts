export type LaunchArgs = {
    gameCategory: string;
    gameName: string;
    lang: string;
    token: string;
    returnUrl: string;
    stopUrl?: string;
    portalName?: string;
};

export interface ProviderAdapter {
    code: string;
    launcherUrl(args: LaunchArgs): string;
    verifySignature(method: string, rawBody: string, signature: string): boolean;
}

export type ProviderConfig = {
    secret: string;
    baseLauncherUrl: string;
    portalName: string;
};
