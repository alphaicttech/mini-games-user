import { createHash } from "crypto";
import { ProviderAdapter, LaunchArgs, ProviderConfig } from "./types";

export class SmartSoftAdapter implements ProviderAdapter {
    public readonly code = "smartsoft";
    constructor(private cfg: ProviderConfig) { }

    launcherUrl(args: LaunchArgs): string {
        const url = new URL(this.cfg.baseLauncherUrl);
        url.searchParams.set("PortalName", args.portalName ?? this.cfg.portalName);
        url.searchParams.set("GameCategory", args.gameCategory);
        url.searchParams.set("GameName", args.gameName);
        url.searchParams.set("Token", args.token);
        url.searchParams.set("Lang", args.lang);
        url.searchParams.set("ReturnUrl", args.returnUrl);
        if (args.stopUrl) url.searchParams.set("StopUrl", args.stopUrl);
        return url.toString();
    }

    verifySignature(method: string, rawBody: string, signature: string): boolean {
        const base = `${this.cfg.secret}|${method.toUpperCase()}|${rawBody}`;
        const expected = createHash("md5").update(base).digest("hex");
        return expected === signature;
    }
}
