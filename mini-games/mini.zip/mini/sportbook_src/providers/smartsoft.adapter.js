"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SmartSoftAdapter = void 0;
const crypto_1 = require("crypto");
class SmartSoftAdapter {
    constructor(cfg) {
        this.cfg = cfg;
        this.code = "smartsoft";
    }
    launcherUrl(args) {
        var _a;
        const url = new URL(this.cfg.baseLauncherUrl);
        url.searchParams.set("PortalName", (_a = args.portalName) !== null && _a !== void 0 ? _a : this.cfg.portalName);
        url.searchParams.set("GameCategory", args.gameCategory);
        url.searchParams.set("GameName", args.gameName);
        url.searchParams.set("Token", args.token);
        url.searchParams.set("Lang", args.lang);
        url.searchParams.set("ReturnUrl", args.returnUrl);
        if (args.stopUrl)
            url.searchParams.set("StopUrl", args.stopUrl);
        return url.toString();
    }
    verifySignature(method, rawBody, signature) {
        const base = `${this.cfg.secret}|${method.toUpperCase()}|${rawBody}`;
        const expected = (0, crypto_1.createHash)("md5").update(base).digest("hex");
        return expected === signature;
    }
}
exports.SmartSoftAdapter = SmartSoftAdapter;
