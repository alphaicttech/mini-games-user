"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = void 0;
const zod_1 = require("zod");
require("dotenv/config");
const schema = zod_1.z.object({
    NODE_ENV: zod_1.z.enum(["development", "production", "test"]).default("development"),
    PORT: zod_1.z.coerce.number().default(8080),
    DATABASE_URL: zod_1.z.string().min(1),
    REDIS_URL: zod_1.z.string().min(1),
    // SmartSoft provider
    PROVIDER_SMARTSOFT_SECRET: zod_1.z.string().min(1),
    PROVIDER_SMARTSOFT_LAUNCH_URL: zod_1.z.string().url(), // e.g. https://launcher.smartsoft/api/launch (example)
    PROVIDER_SMARTSOFT_PORTAL_NAME: zod_1.z.string().min(1),
    // Aggregator brand defaults
    BRAND_RETURN_BASE: zod_1.z.string().url().optional(), // optional default return base
    // Session & idempotency TTLs (seconds)
    LAUNCH_TOKEN_TTL: zod_1.z.coerce.number().default(15 * 60),
    SESSION_TTL: zod_1.z.coerce.number().default(2 * 60 * 60),
    IDEMPOTENCY_TTL: zod_1.z.coerce.number().default(24 * 60 * 60),
});
exports.env = schema.parse(process.env);
