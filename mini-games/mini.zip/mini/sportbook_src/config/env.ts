import { z } from "zod";
import "dotenv/config";

const schema = z.object({
    NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
    PORT: z.coerce.number().default(8080),

    DATABASE_URL: z.string().min(1),
    REDIS_URL: z.string().min(1),

    // SmartSoft provider
    PROVIDER_SMARTSOFT_SECRET: z.string().min(1),
    PROVIDER_SMARTSOFT_LAUNCH_URL: z.string().url(), // e.g. https://launcher.smartsoft/api/launch (example)
    PROVIDER_SMARTSOFT_PORTAL_NAME: z.string().min(1),

    // Aggregator brand defaults
    BRAND_RETURN_BASE: z.string().url().optional(), // optional default return base

    // Session & idempotency TTLs (seconds)
    LAUNCH_TOKEN_TTL: z.coerce.number().default(15 * 60),
    SESSION_TTL: z.coerce.number().default(2 * 60 * 60),
    IDEMPOTENCY_TTL: z.coerce.number().default(24 * 60 * 60),
});

export const env = schema.parse(process.env);
