import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "../db/schema";
import { env } from "./env";

const sql = postgres(env.DATABASE_URL, {
    max: 10,
    idle_timeout: 60,
    connect_timeout: 30,
});

export const db = drizzle(sql, { schema });
