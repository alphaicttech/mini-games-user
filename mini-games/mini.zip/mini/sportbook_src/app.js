"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const raw_body_1 = require("./middleware/raw-body");
const controller_1 = require("./modules/launch/controller");
const controller_2 = require("./modules/wallet/controller");
const verify_signature_1 = require("./middleware/verify-signature");
const require_session_1 = require("./middleware/require-session");
exports.app = (0, express_1.default)();
exports.app.use((0, cors_1.default)({ origin: "*" }));
exports.app.use(express_1.default.json({ verify: raw_body_1.captureRawBody }));
// 1) Launch (sportsbook -> aggregator)
exports.app.post("/games/launch", controller_1.launchHandler);
// 2) Provider wallet endpoints (provider -> aggregator)
// NOTE: Add more providers by changing :provider param (e.g., /smartsoft)
exports.app.post("/:provider/wallet/ActivateSession", (0, verify_signature_1.verifySignature)("smartsoft"), controller_2.activateSession);
exports.app.get("/:provider/wallet/GetBalance", (0, verify_signature_1.verifySignature)("smartsoft"), require_session_1.requireProviderSession, controller_2.getBalance);
exports.app.post("/:provider/wallet/Deposit", (0, verify_signature_1.verifySignature)("smartsoft"), require_session_1.requireProviderSession, controller_2.deposit);
exports.app.post("/:provider/wallet/Withdraw", (0, verify_signature_1.verifySignature)("smartsoft"), require_session_1.requireProviderSession, controller_2.withdraw);
exports.app.post("/:provider/wallet/RollbackTransaction", (0, verify_signature_1.verifySignature)("smartsoft"), require_session_1.requireProviderSession, controller_2.rollback);
// health
exports.app.get("/health", (_req, res) => res.json({ ok: true }));
