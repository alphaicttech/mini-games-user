"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.operators = exports.walletTxns = exports.gameSessions = exports.txnStatus = exports.txnType = exports.gameSessionStatus = void 0;
const pg_core_1 = require("drizzle-orm/pg-core");
exports.gameSessionStatus = (0, pg_core_1.pgEnum)("GameSessionStatus", [
    "DRAFT", "ACTIVE", "CLOSED"
]);
exports.txnType = (0, pg_core_1.pgEnum)("WalletTxnType", [
    "DEPOSIT", "WITHDRAW", "ROLLBACK"
]);
exports.txnStatus = (0, pg_core_1.pgEnum)("WalletTxnStatus", [
    "ACCEPTED", "REJECTED", "REVERSED"
]);
exports.gameSessions = (0, pg_core_1.pgTable)("game_sessions", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    provider: (0, pg_core_1.varchar)("provider", { length: 64 }).notNull(),
    userId: (0, pg_core_1.bigint)("user_id", { mode: "number" }).notNull(),
    username: (0, pg_core_1.text)("username"),
    clientExternalKey: (0, pg_core_1.text)("client_external_key"),
    token: (0, pg_core_1.text)("token").notNull(),
    sessionId: (0, pg_core_1.text)("session_id"),
    currencyCode: (0, pg_core_1.varchar)("currency_code", { length: 3 }),
    status: (0, exports.gameSessionStatus)("status").notNull().default("DRAFT"),
    meta: (0, pg_core_1.jsonb)("meta").$type().default({}),
    expiresAt: (0, pg_core_1.timestamp)("expires_at", { withTimezone: false }),
    lastSeenAt: (0, pg_core_1.timestamp)("last_seen_at", { withTimezone: false }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    byToken: (0, pg_core_1.uniqueIndex)("ux_game_sessions_token").on(t.token),
    bySession: (0, pg_core_1.uniqueIndex)("ux_game_sessions_session").on(t.sessionId),
    byProviderUser: (0, pg_core_1.index)("ix_game_sessions_provider_user").on(t.provider, t.userId)
}));
exports.walletTxns = (0, pg_core_1.pgTable)("wallet_txns", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    provider: (0, pg_core_1.varchar)("provider", { length: 64 }).notNull(),
    providerTxnId: (0, pg_core_1.text)("provider_txn_id").notNull(),
    operatorTxnId: (0, pg_core_1.text)("operator_txn_id").notNull(),
    type: (0, exports.txnType)("type").notNull(),
    status: (0, exports.txnStatus)("status").notNull().default("ACCEPTED"),
    amount: (0, pg_core_1.numeric)("amount", { precision: 18, scale: 2 }).notNull(),
    currencyCode: (0, pg_core_1.varchar)("currency_code", { length: 3 }).notNull(),
    userId: (0, pg_core_1.bigint)("user_id", { mode: "number" }).notNull(),
    sessionId: (0, pg_core_1.text)("session_id").notNull(),
    roundId: (0, pg_core_1.text)("round_id"),
    game: (0, pg_core_1.text)("game"),
    gameNumber: (0, pg_core_1.bigint)("game_number", { mode: "number" }),
    balanceAfter: (0, pg_core_1.numeric)("balance_after", { precision: 18, scale: 2 }).notNull(),
    meta: (0, pg_core_1.jsonb)("meta").$type().default({}),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    byProviderTxnType: (0, pg_core_1.uniqueIndex)("ux_wallet_txn_provider_txn_type")
        .on(t.provider, t.providerTxnId, t.type),
    bySession: (0, pg_core_1.index)("ix_wallet_txn_session").on(t.sessionId),
    byUser: (0, pg_core_1.index)("ix_wallet_txn_user").on(t.userId),
    byRound: (0, pg_core_1.index)("ix_wallet_txn_round").on(t.roundId),
}));
exports.operators = (0, pg_core_1.pgTable)("operators", {
    id: (0, pg_core_1.serial)("id").primaryKey(),
    name: (0, pg_core_1.varchar)("name", { length: 100 }).notNull(),
    portalName: (0, pg_core_1.varchar)("portal_name", { length: 100 }).notNull(), // used in Loader.aspx?PortalName=...
    baseUrl: (0, pg_core_1.text)("base_url").notNull(), // operator wallet API base
    secret: (0, pg_core_1.text)("secret").notNull(), // signing secret (md5)
    currencies: (0, pg_core_1.jsonb)("currencies").$type().default([]),
    ipAllowlist: (0, pg_core_1.jsonb)("ip_allowlist").$type().default([]),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    uxPortal: (0, pg_core_1.uniqueIndex)("ux_operators_portal").on(t.portalName),
    ixName: (0, pg_core_1.index)("ix_operators_name").on(t.name),
}));
