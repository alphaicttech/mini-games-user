import {
    pgTable, serial, bigint, varchar, text, timestamp, jsonb, numeric,
    index, uniqueIndex, pgEnum, boolean
} from "drizzle-orm/pg-core";

export const gameSessionStatus = pgEnum("GameSessionStatus", [
    "DRAFT", "ACTIVE", "CLOSED"
]);

export const txnType = pgEnum("WalletTxnType", [
    "DEPOSIT", "WITHDRAW", "ROLLBACK"
]);

export const txnStatus = pgEnum("WalletTxnStatus", [
    "ACCEPTED", "REJECTED", "REVERSED"
]);

export const gameSessions = pgTable("game_sessions", {
    id: serial("id").primaryKey(),
    provider: varchar("provider", { length: 64 }).notNull(),
    userId: bigint("user_id", { mode: "number" }).notNull(),
    username: text("username"),
    clientExternalKey: text("client_external_key"),
    token: text("token").notNull(),
    sessionId: text("session_id"),
    currencyCode: varchar("currency_code", { length: 3 }),
    status: gameSessionStatus("status").notNull().default("DRAFT"),
    meta: jsonb("meta").$type<Record<string, unknown>>().default({}),
    expiresAt: timestamp("expires_at", { withTimezone: false }),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: false }),
    createdAt: timestamp("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    byToken: uniqueIndex("ux_game_sessions_token").on(t.token),
    bySession: uniqueIndex("ux_game_sessions_session").on(t.sessionId),
    byProviderUser: index("ix_game_sessions_provider_user").on(t.provider, t.userId)
}));

export const walletTxns = pgTable("wallet_txns", {
    id: serial("id").primaryKey(),
    provider: varchar("provider", { length: 64 }).notNull(),
    providerTxnId: text("provider_txn_id").notNull(),
    operatorTxnId: text("operator_txn_id").notNull(),
    type: txnType("type").notNull(),
    status: txnStatus("status").notNull().default("ACCEPTED"),
    amount: numeric("amount", { precision: 18, scale: 2 }).notNull(),
    currencyCode: varchar("currency_code", { length: 3 }).notNull(),

    userId: bigint("user_id", { mode: "number" }).notNull(),
    sessionId: text("session_id").notNull(),

    roundId: text("round_id"),
    game: text("game"),
    gameNumber: bigint("game_number", { mode: "number" }),
    balanceAfter: numeric("balance_after", { precision: 18, scale: 2 }).notNull(),

    meta: jsonb("meta").$type<Record<string, unknown>>().default({}),
    createdAt: timestamp("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    byProviderTxnType: uniqueIndex("ux_wallet_txn_provider_txn_type")
        .on(t.provider, t.providerTxnId, t.type),
    bySession: index("ix_wallet_txn_session").on(t.sessionId),
    byUser: index("ix_wallet_txn_user").on(t.userId),
    byRound: index("ix_wallet_txn_round").on(t.roundId),
}));


export const operators = pgTable("operators", {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    portalName: varchar("portal_name", { length: 100 }).notNull(),   // used in Loader.aspx?PortalName=...
    baseUrl: text("base_url").notNull(),                              // operator wallet API base
    secret: text("secret").notNull(),                                 // signing secret (md5)
    currencies: jsonb("currencies").$type<string[]>().default([]),
    ipAllowlist: jsonb("ip_allowlist").$type<string[]>().default([]),
    createdAt: timestamp("created_at", { withTimezone: false }).defaultNow(),
}, (t) => ({
    uxPortal: uniqueIndex("ux_operators_portal").on(t.portalName),
    ixName: index("ix_operators_name").on(t.name),
}));
