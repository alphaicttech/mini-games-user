"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.newId = void 0;
const crypto_1 = require("crypto");
const newId = () => (0, crypto_1.randomUUID)();
exports.newId = newId;
