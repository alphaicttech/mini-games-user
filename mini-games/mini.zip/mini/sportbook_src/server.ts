import { app } from "./app";
import { env } from "./config/env";

app.listen(env.PORT, () => {
    console.log(`mini-games aggregator listening on :${env.PORT}`);
});
