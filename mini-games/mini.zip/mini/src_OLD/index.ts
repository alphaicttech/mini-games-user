import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { env } from './config/env';
import routes from './routes';
import { jetxCronJob } from './jobs/jetx-cron';
import { redis } from './core/redis';
import { prisma } from './core/prisma';

const app = express();

// Security middleware
app.use(helmet());
app.use(cors({
    origin: env.CORS_ORIGIN,
    credentials: true,
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: env.RATE_LIMIT_WINDOW_MS,
    max: env.RATE_LIMIT_MAX_REQUESTS,
    message: {
        success: false,
        error: 'Too many requests, please try again later.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});
app.use(limiter);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: env.NODE_ENV,
    });
});

// API routes
app.use('/api', routes);

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: 'Route not found',
        path: req.originalUrl,
    });
});

// Global error handler
app.use((error: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('Global error handler:', error);

    res.status(error.status || 500).json({
        success: false,
        error: env.NODE_ENV === 'production' ? 'Internal server error' : error.message,
        ...(env.NODE_ENV === 'development' && { stack: error.stack }),
    });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
    console.log('SIGTERM received, shutting down gracefully...');
    await gracefulShutdown();
});

process.on('SIGINT', async () => {
    console.log('SIGINT received, shutting down gracefully...');
    await gracefulShutdown();
});

async function gracefulShutdown(): Promise<void> {
    try {
        // Stop the JetX cron job
        jetxCronJob.stop();

        // Close Redis connections
        await redis.disconnect();

        // Close Prisma connection
        await prisma.$disconnect();

        console.log('Graceful shutdown completed');
        process.exit(0);
    } catch (error) {
        console.error('Error during graceful shutdown:', error);
        process.exit(1);
    }
}

// Start the server
async function startServer(): Promise<void> {
    try {
        // Test database connection
        await prisma.$connect();
        console.log('Database connected successfully');

        // Test Redis connection
        await redis.set('health-check', 'ok');
        const healthCheck = await redis.get('health-check');
        if (healthCheck === 'ok') {
            console.log('Redis connected successfully');
        }

        // Start JetX cron job
        jetxCronJob.start();

        // Start the server
        const port = env.PORT;
        app.listen(port, () => {
            console.log(`🚀 Server running on port ${port}`);
            console.log(`📊 Environment: ${env.NODE_ENV}`);
            console.log(`🔗 Health check: http://localhost:${port}/health`);
            console.log(`🎮 API base: http://localhost:${port}/api`);
        });

    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}

// Start the server if this file is run directly
if (require.main === module) {
    startServer();
}

export default app; 