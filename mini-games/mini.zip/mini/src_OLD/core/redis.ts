import Redis from 'ioredis';

export interface RedisConfig {
    host: string;
    port: number;
    password?: string;
    db?: number;
    keyPrefix?: string;
}

class RedisClient {
    private client: Redis;
    private subscriber: Redis;
    private publisher: Redis;

    constructor(config: RedisConfig) {
        this.client = new Redis({
            host: config.host,
            port: config.port,
            password: config.password,
            db: config.db || 0,
            keyPrefix: config.keyPrefix || 'alpha-mini:',
        });

        this.subscriber = new Redis({
            host: config.host,
            port: config.port,
            password: config.password,
            db: config.db || 0,
            keyPrefix: config.keyPrefix || 'alpha-mini:',
        });

        this.publisher = new Redis({
            host: config.host,
            port: config.port,
            password: config.password,
            db: config.db || 0,
            keyPrefix: config.keyPrefix || 'alpha-mini:',
        });

        this.setupEventHandlers();
    }

    private setupEventHandlers(): void {
        this.client.on('connect', () => {
            console.log('Redis client connected');
        });

        this.client.on('error', (error) => {
            console.error('Redis client error:', error);
        });

        this.client.on('close', () => {
            console.log('Redis client connection closed');
        });
    }

    // Basic operations
    async get(key: string): Promise<string | null> {
        return this.client.get(key);
    }

    async set(key: string, value: string, ttl?: number): Promise<'OK'> {
        if (ttl) {
            return this.client.setex(key, ttl, value);
        }
        return this.client.set(key, value);
    }

    async del(key: string): Promise<number> {
        return this.client.del(key);
    }

    async exists(key: string): Promise<number> {
        return this.client.exists(key);
    }

    async expire(key: string, ttl: number): Promise<number> {
        return this.client.expire(key, ttl);
    }

    // Hash operations
    async hget(key: string, field: string): Promise<string | null> {
        return this.client.hget(key, field);
    }

    async hset(key: string, field: string, value: string): Promise<number> {
        return this.client.hset(key, field, value);
    }

    async hgetall(key: string): Promise<Record<string, string>> {
        return this.client.hgetall(key);
    }

    async hdel(key: string, field: string): Promise<number> {
        return this.client.hdel(key, field);
    }

    // List operations
    async lpush(key: string, value: string): Promise<number> {
        return this.client.lpush(key, value);
    }

    async rpush(key: string, value: string): Promise<number> {
        return this.client.rpush(key, value);
    }

    async lpop(key: string): Promise<string | null> {
        return this.client.lpop(key);
    }

    async rpop(key: string): Promise<string | null> {
        return this.client.rpop(key);
    }

    async lrange(key: string, start: number, stop: number): Promise<string[]> {
        return this.client.lrange(key, start, stop);
    }

    // Set operations
    async sadd(key: string, member: string): Promise<number> {
        return this.client.sadd(key, member);
    }

    async srem(key: string, member: string): Promise<number> {
        return this.client.srem(key, member);
    }

    async smembers(key: string): Promise<string[]> {
        return this.client.smembers(key);
    }

    async sismember(key: string, member: string): Promise<number> {
        return this.client.sismember(key, member);
    }

    // Pub/Sub operations
    async publish(channel: string, message: string): Promise<number> {
        return this.publisher.publish(channel, message);
    }

    async subscribe(channel: string, callback: (message: string) => void): Promise<void> {
        await this.subscriber.subscribe(channel);
        this.subscriber.on('message', (ch, message) => {
            if (ch === channel) {
                callback(message);
            }
        });
    }

    async unsubscribe(channel: string): Promise<void> {
        await this.subscriber.unsubscribe(channel);
    }

    // Game-specific operations
    async setGameSession(sessionId: string, data: any, ttl: number = 3600): Promise<'OK'> {
        return this.set(`session:${sessionId}`, JSON.stringify(data), ttl);
    }

    async getGameSession(sessionId: string): Promise<any | null> {
        const data = await this.get(`session:${sessionId}`);
        return data ? JSON.parse(data) : null;
    }

    async setGameRound(roundId: string, data: any, ttl: number = 300): Promise<'OK'> {
        return this.set(`round:${roundId}`, JSON.stringify(data), ttl);
    }

    async getGameRound(roundId: string): Promise<any | null> {
        const data = await this.get(`round:${roundId}`);
        return data ? JSON.parse(data) : null;
    }

    // Cleanup
    async disconnect(): Promise<void> {
        await this.client.quit();
        await this.subscriber.quit();
        await this.publisher.quit();
    }
}

// Create default Redis client instance
export const redis = new RedisClient({
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    password: process.env.REDIS_PASSWORD,
    db: parseInt(process.env.REDIS_DB || '0'),
    keyPrefix: 'alpha-mini:',
});

export { RedisClient }; 