import { PrismaClient } from '@prisma/client';

declare global {
    var __prisma: PrismaClient | undefined;
}

class PrismaManager {
    private static instance: PrismaClient;

    static getInstance(): PrismaClient {
        if (!global.__prisma) {
            global.__prisma = new PrismaClient({
                log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
                datasources: {
                    db: {
                        url: process.env.DATABASE_URL,
                    },
                },
            });

            // Graceful shutdown
            process.on('beforeExit', async () => {
                await global.__prisma.$disconnect();
            });

            process.on('SIGINT', async () => {
                await global.__prisma.$disconnect();
                process.exit(0);
            });

            process.on('SIGTERM', async () => {
                await global.__prisma.$disconnect();
                process.exit(0);
            });
        }

        return global.__prisma;
    }

    static async disconnect(): Promise<void> {
        if (global.__prisma) {
            await global.__prisma.$disconnect();
            global.__prisma = undefined;
        }
    }
}

// Export the Prisma client instance
export const prisma = PrismaManager.getInstance();

// Export the manager for advanced usage
export { PrismaManager }; 