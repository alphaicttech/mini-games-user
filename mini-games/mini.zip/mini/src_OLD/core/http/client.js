"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpClient = exports.httpClient = void 0;
const axios_1 = __importDefault(require("axios"));
const signature_1 = require("../utils/signature");
class HttpClient {
    constructor(config) {
        this.config = config;
        this.client = axios_1.default.create({
            baseURL: config.baseURL,
            timeout: config.timeout || 10000,
            headers: Object.assign({ 'Content-Type': 'application/json' }, config.headers),
        });
        this.setupInterceptors();
    }
    setupInterceptors() {
        // Request interceptor
        this.client.interceptors.request.use((config) => {
            // Add timestamp to all requests
            if (config.data) {
                config.data = Object.assign(Object.assign({}, config.data), { timestamp: Date.now() });
            }
            // Add API key if available
            if (this.config.apiKey) {
                config.headers = Object.assign(Object.assign({}, config.headers), { 'X-API-Key': this.config.apiKey });
            }
            // Add signature if required
            const customConfig = config;
            if (config.data && customConfig.requireSignature && this.config.secretKey) {
                const signature = (0, signature_1.generateSmartSoftSignature)(config.data, this.config.secretKey, customConfig.userId || '');
                config.headers = Object.assign(Object.assign({}, config.headers), { 'X-Signature': signature });
            }
            return config;
        }, (error) => {
            return Promise.reject(error);
        });
        // Response interceptor
        this.client.interceptors.response.use((response) => {
            return response;
        }, (error) => {
            // Handle common errors
            if (error.response) {
                console.error('HTTP Error:', error.response.status, error.response.data);
            }
            else if (error.request) {
                console.error('Network Error:', error.request);
            }
            else {
                console.error('Error:', error.message);
            }
            return Promise.reject(error);
        });
    }
    get(url, config) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.get(url, config);
        });
    }
    post(url, data, config) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.post(url, data, config);
        });
    }
    put(url, data, config) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.put(url, data, config);
        });
    }
    delete(url, config) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.delete(url, config);
        });
    }
    // Method to update configuration
    updateConfig(newConfig) {
        this.config = Object.assign(Object.assign({}, this.config), newConfig);
    }
}
exports.HttpClient = HttpClient;
// Create default HTTP client instance
exports.httpClient = new HttpClient({
    baseURL: process.env.API_BASE_URL || 'https://api.example.com',
    timeout: 10000,
    apiKey: process.env.API_KEY,
    secretKey: process.env.API_SECRET,
});
