import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { generateSmartSoftSignature } from '../utils/signature';

export interface HttpClientConfig {
    baseURL: string;
    timeout?: number;
    headers?: Record<string, string>;
    apiKey?: string;
    secretKey?: string;
}

export interface HttpRequestConfig extends AxiosRequestConfig {
    requireSignature?: boolean;
    userId?: string;
}

export interface HttpResponse<T = any> extends AxiosResponse<T> { }

class HttpClient {
    private client: AxiosInstance;
    private config: HttpClientConfig;

    constructor(config: HttpClientConfig) {
        this.config = config;
        this.client = axios.create({
            baseURL: config.baseURL,
            timeout: config.timeout || 10000,
            headers: {
                'Content-Type': 'application/json',
                ...config.headers,
            },
        });

        this.setupInterceptors();
    }

    private setupInterceptors(): void {
        // Request interceptor
        this.client.interceptors.request.use(
            (config) => {
                // Add timestamp to all requests
                if (config.data) {
                    config.data = {
                        ...config.data,
                        timestamp: Date.now(),
                    };
                }

                // Add API key if available
                if (this.config.apiKey) {
                    config.headers = {
                        ...config.headers,
                        'X-API-Key': this.config.apiKey,
                    } as any;
                }

                // Add signature if required
                const customConfig = config as any;
                if (config.data && customConfig.requireSignature && this.config.secretKey) {
                    const signature = generateSmartSoftSignature(
                        config.data,
                        this.config.secretKey,
                        customConfig.userId || ''
                    );
                    config.headers = {
                        ...config.headers,
                        'X-Signature': signature,
                    } as any;
                }

                return config;
            },
            (error) => {
                return Promise.reject(error);
            }
        );

        // Response interceptor
        this.client.interceptors.response.use(
            (response) => {
                return response;
            },
            (error) => {
                // Handle common errors
                if (error.response) {
                    console.error('HTTP Error:', error.response.status, error.response.data);
                } else if (error.request) {
                    console.error('Network Error:', error.request);
                } else {
                    console.error('Error:', error.message);
                }
                return Promise.reject(error);
            }
        );
    }

    async get<T = any>(url: string, config?: HttpRequestConfig): Promise<HttpResponse<T>> {
        return this.client.get<T>(url, config);
    }

    async post<T = any>(url: string, data?: any, config?: HttpRequestConfig): Promise<HttpResponse<T>> {
        return this.client.post<T>(url, data, config);
    }

    async put<T = any>(url: string, data?: any, config?: HttpRequestConfig): Promise<HttpResponse<T>> {
        return this.client.put<T>(url, data, config);
    }

    async delete<T = any>(url: string, config?: HttpRequestConfig): Promise<HttpResponse<T>> {
        return this.client.delete<T>(url, config);
    }

    // Method to update configuration
    updateConfig(newConfig: Partial<HttpClientConfig>): void {
        this.config = { ...this.config, ...newConfig };
    }
}

// Create default HTTP client instance
export const httpClient = new HttpClient({
    baseURL: process.env.API_BASE_URL || 'https://api.example.com',
    timeout: 10000,
    apiKey: process.env.API_KEY,
    secretKey: process.env.API_SECRET,
});

export { HttpClient }; 