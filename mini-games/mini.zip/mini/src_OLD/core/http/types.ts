import { AxiosRequestConfig, AxiosResponse } from 'axios';

export interface HttpRequestConfig extends AxiosRequestConfig {
    requireSignature?: boolean;
    userId?: string;
}

export interface HttpResponse<T = any> extends AxiosResponse<T> { }

export interface HttpClientConfig {
    baseURL: string;
    timeout?: number;
    headers?: Record<string, string>;
    apiKey?: string;
    secretKey?: string;
} 