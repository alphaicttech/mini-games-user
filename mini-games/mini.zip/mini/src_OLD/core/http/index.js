"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpClient = exports.httpClient = void 0;
var client_1 = require("./client");
Object.defineProperty(exports, "httpClient", { enumerable: true, get: function () { return client_1.httpClient; } });
Object.defineProperty(exports, "HttpClient", { enumerable: true, get: function () { return client_1.HttpClient; } });
