"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaManager = exports.prisma = void 0;
const client_1 = require("@prisma/client");
class PrismaManager {
    static getInstance() {
        if (!global.__prisma) {
            global.__prisma = new client_1.PrismaClient({
                log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
                datasources: {
                    db: {
                        url: process.env.DATABASE_URL,
                    },
                },
            });
            // Graceful shutdown
            process.on('beforeExit', () => __awaiter(this, void 0, void 0, function* () {
                yield global.__prisma.$disconnect();
            }));
            process.on('SIGINT', () => __awaiter(this, void 0, void 0, function* () {
                yield global.__prisma.$disconnect();
                process.exit(0);
            }));
            process.on('SIGTERM', () => __awaiter(this, void 0, void 0, function* () {
                yield global.__prisma.$disconnect();
                process.exit(0);
            }));
        }
        return global.__prisma;
    }
    static disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            if (global.__prisma) {
                yield global.__prisma.$disconnect();
                global.__prisma = undefined;
            }
        });
    }
}
exports.PrismaManager = PrismaManager;
// Export the Prisma client instance
exports.prisma = PrismaManager.getInstance();
