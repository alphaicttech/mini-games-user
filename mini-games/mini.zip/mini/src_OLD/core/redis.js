"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisClient = exports.redis = void 0;
const ioredis_1 = __importDefault(require("ioredis"));
class RedisClient {
    constructor(config) {
        this.client = new ioredis_1.default({
            host: config.host,
            port: config.port,
            password: config.password,
            db: config.db || 0,
            keyPrefix: config.keyPrefix || 'alpha-mini:',
        });
        this.subscriber = new ioredis_1.default({
            host: config.host,
            port: config.port,
            password: config.password,
            db: config.db || 0,
            keyPrefix: config.keyPrefix || 'alpha-mini:',
        });
        this.publisher = new ioredis_1.default({
            host: config.host,
            port: config.port,
            password: config.password,
            db: config.db || 0,
            keyPrefix: config.keyPrefix || 'alpha-mini:',
        });
        this.setupEventHandlers();
    }
    setupEventHandlers() {
        this.client.on('connect', () => {
            console.log('Redis client connected');
        });
        this.client.on('error', (error) => {
            console.error('Redis client error:', error);
        });
        this.client.on('close', () => {
            console.log('Redis client connection closed');
        });
    }
    // Basic operations
    get(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.get(key);
        });
    }
    set(key, value, ttl) {
        return __awaiter(this, void 0, void 0, function* () {
            if (ttl) {
                return this.client.setex(key, ttl, value);
            }
            return this.client.set(key, value);
        });
    }
    del(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.del(key);
        });
    }
    exists(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.exists(key);
        });
    }
    expire(key, ttl) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.expire(key, ttl);
        });
    }
    // Hash operations
    hget(key, field) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.hget(key, field);
        });
    }
    hset(key, field, value) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.hset(key, field, value);
        });
    }
    hgetall(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.hgetall(key);
        });
    }
    hdel(key, field) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.hdel(key, field);
        });
    }
    // List operations
    lpush(key, value) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.lpush(key, value);
        });
    }
    rpush(key, value) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.rpush(key, value);
        });
    }
    lpop(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.lpop(key);
        });
    }
    rpop(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.rpop(key);
        });
    }
    lrange(key, start, stop) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.lrange(key, start, stop);
        });
    }
    // Set operations
    sadd(key, member) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.sadd(key, member);
        });
    }
    srem(key, member) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.srem(key, member);
        });
    }
    smembers(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.smembers(key);
        });
    }
    sismember(key, member) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.client.sismember(key, member);
        });
    }
    // Pub/Sub operations
    publish(channel, message) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.publisher.publish(channel, message);
        });
    }
    subscribe(channel, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.subscriber.subscribe(channel);
            this.subscriber.on('message', (ch, message) => {
                if (ch === channel) {
                    callback(message);
                }
            });
        });
    }
    unsubscribe(channel) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.subscriber.unsubscribe(channel);
        });
    }
    // Game-specific operations
    setGameSession(sessionId_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (sessionId, data, ttl = 3600) {
            return this.set(`session:${sessionId}`, JSON.stringify(data), ttl);
        });
    }
    getGameSession(sessionId) {
        return __awaiter(this, void 0, void 0, function* () {
            const data = yield this.get(`session:${sessionId}`);
            return data ? JSON.parse(data) : null;
        });
    }
    setGameRound(roundId_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (roundId, data, ttl = 300) {
            return this.set(`round:${roundId}`, JSON.stringify(data), ttl);
        });
    }
    getGameRound(roundId) {
        return __awaiter(this, void 0, void 0, function* () {
            const data = yield this.get(`round:${roundId}`);
            return data ? JSON.parse(data) : null;
        });
    }
    // Cleanup
    disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.client.quit();
            yield this.subscriber.quit();
            yield this.publisher.quit();
        });
    }
}
exports.RedisClient = RedisClient;
// Create default Redis client instance
exports.redis = new RedisClient({
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    password: process.env.REDIS_PASSWORD,
    db: parseInt(process.env.REDIS_DB || '0'),
    keyPrefix: 'alpha-mini:',
});
