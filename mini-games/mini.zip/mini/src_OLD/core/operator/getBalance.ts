import { httpClient } from '../http';
import { getEndpoint } from '../../config/endpoints';

export interface GetBalanceRequest {
    userId: string;
    sessionToken: string;
    timestamp: number;
}

export interface GetBalanceResponse {
    success: boolean;
    balance?: number;
    currency?: string;
    error?: string;
}

export async function getBalance(
    request: GetBalanceRequest
): Promise<GetBalanceResponse> {
    try {
        const response = await httpClient.get(
            `${getEndpoint('getBalance')}?userId=${request.userId}`,
            {
                headers: {
                    'Authorization': `Bearer ${request.sessionToken}`
                }
            }
        );
        return response.data;
    } catch (error) {
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred'
        };
    }
} 