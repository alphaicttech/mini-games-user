import { httpClient } from '../http';
import { getEndpoint } from '../../config/endpoints';

export interface RollbackRequest {
    transactionId: string;
    sessionToken: string;
    timestamp: number;
}

export interface RollbackResponse {
    success: boolean;
    rolledBackAmount?: number;
    newBalance?: number;
    error?: string;
}

export async function rollback(
    request: RollbackRequest
): Promise<RollbackResponse> {
    try {
        const response = await httpClient.post(
            getEndpoint('rollback'),
            request
        );
        return response.data;
    } catch (error) {
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred'
        };
    }
} 