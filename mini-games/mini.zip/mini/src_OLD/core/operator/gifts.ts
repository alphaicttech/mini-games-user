import { httpClient } from '../http';
import { getEndpoint } from '../../config/endpoints';

export interface GiftRequest {
    userId: string;
    giftType: string;
    amount?: number;
    sessionToken: string;
    timestamp: number;
}

export interface GiftResponse {
    success: boolean;
    giftId?: string;
    amount?: number;
    newBalance?: number;
    error?: string;
}

export async function claimGift(
    request: GiftRequest
): Promise<GiftResponse> {
    try {
        const response = await httpClient.post(
            getEndpoint('gifts'),
            request
        );
        return response.data;
    } catch (error) {
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred'
        };
    }
} 