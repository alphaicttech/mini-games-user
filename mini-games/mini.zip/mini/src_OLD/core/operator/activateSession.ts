import { httpClient } from '../http';
import { getEndpoint } from '../../config/endpoints';

export interface ActivateSessionRequest {
    sessionId: string;
    userId: string;
    timestamp: number;
}

export interface ActivateSessionResponse {
    success: boolean;
    sessionToken?: string;
    expiresAt?: number;
    error?: string;
}

export async function activateSession(
    request: ActivateSessionRequest
): Promise<ActivateSessionResponse> {
    try {
        const response = await httpClient.post(
            getEndpoint('activateSession'),
            request
        );
        return response.data;
    } catch (error) {
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred'
        };
    }
} 