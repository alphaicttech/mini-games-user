import { httpClient } from '../http';
import { getEndpoint } from '../../config/endpoints';

export interface WithdrawRequest {
    userId: string;
    amount: number;
    currency: string;
    sessionToken: string;
    timestamp: number;
}

export interface WithdrawResponse {
    success: boolean;
    transactionId?: string;
    newBalance?: number;
    error?: string;
}

export async function withdraw(
    request: WithdrawRequest
): Promise<WithdrawResponse> {
    try {
        const response = await httpClient.post(
            getEndpoint('withdraw'),
            request
        );
        return response.data;
    } catch (error) {
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred'
        };
    }
} 