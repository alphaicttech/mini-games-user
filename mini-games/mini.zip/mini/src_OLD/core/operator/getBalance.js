"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBalance = getBalance;
const http_1 = require("../http");
const endpoints_1 = require("../../config/endpoints");
function getBalance(request) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const response = yield http_1.httpClient.get(`${(0, endpoints_1.getEndpoint)('getBalance')}?userId=${request.userId}`, {
                headers: {
                    'Authorization': `Bearer ${request.sessionToken}`
                }
            });
            return response.data;
        }
        catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    });
}
