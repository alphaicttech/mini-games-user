import { httpClient } from '../http';
import { getEndpoint } from '../../config/endpoints';

export interface DepositRequest {
    userId: string;
    amount: number;
    currency: string;
    sessionToken: string;
    timestamp: number;
}

export interface DepositResponse {
    success: boolean;
    transactionId?: string;
    newBalance?: number;
    error?: string;
}

export async function deposit(
    request: DepositRequest
): Promise<DepositResponse> {
    try {
        const response = await httpClient.post(
            getEndpoint('deposit'),
            request
        );
        return response.data;
    } catch (error) {
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred'
        };
    }
} 