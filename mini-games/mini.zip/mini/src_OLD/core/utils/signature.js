"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateSignature = generateSignature;
exports.generateSmartSoftSignature = generateSmartSoftSignature;
exports.verifySignature = verifySignature;
exports.generateNonce = generateNonce;
const crypto = __importStar(require("crypto"));
function generateSignature(data, secretKey) {
    const payload = `${data.data}:${data.timestamp}:${data.userId}`;
    return crypto
        .createHmac('sha256', secretKey)
        .update(payload)
        .digest('hex');
}
function generateSmartSoftSignature(data, secretKey, userId) {
    const timestamp = Date.now();
    const payload = JSON.stringify(Object.assign(Object.assign({}, data), { timestamp,
        userId }));
    return crypto
        .createHmac('sha256', secretKey)
        .update(payload)
        .digest('hex');
}
function verifySignature(data, signature, secretKey) {
    const expectedSignature = generateSignature(data, secretKey);
    return crypto.timingSafeEqual(Buffer.from(signature, 'hex'), Buffer.from(expectedSignature, 'hex'));
}
function generateNonce() {
    return crypto.randomBytes(16).toString('hex');
}
