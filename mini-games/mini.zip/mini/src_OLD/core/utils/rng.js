"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.randomFloat = exports.randomInt = exports.generateCrashPoint = exports.randomChoice = exports.rng = exports.RNG = void 0;
const crypto_1 = __importDefault(require("crypto"));
class RNG {
    constructor(seed) {
        this.seed = seed || crypto_1.default.randomBytes(32).toString('hex');
    }
    // Generate a random number between 0 and 1
    random() {
        const hash = crypto_1.default.createHash('sha256').update(this.seed).digest('hex');
        this.seed = hash;
        return parseInt(hash.substring(0, 8), 16) / 0xffffffff;
    }
    // Generate a random integer between min and max (inclusive)
    randomInt(min, max) {
        return Math.floor(this.random() * (max - min + 1)) + min;
    }
    // Generate a random float between min and max
    randomFloat(min, max) {
        return this.random() * (max - min) + min;
    }
    // Make a random choice from an array
    choice(array, options) {
        if ((options === null || options === void 0 ? void 0 : options.weights) && options.weights.length === array.length) {
            return this.weightedChoice(array, options.weights);
        }
        return array[this.randomInt(0, array.length - 1)];
    }
    // Make a weighted random choice
    weightedChoice(array, weights) {
        const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
        let random = this.random() * totalWeight;
        for (let i = 0; i < array.length; i++) {
            random -= weights[i];
            if (random <= 0) {
                return array[i];
            }
        }
        return array[array.length - 1];
    }
    // Generate a crash point for JetX game
    generateCrashPoint() {
        // House edge of 5%
        const houseEdge = 0.95;
        const random = this.random();
        // Calculate crash point using inverse function
        const crashPoint = 1 / (random * houseEdge);
        const multiplier = Math.max(1.0, crashPoint);
        return {
            multiplier,
            crashPoint: multiplier
        };
    }
    // Generate multiple crash points for testing
    generateCrashPoints(count) {
        return Array.from({ length: count }, () => this.generateCrashPoint());
    }
    // Shuffle an array using Fisher-Yates algorithm
    shuffle(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = this.randomInt(0, i);
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }
    // Generate a random string
    randomString(length, charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') {
        let result = '';
        for (let i = 0; i < length; i++) {
            result += charset[this.randomInt(0, charset.length - 1)];
        }
        return result;
    }
    // Set a new seed
    setSeed(seed) {
        this.seed = seed;
    }
    // Get current seed
    getSeed() {
        return this.seed;
    }
}
exports.RNG = RNG;
// Create a default RNG instance
exports.rng = new RNG();
// Export individual functions for convenience
const randomChoice = (array, options) => exports.rng.choice(array, options);
exports.randomChoice = randomChoice;
const generateCrashPoint = () => exports.rng.generateCrashPoint();
exports.generateCrashPoint = generateCrashPoint;
const randomInt = (min, max) => exports.rng.randomInt(min, max);
exports.randomInt = randomInt;
const randomFloat = (min, max) => exports.rng.randomFloat(min, max);
exports.randomFloat = randomFloat;
