import * as crypto from 'crypto';

export interface SignatureData {
    data: string;
    timestamp: number;
    userId: string;
}

export function generateSignature(
    data: SignatureData,
    secretKey: string
): string {
    const payload = `${data.data}:${data.timestamp}:${data.userId}`;
    return crypto
        .createHmac('sha256', secretKey)
        .update(payload)
        .digest('hex');
}

export function generateSmartSoftSignature(
    data: any,
    secretKey: string,
    userId: string
): string {
    const timestamp = Date.now();
    const payload = JSON.stringify({
        ...data,
        timestamp,
        userId,
    });

    return crypto
        .createHmac('sha256', secretKey)
        .update(payload)
        .digest('hex');
}

export function verifySignature(
    data: SignatureData,
    signature: string,
    secretKey: string
): boolean {
    const expectedSignature = generateSignature(data, secretKey);
    return crypto.timingSafeEqual(
        Buffer.from(signature, 'hex'),
        Buffer.from(expectedSignature, 'hex')
    );
}

export function generateNonce(): string {
    return crypto.randomBytes(16).toString('hex');
} 