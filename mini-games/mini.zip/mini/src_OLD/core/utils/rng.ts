import crypto from 'crypto';

export interface RandomChoiceOptions {
    weights?: number[];
    seed?: string;
}

export interface CrashPoint {
    multiplier: number;
    crashPoint: number;
}

export class RNG {
    private seed: string;

    constructor(seed?: string) {
        this.seed = seed || crypto.randomBytes(32).toString('hex');
    }

    // Generate a random number between 0 and 1
    random(): number {
        const hash = crypto.createHash('sha256').update(this.seed).digest('hex');
        this.seed = hash;
        return parseInt(hash.substring(0, 8), 16) / 0xffffffff;
    }

    // Generate a random integer between min and max (inclusive)
    randomInt(min: number, max: number): number {
        return Math.floor(this.random() * (max - min + 1)) + min;
    }

    // Generate a random float between min and max
    randomFloat(min: number, max: number): number {
        return this.random() * (max - min) + min;
    }

    // Make a random choice from an array
    choice<T>(array: T[], options?: RandomChoiceOptions): T {
        if (options?.weights && options.weights.length === array.length) {
            return this.weightedChoice(array, options.weights);
        }
        return array[this.randomInt(0, array.length - 1)];
    }

    // Make a weighted random choice
    weightedChoice<T>(array: T[], weights: number[]): T {
        const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
        let random = this.random() * totalWeight;

        for (let i = 0; i < array.length; i++) {
            random -= weights[i];
            if (random <= 0) {
                return array[i];
            }
        }

        return array[array.length - 1];
    }

    // Generate a crash point for JetX game
    generateCrashPoint(): CrashPoint {
        // House edge of 5%
        const houseEdge = 0.95;
        const random = this.random();

        // Calculate crash point using inverse function
        const crashPoint = 1 / (random * houseEdge);
        const multiplier = Math.max(1.0, crashPoint);

        return {
            multiplier,
            crashPoint: multiplier
        };
    }

    // Generate multiple crash points for testing
    generateCrashPoints(count: number): CrashPoint[] {
        return Array.from({ length: count }, () => this.generateCrashPoint());
    }

    // Shuffle an array using Fisher-Yates algorithm
    shuffle<T>(array: T[]): T[] {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = this.randomInt(0, i);
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }

    // Generate a random string
    randomString(length: number, charset: string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'): string {
        let result = '';
        for (let i = 0; i < length; i++) {
            result += charset[this.randomInt(0, charset.length - 1)];
        }
        return result;
    }

    // Set a new seed
    setSeed(seed: string): void {
        this.seed = seed;
    }

    // Get current seed
    getSeed(): string {
        return this.seed;
    }
}

// Create a default RNG instance
export const rng = new RNG();

// Export individual functions for convenience
export const randomChoice = <T>(array: T[], options?: RandomChoiceOptions): T =>
    rng.choice(array, options);

export const generateCrashPoint = (): CrashPoint =>
    rng.generateCrashPoint();

export const randomInt = (min: number, max: number): number =>
    rng.randomInt(min, max);

export const randomFloat = (min: number, max: number): number =>
    rng.randomFloat(min, max); 