import { roundManager } from '../games/jetx/roundManager';
import { redis } from '../core/redis';

export class JetXCronJob {
    private interval: NodeJS.Timeout | null = null;
    private isRunning: boolean = false;

    /**
     * Start the cron job
     */
    start(): void {
        if (this.isRunning) {
            console.log('JetX cron job is already running');
            return;
        }

        console.log('Starting JetX cron job...');
        this.isRunning = true;

        // Start the round manager
        roundManager.start();

        // Set up event listeners
        this.setupEventListeners();

        // Set up interval for periodic tasks (every 10 seconds)
        this.interval = setInterval(() => {
            this.performPeriodicTasks();
        }, 10000);

        console.log('JetX cron job started successfully');
    }

    /**
     * Stop the cron job
     */
    stop(): void {
        if (!this.isRunning) {
            console.log('JetX cron job is not running');
            return;
        }

        console.log('Stopping JetX cron job...');
        this.isRunning = false;

        // Stop the round manager
        roundManager.stop();

        // Clear interval
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }

        console.log('JetX cron job stopped successfully');
    }

    /**
     * Set up event listeners for round manager events
     */
    private setupEventListeners(): void {
        roundManager.on('roundStarted', (round) => {
            console.log(`JetX Round ${round.id} started - Waiting phase`);
            this.broadcastRoundUpdate(round);
        });

        roundManager.on('activePhaseStarted', (round) => {
            console.log(`JetX Round ${round.id} active phase started`);
            this.broadcastRoundUpdate(round);
        });

        roundManager.on('roundCrashed', (round) => {
            console.log(`JetX Round ${round.id} crashed at ${round.crashPoint}x`);
            this.broadcastRoundUpdate(round);
            this.saveRoundToDatabase(round);
        });

        roundManager.on('playerJoined', ({ roundId, player }) => {
            console.log(`Player ${player.userId} joined round ${roundId} with bet ${player.betAmount}`);
            this.broadcastPlayerUpdate(roundId, 'joined', player);
        });

        roundManager.on('playerCashedOut', ({ roundId, player }) => {
            console.log(`Player ${player.userId} cashed out at ${player.cashoutMultiplier}x with payout ${player.payout}`);
            this.broadcastPlayerUpdate(roundId, 'cashedOut', player);
        });

        roundManager.on('playersCrashed', ({ roundId, players }) => {
            console.log(`${players.length} players crashed in round ${roundId}`);
            this.broadcastPlayersCrashed(roundId, players);
        });
    }

    /**
     * Perform periodic tasks
     */
    private async performPeriodicTasks(): Promise<void> {
        try {
            const currentRound = roundManager.getCurrentRound();
            if (currentRound) {
                // Broadcast current round state
                await this.broadcastRoundUpdate(currentRound);

                // Update round statistics
                const stats = roundManager.getRoundStats();
                await this.broadcastRoundStats(stats);
            }

            // Clean up old rounds from Redis
            await this.cleanupOldRounds();

        } catch (error) {
            console.error('Error in periodic tasks:', error);
        }
    }

    /**
     * Broadcast round update to all connected clients
     */
    private async broadcastRoundUpdate(round: any): Promise<void> {
        try {
            const message = JSON.stringify({
                type: 'roundUpdate',
                data: {
                    roundId: round.id,
                    status: round.status,
                    crashPoint: round.crashPoint,
                    startTime: round.startTime,
                    endTime: round.endTime,
                    totalBets: round.totalBets,
                    totalAmount: round.totalAmount,
                    players: round.players.length,
                }
            });

            await redis.publish('jetx:rounds', message);
        } catch (error) {
            console.error('Error broadcasting round update:', error);
        }
    }

    /**
     * Broadcast player update
     */
    private async broadcastPlayerUpdate(roundId: string, action: string, player: any): Promise<void> {
        try {
            const message = JSON.stringify({
                type: 'playerUpdate',
                data: {
                    roundId,
                    action,
                    player: {
                        userId: player.userId,
                        betAmount: player.betAmount,
                        cashoutMultiplier: player.cashoutMultiplier,
                        payout: player.payout,
                        cashedOut: player.cashedOut,
                    }
                }
            });

            await redis.publish('jetx:players', message);
        } catch (error) {
            console.error('Error broadcasting player update:', error);
        }
    }

    /**
     * Broadcast players crashed event
     */
    private async broadcastPlayersCrashed(roundId: string, players: any[]): Promise<void> {
        try {
            const message = JSON.stringify({
                type: 'playersCrashed',
                data: {
                    roundId,
                    players: players.map(p => ({
                        userId: p.userId,
                        betAmount: p.betAmount,
                        payout: 0,
                    }))
                }
            });

            await redis.publish('jetx:crashed', message);
        } catch (error) {
            console.error('Error broadcasting players crashed:', error);
        }
    }

    /**
     * Broadcast round statistics
     */
    private async broadcastRoundStats(stats: any): Promise<void> {
        try {
            const message = JSON.stringify({
                type: 'roundStats',
                data: stats
            });

            await redis.publish('jetx:stats', message);
        } catch (error) {
            console.error('Error broadcasting round stats:', error);
        }
    }

    /**
     * Save completed round to database
     */
    private async saveRoundToDatabase(round: any): Promise<void> {
        try {
            // This would typically save to a database like PostgreSQL
            // For now, we'll just log it
            console.log(`Saving round ${round.id} to database`);

            // Example database save (commented out until Prisma schema is ready)
            /*
            await prisma.jetXRound.create({
              data: {
                id: round.id,
                crashPoint: round.crashPoint,
                startTime: round.startTime,
                endTime: round.endTime,
                totalBets: round.totalBets,
                totalAmount: round.totalAmount,
                status: round.status,
              }
            });
            */
        } catch (error) {
            console.error('Error saving round to database:', error);
        }
    }

    /**
     * Clean up old rounds from Redis
     */
    private async cleanupOldRounds(): Promise<void> {
        try {
            // This would clean up rounds older than 1 hour
            const oneHourAgo = Date.now() - (60 * 60 * 1000);

            // Implementation would depend on how rounds are stored in Redis
            // For now, we'll just log the cleanup
            console.log('Cleaning up old rounds...');
        } catch (error) {
            console.error('Error cleaning up old rounds:', error);
        }
    }

    /**
     * Get cron job status
     */
    getStatus(): { running: boolean; currentRound: any | null } {
        return {
            running: this.isRunning,
            currentRound: roundManager.getCurrentRound(),
        };
    }
}

// Create and export the cron job instance
export const jetxCronJob = new JetXCronJob(); 