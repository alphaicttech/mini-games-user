"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.jetxCronJob = exports.JetXCronJob = void 0;
const roundManager_1 = require("../games/jetx/roundManager");
const redis_1 = require("../core/redis");
class JetXCronJob {
    constructor() {
        this.interval = null;
        this.isRunning = false;
    }
    /**
     * Start the cron job
     */
    start() {
        if (this.isRunning) {
            console.log('JetX cron job is already running');
            return;
        }
        console.log('Starting JetX cron job...');
        this.isRunning = true;
        // Start the round manager
        roundManager_1.roundManager.start();
        // Set up event listeners
        this.setupEventListeners();
        // Set up interval for periodic tasks (every 10 seconds)
        this.interval = setInterval(() => {
            this.performPeriodicTasks();
        }, 10000);
        console.log('JetX cron job started successfully');
    }
    /**
     * Stop the cron job
     */
    stop() {
        if (!this.isRunning) {
            console.log('JetX cron job is not running');
            return;
        }
        console.log('Stopping JetX cron job...');
        this.isRunning = false;
        // Stop the round manager
        roundManager_1.roundManager.stop();
        // Clear interval
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
        console.log('JetX cron job stopped successfully');
    }
    /**
     * Set up event listeners for round manager events
     */
    setupEventListeners() {
        roundManager_1.roundManager.on('roundStarted', (round) => {
            console.log(`JetX Round ${round.id} started - Waiting phase`);
            this.broadcastRoundUpdate(round);
        });
        roundManager_1.roundManager.on('activePhaseStarted', (round) => {
            console.log(`JetX Round ${round.id} active phase started`);
            this.broadcastRoundUpdate(round);
        });
        roundManager_1.roundManager.on('roundCrashed', (round) => {
            console.log(`JetX Round ${round.id} crashed at ${round.crashPoint}x`);
            this.broadcastRoundUpdate(round);
            this.saveRoundToDatabase(round);
        });
        roundManager_1.roundManager.on('playerJoined', ({ roundId, player }) => {
            console.log(`Player ${player.userId} joined round ${roundId} with bet ${player.betAmount}`);
            this.broadcastPlayerUpdate(roundId, 'joined', player);
        });
        roundManager_1.roundManager.on('playerCashedOut', ({ roundId, player }) => {
            console.log(`Player ${player.userId} cashed out at ${player.cashoutMultiplier}x with payout ${player.payout}`);
            this.broadcastPlayerUpdate(roundId, 'cashedOut', player);
        });
        roundManager_1.roundManager.on('playersCrashed', ({ roundId, players }) => {
            console.log(`${players.length} players crashed in round ${roundId}`);
            this.broadcastPlayersCrashed(roundId, players);
        });
    }
    /**
     * Perform periodic tasks
     */
    performPeriodicTasks() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const currentRound = roundManager_1.roundManager.getCurrentRound();
                if (currentRound) {
                    // Broadcast current round state
                    yield this.broadcastRoundUpdate(currentRound);
                    // Update round statistics
                    const stats = roundManager_1.roundManager.getRoundStats();
                    yield this.broadcastRoundStats(stats);
                }
                // Clean up old rounds from Redis
                yield this.cleanupOldRounds();
            }
            catch (error) {
                console.error('Error in periodic tasks:', error);
            }
        });
    }
    /**
     * Broadcast round update to all connected clients
     */
    broadcastRoundUpdate(round) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const message = JSON.stringify({
                    type: 'roundUpdate',
                    data: {
                        roundId: round.id,
                        status: round.status,
                        crashPoint: round.crashPoint,
                        startTime: round.startTime,
                        endTime: round.endTime,
                        totalBets: round.totalBets,
                        totalAmount: round.totalAmount,
                        players: round.players.length,
                    }
                });
                yield redis_1.redis.publish('jetx:rounds', message);
            }
            catch (error) {
                console.error('Error broadcasting round update:', error);
            }
        });
    }
    /**
     * Broadcast player update
     */
    broadcastPlayerUpdate(roundId, action, player) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const message = JSON.stringify({
                    type: 'playerUpdate',
                    data: {
                        roundId,
                        action,
                        player: {
                            userId: player.userId,
                            betAmount: player.betAmount,
                            cashoutMultiplier: player.cashoutMultiplier,
                            payout: player.payout,
                            cashedOut: player.cashedOut,
                        }
                    }
                });
                yield redis_1.redis.publish('jetx:players', message);
            }
            catch (error) {
                console.error('Error broadcasting player update:', error);
            }
        });
    }
    /**
     * Broadcast players crashed event
     */
    broadcastPlayersCrashed(roundId, players) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const message = JSON.stringify({
                    type: 'playersCrashed',
                    data: {
                        roundId,
                        players: players.map(p => ({
                            userId: p.userId,
                            betAmount: p.betAmount,
                            payout: 0,
                        }))
                    }
                });
                yield redis_1.redis.publish('jetx:crashed', message);
            }
            catch (error) {
                console.error('Error broadcasting players crashed:', error);
            }
        });
    }
    /**
     * Broadcast round statistics
     */
    broadcastRoundStats(stats) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const message = JSON.stringify({
                    type: 'roundStats',
                    data: stats
                });
                yield redis_1.redis.publish('jetx:stats', message);
            }
            catch (error) {
                console.error('Error broadcasting round stats:', error);
            }
        });
    }
    /**
     * Save completed round to database
     */
    saveRoundToDatabase(round) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // This would typically save to a database like PostgreSQL
                // For now, we'll just log it
                console.log(`Saving round ${round.id} to database`);
                // Example database save (commented out until Prisma schema is ready)
                /*
                await prisma.jetXRound.create({
                  data: {
                    id: round.id,
                    crashPoint: round.crashPoint,
                    startTime: round.startTime,
                    endTime: round.endTime,
                    totalBets: round.totalBets,
                    totalAmount: round.totalAmount,
                    status: round.status,
                  }
                });
                */
            }
            catch (error) {
                console.error('Error saving round to database:', error);
            }
        });
    }
    /**
     * Clean up old rounds from Redis
     */
    cleanupOldRounds() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // This would clean up rounds older than 1 hour
                const oneHourAgo = Date.now() - (60 * 60 * 1000);
                // Implementation would depend on how rounds are stored in Redis
                // For now, we'll just log the cleanup
                console.log('Cleaning up old rounds...');
            }
            catch (error) {
                console.error('Error cleaning up old rounds:', error);
            }
        });
    }
    /**
     * Get cron job status
     */
    getStatus() {
        return {
            running: this.isRunning,
            currentRound: roundManager_1.roundManager.getCurrentRound(),
        };
    }
}
exports.JetXCronJob = JetXCronJob;
// Create and export the cron job instance
exports.jetxCronJob = new JetXCronJob();
