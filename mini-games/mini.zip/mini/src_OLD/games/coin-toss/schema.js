"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinTossHistoryRequestSchema = exports.CoinTossRequestSchema = void 0;
const zod_1 = require("zod");
exports.CoinTossRequestSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1, 'User ID is required'),
    betAmount: zod_1.z.number().positive('Bet amount must be positive').max(10000, 'Bet amount cannot exceed 10,000'),
    choice: zod_1.z.enum(['heads', 'tails'], { message: 'Choice must be either "heads" or "tails"' }),
    sessionToken: zod_1.z.string().min(1, 'Session token is required'),
});
exports.CoinTossHistoryRequestSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1, 'User ID is required'),
    sessionToken: zod_1.z.string().min(1, 'Session token is required'),
    limit: zod_1.z.number().max(100, { message: 'Limit cannot exceed 100' }).optional().default(50),
    offset: zod_1.z.number().min(0, { message: 'Offset cannot be negative' }).optional().default(0),
});
