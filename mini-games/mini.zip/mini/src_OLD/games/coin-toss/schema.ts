import { z } from 'zod';

export const CoinTossRequestSchema = z.object({
    userId: z.string().min(1, 'User ID is required'),
    betAmount: z.number().positive('Bet amount must be positive').max(10000, 'Bet amount cannot exceed 10,000'),
    choice: z.enum(['heads', 'tails'], { message: 'Choice must be either "heads" or "tails"' }),
    sessionToken: z.string().min(1, 'Session token is required'),
});

export const CoinTossHistoryRequestSchema = z.object({
    userId: z.string().min(1, 'User ID is required'),
    sessionToken: z.string().min(1, 'Session token is required'),
    limit: z.number().max(100, { message: 'Limit cannot exceed 100' }).optional().default(50),
    offset: z.number().min(0, { message: 'Offset cannot be negative' }).optional().default(0),
});

export type CoinTossRequestType = z.infer<typeof CoinTossRequestSchema>;
export type CoinTossHistoryRequestType = z.infer<typeof CoinTossHistoryRequestSchema>; 