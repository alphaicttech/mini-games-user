export interface CoinTossRequest {
    userId: string;
    betAmount: number;
    choice: 'heads' | 'tails';
    sessionToken: string;
}

export interface CoinTossResponse {
    success: boolean;
    gameId?: string;
    result?: 'heads' | 'tails';
    userChoice?: 'heads' | 'tails';
    betAmount?: number;
    payout?: number;
    newBalance?: number;
    error?: string;
}

export interface CoinTossGame {
    id: string;
    userId: string;
    betAmount: number;
    choice: 'heads' | 'tails';
    result: 'heads' | 'tails';
    payout: number;
    won: boolean;
    createdAt: Date;
}

export interface CoinTossHistory {
    games: CoinTossGame[];
    totalGames: number;
    totalWon: number;
    totalLost: number;
    winRate: number;
} 