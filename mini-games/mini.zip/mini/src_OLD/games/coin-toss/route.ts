import { Router } from 'express';
import { CoinTossController } from './controller';

const router = Router();

// Play a coin toss game
router.post('/play', CoinTossController.playGame);

// Get user's game history
router.get('/history', CoinTossController.getGameHistory);

// Get game statistics
router.get('/stats', CoinTossController.getGameStats);

export default router; 