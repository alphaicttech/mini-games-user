"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinTossService = void 0;
const game_1 = require("./game");
const http_1 = require("../../core/http");
const prisma_1 = require("../../core/prisma");
const redis_1 = require("../../core/redis");
class CoinTossService {
    /**
     * Play a coin toss game
     */
    static playGame(request) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Validate session
                const session = yield redis_1.redis.getGameSession(request.sessionToken);
                if (!session || session.userId !== request.userId) {
                    return {
                        success: false,
                        error: 'Invalid session'
                    };
                }
                // Get user balance
                const balanceResponse = yield this.getUserBalance(request.userId, request.sessionToken);
                if (!balanceResponse.success || !balanceResponse.balance) {
                    return {
                        success: false,
                        error: 'Failed to get user balance'
                    };
                }
                // Validate bet amount
                const validation = game_1.CoinTossGameLogic.validateBetAmount(request.betAmount, balanceResponse.balance);
                if (!validation.valid) {
                    return {
                        success: false,
                        error: validation.error
                    };
                }
                // Withdraw bet amount
                const withdrawResponse = yield http_1.httpClient.post('/withdraw', {
                    amount: request.betAmount,
                    currency: 'USD',
                });
                if (!withdrawResponse.data.success) {
                    return {
                        success: false,
                        error: 'Failed to process bet'
                    };
                }
                // Play the game
                const game = game_1.CoinTossGameLogic.playGame(request.userId, request.betAmount, request.choice);
                // Save game to database
                yield this.saveGame(game);
                // If user won, deposit winnings
                if (game.won) {
                    const depositResponse = yield http_1.httpClient.post('/deposit', {
                        amount: game.payout,
                        currency: 'USD',
                    });
                    if (!depositResponse.data.success) {
                        console.error('Failed to deposit winnings:', depositResponse.data.error);
                    }
                }
                // Get updated balance
                const newBalanceResponse = yield this.getUserBalance(request.userId, request.sessionToken);
                return {
                    success: true,
                    gameId: game.id,
                    result: game.result,
                    userChoice: game.choice,
                    betAmount: game.betAmount,
                    payout: game.payout,
                    newBalance: newBalanceResponse.balance
                };
            }
            catch (error) {
                console.error('Coin toss game error:', error);
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error occurred'
                };
            }
        });
    }
    /**
     * Get user's game history
     */
    static getGameHistory(userId_1, sessionToken_1) {
        return __awaiter(this, arguments, void 0, function* (userId, sessionToken, limit = 50, offset = 0) {
            try {
                // Validate session
                const session = yield redis_1.redis.getGameSession(sessionToken);
                if (!session || session.userId !== userId) {
                    throw new Error('Invalid session');
                }
                // Get games from database
                const games = yield prisma_1.prisma.coinTossGame.findMany({
                    where: { userId },
                    orderBy: { createdAt: 'desc' },
                    take: limit,
                    skip: offset,
                });
                // Convert to CoinTossGame format
                const coinTossGames = games.map((game) => ({
                    id: game.id,
                    userId: game.userId,
                    betAmount: game.betAmount,
                    choice: game.choice,
                    result: game.result,
                    payout: game.payout,
                    won: game.won,
                    createdAt: game.createdAt,
                }));
                // Calculate statistics
                const stats = game_1.CoinTossGameLogic.getGameStats(coinTossGames);
                return {
                    games: coinTossGames,
                    totalGames: stats.totalGames,
                    totalWon: stats.totalWon,
                    totalLost: stats.totalLost,
                    winRate: stats.winRate,
                };
            }
            catch (error) {
                console.error('Get game history error:', error);
                throw error;
            }
        });
    }
    /**
     * Get user balance
     */
    static getUserBalance(userId, sessionToken) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield prisma_1.prisma.user.findUnique({
                    where: { id: userId },
                    select: { balance: true }
                });
                if (!response) {
                    return { success: false, error: 'User not found' };
                }
                return { success: true, balance: response.balance };
            }
            catch (error) {
                return { success: false, error: 'Failed to get balance' };
            }
        });
    }
    /**
     * Save game to database
     */
    static saveGame(game) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield prisma_1.prisma.coinTossGame.create({
                    data: {
                        id: game.id,
                        userId: game.userId,
                        betAmount: game.betAmount,
                        choice: game.choice,
                        result: game.result,
                        payout: game.payout,
                        won: game.won,
                        createdAt: game.createdAt,
                    },
                });
            }
            catch (error) {
                console.error('Failed to save game:', error);
                throw error;
            }
        });
    }
}
exports.CoinTossService = CoinTossService;
