import { randomChoice } from '../../core/utils/rng';
import { CoinTossGame } from './model';

export class CoinTossGameLogic {
    private static readonly PAYOUT_MULTIPLIER = 1.9; // 5% house edge
    private static readonly POSSIBLE_OUTCOMES: ('heads' | 'tails')[] = ['heads', 'tails'];

    /**
     * Play a coin toss game
     */
    static playGame(userId: string, betAmount: number, choice: 'heads' | 'tails'): CoinTossGame {
        // Generate random result
        const result = randomChoice(this.POSSIBLE_OUTCOMES);

        // Check if user won
        const won = choice === result;

        // Calculate payout
        const payout = won ? betAmount * this.PAYOUT_MULTIPLIER : 0;

        // Generate game ID
        const gameId = `coin-toss-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        return {
            id: gameId,
            userId,
            betAmount,
            choice,
            result,
            payout,
            won,
            createdAt: new Date(),
        };
    }

    /**
     * Calculate expected value for a bet
     */
    static calculateExpectedValue(betAmount: number): number {
        const winProbability = 0.5; // 50% chance to win
        const winAmount = betAmount * this.PAYOUT_MULTIPLIER;
        const loseAmount = 0;

        return (winProbability * winAmount) + ((1 - winProbability) * loseAmount);
    }

    /**
     * Calculate house edge
     */
    static getHouseEdge(): number {
        return 1 - this.PAYOUT_MULTIPLIER; // 5%
    }

    /**
     * Validate bet amount
     */
    static validateBetAmount(amount: number, userBalance: number): { valid: boolean; error?: string } {
        if (amount <= 0) {
            return { valid: false, error: 'Bet amount must be positive' };
        }

        if (amount > userBalance) {
            return { valid: false, error: 'Insufficient balance' };
        }

        if (amount > 10000) {
            return { valid: false, error: 'Bet amount cannot exceed 10,000' };
        }

        return { valid: true };
    }

    /**
     * Get game statistics
     */
    static getGameStats(games: CoinTossGame[]): {
        totalGames: number;
        totalWon: number;
        totalLost: number;
        winRate: number;
        totalBet: number;
        totalPayout: number;
        profit: number;
    } {
        const totalGames = games.length;
        const totalWon = games.filter(game => game.won).length;
        const totalLost = totalGames - totalWon;
        const winRate = totalGames > 0 ? (totalWon / totalGames) * 100 : 0;

        const totalBet = games.reduce((sum, game) => sum + game.betAmount, 0);
        const totalPayout = games.reduce((sum, game) => sum + game.payout, 0);
        const profit = totalPayout - totalBet;

        return {
            totalGames,
            totalWon,
            totalLost,
            winRate,
            totalBet,
            totalPayout,
            profit,
        };
    }
} 