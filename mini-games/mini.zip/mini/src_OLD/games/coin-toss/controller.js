"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinTossController = void 0;
const service_1 = require("./service");
const schema_1 = require("./schema");
class CoinTossController {
    /**
     * Play a coin toss game
     */
    static playGame(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Validate request body
                const validationResult = schema_1.CoinTossRequestSchema.safeParse(req.body);
                if (!validationResult.success) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid request data',
                        details: validationResult.error.issues
                    });
                    return;
                }
                const request = validationResult.data;
                // Play the game
                const response = yield service_1.CoinTossService.playGame(request);
                if (response.success) {
                    res.status(200).json(response);
                }
                else {
                    res.status(400).json(response);
                }
            }
            catch (error) {
                console.error('Coin toss controller error:', error);
                res.status(500).json({
                    success: false,
                    error: 'Internal server error'
                });
            }
        });
    }
    /**
     * Get user's game history
     */
    static getGameHistory(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Validate request query
                const validationResult = schema_1.CoinTossHistoryRequestSchema.safeParse({
                    userId: req.query.userId,
                    sessionToken: req.query.sessionToken,
                    limit: req.query.limit ? parseInt(req.query.limit) : undefined,
                    offset: req.query.offset ? parseInt(req.query.offset) : undefined,
                });
                if (!validationResult.success) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid request parameters',
                        details: validationResult.error.issues
                    });
                    return;
                }
                const request = validationResult.data;
                // Get game history
                const history = yield service_1.CoinTossService.getGameHistory(request.userId, request.sessionToken, request.limit, request.offset);
                res.status(200).json({
                    success: true,
                    data: history
                });
            }
            catch (error) {
                console.error('Get game history controller error:', error);
                res.status(500).json({
                    success: false,
                    error: 'Internal server error'
                });
            }
        });
    }
    /**
     * Get game statistics
     */
    static getGameStats(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { userId, sessionToken } = req.query;
                if (!userId || !sessionToken) {
                    res.status(400).json({
                        success: false,
                        error: 'User ID and session token are required'
                    });
                    return;
                }
                // Get game history for stats calculation
                const history = yield service_1.CoinTossService.getGameHistory(userId, sessionToken, 1000, // Get more games for accurate stats
                0);
                res.status(200).json({
                    success: true,
                    data: {
                        totalGames: history.totalGames,
                        totalWon: history.totalWon,
                        totalLost: history.totalLost,
                        winRate: history.winRate,
                    }
                });
            }
            catch (error) {
                console.error('Get game stats controller error:', error);
                res.status(500).json({
                    success: false,
                    error: 'Internal server error'
                });
            }
        });
    }
}
exports.CoinTossController = CoinTossController;
