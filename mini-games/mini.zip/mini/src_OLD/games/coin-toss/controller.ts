import { Request, Response } from 'express';
import { CoinTossService } from './service';
import { CoinTossRequestSchema, CoinTossHistoryRequestSchema, CoinTossHistoryRequestType } from './schema';
import { CoinTossRequest } from './model';

export class CoinTossController {
    /**
     * Play a coin toss game
     */
    static async playGame(req: Request, res: Response): Promise<void> {
        try {
            // Validate request body
            const validationResult = CoinTossRequestSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    success: false,
                    error: 'Invalid request data',
                    details: validationResult.error.issues
                });
                return;
            }

            const request: CoinTossRequest = validationResult.data;

            // Play the game
            const response = await CoinTossService.playGame(request);

            if (response.success) {
                res.status(200).json(response);
            } else {
                res.status(400).json(response);
            }

        } catch (error) {
            console.error('Coin toss controller error:', error);
            res.status(500).json({
                success: false,
                error: 'Internal server error'
            });
        }
    }

    /**
     * Get user's game history
     */
    static async getGameHistory(req: Request, res: Response): Promise<void> {
        try {
            // Validate request query
            const validationResult = CoinTossHistoryRequestSchema.safeParse({
                userId: req.query.userId,
                sessionToken: req.query.sessionToken,
                limit: req.query.limit ? parseInt(req.query.limit as string) : undefined,
                offset: req.query.offset ? parseInt(req.query.offset as string) : undefined,
            });

            if (!validationResult.success) {
                res.status(400).json({
                    success: false,
                    error: 'Invalid request parameters',
                    details: validationResult.error.issues
                });
                return;
            }

            const request: CoinTossHistoryRequestType = validationResult.data;

            // Get game history
            const history = await CoinTossService.getGameHistory(
                request.userId,
                request.sessionToken,
                request.limit,
                request.offset
            );

            res.status(200).json({
                success: true,
                data: history
            });

        } catch (error) {
            console.error('Get game history controller error:', error);
            res.status(500).json({
                success: false,
                error: 'Internal server error'
            });
        }
    }

    /**
     * Get game statistics
     */
    static async getGameStats(req: Request, res: Response): Promise<void> {
        try {
            const { userId, sessionToken } = req.query;

            if (!userId || !sessionToken) {
                res.status(400).json({
                    success: false,
                    error: 'User ID and session token are required'
                });
                return;
            }

            // Get game history for stats calculation
            const history = await CoinTossService.getGameHistory(
                userId as string,
                sessionToken as string,
                1000, // Get more games for accurate stats
                0
            );

            res.status(200).json({
                success: true,
                data: {
                    totalGames: history.totalGames,
                    totalWon: history.totalWon,
                    totalLost: history.totalLost,
                    winRate: history.winRate,
                }
            });

        } catch (error) {
            console.error('Get game stats controller error:', error);
            res.status(500).json({
                success: false,
                error: 'Internal server error'
            });
        }
    }
} 