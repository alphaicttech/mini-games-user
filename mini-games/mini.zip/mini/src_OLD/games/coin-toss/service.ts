import { CoinTossGameLogic } from './game';
import { CoinTossRequest, CoinTossResponse, CoinTossGame, CoinTossHistory } from './model';
import { httpClient } from '../../core/http';
import { prisma } from '../../core/prisma';
import { redis } from '../../core/redis';

export class CoinTossService {
    /**
     * Play a coin toss game
     */
    static async playGame(request: CoinTossRequest): Promise<CoinTossResponse> {
        try {
            // Validate session
            const session = await redis.getGameSession(request.sessionToken);
            if (!session || session.userId !== request.userId) {
                return {
                    success: false,
                    error: 'Invalid session'
                };
            }

            // Get user balance
            const balanceResponse = await this.getUserBalance(request.userId, request.sessionToken);
            if (!balanceResponse.success || !balanceResponse.balance) {
                return {
                    success: false,
                    error: 'Failed to get user balance'
                };
            }

            // Validate bet amount
            const validation = CoinTossGameLogic.validateBetAmount(request.betAmount, balanceResponse.balance);
            if (!validation.valid) {
                return {
                    success: false,
                    error: validation.error
                };
            }

            // Withdraw bet amount
            const withdrawResponse = await httpClient.post('/withdraw', {
                amount: request.betAmount,
                currency: 'USD',
            });

            if (!withdrawResponse.data.success) {
                return {
                    success: false,
                    error: 'Failed to process bet'
                };
            }

            // Play the game
            const game = CoinTossGameLogic.playGame(request.userId, request.betAmount, request.choice);

            // Save game to database
            await this.saveGame(game);

            // If user won, deposit winnings
            if (game.won) {
                const depositResponse = await httpClient.post('/deposit', {
                    amount: game.payout,
                    currency: 'USD',
                });

                if (!depositResponse.data.success) {
                    console.error('Failed to deposit winnings:', depositResponse.data.error);
                }
            }

            // Get updated balance
            const newBalanceResponse = await this.getUserBalance(request.userId, request.sessionToken);

            return {
                success: true,
                gameId: game.id,
                result: game.result,
                userChoice: game.choice,
                betAmount: game.betAmount,
                payout: game.payout,
                newBalance: newBalanceResponse.balance
            };

        } catch (error) {
            console.error('Coin toss game error:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }

    /**
     * Get user's game history
     */
    static async getGameHistory(userId: string, sessionToken: string, limit: number = 50, offset: number = 0): Promise<CoinTossHistory> {
        try {
            // Validate session
            const session = await redis.getGameSession(sessionToken);
            if (!session || session.userId !== userId) {
                throw new Error('Invalid session');
            }

            // Get games from database
            const games = await prisma.coinTossGame.findMany({
                where: { userId },
                orderBy: { createdAt: 'desc' },
                take: limit,
                skip: offset,
            });

            // Convert to CoinTossGame format
            const coinTossGames: CoinTossGame[] = games.map((game: any) => ({
                id: game.id,
                userId: game.userId,
                betAmount: game.betAmount,
                choice: game.choice as 'heads' | 'tails',
                result: game.result as 'heads' | 'tails',
                payout: game.payout,
                won: game.won,
                createdAt: game.createdAt,
            }));

            // Calculate statistics
            const stats = CoinTossGameLogic.getGameStats(coinTossGames);

            return {
                games: coinTossGames,
                totalGames: stats.totalGames,
                totalWon: stats.totalWon,
                totalLost: stats.totalLost,
                winRate: stats.winRate,
            };

        } catch (error) {
            console.error('Get game history error:', error);
            throw error;
        }
    }

    /**
     * Get user balance
     */
    private static async getUserBalance(userId: string, sessionToken: string): Promise<{ success: boolean; balance?: number; error?: string }> {
        try {
            const response = await prisma.user.findUnique({
                where: { id: userId },
                select: { balance: true }
            });

            if (!response) {
                return { success: false, error: 'User not found' };
            }

            return { success: true, balance: response.balance };
        } catch (error) {
            return { success: false, error: 'Failed to get balance' };
        }
    }

    /**
     * Save game to database
     */
    private static async saveGame(game: CoinTossGame): Promise<void> {
        try {
            await prisma.coinTossGame.create({
                data: {
                    id: game.id,
                    userId: game.userId,
                    betAmount: game.betAmount,
                    choice: game.choice,
                    result: game.result,
                    payout: game.payout,
                    won: game.won,
                    createdAt: game.createdAt,
                },
            });
        } catch (error) {
            console.error('Failed to save game:', error);
            throw error;
        }
    }
} 