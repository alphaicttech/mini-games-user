"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinTossGameLogic = void 0;
const rng_1 = require("../../core/utils/rng");
class CoinTossGameLogic {
    /**
     * Play a coin toss game
     */
    static playGame(userId, betAmount, choice) {
        // Generate random result
        const result = (0, rng_1.randomChoice)(this.POSSIBLE_OUTCOMES);
        // Check if user won
        const won = choice === result;
        // Calculate payout
        const payout = won ? betAmount * this.PAYOUT_MULTIPLIER : 0;
        // Generate game ID
        const gameId = `coin-toss-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        return {
            id: gameId,
            userId,
            betAmount,
            choice,
            result,
            payout,
            won,
            createdAt: new Date(),
        };
    }
    /**
     * Calculate expected value for a bet
     */
    static calculateExpectedValue(betAmount) {
        const winProbability = 0.5; // 50% chance to win
        const winAmount = betAmount * this.PAYOUT_MULTIPLIER;
        const loseAmount = 0;
        return (winProbability * winAmount) + ((1 - winProbability) * loseAmount);
    }
    /**
     * Calculate house edge
     */
    static getHouseEdge() {
        return 1 - this.PAYOUT_MULTIPLIER; // 5%
    }
    /**
     * Validate bet amount
     */
    static validateBetAmount(amount, userBalance) {
        if (amount <= 0) {
            return { valid: false, error: 'Bet amount must be positive' };
        }
        if (amount > userBalance) {
            return { valid: false, error: 'Insufficient balance' };
        }
        if (amount > 10000) {
            return { valid: false, error: 'Bet amount cannot exceed 10,000' };
        }
        return { valid: true };
    }
    /**
     * Get game statistics
     */
    static getGameStats(games) {
        const totalGames = games.length;
        const totalWon = games.filter(game => game.won).length;
        const totalLost = totalGames - totalWon;
        const winRate = totalGames > 0 ? (totalWon / totalGames) * 100 : 0;
        const totalBet = games.reduce((sum, game) => sum + game.betAmount, 0);
        const totalPayout = games.reduce((sum, game) => sum + game.payout, 0);
        const profit = totalPayout - totalBet;
        return {
            totalGames,
            totalWon,
            totalLost,
            winRate,
            totalBet,
            totalPayout,
            profit,
        };
    }
}
exports.CoinTossGameLogic = CoinTossGameLogic;
CoinTossGameLogic.PAYOUT_MULTIPLIER = 1.9; // 5% house edge
CoinTossGameLogic.POSSIBLE_OUTCOMES = ['heads', 'tails'];
