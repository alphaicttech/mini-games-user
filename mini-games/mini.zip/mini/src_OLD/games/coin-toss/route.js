"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = require("./controller");
const router = (0, express_1.Router)();
// Play a coin toss game
router.post('/play', controller_1.CoinTossController.playGame);
// Get user's game history
router.get('/history', controller_1.CoinTossController.getGameHistory);
// Get game statistics
router.get('/stats', controller_1.CoinTossController.getGameStats);
exports.default = router;
