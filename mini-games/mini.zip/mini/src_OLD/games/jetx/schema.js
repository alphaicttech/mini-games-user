"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JetXHistoryRequestSchema = exports.JetXCashoutRequestSchema = exports.JetXJoinRequestSchema = void 0;
const zod_1 = require("zod");
exports.JetXJoinRequestSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1, 'User ID is required'),
    betAmount: zod_1.z.number().positive('Bet amount must be positive').max(10000, 'Bet amount cannot exceed 10,000'),
    sessionToken: zod_1.z.string().min(1, 'Session token is required'),
});
exports.JetXCashoutRequestSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1, 'User ID is required'),
    betId: zod_1.z.string().min(1, 'Bet ID is required'),
    sessionToken: zod_1.z.string().min(1, 'Session token is required'),
});
exports.JetXHistoryRequestSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1, 'User ID is required'),
    sessionToken: zod_1.z.string().min(1, 'Session token is required'),
    limit: zod_1.z.number().max(100, { message: 'Limit cannot exceed 100' }).optional().default(20),
    offset: zod_1.z.number().min(0, { message: 'Offset cannot be negative' }).optional().default(0),
});
