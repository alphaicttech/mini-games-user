import { generateCrashPoint } from '../../core/utils/rng';
import { JetXRound, JetXPlayer } from './model';
import { redis } from '../../core/redis';
import { EventEmitter } from 'events';

export interface RoundManagerConfig {
    roundDuration: number; // in seconds
    waitingTime: number; // in seconds
    maxRounds: number;
}

export class JetXRoundManager extends EventEmitter {
    private currentRound: JetXRound | null = null;
    private roundTimer: NodeJS.Timeout | null = null;
    private waitingTimer: NodeJS.Timeout | null = null;
    private config: RoundManagerConfig;

    constructor(config: RoundManagerConfig) {
        super();
        this.config = config;
    }

    /**
     * Start the round manager
     */
    start(): void {
        console.log('JetX Round Manager started');
        this.startNewRound();
    }

    /**
     * Stop the round manager
     */
    stop(): void {
        if (this.roundTimer) {
            clearTimeout(this.roundTimer);
            this.roundTimer = null;
        }
        if (this.waitingTimer) {
            clearTimeout(this.waitingTimer);
            this.waitingTimer = null;
        }
        console.log('JetX Round Manager stopped');
    }

    /**
     * Start a new round
     */
    private startNewRound(): void {
        const roundId = `jetx-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const crashPoint = generateCrashPoint();

        this.currentRound = {
            id: roundId,
            status: 'waiting',
            crashPoint: crashPoint.crashPoint,
            startTime: new Date(),
            duration: this.config.roundDuration,
            totalBets: 0,
            totalAmount: 0,
            players: [],
        };

        // Save round to Redis
        this.saveRound();

        // Emit round started event
        this.emit('roundStarted', this.currentRound);

        // Start waiting timer
        this.waitingTimer = setTimeout(() => {
            this.startActivePhase();
        }, this.config.waitingTime * 1000);
    }

    /**
     * Start the active phase of the round
     */
    private startActivePhase(): void {
        if (!this.currentRound) return;

        this.currentRound.status = 'active';
        this.currentRound.startTime = new Date();

        // Save updated round
        this.saveRound();

        // Emit active phase started
        this.emit('activePhaseStarted', this.currentRound);

        // Start round timer
        this.roundTimer = setTimeout(() => {
            this.crashRound();
        }, this.config.roundDuration * 1000);
    }

    /**
     * Crash the current round
     */
    private crashRound(): void {
        if (!this.currentRound) return;

        this.currentRound.status = 'crashed';
        this.currentRound.endTime = new Date();

        // Save final round state
        this.saveRound();

        // Emit round crashed event
        this.emit('roundCrashed', this.currentRound);

        // Process payouts for players who didn't cash out
        this.processCrashedPayouts();

        // Start next round after a short delay
        setTimeout(() => {
            this.startNewRound();
        }, 2000);
    }

    /**
     * Join a player to the current round
     */
    joinPlayer(userId: string, betAmount: number): { success: boolean; betId?: string; error?: string } {
        if (!this.currentRound) {
            return { success: false, error: 'No active round' };
        }

        if (this.currentRound.status !== 'waiting') {
            return { success: false, error: 'Round is not in waiting phase' };
        }

        // Check if player already joined
        const existingPlayer = this.currentRound.players.find(p => p.userId === userId);
        if (existingPlayer) {
            return { success: false, error: 'Player already joined this round' };
        }

        const betId = `bet-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        const player: JetXPlayer = {
            userId,
            betId,
            betAmount,
            cashedOut: false,
            joinedAt: new Date(),
        };

        this.currentRound.players.push(player);
        this.currentRound.totalBets++;
        this.currentRound.totalAmount += betAmount;

        // Save updated round
        this.saveRound();

        // Emit player joined event
        this.emit('playerJoined', { roundId: this.currentRound.id, player });

        return { success: true, betId };
    }

    /**
     * Cash out a player
     */
    cashoutPlayer(userId: string, betId: string): { success: boolean; payout?: number; multiplier?: number; error?: string } {
        if (!this.currentRound) {
            return { success: false, error: 'No active round' };
        }

        if (this.currentRound.status !== 'active') {
            return { success: false, error: 'Round is not active' };
        }

        const player = this.currentRound.players.find(p => p.userId === userId && p.betId === betId);
        if (!player) {
            return { success: false, error: 'Player not found' };
        }

        if (player.cashedOut) {
            return { success: false, error: 'Player already cashed out' };
        }

        // Calculate current multiplier based on elapsed time
        const elapsedTime = (Date.now() - this.currentRound.startTime.getTime()) / 1000;
        const multiplier = Math.max(1.0, elapsedTime / 10); // 1x per 10 seconds

        // Calculate payout
        const payout = player.betAmount * multiplier;

        // Update player
        player.cashoutMultiplier = multiplier;
        player.payout = payout;
        player.cashedOut = true;
        player.cashedOutAt = new Date();

        // Save updated round
        this.saveRound();

        // Emit player cashed out event
        this.emit('playerCashedOut', { roundId: this.currentRound.id, player });

        return { success: true, payout, multiplier };
    }

    /**
     * Get current round
     */
    getCurrentRound(): JetXRound | null {
        return this.currentRound;
    }

    /**
     * Get round by ID
     */
    async getRound(roundId: string): Promise<JetXRound | null> {
        return redis.getGameRound(roundId);
    }

    /**
     * Save round to Redis
     */
    private async saveRound(): Promise<void> {
        if (this.currentRound) {
            await redis.setGameRound(this.currentRound.id, this.currentRound, 300);
        }
    }

    /**
     * Process payouts for players who didn't cash out when round crashed
     */
    private processCrashedPayouts(): void {
        if (!this.currentRound) return;

        const crashedPlayers = this.currentRound.players.filter(p => !p.cashedOut);

        crashedPlayers.forEach(player => {
            // Players who didn't cash out lose their bet
            player.payout = 0;
            player.cashoutMultiplier = 0;
        });

        // Emit crashed players event
        this.emit('playersCrashed', { roundId: this.currentRound.id, players: crashedPlayers });
    }

    /**
     * Get round statistics
     */
    getRoundStats(): {
        totalPlayers: number;
        totalBets: number;
        totalAmount: number;
        cashedOutPlayers: number;
        crashedPlayers: number;
    } {
        if (!this.currentRound) {
            return {
                totalPlayers: 0,
                totalBets: 0,
                totalAmount: 0,
                cashedOutPlayers: 0,
                crashedPlayers: 0,
            };
        }

        const cashedOutPlayers = this.currentRound.players.filter(p => p.cashedOut).length;
        const crashedPlayers = this.currentRound.players.filter(p => !p.cashedOut).length;

        return {
            totalPlayers: this.currentRound.players.length,
            totalBets: this.currentRound.totalBets,
            totalAmount: this.currentRound.totalAmount,
            cashedOutPlayers,
            crashedPlayers,
        };
    }
}

// Create default round manager instance
export const roundManager = new JetXRoundManager({
    roundDuration: 30, // 30 seconds
    waitingTime: 10,   // 10 seconds waiting
    maxRounds: 100,
}); 