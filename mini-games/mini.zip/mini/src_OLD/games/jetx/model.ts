export interface JetXJoinRequest {
    userId: string;
    betAmount: number;
    sessionToken: string;
}

export interface JetXJoinResponse {
    success: boolean;
    roundId?: string;
    betId?: string;
    error?: string;
}

export interface JetXCashoutRequest {
    userId: string;
    betId: string;
    sessionToken: string;
}

export interface JetXCashoutResponse {
    success: boolean;
    payout?: number;
    multiplier?: number;
    newBalance?: number;
    error?: string;
}

export interface JetXRound {
    id: string;
    status: 'waiting' | 'active' | 'crashed';
    crashPoint: number;
    startTime: Date;
    endTime?: Date;
    duration: number; // in seconds
    totalBets: number;
    totalAmount: number;
    players: JetXPlayer[];
}

export interface JetXPlayer {
    userId: string;
    betId: string;
    betAmount: number;
    cashoutMultiplier?: number;
    payout?: number;
    cashedOut: boolean;
    joinedAt: Date;
    cashedOutAt?: Date;
}

export interface JetXBet {
    id: string;
    userId: string;
    roundId: string;
    amount: number;
    cashoutMultiplier?: number;
    payout?: number;
    cashedOut: boolean;
    createdAt: Date;
    cashedOutAt?: Date;
}

export interface JetXRoundHistory {
    rounds: JetXRound[];
    totalRounds: number;
    totalBets: number;
    totalPayout: number;
} 