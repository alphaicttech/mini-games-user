import { z } from 'zod';

export const JetXJoinRequestSchema = z.object({
    userId: z.string().min(1, 'User ID is required'),
    betAmount: z.number().positive('Bet amount must be positive').max(10000, 'Bet amount cannot exceed 10,000'),
    sessionToken: z.string().min(1, 'Session token is required'),
});

export const JetXCashoutRequestSchema = z.object({
    userId: z.string().min(1, 'User ID is required'),
    betId: z.string().min(1, 'Bet ID is required'),
    sessionToken: z.string().min(1, 'Session token is required'),
});

export const JetXHistoryRequestSchema = z.object({
    userId: z.string().min(1, 'User ID is required'),
    sessionToken: z.string().min(1, 'Session token is required'),
    limit: z.number().max(100, { message: 'Limit cannot exceed 100' }).optional().default(20),
    offset: z.number().min(0, { message: 'Offset cannot be negative' }).optional().default(0),
});

export type JetXJoinRequestType = z.infer<typeof JetXJoinRequestSchema>;
export type JetXCashoutRequestType = z.infer<typeof JetXCashoutRequestSchema>;
export type JetXHistoryRequestType = z.infer<typeof JetXHistoryRequestSchema>; 