import { Router } from 'express';
import coinTossRoutes from '../games/coin-toss/route';
import jetxRoutes from '../games/jetx/route';

const router = Router();

// Health check endpoint
router.get('/health', (req, res) => {
    res.status(200).json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
    });
});

// Game routes
router.use('/coin-toss', coinTossRoutes);
router.use('/jetx', jetxRoutes);

// 404 handler
router.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: 'Route not found',
        path: req.originalUrl,
    });
});

export default router; 