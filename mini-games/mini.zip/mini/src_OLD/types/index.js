"use strict";
// Global shared types for the gaming platform
Object.defineProperty(exports, "__esModule", { value: true });
