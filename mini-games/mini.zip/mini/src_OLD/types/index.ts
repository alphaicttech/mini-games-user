// Global shared types for the gaming platform

export interface User {
    id: string;
    username: string;
    email: string;
    balance: number;
    createdAt: Date;
    updatedAt: Date;
}

export interface GameSession {
    id: string;
    userId: string;
    token: string;
    expiresAt: Date;
    createdAt: Date;
}

export interface Transaction {
    id: string;
    userId: string;
    type: 'deposit' | 'withdraw' | 'bet' | 'payout' | 'bonus';
    amount: number;
    currency: string;
    status: 'pending' | 'completed' | 'failed' | 'cancelled';
    gameId?: string;
    roundId?: string;
    metadata?: Record<string, any>;
    createdAt: Date;
    updatedAt: Date;
}

export interface GameResult {
    success: boolean;
    gameId: string;
    userId: string;
    betAmount: number;
    payout: number;
    multiplier?: number;
    result: any;
    createdAt: Date;
}

export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    error?: string;
    message?: string;
    timestamp: string;
}

export interface PaginatedResponse<T> {
    data: T[];
    pagination: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}

export interface GameConfig {
    name: string;
    enabled: boolean;
    minBet: number;
    maxBet: number;
    houseEdge: number;
    description?: string;
}

export interface ServerStats {
    uptime: number;
    memoryUsage: NodeJS.MemoryUsage;
    cpuUsage: NodeJS.CpuUsage;
    activeConnections: number;
    totalGames: number;
    totalTransactions: number;
}

export interface WebSocketMessage {
    type: string;
    data: any;
    timestamp: string;
    userId?: string;
}

export interface ErrorResponse {
    success: false;
    error: string;
    code?: string;
    details?: any;
}

export interface SuccessResponse<T = any> {
    success: true;
    data: T;
    message?: string;
}

// Game-specific types
export type GameType = 'coin-toss' | 'jetx' | 'dice' | 'roulette';

export interface GameRequest {
    userId: string;
    sessionToken: string;
    gameType: GameType;
    [key: string]: any;
}

export interface GameResponse {
    success: boolean;
    gameId?: string;
    result?: any;
    payout?: number;
    newBalance?: number;
    error?: string;
}

// Authentication types
export interface AuthRequest {
    username: string;
    password: string;
}

export interface AuthResponse {
    success: boolean;
    token?: string;
    user?: User;
    error?: string;
}

// Rate limiting types
export interface RateLimitConfig {
    windowMs: number;
    maxRequests: number;
    message?: string;
}

export interface RateLimitInfo {
    limit: number;
    remaining: number;
    reset: Date;
}

// Logging types
export interface LogEntry {
    level: 'error' | 'warn' | 'info' | 'debug';
    message: string;
    timestamp: string;
    userId?: string;
    gameId?: string;
    metadata?: Record<string, any>;
}

// Event types
export interface GameEvent {
    type: string;
    gameId: string;
    userId: string;
    data: any;
    timestamp: Date;
}

// Utility types
export type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>; 