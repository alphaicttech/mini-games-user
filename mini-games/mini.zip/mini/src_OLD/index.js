"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const env_1 = require("./config/env");
const routes_1 = __importDefault(require("./routes"));
const jetx_cron_1 = require("./jobs/jetx-cron");
const redis_1 = require("./core/redis");
const prisma_1 = require("./core/prisma");
const app = (0, express_1.default)();
// Security middleware
app.use((0, helmet_1.default)());
app.use((0, cors_1.default)({
    origin: env_1.env.CORS_ORIGIN,
    credentials: true,
}));
// Rate limiting
const limiter = (0, express_rate_limit_1.default)({
    windowMs: env_1.env.RATE_LIMIT_WINDOW_MS,
    max: env_1.env.RATE_LIMIT_MAX_REQUESTS,
    message: {
        success: false,
        error: 'Too many requests, please try again later.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});
app.use(limiter);
// Body parsing middleware
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
// Request logging middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});
// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: env_1.env.NODE_ENV,
    });
});
// API routes
app.use('/api', routes_1.default);
// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: 'Route not found',
        path: req.originalUrl,
    });
});
// Global error handler
app.use((error, req, res, next) => {
    console.error('Global error handler:', error);
    res.status(error.status || 500).json(Object.assign({ success: false, error: env_1.env.NODE_ENV === 'production' ? 'Internal server error' : error.message }, (env_1.env.NODE_ENV === 'development' && { stack: error.stack })));
});
// Graceful shutdown
process.on('SIGTERM', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('SIGTERM received, shutting down gracefully...');
    yield gracefulShutdown();
}));
process.on('SIGINT', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('SIGINT received, shutting down gracefully...');
    yield gracefulShutdown();
}));
function gracefulShutdown() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Stop the JetX cron job
            jetx_cron_1.jetxCronJob.stop();
            // Close Redis connections
            yield redis_1.redis.disconnect();
            // Close Prisma connection
            yield prisma_1.prisma.$disconnect();
            console.log('Graceful shutdown completed');
            process.exit(0);
        }
        catch (error) {
            console.error('Error during graceful shutdown:', error);
            process.exit(1);
        }
    });
}
// Start the server
function startServer() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Test database connection
            yield prisma_1.prisma.$connect();
            console.log('Database connected successfully');
            // Test Redis connection
            yield redis_1.redis.set('health-check', 'ok');
            const healthCheck = yield redis_1.redis.get('health-check');
            if (healthCheck === 'ok') {
                console.log('Redis connected successfully');
            }
            // Start JetX cron job
            jetx_cron_1.jetxCronJob.start();
            // Start the server
            const port = env_1.env.PORT;
            app.listen(port, () => {
                console.log(`🚀 Server running on port ${port}`);
                console.log(`📊 Environment: ${env_1.env.NODE_ENV}`);
                console.log(`🔗 Health check: http://localhost:${port}/health`);
                console.log(`🎮 API base: http://localhost:${port}/api`);
            });
        }
        catch (error) {
            console.error('Failed to start server:', error);
            process.exit(1);
        }
    });
}
// Start the server if this file is run directly
if (require.main === module) {
    startServer();
}
exports.default = app;
