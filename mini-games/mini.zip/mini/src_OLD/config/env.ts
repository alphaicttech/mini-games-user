import { z } from 'zod';

const envSchema = z.object({
    NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
    PORT: z.string().transform(Number).default(3000),

    // Database
    DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),

    // Redis
    REDIS_HOST: z.string().default('localhost'),
    REDIS_PORT: z.string().transform(Number).default(6379),
    REDIS_PASSWORD: z.string().optional(),
    REDIS_DB: z.string().transform(Number).default(0),

    // API Configuration
    API_BASE_URL: z.string().default('https://api.example.com'),
    API_KEY: z.string().optional(),
    API_SECRET: z.string().optional(),

    // JWT
    JWT_SECRET: z.string().min(1, 'JWT_SECRET is required'),
    JWT_EXPIRES_IN: z.string().default('24h'),

    // Game Configuration
    COIN_TOSS_MAX_BET: z.string().transform(Number).default(10000),
    JETX_MAX_BET: z.string().transform(Number).default(10000),
    JETX_ROUND_DURATION: z.string().transform(Number).default(30),
    JETX_WAITING_TIME: z.string().transform(Number).default(10),

    // Logging
    LOG_LEVEL: z.enum(['error', 'warn', 'info', 'debug']).default('info'),

    // CORS
    CORS_ORIGIN: z.string().default('*'),

    // Rate Limiting
    RATE_LIMIT_WINDOW_MS: z.string().transform(Number).default(900000), // 15 minutes
    RATE_LIMIT_MAX_REQUESTS: z.string().transform(Number).default(100),
});

export type EnvConfig = z.infer<typeof envSchema>;

export function validateEnv(): EnvConfig {
    try {
        return envSchema.parse(process.env);
    } catch (error) {
        if (error instanceof z.ZodError) {
            console.error('Environment validation failed:');
            (error as z.ZodError).issues.forEach((err: z.ZodIssue) => {
                console.error(`  ${err.path.join('.')}: ${err.message}`);
            });
        }
        process.exit(1);
    }
}

export const env = validateEnv(); 