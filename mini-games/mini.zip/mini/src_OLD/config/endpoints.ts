export const API_ENDPOINTS = {
    // Session management
    activateSession: '/session/activate',

    // Financial operations
    deposit: '/transaction/deposit',
    withdraw: '/transaction/withdraw',
    rollback: '/transaction/rollback',
    getBalance: '/account/balance',

    // Gifts and bonuses
    gifts: '/gifts/claim',

    // User management
    userProfile: '/user/profile',
    userHistory: '/user/history',

    // System endpoints
    health: '/health',
    status: '/status',
} as const;

export type EndpointKey = keyof typeof API_ENDPOINTS;

export function getEndpoint(key: EndpointKey): string {
    return API_ENDPOINTS[key];
}

export function getFullUrl(key: EndpointKey, baseUrl?: string): string {
    const base = baseUrl || process.env.API_BASE_URL || 'https://api.example.com';
    return `${base}${API_ENDPOINTS[key]}`;
}