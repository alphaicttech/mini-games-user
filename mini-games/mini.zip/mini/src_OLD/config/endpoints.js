"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.API_ENDPOINTS = void 0;
exports.getEndpoint = getEndpoint;
exports.getFullUrl = getFullUrl;
exports.API_ENDPOINTS = {
    // Session management
    activateSession: '/session/activate',
    // Financial operations
    deposit: '/transaction/deposit',
    withdraw: '/transaction/withdraw',
    rollback: '/transaction/rollback',
    getBalance: '/account/balance',
    // Gifts and bonuses
    gifts: '/gifts/claim',
    // User management
    userProfile: '/user/profile',
    userHistory: '/user/history',
    // System endpoints
    health: '/health',
    status: '/status',
};
function getEndpoint(key) {
    return exports.API_ENDPOINTS[key];
}
function getFullUrl(key, baseUrl) {
    const base = baseUrl || process.env.API_BASE_URL || 'https://api.example.com';
    return `${base}${exports.API_ENDPOINTS[key]}`;
}
