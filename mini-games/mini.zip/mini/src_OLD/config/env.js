"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = void 0;
exports.validateEnv = validateEnv;
const zod_1 = require("zod");
const envSchema = zod_1.z.object({
    NODE_ENV: zod_1.z.enum(['development', 'production', 'test']).default('development'),
    PORT: zod_1.z.string().transform(Number).default(3000),
    // Database
    DATABASE_URL: zod_1.z.string().min(1, 'DATABASE_URL is required'),
    // Redis
    REDIS_HOST: zod_1.z.string().default('localhost'),
    REDIS_PORT: zod_1.z.string().transform(Number).default(6379),
    REDIS_PASSWORD: zod_1.z.string().optional(),
    REDIS_DB: zod_1.z.string().transform(Number).default(0),
    // API Configuration
    API_BASE_URL: zod_1.z.string().default('https://api.example.com'),
    API_KEY: zod_1.z.string().optional(),
    API_SECRET: zod_1.z.string().optional(),
    // JWT
    JWT_SECRET: zod_1.z.string().min(1, 'JWT_SECRET is required'),
    JWT_EXPIRES_IN: zod_1.z.string().default('24h'),
    // Game Configuration
    COIN_TOSS_MAX_BET: zod_1.z.string().transform(Number).default(10000),
    JETX_MAX_BET: zod_1.z.string().transform(Number).default(10000),
    JETX_ROUND_DURATION: zod_1.z.string().transform(Number).default(30),
    JETX_WAITING_TIME: zod_1.z.string().transform(Number).default(10),
    // Logging
    LOG_LEVEL: zod_1.z.enum(['error', 'warn', 'info', 'debug']).default('info'),
    // CORS
    CORS_ORIGIN: zod_1.z.string().default('*'),
    // Rate Limiting
    RATE_LIMIT_WINDOW_MS: zod_1.z.string().transform(Number).default(900000), // 15 minutes
    RATE_LIMIT_MAX_REQUESTS: zod_1.z.string().transform(Number).default(100),
});
function validateEnv() {
    try {
        return envSchema.parse(process.env);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            console.error('Environment validation failed:');
            error.issues.forEach((err) => {
                console.error(`  ${err.path.join('.')}: ${err.message}`);
            });
        }
        process.exit(1);
    }
}
exports.env = validateEnv();
